extends SceneTree
const Flight := preload("res://sim/flight_session.gd")
const Log := preload("res://sim/flight_log.gd")
const Weather := preload("res://physics/wind_config.gd")
const Catalog := preload("res://app_state/aircraft_catalog.gd")
var failed := false
func _initialize() -> void:
	for spec: Array in [["stik-steady", "jensen-das-ugly-stik-60", false],
		["stik-spatial", "jensen-das-ugly-stik-60", true],
		["timber-spatial", "turbo-lumber-evolution", true]]:
		var flight := Flight.new()
		flight.input_enabled = false
		flight.crash_auto_restart = false
		flight.setup(Catalog.entry(spec[1]).data)
		var config: Dictionary = Weather.spatial_defaults() if spec[2] else Weather.upgrade_column(Weather.defaults())
		if spec[2]:
			config.spatial_wind.identity.seed_u32 = 20261025
			config.spatial_wind.identity.world_epoch_id_u32 = 451
			config.spatial_wind.profile.reference_speed_mps = 3.0
			config.spatial_wind.profile.reference_from_deg = 270.0
			config.spatial_wind.turbulence.rms_mps = 0.3
			config.spatial_wind.turbulence.mode_count = 8
		else:
			config.speed_mps = 3.0
			config.from_deg = 270.0
		if not flight.is_flyable() or not flight.setup_weather(config):
			printerr("baseline setup failed ", spec)
			failed = true
			flight.free()
			continue
		flight.reset()
		var logger := Log.new(flight)
		var path := "C:/DEVELOPMENT/OpenRCsimulator/tmp/downwash-o4/" + str(spec[0]) + ".orfl"
		if logger.start(path) != OK:
			printerr(logger.failure)
			failed = true
		else:
			logger.mark("baseline controls")
			for tick: int in 240:
				flight.sim.inputs[0] = 0.05 if tick < 120 else -0.05
				flight.sim.inputs[1] = 0.02 if tick < 180 else 0.0
				if flight.flaps_available():
					flight.sim.inputs[flight.flap_input_index()] = 0.5 if tick < 120 else 0.0
				if tick == 120: logger.mark("reverse roll / retract flap")
				flight.sim.step()
				if not flight.sim.fault_reason.is_empty():
					printerr(flight.sim.fault_reason)
					failed = true
					break
			if logger.stop() != OK: failed = true
			print(spec[0], " baseline ticks=", flight.sim.tick)
		logger = null
		flight.free()
	print("DOWNWASH_BASELINE_COMPLETE=", not failed)
	quit(1 if failed else 0)
