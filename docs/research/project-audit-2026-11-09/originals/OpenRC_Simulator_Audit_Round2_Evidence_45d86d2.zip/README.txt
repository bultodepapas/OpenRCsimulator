OPENRC SIMULATOR — ROUND 2 REPRODUCIBILITY EVIDENCE

Repository: https://github.com/bultodepapas/OpenRCsimulator
Pinned commit: 45d86d250f6e38a3d9b60d30c01bdc2396571efe
Recorded engine: 4.8.beta2.official.cafc17a19 (official Linux x86_64)
Original capture date: 2026-11-09 UTC

Reproduced OpenRCsimulator production code is Copyright (c) 2026 OpenRCsimulator
contributors and is provided under the MIT License. The pinned root LICENSE is
included verbatim at production/LICENSE. The pinned root has no NOTICE or COPYING.

This is a selected verification package. It is not a patched release, full game,
complete checkout, flight-validation report, or hardware-performance qualification.
Original final probes and original checked report/log pairs are retained unchanged.
Historical paths remain in the original reports to preserve their identity.
No engine, large binary game assets, Godot cache, or whole copied application is
redistributed. The two diagnostic variants contain only the changed source file
and its one-line patch. They are experimental controls, not installed fixes.

EVIDENCE SETS

F06. lake_bank_normal_sign
   bank-integrated-final-ydad69ma and bank-corrected-3v5b6pmk.
   A controlled bank approach using the stock aircraft, actual lake geometry,
   collision routines, and one accepted Simulation tick. The sign-only variant
   changes only app/sim/lake_collision.gd: the two horizontal components of the
   positive-down surface normal. The diagnostic proves that the tested false
   crash disappears for that tick. It does not establish a completed surviving
   landing, subsequent trajectory, or physical calibration of impact thresholds.

F07. lake_sweep_tolerance_override
   tolerance-stopped-original-final-9d2bhdlp,
   tolerance-stopped-sign-final-j6m_r9s4,
   tolerance-stopped-override-final-_3r338fi.
   These three final witnesses use the same stopped-motor X99 starting state.
   Original and sign-only cases retain a lake-bank crash below the aircraft's
   configured 12.5 J/kg threshold. The threshold-only diagnostic changes only
   the GLOBAL fallback constant in app/physics/hull_contact.gd from 2.5 to 12.5.
   It isolates the decision path; globally raising that constant is NOT the
   proposed repair. Correct production behavior needs per-aircraft tolerance
   propagation. Absence of a lake event/hull terminal/gear collapse/prop strike
   in the override witness is limited to its one accepted tick and subsequent
   immediate continuation guard. This is not a full landing or durability test.

F08. statistics_quarantine_idempotence
   quarantine-reopen-a99buh5l.
   Uses three byte-identical production statistics scripts in an isolated project.
   The first no-write open/close/reopen sequence is a Store API test. Production
   service startup can heal a slot by committing while recovering active records,
   so this sequence alone should not be described as every ordinary app restart.
   The second sequence explicitly includes successful healing, a normal reopen,
   and another successful commit before a later same-slot corruption. That case
   survives the service-autohealing objection. Both deliberate corruption events
   use IDENTICAL damaged payload bytes; different damaged contents were not tested.
   All stores close normally. The failing stores still own their writer locks:
   this is separate from the round-1 stale-PID issue. Existing valid history is
   retained while future commits and deletion are refused. Repairing the quarantine
   policy must also integrate with the existing deletion-fence purge; extra retained
   copies must not evade deletion or restore removed history.

SECONDARY OBSERVATION — NOT COUNTED AS A MAJOR FINDING

round2-lifecycle-9kw93ph1, lifecycle_probe.gd, and lifecycle_probe.json retain the
clean lifecycle/cache observation. The probe manually advances disabled-glare
callbacks; 69 callbacks are not a rendered frame-time measurement. Its packed
payload byte count is not a measured allocation-copy cost, process-memory leak,
GPU VRAM reading, or whole-game impact estimate. The 100-build foliage witness
observes one cache entry and one source shadow ID; it does not prove a per-build
cache leak. Packed-array alias behavior is an observation, not by itself a defect.
No major performance claim is inferred from this secondary evidence.

CONTENTS AND INTEGRITY

* audit_round2/: selected original receipts, original probes, secondary sidecar,
  and the isolated statistics project. Exploratory/superseded receipts are omitted.
* production/: selected pinned source/test/data files for source review; not a
  runnable application. Production snapshots use exact Git-blob bytes. Git checkout
  line-ending conversions can change source-file hashes without changing JSON
  values; use the blob manifest for repository identity.
* variants/: one changed source file and diagnostic.patch for each intervention.
* production_source_manifest.json: commit, Git blob object ID, SHA256, byte count,
  and packaged path for each original production source copy.
* diagnostic_variant_manifest.json: exact before/after single-line substitution,
  base/candidate SHA256, paths, and diagnostic limitations.
* original_artifact_manifest.json: SHA256 and original location for retained audit
  probes/reports/logs/sidecars. Original isolated scripts additionally appear in
  the pinned-source manifest.
* receipt_hash_verification.json: original report/log byte-count and SHA256 checks.
* audit_commands.json: exact captured engine commands, working directory, required
  markers, timeout, variant selection, and known original environment override.
* evidence_index.json: stable descriptive evidence keys and secondary qualification.
* SHA256SUMS: SHA256 of every package file other than SHA256SUMS itself.
* verify.py and replay.py: portable path/command helpers described below.

All selected original checked runs have ok=true, process_exit=0, and zero counted
engine errors. A passing witness means its stated reproduction assertions passed;
it does not mean the underlying production behavior is correct. Keep logs with
reports and read the scope above before interpreting a PASS marker.

VERIFY WITHOUT EXECUTING GODOT

From the extracted package directory, with Python 3.10 or newer:

  python3 verify.py
  python3 verify.py --repo /absolute/path/to/OpenRCsimulator

The first command verifies all file hashes, each report/log pair, independently
computed Git-blob identities, and each exact diagnostic substitution. --repo also
compares production snapshots with the pinned commit in a real Git repository.
No engine runs were added while assembling this package. Replay helper preparation
and hash validation are distinct from re-executing the original physics witnesses.

REPLAY PREREQUISITES

Use the official recorded engine and a complete checkout at the pinned commit.
Verify the engine against its official download checksum. For production-project
runs, first import the complete checkout with that engine, outside this package:

  /absolute/path/to/godot --headless --editor --path /absolute/path/to/OpenRCsimulator/app --import --quit

The original executions used Linux. Portable commands remove historical workspace
paths; they are not a claim of bitwise equivalence on other operating systems or
hardware. Incomplete sparse checkouts and absent engine/native/imported resources
are not production defects. Match the headless engine/backend environment before
interpreting a differing replay. Timing, temporary paths, and user-data directory
names can differ without changing the witness.

PORTABLE REPLAY

Each --out must be a NEW directory. The helper verifies the package, checks the
pinned checkout, writes the new command and fresh checked-run results separately,
and preserves original evidence. It isolates Linux user data through XDG_DATA_HOME.

Standalone statistics reproduction:

  python3 replay.py quarantine-reopen --godot /absolute/path/to/godot --out /tmp/openrc-round2-statistics

Production bank witness:

  python3 replay.py bank-integrated-final --godot /absolute/path/to/godot --repo /absolute/path/to/OpenRCsimulator --out /tmp/openrc-round2-bank-original

Sign-only bank diagnostic:

  python3 replay.py bank-corrected --godot /absolute/path/to/godot --repo /absolute/path/to/OpenRCsimulator --out /tmp/openrc-round2-bank-sign

X99 labels (use the same --godot/--repo/--out options and a distinct new output):

  tolerance-stopped-original-final
  tolerance-stopped-sign-final
  tolerance-stopped-override-final

Secondary observation label:

  round2-lifecycle

For an isolated or modified project, replay.py makes a private copy before running.
A modified-project replay copies the user's complete imported app, including local
import products if present, into the new output directory and substitutes only the
verified candidate source file. This can require substantial disk space; no such
assets or caches are included in the ZIP. Original checkout files are not patched.
Original and sign-only X99 runs use the same original probe; only their project
variant differs. The stopped-motor override uses its own final assertion probe.

The lifecycle probe's historical absolute sidecar-output path cannot be reused.
The helper creates an explicitly named *_output_path_adapter.gd copy and replaces
only the output-directory prefix, recording the substitution in adapter_provenance.json.
The original receipt probe remains unchanged. Fresh sidecars are new reproductions.

Add --prepare-only to any replay command to prepare copies and replay_command.json
without launching Godot. For example:

  python3 replay.py quarantine-reopen --godot /absolute/path/to/godot --out /tmp/openrc-round2-prepared --prepare-only

The copied production source, patches, receipts, and reproduction scripts are the
complete verification deliverable. No full game assets or proposed production fix
are required inside this package to inspect its evidence and source identities.
