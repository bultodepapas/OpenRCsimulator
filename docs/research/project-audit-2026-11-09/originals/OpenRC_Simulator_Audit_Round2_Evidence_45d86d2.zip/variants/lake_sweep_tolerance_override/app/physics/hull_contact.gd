## E3d1: soft crash-hull contacts. Each hull point touching the flat field becomes a spring-damper along the ground
## normal with regularized Coulomb friction in the ground plane, so a wingtip brush, a tail touch or a belly slide
## no longer ends the flight. FlightSession decides when a contact is a crash (terminal()). Pure float64.
## Stiffness and damping are numerical contact choices (estimates), not measured airframe or turf compliance.
## GP-07c: the friction coefficient is the field surface's airframe_friction under the point (runway strip, mown,
## rough; ground_surfaces.gd build_airframe), and the regularization speed scales with the point's load so friction
## holds a lightly loaded point near Coulomb while a hard impact stays inside RK4's stable rate.
extends RefCounted

const M := preload("res://physics/math3d.gd")
const RB := preload("res://physics/rigid_body.gd")
const EffectiveMass := preload("res://physics/effective_mass.gd")
const LakeSurface := preload("res://physics/lake_surface.gd")
const Terrain := preload("res://physics/ground_terrain.gd")

## GP-10b: append only for lake-enabled session identities; the no-lake law() stays unchanged.
const LAKE_NORMAL_LAW := "positive-down-bank-gradient-normal-v2"

## Contact natural frequency against each point's smallest effective mass: ω·dt = 0.25 at 240 Hz, so no point is
## stiffer than this for RK4 in any attitude. A belly carrying the whole airplane sags g/ω² ≈ 2.7 mm.
const OMEGA_RAD_S := 60.0
const ZETA := 0.7
## Damping grows from zero over this compression so the force does not jump at touchdown (cf. E1b).
const DAMPING_ONSET_M := 0.004
## Airframe sliding friction without a field surface table (fixtures, lake banks): the mown-strip value, GP-07c.
const FRICTION_MU := 0.4
## GP-07c: below a point's regularization speed friction scales linearly with slip (no chatter at rest). The speed is
## n·μ·F/(m·FRICTION_RATE_MAX) with m the point's smallest effective mass and n the number of hull points touching,
## so each point's linear friction rate on its own mass stays below FRICTION_RATE_MAX/n and the sum over the body,
## Σ (m_i/M)·FRICTION_RATE_MAX/n, below FRICTION_RATE_MAX (λ·dt = 0.5 at 240 Hz, the wheels' SIDE_LAMBDA_DT_MAX),
## however many points share a slide; never below SLIP_REGULARIZATION_MIN_MPS. E3d1 used a fixed 0.2 m/s: a resting
## tip crept, and a hard tip impact reached λ·dt ≈ 4, beyond RK4's real-axis limit of 2.78, so friction chattered
## within the band. Numerical, not a property.
const FRICTION_RATE_MAX := 120.0
const SLIP_REGULARIZATION_MIN_MPS := 0.01
## Floats per surface in the airframe friction table (ground_surfaces.gd build_airframe): north_min, north_max,
## east_min, east_max, airframe_friction; the last block is a catch-all (±INF).
const AIRFRAME_STRIDE := 5
## A contact is a crash when the struck point's normal energy per kilogram of airplane reaches the CR-08b C2 cut
## (surface transfer 1, conservative), or when any point is pushed this deep (a slow crush).
const TERMINAL_J_PER_KG := 12.5
const CRASH_DEPTH_M := 0.08
## X8-08: an aircraft with damage "tolerant_hull" (an EPO foam airframe) carries its own evidence-bearing thresholds
## (model.crash_tolerance); prepare()/prepare_geometry() store them and every terminal test reads them back. Without
## them the prepared dictionary is unchanged and the shared constants above apply.
static func terminal_energy(prepared: Dictionary) -> float:
	return float(prepared.get("terminal_j_per_kg", TERMINAL_J_PER_KG))


static func crash_depth(prepared: Dictionary) -> float:
	return float(prepared.get("crash_depth_m", CRASH_DEPTH_M))


static func _with_tolerance(prepared: Dictionary, tolerance: Dictionary) -> Dictionary:
	if not tolerance.is_empty():
		prepared["terminal_j_per_kg"] = float(tolerance.terminal_specific_energy)
		prepared["crash_depth_m"] = float(tolerance.crash_depth)
	return prepared
## E3d2: a turning propeller whose disc reaches the field is a prop strike (engine stops, not a crash). Estimate: any
## rotation a pilot would hear; research 04 §6 proposed 1.5 × idle, but a glow prop at idle also breaks on the ground.
const STRIKE_MIN_RPM := 300.0

# law() is formatted once: the per-tick hull observation reads it, and every input is a constant.
static var _law_identity := ""


## Identity of this contact law and its constants, for checkpoint configuration hashes and trace metadata.
static func law() -> String:
	if _law_identity.is_empty():
		_law_identity = "soft-hull-spring-friction-v2 omega=%s zeta=%s onset_m=%s mu=field-airframe-friction(default %s) friction_rate_max=%s-shared slip_reg_min_mps=%s terminal_j_per_kg=%s crash_depth_m=%s prop_strike_min_rpm=%s flat-ground" % [
			OMEGA_RAD_S, ZETA, DAMPING_ONSET_M, FRICTION_MU, FRICTION_RATE_MAX, SLIP_REGULARIZATION_MIN_MPS, TERMINAL_J_PER_KG, CRASH_DEPTH_M, STRIKE_MIN_RPM]
	return _law_identity


## GP-07c: the airframe friction coefficient at a ground position from the flat table, FRICTION_MU without one.
static func friction_at(surfaces: PackedFloat64Array, north: float, east: float) -> float:
	if surfaces.is_empty():
		return FRICTION_MU
	var i := 0
	while i + AIRFRAME_STRIDE < surfaces.size():
		if north >= surfaces[i] and north <= surfaces[i + 1] and east >= surfaces[i + 2] and east <= surfaces[i + 3]:
			return surfaces[i + 4]
		i += AIRFRAME_STRIDE
	return surfaces[i + 4]


## GP-07c: slip speed below which friction on a point of smallest effective mass `m_min` carrying `f_up` is linear,
## while `touching` hull points are in contact.
static func slip_regularization(mu: float, f_up: float, m_min: float, touching := 1) -> float:
	return maxf(SLIP_REGULARIZATION_MIN_MPS, float(touching) * mu * f_up / (m_min * FRICTION_RATE_MAX))


## E3d2: the propeller disc from the propulsion data: {hub (body FRD about the CG), axis (unit, body FRD), radius};
## {} for a turbine or data without a propeller diameter. Same hub and axis the thrust is applied at (Propulsion).
static func prop_disc(propulsion: Dictionary) -> Dictionary:
	if str(propulsion.get("kind", "")) == "turbine" or not propulsion.has("diameter") or not propulsion.has("offset"):
		return {}
	var r: PackedFloat64Array = propulsion.offset # [x_aft, y_right, z_up] from the CG
	var a: PackedFloat64Array = propulsion.get("axis", PackedFloat64Array([1.0, 0.0, 0.0]))
	var length := M.norm(a)
	var radius := 0.5 * float(propulsion.diameter)
	if not is_finite(length) or length <= 0.0 or not is_finite(radius) or radius <= 0.0:
		return {}
	return {hub = PackedFloat64Array([-r[0], r[1], -r[2]]), axis = M.scale(a, 1.0 / length), radius = radius}


## E3d2: depth (m, positive below the field) of the disc's lowest point at state `s`, and that point in NED. The lowest
## point is the hub plus the radius along the ground-down direction projected onto the disc plane.
static func prop_disc_depth(s: PackedFloat64Array, disc: Dictionary, lake: Dictionary = {}, time_s: float = 0.0) -> Dictionary:
	if disc.is_empty():
		return {depth = -INF, point_ned = PackedFloat64Array()}
	if (not lake.is_empty() and not LakeSurface.is_valid_definition(lake)) or not is_finite(time_s):
		return {depth = NAN, point_ned = PackedFloat64Array()}
	var down := _down_row(s)
	var a: PackedFloat64Array = disc.axis
	var along := down[0] * a[0] + down[1] * a[1] + down[2] * a[2]
	var p := PackedFloat64Array([down[0] - along * a[0], down[1] - along * a[1], down[2] - along * a[2]])
	var p_len := M.norm(p)
	var lowest: PackedFloat64Array = disc.hub.duplicate()
	if p_len > 1.0e-9: # an axis pointing straight down leaves the disc horizontal: every rim point is as deep
		lowest = M.add(lowest, M.scale(p, float(disc.radius) / p_len))
	var depth := s[RB.POS + 2] + down[0] * lowest[0] + down[1] * lowest[1] + down[2] * lowest[2]
	var point_ned: PackedFloat64Array = M.add(RB._slice3(s, RB.POS), M.q_rotate(RB._att(s), lowest))
	if not lake.is_empty():
		var terrain: Dictionary = LakeSurface.sample_covered_terrain_validated(lake, point_ned[0], point_ned[1])
		if bool(terrain.get("covered", false)):
			var surface_down: float = LakeSurface.water_height_down(lake, point_ned[0], point_ned[1], time_s)
			if not is_finite(surface_down):
				surface_down = float(terrain.ground_down_m)
			depth = point_ned[2] - surface_down
	return {depth = depth, point_ned = point_ned}


const _DIRECTIONS := [
	[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
	[1, 1, 0], [1, -1, 0], [-1, 1, 0], [-1, -1, 0], [1, 0, 1], [1, 0, -1], [-1, 0, 1], [-1, 0, -1],
	[0, 1, 1], [0, 1, -1], [0, -1, 1], [0, -1, -1],
	[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1],
]


## Per-point stiffness/damping for `hull` (body FRD about the CG, flattened) from the smallest effective mass over
## 26 body directions. Returns {} when the inputs cannot support a contact (callers then add no hull forces).
static func prepare(hull: PackedFloat64Array, mass: float, inertia: PackedFloat64Array,
		lake: Dictionary = {}, surfaces := PackedFloat64Array(), tolerance: Dictionary = {}) -> Dictionary:
	if hull.is_empty() or hull.size() % 3 != 0 or not is_finite(mass) or mass <= 0.0 \
			or (not lake.is_empty() and not LakeSurface.is_valid_definition(lake)):
		return {}
	var identity := PackedFloat64Array([1.0, 0.0, 0.0, 0.0])
	var k := PackedFloat64Array()
	var c := PackedFloat64Array()
	var reach := 0.0
	for i in range(0, hull.size(), 3):
		var r := hull.slice(i, i + 3)
		var smallest := mass
		for d: Array in _DIRECTIONS:
			var m_eff := EffectiveMass.at_point(identity, r, PackedFloat64Array([float(d[0]), float(d[1]), float(d[2])]), mass, inertia)
			if m_eff <= 0.0:
				return {}
			smallest = minf(smallest, m_eff)
		k.append(smallest * OMEGA_RAD_S * OMEGA_RAD_S)
		c.append(2.0 * ZETA * smallest * OMEGA_RAD_S)
		reach = maxf(reach, M.norm(r))
	var prepared := {points = hull.duplicate(), stiffness = k, damping = c, reach = reach,
		mass = mass, inertia = inertia.duplicate(), surfaces = surfaces.duplicate()}
	if not lake.is_empty():
		prepared["lake"] = lake.duplicate(true)
		prepared["lake_bounds_ne_m"] = _polygon_bounds(lake.bank_ne_m)
	return _with_tolerance(prepared, tolerance)


## Geometry-only preparation for a body whose mass properties change during flight. It deliberately does no
## inertia inversion or contact-coefficient work; the stage path can reject distant hulls before building a
## short-lived coefficient view from its one sampled mass-properties snapshot.
static func prepare_geometry(hull: PackedFloat64Array, lake: Dictionary = {},
		surfaces := PackedFloat64Array(), tolerance: Dictionary = {}) -> Dictionary:
	if hull.is_empty() or hull.size() % 3 != 0 or not _finite_array(hull) \
			or (not lake.is_empty() and not LakeSurface.is_valid_definition(lake)):
		return {}
	var reach: float = 0.0
	for i in range(0, hull.size(), 3):
		reach = maxf(reach, M.norm(hull.slice(i, i + 3)))
	var geometry := {points = hull.duplicate(), reach = reach, geometry_only = true, surfaces = surfaces.duplicate()}
	if not lake.is_empty():
		geometry["lake"] = lake.duplicate(true)
		geometry["lake_bounds_ne_m"] = _polygon_bounds(lake.bank_ne_m)
	return _with_tolerance(geometry, tolerance)


## Stage loads for live mass properties, returning failure separately from a valid no-contact result.
## Geometry and output torque arms remain about fixed datum O, matching the state integration contract.
static func loads_at_properties(s: PackedFloat64Array, geometry: Dictionary, properties: Dictionary,
		diagnostics_out: Variant = null) -> Dictionary:
	if diagnostics_out is Array:
		diagnostics_out.clear()
	elif diagnostics_out is Dictionary:
		diagnostics_out.clear()
		diagnostics_out.merge({available = true, reason = "", rows = []})
	var valid: Dictionary = EffectiveMass.validate_properties(properties)
	if not bool(valid.get("ok", false)):
		return {ok = false, loads = PackedFloat64Array(), reason = str(valid.get("reason", "invalid_mass_properties"))}
	if geometry.is_empty() or not bool(geometry.get("geometry_only", false)) \
			or not geometry.has("points") or not geometry.has("reach"):
		return {ok = false, loads = PackedFloat64Array(), reason = "invalid_contact_geometry"}
	if s.size() != RB.SIZE or not _finite_array(s) or -s[RB.POS + 2] > float(geometry.reach):
		if s.size() != RB.SIZE or not _finite_array(s):
			return {ok = false, loads = PackedFloat64Array(), reason = "invalid_rigid_body_state"}
		return {ok = true, loads = PackedFloat64Array(), reason = ""}
	var hull: PackedFloat64Array = geometry.points
	# The contact coefficients matter only where loads() can apply a force.
	# In particular, a runway start must not invert inertia 26 times for every
	# hull point that is clear of the ground at every RK stage.
	var down: PackedFloat64Array = _down_row(s)
	var lake: Dictionary = geometry.get("lake", {})
	# Valid lake beds are below the field datum. When every point is clear of
	# that datum, skip the lake queries and the contact-parameter work.
	if not lake.is_empty():
		var qw := s[RB.ATT]
		var qx := s[RB.ATT + 1]
		var qy := s[RB.ATT + 2]
		var qz := s[RB.ATT + 3]
		var may_contact := false
		for i in range(0, hull.size(), 3):
			var rx := hull[i]
			var ry := hull[i + 1]
			var rz := hull[i + 2]
			var depth: float = s[RB.POS + 2] + down[0] * rx + down[1] * ry + down[2] * rz
			if not is_finite(depth):
				return {ok = false, loads = PackedFloat64Array(), reason = "invalid_contact_geometry"}
			# Reproduce M.q_rotate and M.add's scalar order. The flat and lake
			# tests round differently, so both must prove clearance.
			var tx := (qy * rz - qz * ry) * 2.0
			var ty := (qz * rx - qx * rz) * 2.0
			var tz := (qx * ry - qy * rx) * 2.0
			var rotated_x := (rx + tx * qw) + (qy * tz - qz * ty)
			var rotated_y := (ry + ty * qw) + (qz * tx - qx * tz)
			var rotated_z := (rz + tz * qw) + (qx * ty - qy * tx)
			var point_x := s[RB.POS] + rotated_x
			var point_y := s[RB.POS + 1] + rotated_y
			var point_z := s[RB.POS + 2] + rotated_z
			if not is_finite(point_x) or not is_finite(point_y) or not is_finite(point_z):
				return {ok = false, loads = PackedFloat64Array(), reason = "invalid_contact_geometry"}
			if depth > 0.0 or point_z > 0.0:
				may_contact = true
				break
		if not may_contact:
			return {ok = true, loads = PackedFloat64Array(), reason = ""}
	var active := PackedByteArray()
	active.resize(hull.size() / 3)
	var any_active := false
	var lake_samples: Array[Dictionary] = []
	var lake_clear: bool = not lake.is_empty() and _hull_clear_of_lake(s, geometry)
	for i in range(0, hull.size(), 3):
		var depth: float = s[RB.POS + 2] + down[0] * hull[i] + down[1] * hull[i + 1] + down[2] * hull[i + 2]
		if not is_finite(depth):
			return {ok = false, loads = PackedFloat64Array(), reason = "invalid_contact_geometry"}
		var may_touch := depth > 0.0
		if not lake.is_empty():
			var point_ned: PackedFloat64Array = _point_ned(s, hull.slice(i, i + 3))
			if not _finite_array(point_ned):
				return {ok = false, loads = PackedFloat64Array(), reason = "invalid_contact_geometry"}
			# Valid lake beds/banks are down from the field datum. A point at or
			# above that datum and clear of flat ground cannot touch either surface.
			if depth <= 0.0 and point_ned[2] <= 0.0:
				lake_samples.append({point_ned = point_ned, terrain = {covered = false}})
				active[i / 3] = 0
				continue
			# The finiteness check above still runs; only the known {covered = false} answer is skipped.
			var terrain: Dictionary = {covered = false} if lake_clear else _lake_sample(geometry, point_ned)
			lake_samples.append({point_ned = point_ned, terrain = terrain})
			if bool(terrain.get("covered", false)):
				# Qualification uses this exact force owner's sample, even when no
				# point needs coefficients and the dynamic path returns early.
				if diagnostics_out is Dictionary:
					diagnostics_out.available = false
					diagnostics_out.reason = "covered_lake_branch_unqualified"
					diagnostics_out.rows.clear()
				var ground_down: float = float(terrain.get("ground_down_m", NAN))
				if not is_finite(ground_down):
					return {ok = false, loads = PackedFloat64Array(), reason = "invalid_lake_terrain"}
				may_touch = point_ned[2] > ground_down
		active[i / 3] = 1 if may_touch else 0
		any_active = any_active or may_touch
	if not any_active:
		return {ok = true, loads = PackedFloat64Array(), reason = ""}
	var stiffness := PackedFloat64Array()
	var damping := PackedFloat64Array()
	stiffness.resize(active.size())
	damping.resize(active.size())
	var identity := PackedFloat64Array([1.0, 0.0, 0.0, 0.0])
	for i in range(0, hull.size(), 3):
		if active[i / 3] == 0:
			continue
		var body_point_o: PackedFloat64Array = hull.slice(i, i + 3)
		var smallest: float = float(properties.mass_kg)
		for d: Array in _DIRECTIONS:
			var effective: Dictionary = EffectiveMass._at_point_properties_validated(identity, body_point_o,
				PackedFloat64Array([float(d[0]), float(d[1]), float(d[2])]), properties)
			if not bool(effective.get("ok", false)):
				return {ok = false, loads = PackedFloat64Array(), reason = str(effective.get("reason", "invalid_effective_mass"))}
			smallest = minf(smallest, float(effective.effective_mass_kg))
		stiffness[i / 3] = smallest * OMEGA_RAD_S * OMEGA_RAD_S
		damping[i / 3] = 2.0 * ZETA * smallest * OMEGA_RAD_S
	var prepared := {points = hull, stiffness = stiffness, damping = damping,
		reach = float(geometry.reach), mass = float(properties.mass_kg), inertia = properties.inertia,
		surfaces = geometry.get("surfaces", PackedFloat64Array())}
	if geometry.has("lake"):
		prepared["lake"] = geometry.lake
		prepared["lake_bounds_ne_m"] = geometry.get("lake_bounds_ne_m", PackedFloat64Array())
	return {ok = true, loads = loads(s, prepared, lake_samples, diagnostics_out), reason = ""}


## Optional diagnostics accept the historical Array or a structured collector
## {available, reason, rows}. Covered lake branches invalidate the entire structured
## batch. This qualification reuses force samples; it never classifies terrain again.
## Body loads [Fx, Fy, Fz, Mx, My, Mz] from every touching hull point, or EMPTY when none touches (callers add
## nothing, so flight away from the ground is bit-identical).
static func loads(s: PackedFloat64Array, prepared: Dictionary,
		lake_samples: Array[Dictionary] = [], diagnostics_out: Variant = null) -> PackedFloat64Array:
	if diagnostics_out is Array:
		diagnostics_out.clear()
	elif diagnostics_out is Dictionary:
		diagnostics_out.clear()
		diagnostics_out.merge({available = true, reason = "", rows = []})
	if prepared.is_empty() or -s[RB.POS + 2] > float(prepared.reach):
		return PackedFloat64Array()
	var hull: PackedFloat64Array = prepared.points
	var rows := _rows(s)
	var north: PackedFloat64Array = rows[0]
	var east: PackedFloat64Array = rows[1]
	var down: PackedFloat64Array = rows[2]
	var out := PackedFloat64Array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var touched := false
	var lake: Dictionary = prepared.get("lake", {})
	var surfaces: PackedFloat64Array = prepared.get("surfaces", PackedFloat64Array())
	var samples: Array[Dictionary] = lake_samples
	var lake_sampled: bool = not lake.is_empty()
	if lake_sampled and samples.size() != hull.size() / 3:
		# LU-25-R4: a hull wholly outside the bank bounds samples {covered = false} at every point.
		lake_sampled = not _hull_clear_of_lake(s, prepared)
		samples = []
		for i in range(0, hull.size() if lake_sampled else 0, 3):
			var point_ned: PackedFloat64Array = _point_ned(s, hull.slice(i, i + 3))
			samples.append({point_ned = point_ned, terrain = _lake_sample(prepared, point_ned)})
	# GP-07c: how many points touch, for the friction regularization's shared rate bound.
	var touching := 0
	for i in range(0, hull.size(), 3):
		if lake_sampled and bool(samples[i / 3].terrain.get("covered", false)):
			# Certify the whole diagnostic batch BEFORE any force row can publish.
			# Default loads still use this same sample and arithmetic unchanged.
			if diagnostics_out is Dictionary:
				diagnostics_out.available = false
				diagnostics_out.reason = "covered_lake_branch_unqualified"
				diagnostics_out.rows.clear()
			if _lake_compression(samples[i / 3].point_ned, samples[i / 3].terrain) > 0.0:
				touching += 1
		elif s[RB.POS + 2] + down[0] * hull[i] + down[1] * hull[i + 1] + down[2] * hull[i + 2] > 0.0:
			touching += 1
	for i in range(0, hull.size(), 3):
		var body_point: PackedFloat64Array = hull.slice(i, i + 3)
		if lake_sampled:
			var point_ned: PackedFloat64Array = samples[i / 3].point_ned
			var terrain: Dictionary = samples[i / 3].terrain
			if bool(terrain.get("covered", false)):
				var lake_load: PackedFloat64Array = _lake_load(s, prepared, i / 3, body_point, point_ned, terrain, touching)
				if not lake_load.is_empty():
					for axis: int in 6:
						out[axis] += lake_load[axis]
					touched = true
				continue
		var rx := hull[i]
		var ry := hull[i + 1]
		var rz := hull[i + 2]
		var depth := s[RB.POS + 2] + down[0] * rx + down[1] * ry + down[2] * rz
		if depth <= 0.0:
			continue
		var vx := s[RB.VEL] + s[RB.RATE + 1] * rz - s[RB.RATE + 2] * ry
		var vy := s[RB.VEL + 1] + s[RB.RATE + 2] * rx - s[RB.RATE] * rz
		var vz := s[RB.VEL + 2] + s[RB.RATE] * ry - s[RB.RATE + 1] * rx
		var rate := down[0] * vx + down[1] * vy + down[2] * vz
		var point := i / 3
		var onset := minf(depth / DAMPING_ONSET_M, 1.0)
		var f_up: float = prepared.stiffness[point] * depth + prepared.damping[point] * onset * rate
		if f_up <= 0.0:
			continue # a damper never pulls the airframe into the ground
		var vn := north[0] * vx + north[1] * vy + north[2] * vz
		var ve := east[0] * vx + east[1] * vy + east[2] * vz
		var slip := sqrt(vn * vn + ve * ve)
		var mu := FRICTION_MU
		if not surfaces.is_empty():
			mu = friction_at(surfaces, s[RB.POS] + north[0] * rx + north[1] * ry + north[2] * rz,
				s[RB.POS + 1] + east[0] * rx + east[1] * ry + east[2] * rz)
		var m_min: float = prepared.stiffness[point] / (OMEGA_RAD_S * OMEGA_RAD_S)
		var scale := mu * f_up / maxf(slip, slip_regularization(mu, f_up, m_min, touching))
		var f_n := -scale * vn
		var f_e := -scale * ve
		# NED force (f_n, f_e, −f_up) in body axes.
		var fx := f_n * north[0] + f_e * east[0] - f_up * down[0]
		var fy := f_n * north[1] + f_e * east[1] - f_up * down[1]
		var fz := f_n * north[2] + f_e * east[2] - f_up * down[2]
		out[0] += fx
		out[1] += fy
		out[2] += fz
		out[3] += ry * fz - rz * fy
		out[4] += rz * fx - rx * fz
		out[5] += rx * fy - ry * fx
		# GP-19 optional endpoint diagnostics use the SAME computed force/velocity.
		# No allocation on ordinary RK loads; no interval-work or heat claim.
		if (diagnostics_out is Array and lake.is_empty()) \
			or (diagnostics_out is Dictionary and diagnostics_out.available):
			var row := {index = point, point_ned = _point_ned(s, body_point),
				normal_force_n = f_up, tangent_force_ned_n = PackedFloat64Array([f_n, f_e, 0.0]),
				relative_tangent_velocity_ned_mps = PackedFloat64Array([vn, ve, 0.0]),
				friction_power_w = -(f_n * vn + f_e * ve)}
			if diagnostics_out is Array: diagnostics_out.append(row)
			else: diagnostics_out.rows.append(row)
		touched = true
	return out if touched else PackedFloat64Array()


## The hull point that makes the step previous → s a crash, or -1. Graded on the point's state in `previous` (just
## before it touched): a point newly below the ground crashes when transfer-free ½·m_eff·v_n²/m reaches
## the prepared terminal energy (TERMINAL_J_PER_KG unless X8-08 tolerant); any point deeper than the prepared crash depth
## (CRASH_DEPTH_M by default) crashes too. Returns {index, rule, specific_j_per_kg,
## normal_speed_mps, depth_m}.
static func terminal(previous: PackedFloat64Array, s: PackedFloat64Array, prepared: Dictionary) -> Dictionary:
	var none := {index = -1, rule = "", specific_j_per_kg = 0.0, normal_speed_mps = 0.0, depth_m = 0.0}
	# CR-22c: runs every tick; nothing can touch above the hull's reach, and points in the air cost no allocation.
	if prepared.is_empty() or previous.size() != s.size() or -s[RB.POS + 2] > float(prepared.reach):
		return none
	var hull: PackedFloat64Array = prepared.points
	var down_now: PackedFloat64Array = _down_row(s)
	var down_before: PackedFloat64Array = _down_row(previous)
	var q_before := RB._att(previous)
	var worst := none.duplicate()
	var lake: Dictionary = prepared.get("lake", {})
	var lake_sampled: bool = not lake.is_empty() and not _hull_clear_of_lake(s, prepared)
	for i in range(0, hull.size(), 3):
		var r := hull.slice(i, i + 3)
		if lake_sampled:
			var point_now: PackedFloat64Array = _point_ned(s, r)
			var terrain_now: Dictionary = _lake_sample(prepared, point_now)
			if bool(terrain_now.get("covered", false)):
				var lake_result: Dictionary = _lake_terminal_candidate(previous, s, prepared, i / 3,
					r, point_now, terrain_now, q_before)
				if str(lake_result.get("rule", "")) == "depth":
					return lake_result
				if not lake_result.is_empty() and float(lake_result.specific_j_per_kg) > float(worst.specific_j_per_kg):
					worst = lake_result
				continue
		var depth := s[RB.POS + 2] + down_now[0] * hull[i] + down_now[1] * hull[i + 1] + down_now[2] * hull[i + 2]
		if depth <= 0.0:
			continue
		if depth > crash_depth(prepared):
			return {index = i / 3, rule = "depth", specific_j_per_kg = 0.0, normal_speed_mps = 0.0, depth_m = depth}
		var depth_before := previous[RB.POS + 2] + down_before[0] * r[0] + down_before[1] * r[1] + down_before[2] * r[2]
		if depth_before > 0.0:
			continue # already in contact: a resting or sliding point is not a new impact
		var v_ned := M.q_rotate(q_before, M.add(RB._slice3(previous, RB.VEL), M.cross(RB._slice3(previous, RB.RATE), r)))
		var v_n := maxf(0.0, v_ned[2])
		var m_eff := EffectiveMass.at_point(q_before, r, PackedFloat64Array([0.0, 0.0, -1.0]), float(prepared.mass), prepared.inertia)
		if m_eff <= 0.0:
			m_eff = float(prepared.mass)
		var specific := 0.5 * m_eff * v_n * v_n / float(prepared.mass)
		if specific >= terminal_energy(prepared) and specific > float(worst.specific_j_per_kg):
			worst = {index = i / 3, rule = "impact", specific_j_per_kg = specific, normal_speed_mps = v_n, depth_m = depth}
	return worst


## Dynamic terminal test. The sample is specifically for `previous`: existing soft-hull impact energy uses the
## pre-contact pose/velocity and only the candidate state to establish penetration. A deep-crush result is still
## mass-independent, but invalid samples fail closed before any candidate is accepted.
static func terminal_at_properties(previous: PackedFloat64Array, s: PackedFloat64Array,
		geometry: Dictionary, properties_previous: Dictionary) -> Dictionary:
	var none := {index = -1, rule = "", specific_j_per_kg = 0.0, normal_speed_mps = 0.0, depth_m = 0.0}
	var valid: Dictionary = EffectiveMass.validate_properties(properties_previous)
	if not bool(valid.get("ok", false)):
		return {ok = false, event = none, reason = str(valid.get("reason", "invalid_mass_properties"))}
	if geometry.is_empty() or not bool(geometry.get("geometry_only", false)) \
			or previous.size() != RB.SIZE or s.size() != RB.SIZE \
			or not _finite_array(previous) or not _finite_array(s):
		return {ok = false, event = none, reason = "invalid_contact_input"}
	var q_before: PackedFloat64Array = RB._att(previous)
	var previous_q_norm_squared: float = q_before[0] * q_before[0] + q_before[1] * q_before[1] \
		+ q_before[2] * q_before[2] + q_before[3] * q_before[3]
	if not is_finite(previous_q_norm_squared) or absf(previous_q_norm_squared - 1.0) > 1.0e-9:
		return {ok = false, event = none, reason = "invalid_previous_attitude"}
	if -s[RB.POS + 2] > float(geometry.reach):
		return {ok = true, event = none, reason = ""}
	var hull: PackedFloat64Array = geometry.points
	var down_now: PackedFloat64Array = _down_row(s)
	var down_before: PackedFloat64Array = _down_row(previous)
	var worst: Dictionary = none.duplicate()
	var lake: Dictionary = geometry.get("lake", {})
	var lake_sampled: bool = not lake.is_empty() and not _hull_clear_of_lake(s, geometry)
	for i in range(0, hull.size(), 3):
		var r: PackedFloat64Array = hull.slice(i, i + 3)
		if lake_sampled:
			var point_now: PackedFloat64Array = _point_ned(s, r)
			var terrain_now: Dictionary = _lake_sample(geometry, point_now)
			if bool(terrain_now.get("covered", false)):
				var lake_event: Dictionary = _lake_terminal_candidate_properties(previous, s, geometry,
					i / 3, r, point_now, terrain_now, q_before, properties_previous)
				if bool(lake_event.get("invalid", false)):
					return {ok = false, event = none, reason = str(lake_event.get("reason", "invalid_effective_mass"))}
				if str(lake_event.get("rule", "")) == "depth":
					return {ok = true, event = lake_event, reason = ""}
				if not lake_event.is_empty() and float(lake_event.specific_j_per_kg) > float(worst.specific_j_per_kg):
					worst = lake_event
				continue
		var depth: float = s[RB.POS + 2] + down_now[0] * r[0] + down_now[1] * r[1] + down_now[2] * r[2]
		if depth <= 0.0:
			continue
		if depth > crash_depth(geometry):
			return {ok = true, event = {index = i / 3, rule = "depth", specific_j_per_kg = 0.0,
				normal_speed_mps = 0.0, depth_m = depth}, reason = ""}
		var depth_before: float = previous[RB.POS + 2] + down_before[0] * r[0] + down_before[1] * r[1] + down_before[2] * r[2]
		if depth_before > 0.0:
			continue
		var velocity_ned: PackedFloat64Array = M.q_rotate(q_before,
			M.add(RB._slice3(previous, RB.VEL), M.cross(RB._slice3(previous, RB.RATE), r)))
		var normal_speed: float = maxf(0.0, velocity_ned[2])
		var effective: Dictionary = EffectiveMass._at_point_properties_validated(q_before, r,
			PackedFloat64Array([0.0, 0.0, -1.0]), properties_previous)
		if not bool(effective.get("ok", false)):
			return {ok = false, event = none, reason = str(effective.get("reason", "invalid_effective_mass"))}
		var specific: float = 0.5 * float(effective.effective_mass_kg) * normal_speed * normal_speed \
			/ float(properties_previous.mass_kg)
		if specific >= terminal_energy(geometry) and specific > float(worst.specific_j_per_kg):
			worst = {index = i / 3, rule = "impact", specific_j_per_kg = specific,
				normal_speed_mps = normal_speed, depth_m = depth}
	return {ok = true, event = worst, reason = ""}


## Presentation feed: every hull point touching after the step previous → s, as {index, new, depth_m,
## normal_speed_mps (into the ground, from `previous`), slide_speed_mps, point_ned}. Empty in the air.
static func contacts(previous: PackedFloat64Array, s: PackedFloat64Array, prepared: Dictionary) -> Array:
	var out: Array = []
	if prepared.is_empty() or previous.size() != s.size() or -s[RB.POS + 2] > float(prepared.reach):
		return out
	var hull: PackedFloat64Array = prepared.points
	var down_now: PackedFloat64Array = _down_row(s)
	var down_before: PackedFloat64Array = _down_row(previous)
	var q := RB._att(s)
	var q_before := RB._att(previous)
	var lake: Dictionary = prepared.get("lake", {})
	var lake_sampled: bool = not lake.is_empty() and not _hull_clear_of_lake(s, prepared)
	for i in range(0, hull.size(), 3):
		var r := hull.slice(i, i + 3)
		if lake_sampled:
			var point_now: PackedFloat64Array = _point_ned(s, r)
			var terrain_now: Dictionary = _lake_sample(prepared, point_now)
			if bool(terrain_now.get("covered", false)):
				var lake_contact: Dictionary = _lake_contact_record(previous, s, prepared, i / 3,
					r, point_now, terrain_now, q_before, q)
				if not lake_contact.is_empty():
					out.append(lake_contact)
				continue
		var depth := s[RB.POS + 2] + down_now[0] * hull[i] + down_now[1] * hull[i + 1] + down_now[2] * hull[i + 2]
		if depth <= 0.0:
			continue
		var depth_before := previous[RB.POS + 2] + down_before[0] * r[0] + down_before[1] * r[1] + down_before[2] * r[2]
		var v_before := M.q_rotate(q_before, M.add(RB._slice3(previous, RB.VEL), M.cross(RB._slice3(previous, RB.RATE), r)))
		var v_now := M.q_rotate(q, M.add(RB._slice3(s, RB.VEL), M.cross(RB._slice3(s, RB.RATE), r)))
		out.append({index = i / 3, new = depth_before <= 0.0, depth_m = depth, normal_speed_mps = maxf(0.0, v_before[2]),
			slide_speed_mps = sqrt(v_now[0] * v_now[0] + v_now[1] * v_now[1]),
			point_ned = M.add(RB._slice3(s, RB.POS), M.q_rotate(q, r)), velocity_ned = v_now})
	return out


## Depth of a lake-covered point below the bed or bank along its normal (≤ 0: clear); NAN-free inputs assumed.
static func _lake_compression(point_ned: PackedFloat64Array, terrain: Dictionary) -> float:
	var normal_length: float = M.norm(PackedFloat64Array([
		float(terrain.get("slope_north", 0.0)), float(terrain.get("slope_east", 0.0)), 1.0]))
	return (point_ned[2] - float(terrain.get("ground_down_m", -INF))) / normal_length


static func _lake_load(s: PackedFloat64Array, prepared: Dictionary, point_index: int,
	body_point: PackedFloat64Array, point_ned: PackedFloat64Array, terrain: Dictionary, touching := 1) -> PackedFloat64Array:
	var normal: PackedFloat64Array = _lake_normal(terrain)
	if normal.is_empty():
		return PackedFloat64Array()
	var normal_length: float = M.norm(PackedFloat64Array([
		float(terrain.slope_north), float(terrain.slope_east), 1.0]))
	var compression: float = (point_ned[2] - float(terrain.ground_down_m)) / normal_length
	if compression <= 0.0:
		return PackedFloat64Array()
	var q: PackedFloat64Array = RB._att(s)
	var velocity_body: PackedFloat64Array = M.add(RB._slice3(s, RB.VEL),
		M.cross(RB._slice3(s, RB.RATE), body_point))
	var velocity_ned: PackedFloat64Array = M.q_rotate(q, velocity_body)
	var normal_rate: float = -M.dot(velocity_ned, normal)
	var onset: float = minf(compression / DAMPING_ONSET_M, 1.0)
	var f_up: float = float(prepared.stiffness[point_index]) * compression \
		+ float(prepared.damping[point_index]) * onset * normal_rate
	if f_up <= 0.0:
		return PackedFloat64Array()
	var normal_speed: float = M.dot(velocity_ned, normal)
	var tangent_velocity: PackedFloat64Array = M.sub(velocity_ned, M.scale(normal, normal_speed))
	var slip: float = M.norm(tangent_velocity)
	var m_min: float = float(prepared.stiffness[point_index]) / (OMEGA_RAD_S * OMEGA_RAD_S)
	var friction_scale: float = FRICTION_MU * f_up / maxf(slip, slip_regularization(FRICTION_MU, f_up, m_min, touching))
	var force_ned: PackedFloat64Array = M.sub(M.scale(normal, f_up), M.scale(tangent_velocity, friction_scale))
	var q_inverse: PackedFloat64Array = PackedFloat64Array([q[0], -q[1], -q[2], -q[3]])
	var force_body: PackedFloat64Array = M.q_rotate(q_inverse, force_ned)
	return PackedFloat64Array([
		force_body[0], force_body[1], force_body[2],
		body_point[1] * force_body[2] - body_point[2] * force_body[1],
		body_point[2] * force_body[0] - body_point[0] * force_body[2],
		body_point[0] * force_body[1] - body_point[1] * force_body[0],
	])


static func _lake_terminal_candidate(previous: PackedFloat64Array, s: PackedFloat64Array,
	prepared: Dictionary, point_index: int, body_point: PackedFloat64Array, point_now: PackedFloat64Array,
	terrain_now: Dictionary, q_before: PackedFloat64Array) -> Dictionary:
	var normal: PackedFloat64Array = _lake_normal(terrain_now)
	if normal.is_empty():
		return {}
	var normal_length: float = M.norm(PackedFloat64Array([
		float(terrain_now.slope_north), float(terrain_now.slope_east), 1.0]))
	var depth: float = (point_now[2] - float(terrain_now.ground_down_m)) / normal_length
	if depth <= 0.0:
		return {}
	if depth > crash_depth(prepared):
		return {index = point_index, rule = "depth", specific_j_per_kg = 0.0,
			normal_speed_mps = 0.0, depth_m = depth}
	var point_before: PackedFloat64Array = _point_ned(previous, body_point)
	var terrain_before: Dictionary = _lake_sample(prepared, point_before)
	var depth_before: float = 0.0
	if bool(terrain_before.get("covered", false)):
		var before_normal_length: float = M.norm(PackedFloat64Array([
			float(terrain_before.slope_north), float(terrain_before.slope_east), 1.0]))
		depth_before = (point_before[2] - float(terrain_before.ground_down_m)) / before_normal_length
	else:
		var extrapolated_ground_down: float = float(terrain_now.ground_down_m) \
			+ float(terrain_now.slope_north) * (point_before[0] - point_now[0]) \
			+ float(terrain_now.slope_east) * (point_before[1] - point_now[1])
		depth_before = (point_before[2] - extrapolated_ground_down) / normal_length
	if depth_before > 0.0:
		return {} # Resting or sliding bank contact is handled by the spring-damper, not a new impact.
	var velocity_ned: PackedFloat64Array = M.q_rotate(q_before, M.add(RB._slice3(previous, RB.VEL),
		M.cross(RB._slice3(previous, RB.RATE), body_point)))
	var normal_speed: float = maxf(0.0, -M.dot(velocity_ned, normal))
	var effective_mass: float = EffectiveMass.at_point(q_before, body_point, normal,
		float(prepared.mass), prepared.inertia)
	if effective_mass <= 0.0:
		effective_mass = float(prepared.mass)
	var specific: float = 0.5 * effective_mass * normal_speed * normal_speed / float(prepared.mass)
	if specific >= terminal_energy(prepared):
		return {index = point_index, rule = "impact", specific_j_per_kg = specific,
			normal_speed_mps = normal_speed, depth_m = depth}
	return {}


static func _lake_terminal_candidate_properties(previous: PackedFloat64Array, s: PackedFloat64Array,
		geometry: Dictionary, point_index: int, body_point_o: PackedFloat64Array,
		point_now: PackedFloat64Array, terrain_now: Dictionary, q_before: PackedFloat64Array,
		properties_previous: Dictionary) -> Dictionary:
	var normal: PackedFloat64Array = _lake_normal(terrain_now)
	if normal.is_empty():
		return {}
	var normal_length: float = M.norm(PackedFloat64Array([
		float(terrain_now.slope_north), float(terrain_now.slope_east), 1.0]))
	var depth: float = (point_now[2] - float(terrain_now.ground_down_m)) / normal_length
	if depth <= 0.0:
		return {}
	if depth > crash_depth(geometry):
		return {index = point_index, rule = "depth", specific_j_per_kg = 0.0,
			normal_speed_mps = 0.0, depth_m = depth}
	var point_before: PackedFloat64Array = _point_ned(previous, body_point_o)
	var terrain_before: Dictionary = _lake_sample(geometry, point_before)
	var depth_before: float
	if bool(terrain_before.get("covered", false)):
		var before_normal_length: float = M.norm(PackedFloat64Array([
			float(terrain_before.slope_north), float(terrain_before.slope_east), 1.0]))
		depth_before = (point_before[2] - float(terrain_before.ground_down_m)) / before_normal_length
	else:
		var extrapolated_ground_down: float = float(terrain_now.ground_down_m) \
			+ float(terrain_now.slope_north) * (point_before[0] - point_now[0]) \
			+ float(terrain_now.slope_east) * (point_before[1] - point_now[1])
		depth_before = (point_before[2] - extrapolated_ground_down) / normal_length
	if depth_before > 0.0:
		return {}
	var velocity_ned: PackedFloat64Array = M.q_rotate(q_before, M.add(RB._slice3(previous, RB.VEL),
		M.cross(RB._slice3(previous, RB.RATE), body_point_o)))
	var normal_speed: float = maxf(0.0, -M.dot(velocity_ned, normal))
	var effective: Dictionary = EffectiveMass._at_point_properties_validated(q_before, body_point_o, normal, properties_previous)
	if not bool(effective.get("ok", false)):
		return {invalid = true, reason = str(effective.get("reason", "invalid_effective_mass"))}
	var specific: float = 0.5 * float(effective.effective_mass_kg) * normal_speed * normal_speed \
		/ float(properties_previous.mass_kg)
	if specific >= terminal_energy(geometry):
		return {index = point_index, rule = "impact", specific_j_per_kg = specific,
			normal_speed_mps = normal_speed, depth_m = depth}
	return {}


static func _lake_contact_record(previous: PackedFloat64Array, s: PackedFloat64Array,
	prepared: Dictionary, point_index: int, body_point: PackedFloat64Array, point_now: PackedFloat64Array,
	terrain_now: Dictionary, q_before: PackedFloat64Array, q_now: PackedFloat64Array) -> Dictionary:
	var normal: PackedFloat64Array = _lake_normal(terrain_now)
	if normal.is_empty():
		return {}
	var normal_length: float = M.norm(PackedFloat64Array([
		float(terrain_now.slope_north), float(terrain_now.slope_east), 1.0]))
	var depth: float = (point_now[2] - float(terrain_now.ground_down_m)) / normal_length
	if depth <= 0.0:
		return {}
	var point_before: PackedFloat64Array = _point_ned(previous, body_point)
	var terrain_before: Dictionary = _lake_sample(prepared, point_before)
	var depth_before: float
	if bool(terrain_before.get("covered", false)):
		var before_normal_length: float = M.norm(PackedFloat64Array([
			float(terrain_before.slope_north), float(terrain_before.slope_east), 1.0]))
		depth_before = (point_before[2] - float(terrain_before.ground_down_m)) / before_normal_length
	else:
		var extrapolated_ground_down: float = float(terrain_now.ground_down_m) \
			+ float(terrain_now.slope_north) * (point_before[0] - point_now[0]) \
			+ float(terrain_now.slope_east) * (point_before[1] - point_now[1])
		depth_before = (point_before[2] - extrapolated_ground_down) / normal_length
	var velocity_before: PackedFloat64Array = M.q_rotate(q_before, M.add(RB._slice3(previous, RB.VEL),
		M.cross(RB._slice3(previous, RB.RATE), body_point)))
	var velocity_now: PackedFloat64Array = M.q_rotate(q_now, M.add(RB._slice3(s, RB.VEL),
		M.cross(RB._slice3(s, RB.RATE), body_point)))
	var normal_rate: float = maxf(0.0, -M.dot(velocity_before, normal))
	var tangent_now: PackedFloat64Array = M.sub(velocity_now, M.scale(normal, M.dot(velocity_now, normal)))
	return {index = point_index, new = depth_before <= 0.0, depth_m = depth,
		normal_speed_mps = normal_rate, slide_speed_mps = M.norm(tangent_now),
		point_ned = point_now, velocity_ned = velocity_now, normal_ned = normal}


static func _point_ned(s: PackedFloat64Array, body_point: PackedFloat64Array) -> PackedFloat64Array:
	return M.add(RB._slice3(s, RB.POS), M.q_rotate(RB._att(s), body_point))


## True when every hull point is outside the bank bounds that `_lake_sample` rejects with
## {covered = false}. A stage quaternion is not exactly unit: q_rotate lengthens a body
## vector by at most 1 + 4|q|², and the 1 mm slack covers rounding at field-scale positions.
## A nonfinite state compares false and keeps per-point sampling.
static func _hull_clear_of_lake(s: PackedFloat64Array, prepared: Dictionary) -> bool:
	var bounds_value: Variant = prepared.get("lake_bounds_ne_m", PackedFloat64Array())
	if typeof(bounds_value) != TYPE_PACKED_FLOAT64_ARRAY or bounds_value.size() != 4:
		return false
	var bounds: PackedFloat64Array = bounds_value
	var qq: float = s[RB.ATT] * s[RB.ATT] + s[RB.ATT + 1] * s[RB.ATT + 1] \
		+ s[RB.ATT + 2] * s[RB.ATT + 2] + s[RB.ATT + 3] * s[RB.ATT + 3]
	var radius: float = float(prepared.reach) * (1.0 + 4.0 * qq) + 0.001
	return s[RB.POS] + radius < bounds[0] or s[RB.POS] - radius > bounds[1] \
		or s[RB.POS + 1] + radius < bounds[2] or s[RB.POS + 1] - radius > bounds[3]


static func _lake_sample(prepared: Dictionary, point_ned: PackedFloat64Array) -> Dictionary:
	var lake_value: Variant = prepared.get("lake", {})
	if typeof(lake_value) != TYPE_DICTIONARY or lake_value.is_empty() or point_ned.size() != 3:
		return {covered = false}
	var lake: Dictionary = lake_value
	var bounds_value: Variant = prepared.get("lake_bounds_ne_m", PackedFloat64Array())
	if typeof(bounds_value) == TYPE_PACKED_FLOAT64_ARRAY and bounds_value.size() == 4:
		var bounds: PackedFloat64Array = bounds_value
		if point_ned[0] < bounds[0] or point_ned[0] > bounds[1] \
				or point_ned[1] < bounds[2] or point_ned[1] > bounds[3]:
			return {covered = false}
	return LakeSurface.sample_terrain_validated(lake, point_ned[0], point_ned[1])


static func _lake_normal(terrain: Dictionary) -> PackedFloat64Array:
	var slope_north: float = float(terrain.get("slope_north", NAN))
	var slope_east: float = float(terrain.get("slope_east", NAN))
	if not is_finite(slope_north) or not is_finite(slope_east):
		return PackedFloat64Array()
	# LakeSurface slopes differentiate NED down; the shared normal helper takes height-up slopes.
	return Terrain.normal_from_up_slopes(-slope_north, -slope_east)


static func _polygon_bounds(polygon: PackedFloat64Array) -> PackedFloat64Array:
	var north_min: float = INF
	var north_max: float = -INF
	var east_min: float = INF
	var east_max: float = -INF
	for index: int in range(0, polygon.size(), 2):
		north_min = minf(north_min, polygon[index])
		north_max = maxf(north_max, polygon[index])
		east_min = minf(east_min, polygon[index + 1])
		east_max = maxf(east_max, polygon[index + 1])
	return PackedFloat64Array([north_min, north_max, east_min, east_max])


static func _rows(s: PackedFloat64Array) -> Array:
	var w := s[RB.ATT]
	var x := s[RB.ATT + 1]
	var y := s[RB.ATT + 2]
	var z := s[RB.ATT + 3]
	return [
		PackedFloat64Array([1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - w * z), 2.0 * (x * z + w * y)]),
		PackedFloat64Array([2.0 * (x * y + w * z), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - w * x)]),
		_down_row(s),
	]


static func _down_row(s: PackedFloat64Array) -> PackedFloat64Array:
	var w := s[RB.ATT]
	var x := s[RB.ATT + 1]
	var y := s[RB.ATT + 2]
	var z := s[RB.ATT + 3]
	return PackedFloat64Array([2.0 * (x * z - w * y), 2.0 * (y * z + w * x), 1.0 - 2.0 * (x * x + y * y)])


static func _finite_array(values: PackedFloat64Array) -> bool:
	for value: float in values:
		if not is_finite(value):
			return false
	return true
