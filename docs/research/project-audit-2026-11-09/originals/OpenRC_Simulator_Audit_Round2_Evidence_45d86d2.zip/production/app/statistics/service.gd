## UI-FS: app-owned observation service. No inputs, forces or solver checkpoint mutation.
extends Node

const AircraftIdentity := preload("res://statistics/aircraft_identity.gd")
const Catalog := preload("res://app_state/aircraft_catalog.gd")
const Rules := preload("res://statistics/rules.gd")
const StoreSchema := preload("res://statistics/schema.gd")
const FlightEvent := preload("res://statistics/flight_event.gd")

signal changed
## One detached ordered batch after classifier output is ingested. Subscribers
## share this service's classifier; they must not instantiate parallel timers.
signal flight_events_accepted(events: Array)
var note := ""
## `delete_history` remains a bool; this receipt distinguishes refusal from
## a committed deletion whose durable cleanup needs recovery.
var last_delete_outcome: Dictionary = {status = "none", note = "", available = false, revision = -1}
var revision: int = 0
var data: Dictionary = {}
var store: RefCounted
var detector: RefCounted
var adapter: RefCounted
var persistent := false
var _session: Node
var _aircraft_id := ""
var _aircraft_name := ""
var _metadata: Dictionary = {}
var _active_record: Dictionary = {}
var _generation := ""
var _last_operation := -1
var _last_flush_time := 0.0
var _dirty := false
var _flush_requested := false
var _suspended := false
var _branch := false
var _closed := false
var _query_cache: Dictionary = {}
var _summary_cache: Dictionary = {}
var _query_bucket := -1
var _retry_after_msec := 0
var _writer: RefCounted
var _write_revision := -1
var _write_time := 0.0
var _write_tick := 0
var _durable_tick := 0
var _save_error := ""
var _available := true
var _opened_read_only := false
var _deletion_session_close_needed := false
var _failure_seen_generation := ""
var _pending_failure: Dictionary = {}
var _last_closed_generation := ""
var _last_closed_record_id := ""
var _last_closed_tick := -1


func setup(path: String = "user://flight_statistics", save: bool = true) -> bool:
	persistent = save
	store = load("res://statistics/store.gd").new()
	_writer = load("res://statistics/writer.gd").new()
	if save:
		store.open(path)
		_available = not store.data.is_empty()
		data = store.data.duplicate(true)
		note = store.note
	else:
		data = load("res://statistics/schema.gd").create(_uuid())
	if data.is_empty():
		data = load("res://statistics/schema.gd").create(_uuid())
	_opened_read_only = save and not store.writable
	if not save or store.writable:
		_recover()
	return not save or store.writable


func _uuid() -> String:
	return Crypto.new().generate_random_bytes(16).hex_encode()


func _next_sequence() -> int:
	data.sequence = int(data.get("sequence", 0)) + 1
	return int(data.sequence)


func _utc() -> String:
	return Time.get_datetime_string_from_system(true)


func _recover() -> void:
	var recovered := false
	for record: Dictionary in data.records:
		if record.get("kind") == "flight" and record.get("outcome") == "active":
			record.outcome = "interrupted"
			record.complete_observation = false
			record.end_seq = _next_sequence()
			record.ended_utc = _utc()
			recovered = true
	data.active_context = {}
	if bool(data.get("clean_exit", true)):
		data.current_session = ""
	if recovered:
		note = "Interrupted flight recovered. Only saved airborne time is included."
		_mark_dirty()
		flush()


func _ensure_session() -> void:
	if not str(data.get("current_session", "")).is_empty():
		return
	data.current_session = _uuid()
	data.sessions.append({id = data.current_session, opened_utc = _utc(), closed_utc = "", status = "open"})


func begin_activity(session: Node, aircraft_id: String, aircraft_name: String, metadata: Dictionary = {}) -> void:
	if session == null or (persistent and not store.writable):
		return
	if _session == session:
		resume_activity()
		return
	if not end_activity("abandoned"):
		return
	_ensure_session()
	_opened_read_only = false # This service has now taken responsibility for a session.
	_session = session
	_aircraft_id = aircraft_id
	_aircraft_name = aircraft_name
	_metadata = metadata.duplicate(true)
	_generation = _uuid()
	_clear_failure_observation()
	_last_operation = -1
	_branch = false
	_suspended = false
	data.clean_exit = false
	adapter = load("res://statistics/fixed_wing_adapter.gd").new()
	adapter.configure(session, aircraft_id, Callable(self, "_observe"), Callable(self, "_may_observe"))
	# Session receipt generations are local counters. Persisted event identity uses
	# this service's globally unique activity namespace, including fresh sessions.
	adapter.profile.generation_id = _generation
	_set_event_identity()
	detector = load("res://statistics/detector.gd").new()
	detector.configure(adapter.profile, session.start_choice != "runway")
	_session.statistics_lifecycle.connect(_lifecycle)
	_session.sim.paused_changed.connect(_paused)
	_attach_failure_observer()
	adapter.attach()
	_last_flush_time = float(session.sim.time())
	_mark_dirty()
	_flush_requested = true


func _may_observe() -> bool:
	return not _suspended and not _branch and detector != null


func _clear_failure_observation() -> void:
	_failure_seen_generation = ""
	_pending_failure = {}
	_last_closed_generation = ""
	_last_closed_record_id = ""
	_last_closed_tick = -1


func _attach_failure_observer() -> void:
	if is_instance_valid(_session) and _session.has_signal("failure_changed") \
			and not _session.is_connected("failure_changed", _failure_changed):
		_session.connect("failure_changed", _failure_changed)


func _detach_failure_observer() -> void:
	if is_instance_valid(_session) and _session.has_signal("failure_changed") \
			and _session.is_connected("failure_changed", _failure_changed):
		_session.disconnect("failure_changed", _failure_changed)


## Only a committed session notification is evidence of an actual failure.
## This signal precedes the statistics stepped observer; a same-tick contact
## may already have closed its record, or flight admission may still be pending.
func _failure_changed() -> void:
	if not _may_observe() or not is_instance_valid(_session) or not _session.has_method("failure_status") \
			or _generation.is_empty() or _failure_seen_generation == _generation:
		return
	var owner: Node = _session
	var generation: String = _generation
	var status: Variant = owner.failure_status()
	if not _may_observe() or _session != owner or _generation != generation or not status is Dictionary \
			or typeof(status.get("active")) != TYPE_BOOL or not status.active \
			or typeof(status.get("activation_tick")) != TYPE_INT \
			or int(status.activation_tick) <= 0 or int(status.activation_tick) != owner.sim.tick \
			or typeof(status.get("event_id")) != TYPE_STRING or not StoreSchema._safe_id(status.event_id):
		return
	var event := {type = "failure_activated", failure_id = status.event_id, tick = status.activation_tick,
		source = "accepted_failure_signal_v1"}
	_failure_seen_generation = generation
	if _last_closed_generation == generation and _last_closed_tick == int(status.activation_tick):
		for index: int in range(data.records.size() - 1, -1, -1):
			if str(data.records[index].get("id", "")) == _last_closed_record_id:
				var record: Dictionary = data.records[index].duplicate(true)
				_append_record_event(record, event)
				data.records[index] = record
				_mark_dirty()
				_flush_requested = true
				return
		# Never attach this tick's event to a subsequently opened flight.
		return
	if not _active_record.is_empty():
		_append_event(event)
		_upsert(_active_record)
		_mark_dirty()
		_flush_requested = true
		return
	if str(detector.get("_phase")) != "terminal":
		_pending_failure = {generation = generation, event = event}


## Existing records own detached metadata. Only future records lose provenance.
func invalidate_launch_context(scenario_only: bool = false) -> void:
	_metadata.erase("scenario")
	if not scenario_only:
		for key: String in ["launch_context_format", "failure_config", "failure_seed"]:
			_metadata.erase(key)


func _observe(sample: Dictionary) -> void:
	if not _may_observe():
		return
	_ingest(detector.observe(sample))
	if not _pending_failure.is_empty() and str(detector.get("_phase")) == "terminal":
		_pending_failure = {}
	var bucket: int = int(sample.get("tick", 0)) / 24
	if bucket != _query_bucket:
		_query_cache.clear()
		_query_bucket = bucket
	if is_instance_valid(_session):
		var observed_time: float = float(_session.sim.time())
		# An in-flight snapshot already covers its scheduled time. A later event
		# or pause keeps its independent request, and a long write can still
		# accumulate another five simulated seconds before it completes.
		var checkpoint_time: float = _write_time if _writer != null and _writer.pending() else _last_flush_time
		if observed_time - checkpoint_time >= 5.0:
			_flush_requested = true


func _record(kind: String) -> Dictionary:
	return {kind = kind, id = _uuid(), seq = _next_sequence(), session_id = data.current_session,
		aircraft_id = _aircraft_id, aircraft_name = _aircraft_name, utc = _utc(),
		account_epoch = int(data.epochs.get("account", 0)),
		aircraft_epoch = int(data.epochs.get("aircraft", {}).get(_aircraft_id, 0)),
		metadata = _metadata.duplicate(true)}


func _ingest(events: Array) -> void:
	var semantic: Array[Dictionary] = []
	for event: Dictionary in events:
		match str(event.get("type", "")):
			"semantic":
				if not FlightEvent.valid(event.get("event")): continue
				semantic.append(event.event.duplicate(true))
				_append_semantic_event(event.event)
			"started":
				_active_record = _record("flight")
				_active_record.end_seq = -1
				_active_record.merge(event.get("flight", {}), true)
				_active_record.config_hash = str(_metadata.get("config_hash", ""))
				_active_record.rules_version = Rules.VERSION
				_active_record.start_kind = event.get("start_kind", "takeoff")
				_active_record.metadata.events = []
				var admitted_failure: Dictionary = {}
				if not _pending_failure.is_empty():
					var start_tick: int = int(detector.get("_first_unsupported_tick"))
					if _pending_failure.generation == _generation and start_tick >= 0 \
							and int(_pending_failure.event.tick) >= start_tick \
							and int(_pending_failure.event.tick) <= int(event.get("tick", -1)):
						admitted_failure = _pending_failure.event
					_pending_failure = {}
				if not admitted_failure.is_empty() and int(admitted_failure.tick) < int(event.get("tick", -1)):
					_append_event(admitted_failure)
				_append_event(event)
				if not admitted_failure.is_empty() and int(admitted_failure.tick) == int(event.get("tick", -1)):
					_append_event(admitted_failure)
				_update_active()
			"landing":
				_append_event(event)
			"accident", "accident_updated":
				_append_event(event)
				if bool(event.get("terminal", false)):
					# Escalation updates the original generation-latched counter record.
					# It must not create another crash or lose the earlier gear-up cause.
					for index: int in range(data.records.size() - 1, -1, -1):
						var record: Dictionary = data.records[index]
						if record.get("kind") == "crash" and not str(event.get("accident_id", "")).is_empty() \
								and record.metadata.get("activity_generation") == _generation \
								and record.metadata.get("accident_id") == event.accident_id:
							# Background snapshots share immutable record entries. Replace,
							# never mutate the object a writer may already be serializing.
							record = record.duplicate(true)
							record.metadata.terminal = true
							record.metadata.terminal_event_id = event.get("event_id", "")
							data.records[index] = record
							break
			"closed":
				if not _active_record.is_empty():
					_append_event(event)
					_active_record.merge(event.get("flight", {}), true)
					_active_record.outcome = str(event.get("outcome", _active_record.get("outcome", "interrupted")))
					if _active_record.outcome == "interrupted":
						_active_record.complete_observation = false
					_active_record.end_seq = _next_sequence()
					_active_record.ended_utc = _utc()
					_upsert(_active_record)
					_last_closed_generation = _generation
					_last_closed_record_id = str(_active_record.id)
					_last_closed_tick = int(event.get("tick", -1))
					_active_record = {}
			"crash":
				_append_event(event)
				var crash: Dictionary = _record("crash")
				crash.metadata.ground = bool(event.get("ground", false))
				crash.metadata.terminal = bool(event.get("terminal", true))
				crash.metadata.activity_generation = _generation
				for key: String in ["accident_id", "event_id", "rules_version", "kind"]:
					if event.has(key): crash.metadata[key] = event[key]
				if event.has("damage_summary"): _copy_damage_summary(crash.metadata, event.damage_summary)
				data.records.append(crash)
		_mark_dirty()
		_flush_requested = true
	if not semantic.is_empty(): flight_events_accepted.emit(FlightEvent.frozen_batch(semantic))


func _set_event_identity() -> void:
	adapter.profile.activity_id = _generation
	adapter.profile.aircraft_id = _aircraft_id
	adapter.profile.configuration_hash = str(_metadata.get("config_hash", ""))
	adapter.profile.field_hash = str(_metadata.get("field_hash", ""))


## This is bounded flight detail, not a comprehensive accident archive. Keep
## the full semantic packet on the subscriber bus and a compact record here.
func _append_semantic_event(event: Dictionary) -> void:
	var compact := {type = event.type, tick = event.accepted_tick,
		event_id = event.event_id, accident_id = event.accident_id, terminal = event.terminal,
		rules_version = event.rules_version, contact_episode_id = event.contact_episode_id,
		revision = event.revision, measurements = event.measurements.duplicate(true)}
	if int(event.version) == FlightEvent.DAMAGE_VERSION:
		compact.law_identity = event.law_identity
		compact.contact_ids = event.contact_ids.duplicate()
		compact.component_ids = event.component_ids.duplicate()
		compact.physical_evidence = event.physical_evidence.duplicate(true)
	_append_event(compact)


func _append_event(event: Dictionary) -> void:
	if _active_record.is_empty():
		return
	_append_record_event(_active_record, event)


func _append_record_event(record: Dictionary, event: Dictionary) -> void:
	var timeline: Array = record.metadata.get("events", [])
	# Bounded event detail: aggregate counters continue after the detail limit.
	if timeline.size() >= 128:
		record.metadata.events_omitted = int(record.metadata.get("events_omitted", 0)) + 1
		return
	var entry: Dictionary = {}
	for key: String in ["type", "kind", "outcome", "reason", "tick", "first_contact_tick", "start_kind",
			"accident_id", "event_id", "failure_id", "source", "rules_version", "terminal", "ground", "contact_episode_id", "revision", "measurements", "law_identity", "contact_ids", "component_ids", "physical_evidence"]:
		if event.has(key): entry[key] = event[key]
	# Shared semantic detail contains longer identities and measurements. Preserve
	# the existing store's byte contract as well as the 128-event count limit.
	var candidate: Dictionary = record.metadata.duplicate(true)
	var expanded: Array = timeline.duplicate(true)
	expanded.append(entry.duplicate(true))
	candidate.events = expanded
	candidate.events_omitted = int(candidate.get("events_omitted", 0))
	if var_to_bytes(candidate).size() > StoreSchema.MAX_METADATA_BYTES - 256:
		record.metadata.events_omitted = int(record.metadata.get("events_omitted", 0)) + 1
		return
	timeline.append(entry)
	record.metadata.events = timeline


func _update_active() -> void:
	if _active_record.is_empty() or detector == null or detector.flight.is_empty():
		return
	_active_record.merge(detector.flight, true)
	# A live observation has no terminal boundary yet; detector continuity is retained
	# in its checkpoint and copied into the record only when the flight closes.
	_active_record.complete_observation = false
	_upsert(_active_record)


func _upsert(record: Dictionary) -> void:
	for i: int in range(data.records.size() - 1, -1, -1):
		if data.records[i].id == record.id:
			data.records[i] = record.duplicate(true)
			return
	data.records.append(record.duplicate(true))


func _mark_dirty() -> void:
	_dirty = true
	revision += 1
	_query_cache.clear()
	_summary_cache.clear()
	changed.emit()


func _paused(_paused_value: bool) -> void:
	_flush_requested = true


func _lifecycle(receipt: Dictionary) -> void:
	var operation: int = int(receipt.get("operation_id", -1))
	if operation <= _last_operation or not receipt.get("success", false):
		return
	_last_operation = operation
	var cause: String = str(receipt.get("cause", "restart"))
	if cause == "checkpoint_restore":
		_ingest(detector.end("interrupted"))
		_branch = true
		_clear_failure_observation()
		invalidate_launch_context()
		note = "Checkpoint experiment: flight statistics are not recorded until Restart."
	else:
		if not _branch:
			_ingest(detector.end("restarted"))
			var restart: Dictionary = _record("restart")
			restart.metadata.cause = cause
			data.records.append(restart)
		_branch = false
		_generation = _uuid()
		_clear_failure_observation()
		adapter.configure(_session, _aircraft_id, Callable(self, "_observe"), Callable(self, "_may_observe"))
		adapter.profile.generation_id = _generation
		_metadata.config_hash = str(_session.aircraft.get("input_identity", {}).get("sha256", ""))
		_set_event_identity()
		detector.configure(adapter.profile, _session.start_choice != "runway")
		_last_flush_time = float(_session.sim.time())
	_mark_dirty()
	_flush_requested = true


func suspend_activity() -> void:
	_detach_failure_observer()
	if adapter != null:
		adapter.detach()
	_suspended = true
	flush()


func resume_activity() -> void:
	_suspended = false
	_attach_failure_observer()
	if adapter != null:
		adapter.attach()


func end_activity(reason: String = "abandoned", discard_unsaved: bool = false, close_session: bool = false) -> bool:
	_finish_write()
	if detector == null:
		if close_session and not discard_unsaved:
			# A store opened read-only never began a session here; its existing history belongs to another writer.
			# A clean idle store can also become read-only after a deletion receipt;
			# there is no unsaved flight to write while deletion recovery is pending.
			var deletion_read_only: bool = str(last_delete_outcome.get("status", "none")) != "none"
			if (_opened_read_only or deletion_read_only) and persistent and not store.writable and not _dirty:
				if _opened_read_only:
					return true
				if data.is_empty() and _deletion_session_close_needed:
					note = "Statistics session could not be closed while deletion survivors are unavailable."
					return false
				if data.is_empty() or str(data.get("current_session", "")).is_empty() \
						or bool(data.get("clean_exit", true)):
					return true
				if str(last_delete_outcome.get("status", "none")) not in ["committed_pending", "completed"]:
					note = store.note if not store.note.is_empty() else "Statistics session could not be closed while the store is read-only."
					return false
				# A real retained session still needs a durable close. Retry the same
				# fenced recovery used on reopen; never silently resume it as a new session.
				if not store.recover_pending_deletion():
					note = store.note if not store.note.is_empty() else "Statistics session could not be closed while deletion recovery is pending."
					return false
				data = store.data.duplicate(true)
				_available = true
				note = store.note
				revision += 1
				last_delete_outcome = {status = "completed", note = note, available = true, revision = revision}
				_query_cache.clear()
				_summary_cache.clear()
				changed.emit()
			var previous_idle_data: Dictionary = data.duplicate(true)
			_close_session_record()
			if flush(false):
				_deletion_session_close_needed = false
				return true
			# Cancel must leave this still-running session open, even with no active flight.
			data = previous_idle_data
			_query_cache.clear()
			_summary_cache.clear()
			return false
		return true
	var previous_data: Dictionary = data.duplicate(true)
	var previous_record: Dictionary = _active_record.duplicate(true)
	var previous_detector: Dictionary = detector.snapshot()
	var previous_failure := {seen = _failure_seen_generation, pending = _pending_failure.duplicate(true),
		closed_generation = _last_closed_generation, closed_id = _last_closed_record_id, closed_tick = _last_closed_tick}
	if detector != null:
		_ingest(detector.end(reason))
	data.active_context = {}
	if close_session:
		_close_session_record()
	if not discard_unsaved and not flush(false):
		data = previous_data
		_active_record = previous_record
		detector.restore(previous_detector)
		_failure_seen_generation = previous_failure.seen
		_pending_failure = previous_failure.pending
		_last_closed_generation = previous_failure.closed_generation
		_last_closed_record_id = previous_failure.closed_id
		_last_closed_tick = previous_failure.closed_tick
		_query_cache.clear()
		_summary_cache.clear()
		return false
	if adapter != null:
		adapter.detach()
	_detach_failure_observer()
	if is_instance_valid(_session):
		if _session.statistics_lifecycle.is_connected(_lifecycle):
			_session.statistics_lifecycle.disconnect(_lifecycle)
		if _session.sim.paused_changed.is_connected(_paused):
			_session.sim.paused_changed.disconnect(_paused)
	_session = null
	adapter = null
	detector = null
	_active_record = {}
	_clear_failure_observation()
	data.active_context = {}
	_query_cache.clear()
	_summary_cache.clear()
	if discard_unsaved:
		_flush_requested = false
		_dirty = false
		if persistent:
			data = store.data.duplicate(true)
			for record: Dictionary in data.records:
				if record.get("outcome") == "active":
					record.outcome = "interrupted"
					record.complete_observation = false
					record.end_seq = _next_sequence()
			data.active_context = {}
	return true


func _process(_delta: float) -> void:
	if _writer != null:
		_accept_write(_writer.poll())
	if _flush_requested and Time.get_ticks_msec() >= _retry_after_msec:
		if _writer != null and _writer.pending(): return
		_flush_requested = false
		if not persistent:
			flush()
		else:
			_update_active()
			_capture_context()
			_write_revision = revision
			_write_time = float(_session.sim.time()) if is_instance_valid(_session) else 0.0
			_write_tick = int(_session.sim.tick) if is_instance_valid(_session) else 0
			if not _writer.start(store, _write_snapshot()):
				_flush_requested = true


func _capture_context() -> void:
	if detector != null and is_instance_valid(_session):
		data.active_context = {generation_id = _generation, aircraft_id = _aircraft_id,
			tick = int(_session.sim.tick), detector = detector.snapshot(), suspended = _suspended}


func _write_snapshot() -> Dictionary:
	# Ledger entries are immutable after insertion: _upsert replaces the dictionary.
	# Copy the array, not every historical record, so the worker owns a stable view.
	# Mutable root containers and active checkpoint are detached explicitly.
	var snapshot := data.duplicate(false)
	snapshot.records = data.records.duplicate(false)
	snapshot.sessions = data.sessions.duplicate(true)
	snapshot.epochs = data.epochs.duplicate(true)
	snapshot.active_context = data.get("active_context", {}).duplicate(true)
	return snapshot


func _accept_write(result: Dictionary) -> void:
	if result.is_empty(): return
	if bool(result.get("ok", false)):
		data.generation = int(result.generation)
		_dirty = revision != _write_revision
		_last_flush_time = _write_time
		_durable_tick = _write_tick
		if note == _save_error: note = ""
		_save_error = ""
	else:
		note = str(result.get("note", "Statistics could not be saved."))
		_save_error = note
		_retry_after_msec = Time.get_ticks_msec() + 5000
		_flush_requested = true
	_query_cache.clear()
	changed.emit()


func _finish_write() -> void:
	if _writer != null: _accept_write(_writer.finish())


func flush(capture_context: bool = true) -> bool:
	_finish_write()
	if data.is_empty():
		return _available
	_update_active()
	if capture_context: _capture_context()
	var ok: bool = not persistent or store.commit(data)
	if ok:
		_dirty = false
		_flush_requested = false
		_retry_after_msec = 0
		if persistent:
			data = store.data.duplicate(true)
		if is_instance_valid(_session):
			_last_flush_time = float(_session.sim.time())
			_durable_tick = int(_session.sim.tick)
		if note == _save_error: note = ""
		_save_error = ""
	else:
		note = store.note
		_save_error = note
		_retry_after_msec = Time.get_ticks_msec() + 5000
	_query_cache.clear()
	return ok


func query(aircraft_id: String = "", period: String = "session") -> Dictionary:
	if period == "since_reset": period = "counters"
	var key: String = aircraft_id + ":" + period
	if not _query_cache.has(key):
		_update_active()
		var result: Dictionary = load("res://statistics/reducer.gd").query(data, aircraft_id, period)
		result.revision = revision
		result.available = _available and bool(result.get("available", false))
		result.has_lifetime_history = not data.get("records", []).is_empty()
		result.tracking_started_utc = str(data.get("tracking_started_utc", ""))
		result.durable_tick = _durable_tick
		result.save_pending = _dirty or (_writer != null and _writer.pending())
		_query_cache[key] = result
	return _query_cache[key].duplicate(true)


## HUD summaries retain the event rollup, adding only current-flight scalar deltas.
## The complete ledger is not validated/copied for every rendered HUD refresh.
func summary(aircraft_id: String = "", period: String = "session") -> Dictionary:
	if period == "since_reset": period = "counters"
	var key := aircraft_id + ":" + period
	if not _summary_cache.has(key):
		_update_active()
		var result: Dictionary = load("res://statistics/reducer.gd").query(data, aircraft_id, period, "", false)
		var included := not _active_record.is_empty() and (aircraft_id.is_empty() or AircraftIdentity.matches(aircraft_id, _aircraft_id))
		_summary_cache[key] = {"result": result, "active_id": str(_active_record.get("id", "")) if included else "",
			"seconds": float(_active_record.get("airborne_seconds", 0.0)) if included else 0.0}
	var cached: Dictionary = _summary_cache[key]
	var result: Dictionary = cached.result.duplicate(true)
	if detector != null and not detector.flight.is_empty() and not str(cached.active_id).is_empty() \
			and str(cached.active_id) == str(_active_record.get("id", "")):
		var delta_seconds := maxf(0.0, float(detector.flight.airborne_seconds) - float(cached.seconds))
		result.airborne_seconds = float(result.airborne_seconds) + delta_seconds
		result.current_clean_seconds = float(result.current_clean_seconds) + delta_seconds
		result.best_clean_seconds = maxf(float(result.best_clean_seconds), float(result.current_clean_seconds))
		result.max_tas_mps = maxf(float(result.max_tas_mps), float(detector.flight.max_tas_mps))
		result.max_groundspeed_mps = maxf(float(result.max_groundspeed_mps), float(detector.flight.max_groundspeed_mps))
	result.revision = revision
	result.available = _available and bool(result.get("available", false))
	return result


func aircraft_choices() -> Array:
	var choices: Array = []
	var seen: Dictionary = {}
	for record: Dictionary in data.get("records", []):
		if str(record.get("kind", "")) == "gap":
			continue
		var id: String = str(record.get("aircraft_id", ""))
		var related: PackedStringArray = AircraftIdentity.related(id)
		var display_name: String = str(record.get("aircraft_name", id))
		if related.size() == 2:
			# Follow the installed catalog during the staged transition; records keep their IDs.
			id = related[1] if Catalog.has("moonrunner-x99") else related[0]
			var catalog_id: String = "moonrunner-x99" if Catalog.has("moonrunner-x99") else "skywalker-x8"
			display_name = str(Catalog.entry(catalog_id).get("name", display_name))
			# Bare catalog IDs and stock:-prefixed IDs have no proven shared origin.
			# Keep their scopes separate and expose the selected namespace in the label.
			if id.begins_with("stock:"):
				display_name += " · " + id
		if not id.is_empty() and not seen.has(id):
			seen[id] = true
			choices.append({id = id, name = display_name})
	return choices


func can_manage() -> bool:
	return _available and _session == null and not _dirty and (_writer == null or not _writer.pending()) \
		and (not persistent or store.writable)


func reset_counters(scope: String, aircraft_id: String = "") -> bool:
	if not can_manage():
		return false
	var candidate: Dictionary = load("res://statistics/reducer.gd").reset(data, scope, aircraft_id, _uuid(), _utc())
	if candidate.is_empty():
		return false
	if persistent and not store.commit(candidate):
		note = store.note
		return false
	data = store.data.duplicate(true) if persistent else candidate
	_query_cache.clear()
	_summary_cache.clear()
	revision += 1
	changed.emit()
	return true


func delete_history(aircraft_id: String = "") -> bool:
	# The writer owns store.data until its thread has joined; it must not race
	# the deletion fence with a snapshot captured before that fence.
	_finish_write()
	if not can_manage():
		revision += 1
		last_delete_outcome = {status = "refused", note = note, available = _available, revision = revision}
		_query_cache.clear()
		_summary_cache.clear()
		changed.emit()
		return false
	if not persistent:
		# Sandbox UI exercises the same deletion reducer through an isolated temporary store in tests.
		note = "History management is unavailable in this temporary session."
		revision += 1
		last_delete_outcome = {status = "refused", note = note, available = _available, revision = revision}
		_query_cache.clear()
		_summary_cache.clear()
		changed.emit()
		return false
	var had_open_session: bool = not str(data.get("current_session", "")).is_empty() and not bool(data.get("clean_exit", true))
	var succeeded: bool = store.delete_history(aircraft_id)
	last_delete_outcome = store.last_delete_outcome.duplicate(true)
	note = store.note
	if str(last_delete_outcome.get("status", "refused")) != "refused":
		_deletion_session_close_needed = not aircraft_id.is_empty() and had_open_session
		data = store.data.duplicate(true)
		_available = bool(last_delete_outcome.get("available", false)) and not data.is_empty()
		_dirty = false
		_flush_requested = false
		_retry_after_msec = 0
	elif not store.writable:
		# Admission required a clean ledger, so no unsaved observation is lost.
		_flush_requested = false
	_query_cache.clear()
	_summary_cache.clear()
	revision += 1
	last_delete_outcome["revision"] = revision
	changed.emit()
	return succeeded


func finish(discard_unsaved: bool = false) -> bool:
	return end_activity("abandoned", discard_unsaved, true)


func _close_session_record() -> void:
	data.clean_exit = true
	for entry: Dictionary in data.get("sessions", []):
		if entry.id == data.current_session:
			entry.closed_utc = _utc()
			entry.status = "closed"


func close() -> void:
	if _closed:
		return
	_closed = true
	_finish_write()
	end_activity("interrupted", true)
	if store != null:
		store.close()


func _exit_tree() -> void:
	close()

## Keep bounded first-failure detail on the existing M7 record even before a
## flight timeline exists. This is not a separate per-accident archive.
func _copy_damage_summary(metadata: Dictionary, values: Variant) -> void:
	if typeof(values) != TYPE_ARRAY or values.size() > 16: return
	for record: Variant in values:
		if typeof(record) != TYPE_DICTIONARY or typeof(record.get("physical_evidence")) != TYPE_DICTIONARY \
			or typeof(record.get("measurements")) != TYPE_DICTIONARY \
			or typeof(record.measurements.get("sample_interval_s")) not in [TYPE_FLOAT, TYPE_INT] \
			or not FlightEvent._integer(record.get("accepted_tick")): return
		if not FlightEvent.valid_damage_record(record, int(record.accepted_tick), record.physical_evidence.get("source_generation_id"),
			record.physical_evidence.get("response_identity"), float(record.measurements.sample_interval_s)): return
	var retained: Array = []
	var omitted := 0
	for record: Dictionary in values:
		var candidate := metadata.duplicate(true)
		var expanded := retained.duplicate(true)
		expanded.append(record.duplicate(true))
		candidate.component_damage = expanded
		candidate.component_damage_omitted = omitted
		if var_to_bytes(candidate).size() > StoreSchema.MAX_METADATA_BYTES - 256:
			omitted += 1
		else: retained = expanded
	var candidate := metadata.duplicate(true)
	candidate.component_damage = retained
	candidate.component_damage_omitted = omitted
	if var_to_bytes(candidate).size() <= StoreSchema.MAX_METADATA_BYTES - 256:
		metadata.component_damage = retained
		metadata.component_damage_omitted = omitted
