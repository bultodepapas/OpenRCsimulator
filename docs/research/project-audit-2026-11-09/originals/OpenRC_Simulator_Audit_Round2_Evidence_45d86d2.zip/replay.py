"""Portable replay adapter. Copies modified projects/probes; never patches the checkout."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
PIN='45d86d250f6e38a3d9b60d30c01bdc2396571efe'; ENGINE='4.8.beta2.official.cafc17a19'
OLD_ROOT='/workspace/scratch/30a3be555435/audit_round2/'
commands={r['label']:r for r in json.loads((ROOT/'audit_commands.json').read_text())}
variants={r['key']:r for r in json.loads((ROOT/'diagnostic_variant_manifest.json').read_text())}
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('run',choices=list(commands)); p.add_argument('--godot',type=Path,required=True)
p.add_argument('--repo',type=Path,help='Complete, imported pinned checkout; required except quarantine-reopen')
p.add_argument('--out',type=Path,required=True,help='New output directory')
p.add_argument('--prepare-only',action='store_true',help='Prepare copies and a JSON command, without executing Godot')
args=p.parse_args(); out=args.out.resolve(); engine=args.godot.resolve(); item=commands[args.run]
if out.exists(): p.error('--out must be a new directory')
subprocess.run([sys.executable,str(ROOT/'verify.py')],check=True)
if args.repo:
 args.repo=args.repo.resolve()
 head=subprocess.check_output(['git','-C',str(args.repo),'rev-parse','HEAD'],text=True).strip()
 if head!=PIN: p.error('repository HEAD differs from pinned commit')
 if subprocess.run(['git','-C',str(args.repo),'diff','--quiet',PIN,'--','app','tools/godot/run_checked.py']).returncode:
  p.error('tracked application/runner changes must be isolated before replay')
if item['variant']!='isolated' and not args.repo: p.error('--repo is required for this witness')
if not args.prepare_only:
 version=subprocess.check_output([str(engine),'--version'],text=True).strip()
 if version!=ENGINE: p.error('engine differs from recorded version: '+version)
out.mkdir(parents=True)
record=json.loads((ROOT/item['receipt']).read_text()); cmd=list(record['command']); cmd[0]=str(engine)
if item['variant']=='isolated':
 project=out/'isolated_project'
 shutil.copytree(ROOT/'audit_round2/persistence/isolated_project',project)
elif item['variant']=='pinned': project=args.repo/'app'
else:
 # Fully copy the already-imported project at replay time, including its local import
 # products if present. Dereference links so the candidate cannot write through to
 # the user's original application. No such assets/caches ship in the evidence ZIP.
 project=out/'candidate_app'; shutil.copytree(args.repo/'app',project,symlinks=False)
 v=variants[item['variant']]; target=project/v['source'].removeprefix('app/')
 data=target.read_bytes(); base=(ROOT/v['base_packaged_path']).read_bytes()
 if data!=base: p.error('candidate target differs from pinned source before substitution')
 target.write_bytes((ROOT/v['candidate_packaged_path']).read_bytes())
 (out/'diagnostic_variant.json').write_text(json.dumps(v,indent=2)+'\n')
cmd[cmd.index('--path')+1]=str(project)
idx=cmd.index('--script')+1; original=cmd[idx]
if not original.startswith(OLD_ROOT): p.error('unrecognized original probe path')
source=ROOT/'audit_round2'/original[len(OLD_ROOT):]
content=source.read_text()
if OLD_ROOT in content:
 sidecars=out/'sidecars'; (sidecars/'performance').mkdir(parents=True)
 adapter=out/(source.stem+'_output_path_adapter.gd')
 adapter.write_text(content.replace(OLD_ROOT,str(sidecars)+'/'))
 cmd[idx]=str(adapter)
 (out/'adapter_provenance.json').write_text(json.dumps({'original':str(source),'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'adapter':str(adapter),'replacement':'Output directory prefix only','before':OLD_ROOT,'after':str(sidecars)+'/'},indent=2)+'\n')
else: cmd[idx]=str(source)
runner=ROOT/'production/tools/godot/run_checked.py'
wrapped=[sys.executable,str(runner),'--timeout',str(record['timeout_seconds']),'--out-dir',str(out/'checks'),'--label',record['label']+'-replay']
for marker in record['required_text']: wrapped+=['--require-text',marker]
wrapped+=['--',*cmd]
environment=os.environ.copy(); environment['XDG_DATA_HOME']=str(out/'userdata'); environment['APPDATA']=str(out/'userdata')
context={'command':wrapped,'cwd':str(args.repo or out),'original_receipt':item['receipt'],'variant':item['variant'],'environment_overrides':{'XDG_DATA_HOME':environment['XDG_DATA_HOME'],'APPDATA':environment['APPDATA']},'scope':'Fresh replay. Original receipt artifacts unchanged.'}
(out/'replay_command.json').write_text(json.dumps(context,indent=2)+'\n')
if args.prepare_only:
 print('Prepared replay_command.json; no Godot process executed.'); raise SystemExit(0)
raise SystemExit(subprocess.run(wrapped,cwd=context['cwd'],env=environment).returncode)
