"""Verify package hashes, original receipts, pinned blobs and diagnostic substitutions."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(); p.add_argument('--repo',type=Path); args=p.parse_args()
def digest(b): return hashlib.sha256(b).hexdigest()
issues=[]; count=0
for line in (ROOT/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1); path=ROOT/name; count+=1
 if not path.is_file() or digest(path.read_bytes())!=expected: issues.append(name)
receipts=json.loads((ROOT/'receipt_hash_verification.json').read_text())
for item in receipts:
 folder=ROOT/item['receipt']; report=json.loads((folder/'report.json').read_text()); data=(folder/'engine.log').read_bytes()
 if digest(data)!=report['log_sha256'] or len(data)!=report['log_bytes']: issues.append(item['receipt'])
for item in json.loads((ROOT/'original_artifact_manifest.json').read_text()):
 data=(ROOT/item['packaged_path']).read_bytes()
 if digest(data)!=item['sha256'] or len(data)!=item['bytes']: issues.append(item['packaged_path']+' original-copy')
sources=json.loads((ROOT/'production_source_manifest.json').read_text())
for item in sources:
 data=(ROOT/item['packaged_path']).read_bytes()
 oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if digest(data)!=item['sha256'] or oid!=item['git_blob_oid']: issues.append(item['packaged_path']+' pinned-blob')
 if args.repo:
  pinned=subprocess.check_output(['git','-C',str(args.repo),'show',item['commit']+':'+item['repository_path']])
  if pinned!=data: issues.append(item['packaged_path']+' pinned-repository-source')
variants=json.loads((ROOT/'diagnostic_variant_manifest.json').read_text())
for item in variants:
 base=(ROOT/item['base_packaged_path']).read_bytes(); changed=(ROOT/item['candidate_packaged_path']).read_bytes()
 if digest(base)!=item['base_sha256'] or digest(changed)!=item['candidate_sha256'] or base.count(item['before'].encode())!=1 or base.replace(item['before'].encode(),item['after'].encode(),1)!=changed:
  issues.append(item['key']+' exact-diagnostic-substitution')
print(json.dumps({'checksummed_files':count,'original_receipts':len(receipts),'pinned_source_copies':len(sources),'diagnostic_variants':len(variants),'issues':issues},indent=2))
raise SystemExit(1 if issues else 0)
