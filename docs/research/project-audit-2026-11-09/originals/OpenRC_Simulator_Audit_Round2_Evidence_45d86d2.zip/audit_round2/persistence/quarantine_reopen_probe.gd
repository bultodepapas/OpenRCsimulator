extends SceneTree
const Store := preload("res://statistics/store.gd")
var rows: Array = []
var valid := true

func write_bad(uri: String, slot: String) -> void:
	var file := FileAccess.open(uri.path_join(slot), FileAccess.WRITE)
	file.store_string("audit-deliberate-corrupt-snapshot")
	file.close()

func capture(label: String, store: RefCounted, opened: bool) -> void:
	rows.append({label=label, opened=opened, writable=store.writable, owns_lock=store.get("_owns_lock"),
		generation=store.data.get("generation",-1), current_slot=store.get("_current_slot"), note=store.note})

func _initialize() -> void:
	for repair_first in [false,true]:
		var uri: String = "user://quarantine_%s_%d" % [str(repair_first),Time.get_ticks_usec()]
		var fixture := Store.new()
		valid = fixture.open(uri) and valid
		valid = fixture.commit(fixture.data.duplicate(true)) and valid
		var bad_slot: String = fixture.get("_current_slot")
		fixture.close()
		write_bad(uri,bad_slot)
		var first := Store.new()
		var first_opened := first.open(uri)
		capture("first recovery; repair_first="+str(repair_first),first,first_opened)
		valid = first_opened and first.writable and valid
		if repair_first:
			valid = first.commit(first.data.duplicate(true)) and valid
		first.close()
		if repair_first:
			var healed := Store.new()
			var healed_opened := healed.open(uri)
			capture("healed normal reopen",healed,healed_opened)
			valid = healed_opened and healed.writable and valid
			valid = healed.commit(healed.data.duplicate(true)) and valid
			healed.close()
			write_bad(uri,bad_slot)
		var second := Store.new()
		var second_opened := second.open(uri)
		capture("repeat recovery; repair_first="+str(repair_first),second,second_opened)
		var still_owns: bool = second.get("_owns_lock")
		var save_refused := not second.commit(second.data.duplicate(true))
		var delete_refused := not second.delete_history()
		valid = second_opened and not second.writable and still_owns and save_refused and delete_refused and valid
		rows.append({label="blocked operations", repair_first=repair_first, save_refused=save_refused, delete_refused=delete_refused,
			root=ProjectSettings.globalize_path(uri),quarantine_file_exists=FileAccess.file_exists(uri.path_join("snapshot_quarantine_b.bin"))})
		second.close()
	print("AUDIT_QUARANTINE ",JSON.stringify(rows))
	print("AUDIT_QUARANTINE_REOPEN_REPRODUCED=",valid)
	quit(0 if valid else 1)
