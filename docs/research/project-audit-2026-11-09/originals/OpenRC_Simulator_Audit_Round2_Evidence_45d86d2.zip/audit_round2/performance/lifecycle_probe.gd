extends SceneTree

const Skyline = preload("res://render/sun/skyline.gd")
const Ridges = preload("res://render/landscape_upgrade/ridges.gd")
const Vegetation = preload("res://scenery/imported_vegetation.gd")
const Glare = preload("res://render/landscape_upgrade/sun_glare.gd")
const SKY_SHADER = preload("res://render/sky.gdshader")
const OUTPUT = "/workspace/scratch/30a3be555435/audit_round2/performance/lifecycle_probe.json"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var report := {}
	var packed := PackedFloat32Array([1.0, 2.0])
	var owner := {values = packed}
	var alias: PackedFloat32Array = owner.values
	alias[0] = 99.0
	report.packed_array_alias_updates_owner = owner.values[0] == 99.0
	var source := _mesh()
	source.shadow_mesh = _mesh()
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	var cache_start: int = Vegetation._foliage_shadow_mesh_cache.size()
	var ids := {}
	for repeat in 100:
		var draw := source.duplicate() as ArrayMesh
		ids[draw.shadow_mesh.get_instance_id()] = true
		Vegetation._without_sparse_foliage_lods(draw, [material])
	report.foliage_cache = {builds = 100, source_shadow_ids = ids.size(), cache_growth = Vegetation._foliage_shadow_mesh_cache.size() - cache_start}
	var host := Node3D.new()
	root.add_child(host)
	var field := Node3D.new()
	field.name = "Field"
	host.add_child(field)
	field.add_child(Ridges.build())
	var skyline := Skyline.new(field, Vector3(0.0, 1.7, 0.0))
	skyline.step(1)
	var job: Dictionary = skyline._job
	report.skyline_one_sample = {
		kind = job.kind, index = job.index, all_vertices = job.vertices.size(),
		all_indices = job.indices.size(), azimuth_values = job.azimuths.size(),
		elevation_values = job.elevations.size(),
		packed_payload_bytes = job.vertices.size() * 12 + job.indices.size() * 4 + (job.azimuths.size() + job.elevations.size()) * 4,
	}
	var camera := Camera3D.new()
	camera.position = Vector3(0.0, 1.7, 0.0)
	host.add_child(camera)
	camera.make_current()
	var env := Environment.new()
	env.sky = Sky.new()
	var sky_material := ShaderMaterial.new()
	sky_material.shader = SKY_SHADER
	env.sky.sky_material = sky_material
	var glare := Glare.attach(host, env)
	glare.set_process(false)
	var initially_started: bool = glare.skyline() != null
	var callbacks := 0
	while glare.skyline() != null and not glare.skyline().done and callbacks < 1000:
		glare._process(0.0)
		callbacks += 1
	report.disabled_glare = {intensity = glare.intensity, started_skyline = initially_started, manual_callbacks_after_ready = callbacks, completed_skyline = glare.skyline() != null and glare.skyline().done, visible = glare.visible}
	host.free()
	var file := FileAccess.open(OUTPUT, FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t") + "\n")
	file.close()
	print("ROUND2_LIFECYCLE_PROBE " + JSON.stringify(report))
	quit(0)

func _mesh() -> ArrayMesh:
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = PackedVector3Array([Vector3(-1.0, 0.0, 0.0), Vector3(1.0, 0.0, 0.0), Vector3(0.0, 3.0, 0.0), Vector3(-1.0, 3.0, 0.0)])
	arrays[Mesh.ARRAY_INDEX] = PackedInt32Array([0, 1, 2, 0, 2, 3])
	var result := ArrayMesh.new()
	result.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays, [], {1.0: PackedInt32Array([0, 1, 2])})
	return result
