extends SceneTree
const M := preload("res://physics/math3d.gd")
const RB := preload("res://physics/rigid_body.gd")
const Loader := preload("res://data/lake_loader.gd")
const LakeSurface := preload("res://physics/lake_surface.gd")
const LakeCollision := preload("res://sim/lake_collision.gd")
const HullContact := preload("res://physics/hull_contact.gd")
const EffectiveMass := preload("res://physics/effective_mass.gd")
const Session := preload("res://sim/flight_session.gd")
func _initialize() -> void:
	var lake: Dictionary = Loader.load_from("res://data/fields/lake.json").lake
	var session: Session = Session.new()
	session.physics_enabled = false
	session.soft_hull_contacts = true
	session.crash_auto_restart = false
	root.add_child(session)
	session.setup()
	var installed: bool = session.set_lake_context(lake)
	var dt: float = session.sim.dt()
	var q: PackedFloat64Array = M.q_from_euler(-PI/2.0,0.0,0.0)
	var velocity_body := PackedFloat64Array([35.0,0.0,4.45])
	var velocity_world: PackedFloat64Array = M.q_rotate(q,velocity_body)
	var hull: PackedFloat64Array = session.aircraft.model.crash_hull
	var min_down: float = INF
	var min_point: int = -1
	var hit_terrain: Dictionary = {}
	var hit_offset := PackedFloat64Array()
	for i in range(0,hull.size(),3):
		var offset: PackedFloat64Array = M.q_rotate(q,hull.slice(i,i+3))
		var terrain: Dictionary = LakeSurface.sample_terrain_validated(lake,110.0+offset[0],171.3+offset[1])
		var threshold: float = terrain.ground_down_m-offset[2]
		if threshold < min_down:
			min_down = threshold
			min_point = i/3
			hit_offset = offset
			hit_terrain = terrain
	var center := PackedFloat64Array([110.0,171.3,min_down + 0.001])
	var before_pos: PackedFloat64Array = M.sub(center,M.scale(velocity_world,dt/2.0))
	var after_pos: PackedFloat64Array = M.add(center,M.scale(velocity_world,dt/2.0))
	var rates := PackedFloat64Array([0.0,0.0,0.0])
	var before: PackedFloat64Array = RB.make_state(before_pos,velocity_body,q,rates)
	var after: PackedFloat64Array = RB.make_state(after_pos,velocity_body,q,rates)
	var before_hit: PackedFloat64Array = M.add(before_pos,hit_offset)
	var after_hit: PackedFloat64Array = M.add(after_pos,hit_offset)
	var before_ground: Dictionary = LakeSurface.sample_terrain_validated(lake,before_hit[0],before_hit[1])
	var after_ground: Dictionary = LakeSurface.sample_terrain_validated(lake,after_hit[0],after_hit[1])
	var event: LakeCollision.WaterEvent = LakeCollision.first_hit(lake,before,after,hull,session.current_landing_gear(),1,dt,session.sim.mass,session.sim.inertia,true,session._prop_disc)
	var terminal: Dictionary = HullContact.terminal(before,after,session._hull_contact)
	var expected_speed: float = (velocity_world[2]-float(hit_terrain.slope_north)*velocity_world[0]-float(hit_terrain.slope_east)*velocity_world[1])/sqrt(1.0+float(hit_terrain.slope_north)**2+float(hit_terrain.slope_east)**2)
	print("aircraft=%s installed=%s dt=%.12f point=%d center=%s point_at_mid=%s velocity_world=%s slopes=(%.12f,%.12f)" % [session.aircraft.get("id","?"),installed,dt,min_point,center,M.add(center,hit_offset),velocity_world,hit_terrain.slope_north,hit_terrain.slope_east])
	print("gaps before=%.12f after=%.12f correct_speed=%.12f endpoint_terminal=%s" % [before_hit[2]-float(before_ground.ground_down_m),after_hit[2]-float(after_ground.ground_down_m),expected_speed,terminal])
	if event != null:
		print("event trigger=%s point=%d normal=%s speed=%.12f specific=%.12f fraction=%.12f" % [event.trigger,event.point_index,event.normal_ned,event.normal_speed_mps,event.specific_j_per_kg,event.time_fraction])
	else:
		print("event=null")
	var reset_ok: bool = session.sim.reset(before)
	session.sim.set_paused(false)
	session.sim.step()
	var actual: LakeCollision.WaterEvent = session.last_lake_event()
	var passed: bool = installed and reset_ok and session.sim.tick == 1 and session.sim.fault_reason.is_empty() and not session.crash.is_empty() and actual != null and actual.trigger == "lake_bank" and int(terminal.index) == -1
	if actual != null:
		var tt: Dictionary = LakeSurface.sample_terrain_validated(lake,actual.point_ned[0],actual.point_ned[1])
		var normal := PackedFloat64Array([tt.slope_north,tt.slope_east,-1.0])
		normal = M.scale(normal,1.0/M.norm(normal))
		var correct: float = maxf(0.0,-M.dot(actual.velocity_ned,normal))
		var effective: float = EffectiveMass.at_point(RB._att(actual.contact_state()),actual.body_point,normal,session.sim.mass,session.sim.inertia)
		var specific: float = 0.5*effective*correct*correct/session.sim.mass
		print("full_step tick=%d fault=%s crash=%s lake_event=%s at=%s velocity=%s reported_normal=%s normal_speed=%.12f specific=%.12f correct_normal=%s normal_speed=%.12f specific=%.12f" % [session.sim.tick,session.sim.fault_reason,not session.crash.is_empty(),actual.trigger,actual.point_ned,actual.velocity_ned,actual.normal_ned,actual.normal_speed_mps,actual.specific_j_per_kg,normal,correct,specific])
		passed = passed and actual.normal_speed_mps > 8.0 and actual.specific_j_per_kg > HullContact.TERMINAL_J_PER_KG and specific < HullContact.TERMINAL_J_PER_KG
	print("LAKE_REAL_AIRCRAFT_PASS" if passed else "LAKE_REAL_AIRCRAFT_FAIL")
	quit(0 if passed else 1)
