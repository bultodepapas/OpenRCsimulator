extends SceneTree
const M := preload("res://physics/math3d.gd")
const RB := preload("res://physics/rigid_body.gd")
const Loader := preload("res://data/lake_loader.gd")
const LakeSurface := preload("res://physics/lake_surface.gd")
const LakeCollision := preload("res://sim/lake_collision.gd")
const HullContact := preload("res://physics/hull_contact.gd")
const EffectiveMass := preload("res://physics/effective_mass.gd")
const Session := preload("res://sim/flight_session.gd")
func _initialize() -> void:
	var lake: Dictionary = Loader.load_from("res://data/fields/lake.json").lake
	var session: Session = Session.new()
	session.physics_enabled = false
	session.soft_hull_contacts = true
	session.crash_auto_restart = false
	root.add_child(session)
	session.setup("res://data/aircraft/moonrunner_x99.json")
	var installed: bool = session.set_lake_context(lake)
	var dt: float = session.sim.dt()
	var q: PackedFloat64Array = M.q_from_euler(0.0,0.0,0.0)
	var velocity_body := PackedFloat64Array([0.0,0.0,5.0])
	var hull: PackedFloat64Array = session.aircraft.model.crash_hull
	var min_down: float = INF
	var min_point: int = -1
	var hit_terrain: Dictionary = {}
	var hit_offset := PackedFloat64Array()
	for i in range(0,hull.size(),3):
		var offset: PackedFloat64Array = M.q_rotate(q,hull.slice(i,i+3))
		var terrain: Dictionary = LakeSurface.sample_terrain_validated(lake,110.0+offset[0],174.0+offset[1])
		var threshold: float = terrain.ground_down_m-offset[2]
		if threshold < min_down:
			min_down = threshold
			min_point = i/3
			hit_offset = offset
			hit_terrain = terrain
	var center := PackedFloat64Array([110.0,174.0,min_down])
	var before_pos: PackedFloat64Array = M.sub(center,M.scale(velocity_body,dt/4.0))
	var after_pos: PackedFloat64Array = M.add(before_pos,M.scale(velocity_body,dt))
	var rates := PackedFloat64Array([0.0,0.0,0.0])
	var before: PackedFloat64Array = RB.make_state(before_pos,velocity_body,q,rates)
	var after: PackedFloat64Array = RB.make_state(after_pos,velocity_body,q,rates)
	var event: LakeCollision.WaterEvent = LakeCollision.first_hit(lake,before,after,hull,session.current_landing_gear(),1,dt,session.sim.mass,session.sim.inertia,true,session._prop_disc)
	var terminal: Dictionary = HullContact.terminal(before,after,session._hull_contact)
	print("model_ok=%s lake=%s mass=%.12f tolerance=%s dt=%.12f point=%d center=%s point=%s slopes=(%.12f,%.12f) region=%s" % [session.aircraft.get("ok",false),installed,session.sim.mass,session.aircraft.model.crash_tolerance,dt,min_point,center,M.add(center,hit_offset),hit_terrain.slope_north,hit_terrain.slope_east,hit_terrain.region])
	print("direct event=%s point=%d normal=%s speed=%.12f specific=%.12f fraction=%.12f tolerant_terminal=%s" % [event.trigger if event != null else "null",event.point_index if event != null else -1,event.normal_ned if event != null else PackedFloat64Array(),event.normal_speed_mps if event != null else -1.0,event.specific_j_per_kg if event != null else -1.0,event.time_fraction if event != null else -1.0,terminal])
	session.engine_running = false
	session.sim.continuous[session._rotor_index()] = 0.0
	session.sim.aux[Session.AUX_RPM] = 0.0
	var reset_ok: bool = session.sim.reset(before)
	session.sim.set_paused(false)
	session.sim.step()
	var actual: LakeCollision.WaterEvent = session.last_lake_event()
	var terminal_after: Dictionary = HullContact.terminal(before,session.sim.state,session._hull_contact)
	var gear_failure: bool = session.gear_collapsed(session.sim.state)
	session.physics_enabled = true
	var may_continue: bool = session._session_after_input()
	var passed: bool = installed and reset_ok and session.sim.tick == 1 and session.sim.fault_reason.is_empty() and session.crash.is_empty() and actual == null and int(terminal_after.index) == -1 and not gear_failure and session.prop_strike.is_empty() and may_continue
	print("tolerant_full_step tick=%d fault=%s crash=%s lake_event=%s hull_terminal=%s gear_collapsed=%s prop_strike=%s may_continue=%s state=%s" % [session.sim.tick,session.sim.fault_reason,not session.crash.is_empty(),actual.trigger if actual != null else "null",terminal_after,gear_failure,session.prop_strike,may_continue,session.sim.state.slice(0,6)])
	print("LAKE_TOLERANCE_OVERRIDE_PASS" if passed else "LAKE_TOLERANCE_OVERRIDE_FAIL")
	quit(0 if passed else 1)
