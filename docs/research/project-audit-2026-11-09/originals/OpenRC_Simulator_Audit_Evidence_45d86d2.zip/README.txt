OPENRC SIMULATOR AUDIT — REPRODUCIBILITY EVIDENCE

Repository: https://github.com/bultodepapas/OpenRCsimulator
Pinned commit: 45d86d250f6e38a3d9b60d30c01bdc2396571efe
Recorded engine: 4.8.beta2.official.cafc17a19 (official Linux x86_64)
Capture date: 2026-11-09 UTC

Source attribution: Reproduced OpenRCsimulator production code is Copyright (c)
2026 OpenRCsimulator contributors and is provided under the MIT License. The
original pinned root license is included verbatim at production/LICENSE. No root
NOTICE or COPYING file is present in the pinned repository tree.

This is an evidence package, not a patched game, complete repository, benchmark
suite, or audit narrative. Original selected probes, engine logs, and checked-run
reports are preserved byte for byte. Their historical absolute paths remain in
reports to preserve the record. No Godot import cache or large binary game assets
are included. A full pinned checkout and official engine are external prerequisites
for production-project replays. Two isolated projects are included separately.

CONTENTS AND VERIFICATION

* audit_work/: selected original probes, nine report/log pairs, sidecar outputs,
  inventories, isolated projects, and their original provenance records.
* production/: selected original source/test/data files, taken byte for byte from
  pinned Git blobs. These files provide review context; this is not a runnable app.
* production_source_manifest.json: Git blob object ID, SHA256, size, pinned commit,
  and location for 69 source copies. It also records checkout identity. A few files
  were checked out with Git-configured CRLF line endings; their packaged production
  snapshots use pinned-blob bytes. The isolated project source copies match pinned
  blobs byte for byte. No source logic was changed.
* receipt_hash_verification.json: expected and actual SHA256/size for all nine logs.
* audit_commands.json: exact original commands, working directories, markers,
  timeouts, receipt references, and recorded expected verdicts.
* SHA256SUMS: SHA256 for every package file other than SHA256SUMS itself.
* verify.py: standard-library validation of all file hashes, report/log integrity,
  and Git blob identities. Optional --repo compares against the actual pinned Git
  tree, independently of the checkout's line-ending conversion.
* replay.py: portable command/path adapter; it never edits original evidence.

Run from the extracted package directory with Python 3.10 or newer:

  python3 verify.py
  python3 verify.py --repo /absolute/path/to/OpenRCsimulator

For repository-assisted replays, use a complete checkout of the pinned commit.
Do not interpret missing files from a sparse checkout as defects in the game.
Obtain the official Godot 4.8-beta2 executable and verify its official checksum.
Engine and game assets are not redistributed in this package. First import a full
checkout, using the executable appropriate to your system:

  /absolute/path/to/godot --headless --editor --path /absolute/path/to/OpenRCsimulator/app --import --quit

The recorded witness probes were run on Linux. The statistics probe invokes
/bin/true, and the material probe reads /proc/self/status; Linux is required for
unmodified execution of those two probes. General source review is platform-neutral.
The helper deliberately requires the exact recorded engine version.

REPLAY COMMANDS

Each --out must identify a new directory. The helper writes fresh reports there;
it never replaces original reports or converts failing gates into passes.

Standalone isolated statistics witness (three unchanged production scripts):

  python3 replay.py statistics-lock-isolated --godot /absolute/path/to/godot --out /tmp/openrc-statistics-replay

Standalone cloud binding fixture (30 unchanged production source files):

  python3 replay.py cloud-seed-ready-fixture --godot /absolute/path/to/godot --out /tmp/openrc-cloud-replay

The helper copies each isolated project into the new output directory before
Godot can create cache/UID files. Original projects remain untouched.

Production-project runs (replace the paths; use one label from the list below):

  python3 replay.py strip-seam-held-wake --godot /absolute/path/to/godot --repo /absolute/path/to/OpenRCsimulator --out /tmp/openrc-seam-replay

Additional labels:
  collision-quality-full-world
  collision-quality-census
  rc-material-load
  yaw-strict
  rudder-strict-clean
  simulation-evidence

Static preload inventory replay:

  python3 replay.py inventory --repo /absolute/path/to/OpenRCsimulator --out /tmp/openrc-inventory-replay

The collision probes originally write sidecar JSON to an absolute audit output
path. replay.py creates an explicit *_output_path_adapter.gd copy and replaces
only that output-root string. adapter_provenance.json records both paths and the
replacement. Original receipt probes remain unchanged. For inventory_preloads.py,
the adapter changes only ROOT, OUT, and the asset_sizes.json input path. Adapter
outputs are new reproductions, not the original receipt artifacts.

RECORDED VERDICTS

Seven selected reports have ok=true, process_exit=0, zero engine errors, and all
required completion markers. These include the baseline simulation check,
which prints 11 checks, 0 failed. The remaining two reports intentionally retain
strict gates that completed but failed:

  yaw-strict:          ok=false, process_exit=1, reason=process_exit
  rudder-strict-clean: ok=false, process_exit=1, reason=process_exit

Both failing strict runs have zero recorded engine errors and include their
required pending-comparison markers. Complete=true means collection completed;
it does not mean the test passed. replay.py preserves nonzero exit status.
Read their engine.log files and production test sources before interpreting.

SCOPE AND LIMITATIONS

The seam probe is a numerical production-force witness with limiting sequences,
held-wake comparisons, and strip-factor ablation; it does not establish a measured
in-flight failure frequency or substitute for aircraft flight-test calibration.

The statistics witness creates a stale writer-lock scenario around an exited
child process and reopens the real store twice. It is an isolated persistence
proof, not a GUI crash recording. It leaves its generated test files in Godot's
isolated audit-project user-data directory, away from the normal app profile.

The collision census extracts unchanged policy fragments from production code;
the separate full-world probe uses the real collision builder and collision
resolver. Neither receipt is a rendered playthrough or multiplayer experiment.

The cloud fixture injects synthetic ready cache textures to inspect actual
material bindings and layer seeds. It does not run a GPU bake, show a visual
screenshot, or establish a measured frame-time regression.

Preload inventory bytes are encoded source-file sizes, not RAM/VRAM usage or
loading-time measurements. Its literal preload/extends graph excludes dynamic
loads and transitive scene/model resources. The material probe measures a
headless module-load witness and resource-cache states. Its memory observations
are process/debug counters in this environment; they are not GPU VRAM readings
or a universal whole-game performance estimate. Timing, PIDs, temporary paths,
resource counters, and process-memory values can differ in replays.

The release-readiness and flight-statistics documentation already discloses some
limitations; this package does not claim every issue is newly discovered.
Software evidence is distinct from hardware, aerodynamic, and visual qualification.
