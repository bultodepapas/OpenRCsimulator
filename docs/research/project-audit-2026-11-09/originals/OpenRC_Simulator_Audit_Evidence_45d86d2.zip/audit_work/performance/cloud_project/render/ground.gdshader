// Ground (L2; LANDSCAPE-PLAN, investigation 02). Ours, MIT. The grass texture in world space (one tile every tile_m
// metres), matte, and the haze written as custom FOG: the same colour formula as the engine's fog and the sky's
// horizon, exponential amount 1 − e^(−βd), plus a rim fade to full haze between rim_start and rim_end so the 6 km
// edge of the ground can never show (realistic haze leaves 36 % contrast there).
// Landscape improvement phases 2 and 5 (docs/research/landscape-improvement-2026-10-07, reports 01 and 03):
// - anti-tiling: Inigo Quilez's "technique 3" idea, our own code: an index noise picks two hashed offsets of the same
//   tile and blends them (2 textureGrad fetches); Hoskins' "hash without sine" (MIT) instead of sin() hashes;
// - macro variation: value noise at 9, 37 and 160 m plus dry patches, pinned to its mean around the pilot station so
//   the near view keeps its L9a brightness;
// - a far-field patchwork of fields (green, straw, stubble, ploughed) beyond about 1 km, so raised views do not end in
//   one even green band.
// L9c: flat field rectangles are composed in the rough ground pass, without depth-separated overlays.
// surface_kind 1/2 retain the existing plane fallback for custom layouts that cannot be consolidated.
// They first compute the rough grass exactly as the ground below does, then blend to mown turf inside a noisy border,
// so the edge is soft and irregular and never a colour seam. The runway adds filtered mowing stripes (view-dependent,
// as real stripes are) and worn touchdown zones. RC sessions optionally bind downloaded soil/grass detail maps.
// No TIME: every value is a pure function of position and view.
shader_type spatial;
render_mode cull_back;

#include "res://render/cloud_field.gdshaderinc"
#include "res://render/cloud_shadow_map.gdshaderinc"
#include "res://render/grass_surface.gdshaderinc"
#include "res://render/turf_detail.gdshaderinc"
#include "res://render/rc_ground_detail.gdshaderinc"
#include "res://vehicles/ground/track_surface_detail.gdshaderinc"

// L15d: the same cumulus density as the sky, projected along the sun ray to a 1.5 km deck.
// Only direct sunlight is attenuated. Ambient light and the calibrated haze keep their energy.
global uniform vec2 cloud_drift_offset;
uniform float cloud_coverage = 0.35;
uniform float cloud_scale = 6.0;
uniform uint cloud_seed = 1253u;
uniform float cluster_strength = 0.0;
uniform float cloud_deck_m = 1500.0;
uniform float cloud_shadow_strength = 0.0;
uniform bool appearance_cloud_shadow = false;
uniform float appearance_shadow_scale_m = 250.0;
uniform float appearance_shadow_coverage = 0.35;
uniform float appearance_shadow_density = 1.0;
uniform uint appearance_shadow_seed = 1253u;
uniform float appearance_shadow_cluster = 0.0;
varying float cloud_transmission;

uniform vec3 haze_lin = vec3(0.584, 0.768, 0.846);
uniform vec3 sun_dir = vec3(0.0, 0.707, 0.707);
uniform vec3 sun_lin = vec3(3.14159);
uniform float sun_scatter = 0.0;
// FW-22 time of day: the physical horizon lobe toward the brighter source (zero in the calibrated fixed-sun mode).
uniform vec3 lobe_lin = vec3(0.0);
uniform vec3 lobe_dir = vec3(1.0, 0.0, 0.0);
uniform float lobe_k = 8.0;
uniform float lobe_height = 1.5708;          // rad; the vertical e-folding of the lobe
uniform float beta = 0.00017;
uniform float rim_start = 4800.0;
uniform float rim_end = 6000.0;
// L7 clear preset: inverse distance distributes the artificial rim closure over projected screen rows.
uniform bool rim_angular = false;
// Phase 2 (estimates tuned on the spike of report 01: luminance spread 9-14 levels, tile repeat <= 0.30).
// Phase 5: the far-field patchwork.
uniform float fields_start_m = 700.0;
uniform float fields_full_m = 1300.0;
uniform float field_size_m = 230.0;
uniform float parcel_blend_m = 80.0;
uniform float parcel_strength = 0.6;        // of the crop factors below
uniform float fields_fade_start_m = 1800.0;  // the parcels fade out before the rim fade (L2: no step at the rim)
uniform float fields_fade_end_m = 3000.0;
// Phase 4: 0 rough, 1 mown, 2 runway; the surface's rectangle in render x/z (centre and half extents, m).
uniform int surface_kind = 0;
uniform vec2 rect_center = vec2(0.0);
uniform vec2 rect_half = vec2(1.0);
// Ground.MAX_SURFACES; initialized in full by configure_surfaces. Zero count keeps the legacy fixture unchanged.
uniform int surface_count = 0;
uniform vec4 surface_rects[32];
uniform int surface_kinds[32];
uniform vec4 surface_bounds = vec4(0.0);
// GP-01: deterministic soil micro-relief. These amplitudes match GroundTerrain's estimates at the
// field's current rolling factors; terrain rectangles below use the same NED field layout and order.
uniform bool terrain_relief_enabled = false;
uniform float terrain_runway_amplitude_m = 0.001;
uniform float terrain_rotorpad_amplitude_m = 0.0;
uniform float terrain_mown_amplitude_m = 0.004;
uniform float terrain_rough_amplitude_m = 0.007;
uniform float terrain_edge_blend_m = 0.5;
// Visual-only anti-aliasing: physics still samples relief at every wheel at every stage.
uniform float terrain_relief_start_m = 20.0;
uniform float terrain_relief_end_m = 80.0;
uniform float terrain_footprint_start_m = 0.08;
uniform float terrain_footprint_end_m = 0.41;
uniform int terrain_surface_count = 0;
uniform vec4 terrain_surface_rects[32];
uniform int terrain_surface_kinds[32];
uniform float mown_value = 1.25;      // report 04: rough = 0.75-0.85 × mown; the top keeps the runway readable at 100 m+
uniform float mown_desat = 0.15;      // saturation -0.05...-0.10 at this grass colour
uniform float stripe_m = 1.5;         // one ride-on deck (1.2-1.8 m)
uniform float stripe_amp = 0.05;      // +-(3-6 %), below half the edge step
uniform float border_m = 0.6;         // noisy border, amplitude 0.3-0.8 m
uniform float wear = 0.45;            // touchdown wear weight, 10-30 m in from each threshold
uniform bool club_field_detail = false;

varying vec3 world_pos;
// LU-25: yield the exact validated bank footprint to the real basin geometry.
uniform int lake_mask_mode = 0; // 0 ordinary field, 1 outside bank (now a geometric cut, render/lake/lake_world.gd)
uniform int lake_bank_count = 0;
uniform vec2 lake_bank_points[64];
uniform vec4 lake_bank_bounds = vec4(0.0);

// Far-field land cover: integer-hash Voronoi parcels, each a crop colour factor. Borders blend over parcel_blend_m
// (hard edges at 2-5 km alias into row steps and shimmer from altitude).
vec3 crop(vec2 id) {
	float h = hash12(id + 91.7);
	if (h < 0.34) return vec3(1.0);                    // pasture like the field
	if (h < 0.52) return vec3(0.86, 0.97, 0.80);       // lush, darker green
	if (h < 0.68) return vec3(1.45, 1.18, 0.78);       // ripe cereal / straw
	if (h < 0.82) return vec3(1.22, 1.04, 0.82);       // stubble
	if (h < 0.93) return vec3(0.98, 0.80, 0.64);       // ploughed earth
	return vec3(1.10, 1.06, 0.92);                     // young crop
}

vec3 parcel(vec2 p) {
	vec2 cell = floor(p / field_size_m);
	float d1 = 1e9;
	float d2 = 1e9;
	vec2 id1 = cell;
	vec2 id2 = cell;
	for (int y = -1; y <= 1; y++) {
		for (int x = -1; x <= 1; x++) {
			vec2 c = cell + vec2(float(x), float(y));
			vec2 site = (c + 0.15 + 0.7 * hash22(c)) * field_size_m;
			float d = distance(p, site);
			if (d < d1) {
				d2 = d1;
				id2 = id1;
				d1 = d;
				id1 = c;
			} else if (d < d2) {
				d2 = d;
				id2 = c;
			}
		}
	}
	return mix(crop(id2), crop(id1), 0.5 + 0.5 * smoothstep(0.0, parcel_blend_m, d2 - d1));
}

// A square wave of period 1 (+1, then -1) box-filtered over du: the exact mean via its triangle-wave integral.
float square_filtered(float u, float du) {
	du = max(du, 1e-4);
	float a = 0.5 - abs(fract(u + 0.5 * du) - 0.5);
	float b = 0.5 - abs(fract(u - 0.5 * du) - 0.5);
	return (a - b) / du;
}

// Mown turf over the rough colour, inside the surface's rectangle (Phase 4).
vec3 surface_colour(vec3 rough, vec3 underneath, vec2 p, vec3 view, vec2 footprint, int kind, vec4 rect) {
	vec2 half_size = rect.zw;
	vec2 d = p - rect.xy;
	float edge = border_m * (0.2 + 0.55 * vnoise(p / 3.5 + 41.0) + 0.25 * vnoise(p / 1.1 + 7.0));
	// Integrate both sides of each interval, so a subpixel strip keeps its coverage instead of becoming
	// a half-bright pixel regardless of width. The 0.2 m minimum is the existing artistic border feather.
	vec2 inset = max(half_size - vec2(edge + 0.1), vec2(0.0));
	vec2 filter_width = max(footprint, vec2(0.2));
	vec2 coverage = clamp((min(d + 0.5 * filter_width, inset) - max(d - 0.5 * filter_width, -inset)) / filter_width, vec2(0.0), vec2(1.0));
	float inside = coverage.x * coverage.y;
	float luma = dot(rough, vec3(0.2126, 0.7152, 0.0722));
	// Club turf has the same grass species as its shoulder. Keep mowing readable without a luminous slab.
	float value = club_field_detail ? (kind == 2 ? 1.155 : 1.09) : mown_value;
	vec3 mown = mix(rough, vec3(luma), club_field_detail ? 0.075 : mown_desat) * value;
	if (kind == 2) {
		bool along_x = half_size.x >= half_size.y;
		float along = along_x ? d.x : d.y;
		float across = along_x ? d.y : d.x;
		float half_len = max(half_size.x, half_size.y);
		float half_wid = min(half_size.x, half_size.y);
		float u = across / (2.0 * stripe_m);
		float stripe = square_filtered(u, (along_x ? footprint.y : footprint.x) / (2.0 * stripe_m));
		vec2 axis = along_x ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
		float bend = dot(normalize(view.xz + vec2(1e-5)), axis);
		// Keep the club's subtle cap while letting stripe_amp=0 remove the stripes for guarded captures.
		float active_stripe_amp = club_field_detail ? clamp(stripe_amp, 0.0, 0.026) : stripe_amp;
		mown *= 1.0 + active_stripe_amp * stripe * bend;
		float from_end = half_len - abs(along);
		float zone = smoothstep(6.0, 12.0, from_end) * (1.0 - smoothstep(26.0, 34.0, from_end));
		float centre = 1.0 - smoothstep(0.12, 0.45, abs(across) / max(half_wid, 0.1));
		float w = wear * zone * centre * (0.3 + 0.7 * vnoise(p / 2.2 + 5.0));
		mown *= mix(vec3(1.0), club_field_detail ? vec3(1.01, 0.985, 0.91) : vec3(1.12, 1.0, 0.78), w);
	}
	return mix(underneath, mown, inside);
}

// Cubic edge feather and its derivative, matching GroundTerrain's C1 rectangle mask.
vec2 terrain_edge(float distance_m) {
	if (distance_m <= 0.0) return vec2(0.0);
	if (distance_m >= terrain_edge_blend_m) return vec2(1.0, 0.0);
	float t = distance_m / terrain_edge_blend_m;
	return vec2(t * t * (3.0 - 2.0 * t), 6.0 * t * (1.0 - t) / terrain_edge_blend_m);
}

// Rectangle coverage and gradient in renderer coordinates (east, -north).
vec3 terrain_rect_mask(vec2 p, vec4 rect) {
	vec2 low_x = terrain_edge(p.x - (rect.x - rect.z));
	vec2 high_x = terrain_edge((rect.x + rect.z) - p.x);
	vec2 low_y = terrain_edge(p.y - (rect.y - rect.w));
	vec2 high_y = terrain_edge((rect.y + rect.w) - p.y);
	float x = low_x.x * high_x.x;
	float y = low_y.x * high_y.x;
	return vec3(x * y,
		(low_x.y * high_x.x - low_x.x * high_x.y) * y,
		(low_y.y * high_y.x - low_y.x * high_y.y) * x);
}

// Layer mown and runway amplitudes over rough in the same low-to-high precedence order as the field.
vec3 terrain_amplitude(vec2 p) {
	float amplitude = terrain_rough_amplitude_m;
	vec2 gradient = vec2(0.0);
	for (int i = 0; i < min(terrain_surface_count, 32); i++) {
		vec3 mask = terrain_rect_mask(p, terrain_surface_rects[i]);
		int kind = terrain_surface_kinds[i];
		float target = terrain_mown_amplitude_m;
		if (kind == 2) target = terrain_runway_amplitude_m;
	else if (kind == 3) target = terrain_rotorpad_amplitude_m;
		float difference = target - amplitude;
		gradient = gradient * (1.0 - mask.x) + difference * mask.yz;
		amplitude += difference * mask.x;
	}
	return vec3(amplitude, gradient);
}

// [height, dh/dnorth, dh/deast], exactly the directional waves used by physics/ground_terrain.gd.
vec3 terrain_height(vec2 north_east) {
	vec3 amplitude_data = terrain_amplitude(vec2(north_east.y, -north_east.x));
	float amplitude = amplitude_data.x;
	float wave = 0.45 * sin(6.283185307179586 * (0.8 * north_east.x + 0.6 * north_east.y) / 1.2 + 0.17)
		+ 0.35 * sin(6.283185307179586 * (-0.35 * north_east.x + 0.9367496998 * north_east.y) / 0.73 + 2.11)
		+ 0.20 * sin(6.283185307179586 * (0.6 * north_east.x - 0.8 * north_east.y) / 0.41 + 4.73);
	float wave_north = 0.45 * 6.283185307179586 / 1.2 * 0.8 * cos(6.283185307179586 * (0.8 * north_east.x + 0.6 * north_east.y) / 1.2 + 0.17)
		+ 0.35 * 6.283185307179586 / 0.73 * -0.35 * cos(6.283185307179586 * (-0.35 * north_east.x + 0.9367496998 * north_east.y) / 0.73 + 2.11)
		+ 0.20 * 6.283185307179586 / 0.41 * 0.6 * cos(6.283185307179586 * (0.6 * north_east.x - 0.8 * north_east.y) / 0.41 + 4.73);
	float wave_east = 0.45 * 6.283185307179586 / 1.2 * 0.6 * cos(6.283185307179586 * (0.8 * north_east.x + 0.6 * north_east.y) / 1.2 + 0.17)
		+ 0.35 * 6.283185307179586 / 0.73 * 0.9367496998 * cos(6.283185307179586 * (-0.35 * north_east.x + 0.9367496998 * north_east.y) / 0.73 + 2.11)
		- 0.20 * 6.283185307179586 / 0.41 * 0.8 * cos(6.283185307179586 * (0.6 * north_east.x - 0.8 * north_east.y) / 0.41 + 4.73);
	// gradient is dA/d(east), dA/d(-north) because renderer y = -north.
	float amplitude_north = -amplitude_data.z;
	float amplitude_east = amplitude_data.y;
	return vec3(amplitude * wave,
		amplitude_north * wave + amplitude * wave_north,
		amplitude_east * wave + amplitude * wave_east);
}

void vertex() {
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	rc_coverage = 1.0 - COLOR.a;
}

// FW-61/FW-22: the twilight arch toward the brighter source, azimuth exponent `lobe_k`, vertical e-folding
// `lobe_height` (radians): it hugs the horizon. Zero lobe_lin (the calibrated fixed sun) adds exactly nothing.
vec3 lobe_term(vec3 d) {
	// Fixed-day lighting has no twilight lobe; this uniform branch skips inactive angular work.
	if (all(equal(lobe_lin, vec3(0.0)))) return vec3(0.0);
	float h = max(length(d.xz), 1e-4);
	float az = max(dot(d.xz / h, normalize(lobe_dir.xz + vec2(1e-6, 0.0))), 0.0);
	return lobe_lin * pow(az, lobe_k) * exp(-max(asin(clamp(d.y, -1.0, 1.0)), 0.0) / lobe_height);
}

void fragment() {
	vec3 col = rough_grass_colour(world_pos.xz);
	col = club_turf(col, world_pos.xz, club_field_detail);
	// Evaluate derivatives before the terrain branch; suppress subpixel relief and skip all wave work beyond 80 m.
	vec2 footprint = fwidth(world_pos.xz);
	vec3 to_frag = world_pos - CAMERA_POSITION_WORLD;
	float d = length(to_frag);
	vec3 v = to_frag / max(d, 1e-3);
	if (terrain_relief_enabled && d < terrain_relief_end_m) {
		float distance_weight = 1.0 - smoothstep(terrain_relief_start_m, terrain_relief_end_m, d);
		float footprint_m = max(footprint.x, footprint.y);
		float footprint_weight = 1.0 - smoothstep(terrain_footprint_start_m, terrain_footprint_end_m, footprint_m);
		float relief_weight = distance_weight * footprint_weight;
		if (relief_weight > 0.001) {
			vec3 relief = terrain_height(vec2(-world_pos.z, world_pos.x));
			vec3 base_normal = normalize(NORMAL);
			vec3 east_view = (VIEW_MATRIX * vec4(1.0, 0.0, 0.0, 0.0)).xyz;
			vec3 north_view = (VIEW_MATRIX * vec4(0.0, 0.0, -1.0, 0.0)).xyz;
			vec3 perturbation = -relief.z * east_view - relief.y * north_view;
			perturbation *= relief_weight;
			perturbation -= base_normal * dot(base_normal, perturbation);
			NORMAL = normalize(base_normal + perturbation);
		}
	}
	float dist_pilot = distance(world_pos.xz, pilot_xz);
	float far = smoothstep(fields_start_m, fields_full_m, dist_pilot) * (1.0 - smoothstep(fields_fade_start_m, fields_fade_end_m, dist_pilot));
	float parcel_weight = far * parcel_strength;
	// The parcel has no effect at zero weight; its nine-site search needs no derivatives.
	if (parcel_weight != 0.0) {
		col *= mix(vec3(1.0), parcel(world_pos.xz), parcel_weight);
	}
	// Derivatives must be evaluated before spatially varying branches/loops (including the bounds early-out).
	// Explicit derivatives outside divergent surface/LOD branches.
	vec2 turf_dx = dFdx(world_pos.xz);
	vec2 turf_dy = dFdy(world_pos.xz);
	if (surface_kind > 0) {
		col = surface_colour(col, col, world_pos.xz, v, footprint, surface_kind, vec4(rect_center, rect_half));
	} else if (surface_count > 0) {
		vec2 p = world_pos.xz;
		if (all(greaterThanEqual(p, surface_bounds.xy - footprint)) && all(lessThanEqual(p, surface_bounds.zw + footprint))) {
			vec3 rough = col;
			for (int i = 0; i < min(surface_count, 32); i++) {
				vec4 rect = surface_rects[i];
				if (all(lessThanEqual(abs(p - rect.xy), rect.zw + footprint))) {
					col = surface_colour(rough, col, p, v, footprint, surface_kinds[i], rect);
				}
			}
		}
	}
	cloud_transmission = 1.0;
	if (cloud_shadow_strength > 0.0 && cloud_coverage > 0.0 && sun_dir.y > 0.01) {
		vec2 deck = world_pos.xz + max(cloud_deck_m - world_pos.y, 0.0) * sun_dir.xz / sun_dir.y;
		float density;
		if (appearance_cloud_shadow) {
			density = cloud_shadow_density(deck / max(appearance_shadow_scale_m, 1.0) + cloud_drift_offset,
				appearance_shadow_seed, appearance_shadow_coverage, appearance_shadow_cluster) * appearance_shadow_density;
		} else {
			density = cloud_shadow_density(deck * (cloud_scale / cloud_deck_m) + cloud_drift_offset,
				cloud_seed, cloud_coverage, cluster_strength);
		}
		cloud_transmission -= clamp(cloud_shadow_strength, 0.0, 1.0) * density * smoothstep(0.01, 0.1, sun_dir.y);
	}
	float detail_weight = turf_weight(turf_dx, turf_dy, d);
	float photo_weight = (rc_surface_enabled || grass_photo_enabled) ? rc_near_weight(turf_dx, turf_dy, d) : 0.0;
	detail_weight *= 1.0 - photo_weight;
	if (detail_weight > 0.0) {
		vec3 detail = turf_sample(world_pos.xz, turf_dx, turf_dy);
		col *= 1.0 + (detail.b - 0.5) * 0.9 * detail_weight;
		// Packed slopes are linear data in world x/z. NORMAL is in view space.
		vec2 slope = (detail.rg * 2.0 - 1.0) * 0.65 * detail_weight;
		vec3 perturbation = (VIEW_MATRIX * vec4(slope.x, 0.0, slope.y, 0.0)).xyz;
		vec3 base_normal = normalize(NORMAL);
		perturbation -= base_normal * dot(base_normal, perturbation);
		NORMAL = normalize(base_normal + perturbation);
	}
	ALBEDO = col;
	ROUGHNESS = 1.0;
	METALLIC = 0.0;
	SPECULAR = 0.0;
	rc_soil_specular = 0.0;
	float dirt_weight = (rc_surface_enabled && rc_track_surface) ? smoothstep(0.0, 1.0, clamp(rc_coverage, 0.0, 1.0)) : 0.0;
	// Far-away photo detail and absent dirt contribute nothing to the surface.
	if (photo_weight > 0.0 || dirt_weight > 0.0) {
		vec2 uv_a;
		vec2 uv_b;
		float uv_blend;
		vec3 base_normal = normalize(NORMAL);
		if (photo_weight > 0.0 && dirt_weight < 1.0) {
			rc_uvs(world_pos.xz, 1.4, uv_a, uv_b, uv_blend);
			vec3 grass_color;
			vec3 grass_normal;
			float grass_roughness;
			rc_grass_sample(uv_a, uv_b, turf_dx / 1.4, turf_dy / 1.4, uv_blend, grass_color, grass_normal, grass_roughness);
			// Retain the accepted field palette/stripes and distant brightness.
			vec3 grass_mean = OUTPUT_IS_SRGB ? RC_GRASS_MEAN_SRGB : RC_GRASS_MEAN_LINEAR;
			vec3 modulation = clamp(grass_color / grass_mean, vec3(0.25), vec3(2.4));
			ALBEDO *= mix(vec3(1.0), modulation, photo_weight * 0.7);
			NORMAL = rc_project_normal(base_normal, grass_normal, VIEW_MATRIX, photo_weight * 0.65);
			ROUGHNESS = mix(1.0, max(grass_roughness, 0.78), photo_weight);
		}
		if (dirt_weight > 0.0) {
			rc_uvs(world_pos.xz, 2.0, uv_a, uv_b, uv_blend);
			vec3 dirt_color;
			vec3 dirt_normal;
			float dirt_roughness;
			rc_dirt_sample(uv_a, uv_b, turf_dx * 0.5, turf_dy * 0.5, uv_blend, dirt_color, dirt_normal, dirt_roughness);
			ALBEDO = mix(ALBEDO, dirt_color, dirt_weight);
			NORMAL = normalize(mix(NORMAL, rc_project_normal(base_normal, dirt_normal, VIEW_MATRIX, 0.55 * photo_weight), dirt_weight));
			ROUGHNESS = mix(ROUGHNESS, clamp(dirt_roughness, 0.65, 1.0), dirt_weight);
			rc_soil_specular = dirt_weight;
			if (rc_track_surface) {
				rc_track_surface_finish(world_pos.xz, turf_dx, turf_dy, d,
					rc_coverage, VIEW_MATRIX, ALBEDO, NORMAL, ROUGHNESS);
				rc_track_paint_lane(world_pos.xz, turf_dx, turf_dy,
					rc_coverage, ALBEDO, ROUGHNESS);
			}
		}
	}
	vec3 haze = haze_lin + sun_lin * pow(max(dot(v, sun_dir), 0.0), 8.0) * sun_scatter + lobe_term(v);
	float rim = rim_angular
		? 1.0 - smoothstep(1.0 / rim_end, 1.0 / rim_start, 1.0 / max(d, 1e-3))
		: smoothstep(rim_start, rim_end, d);
	FOG = vec4(haze, max(1.0 - exp(-beta * d), rim));
	// DT-MAC-06b D1: no shoreline `discard`. Its mere presence disabled hidden-surface removal on Apple GPUs
	// (≈ 2 ms per frame at 2560×1600 on an M1); render/lake/lake_world.gd cuts the bank polygon from the mesh.
}

// Preserve this shader's existing Compatibility fallback: Lambert (no diffuse_burley render mode).
// LIGHT_COLOR includes PI; the renderer applies ALBEDO after accumulating diffuse light.
// Explicit Burley changes grazing views even with clouds disabled; see the zero-strength A/B proof.
void light() {
	float diffuse = max(dot(NORMAL, LIGHT), 0.0) * (1.0 / PI);
	float transmission = LIGHT_IS_DIRECTIONAL ? cloud_transmission : 1.0;
	DIFFUSE_LIGHT += LIGHT_COLOR * diffuse * ATTENUATION * transmission;
	// Dry soil's weak dielectric reflection, with the downloaded roughness.
	// Zero outside the RC dirt; the accepted field lighting remains exact there.
	if (rc_soil_specular > 0.0) {
		vec3 half_vector = normalize(LIGHT + VIEW);
		float nl = max(dot(NORMAL, LIGHT), 0.0);
		float nv = max(dot(NORMAL, VIEW), 0.001);
		float nh = max(dot(NORMAL, half_vector), 0.0);
		float vh = max(dot(VIEW, half_vector), 0.0);
		float a2 = pow(ROUGHNESS, 4.0);
		float denominator = nh * nh * (a2 - 1.0) + 1.0;
		float distribution = a2 / max(PI * denominator * denominator, 0.0001);
		float k = pow(ROUGHNESS + 1.0, 2.0) * 0.125;
		float geometry = (nl / max(nl * (1.0 - k) + k, 0.001)) * (nv / (nv * (1.0 - k) + k));
		float fresnel = 0.04 + 0.96 * pow(1.0 - vh, 5.0);
		SPECULAR_LIGHT += LIGHT_COLOR * ATTENUATION * transmission * rc_soil_specular * distribution * geometry * fresnel / (4.0 * nv);
	}
}
