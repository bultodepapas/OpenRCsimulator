// L11a opaque near-field blades. Artistic dimensions; deterministic clock, no physics or collision.
shader_type spatial;
render_mode cull_disabled, world_vertex_coords;
#include "res://render/grass_surface.gdshaderinc"
#include "res://render/cloud_field.gdshaderinc"
#include "res://render/cloud_shadow_map.gdshaderinc"

global uniform float sim_clock;
global uniform vec3 wind_vec;
global uniform vec2 cloud_drift_offset;
uniform vec3 haze_lin = vec3(0.584, 0.768, 0.846);
uniform vec3 sun_dir = vec3(0.0, 0.707, 0.707);
uniform vec3 sun_lin = vec3(3.14159);
uniform float sun_scatter = 0.0;
// FW-22 time of day: the physical horizon lobe toward the brighter source (zero in the calibrated fixed-sun mode).
uniform vec3 lobe_lin = vec3(0.0);
uniform vec3 lobe_dir = vec3(1.0, 0.0, 0.0);
uniform float lobe_k = 8.0;
uniform float lobe_height = 1.5708;          // rad; the vertical e-folding of the lobe
uniform float beta = 0.00017;
uniform float cloud_coverage = 0.35;
uniform float cloud_scale = 6.0;
uniform uint cloud_seed = 1253u;
uniform float cluster_strength = 0.0;
uniform float cloud_deck_m = 1500.0;
uniform float cloud_shadow_strength = 0.0;
uniform bool appearance_cloud_shadow = false;
uniform float appearance_shadow_scale_m = 250.0;
uniform float appearance_shadow_coverage = 0.35;
uniform float appearance_shadow_density = 1.0;
uniform uint appearance_shadow_seed = 1253u;
uniform float appearance_shadow_cluster = 0.0;
uniform float fade_start_m = 22.0;
uniform float fade_end_m = 30.0;
uniform bool club_field_detail = false;
varying vec3 world_pos;
varying float cloud_transmission;

void vertex() {
	vec3 origin = MODEL_MATRIX[3].xyz;
	// The field is planted around the pilot. A distant chase camera must not retain a grass disk behind it.
	float d = max(distance(origin.xz, pilot_xz), distance(origin, CAMERA_POSITION_WORLD));
	float shrink = 1.0 - smoothstep(fade_start_m, fade_end_m, d);
	vec3 offset = VERTEX - origin;
	float speed = length(wind_vec.xz);
	vec2 direction = wind_vec.xz / max(speed, 1e-4);
	float phase = fract(origin.x * 0.137 + origin.z * 0.719);
	// 0.25 Hz = 256/1024: continuous across ShaderClock's wrap. Zero wind means zero sway until M5.
	float sway = 0.035 * min(speed / 5.0, 1.0) * sin(TAU * fract(0.25 * sim_clock + phase));
	offset.xz += direction * sway * UV.y * UV.y;
	VERTEX = origin + offset * shrink; // collapse the whole triangle at 30 m, no flat z-fighting remnant
	world_pos = VERTEX;
}

// FW-61/FW-22: the twilight arch toward the brighter source, azimuth exponent `lobe_k`, vertical e-folding
// `lobe_height` (radians): it hugs the horizon. Zero lobe_lin (the calibrated fixed sun) adds exactly nothing.
vec3 lobe_term(vec3 d) {
	// Fixed-day lighting has no twilight lobe; this uniform branch skips inactive angular work.
	if (all(equal(lobe_lin, vec3(0.0)))) return vec3(0.0);
	float h = max(length(d.xz), 1e-4);
	float az = max(dot(d.xz / h, normalize(lobe_dir.xz + vec2(1e-6, 0.0))), 0.0);
	return lobe_lin * pow(az, lobe_k) * exp(-max(asin(clamp(d.y, -1.0, 1.0)), 0.0) / lobe_height);
}

void fragment() {
	// Override after the renderer's back-face flip: grass roots receive the same upward lighting as the ground.
	NORMAL = normalize((VIEW_MATRIX * vec4(0.0, 1.0, 0.0, 0.0)).xyz);
	ALBEDO = club_turf(rough_grass_colour(world_pos.xz), world_pos.xz, club_field_detail) * mix(1.0, 0.94, UV.y);
	ROUGHNESS = 1.0;
	METALLIC = 0.0;
	SPECULAR = 0.0;
	cloud_transmission = 1.0;
	if (cloud_shadow_strength > 0.0 && cloud_coverage > 0.0 && sun_dir.y > 0.01) {
		vec2 deck = world_pos.xz + max(cloud_deck_m - world_pos.y, 0.0) * sun_dir.xz / sun_dir.y;
		float density;
		if (appearance_cloud_shadow) {
			density = cloud_shadow_density(deck / max(appearance_shadow_scale_m, 1.0) + cloud_drift_offset,
				appearance_shadow_seed, appearance_shadow_coverage, appearance_shadow_cluster) * appearance_shadow_density;
		} else {
			density = cloud_shadow_density(deck * (cloud_scale / cloud_deck_m) + cloud_drift_offset,
				cloud_seed, cloud_coverage, cluster_strength);
		}
		cloud_transmission -= clamp(cloud_shadow_strength, 0.0, 1.0) * density * smoothstep(0.01, 0.1, sun_dir.y);
	}
	vec3 to_frag = world_pos - CAMERA_POSITION_WORLD;
	float d = length(to_frag);
	vec3 v = to_frag / max(d, 1e-3);
	vec3 haze = haze_lin + sun_lin * pow(max(dot(v, sun_dir), 0.0), 8.0) * sun_scatter + lobe_term(v);
	FOG = vec4(haze, 1.0 - exp(-beta * d));
}

void light() {
	float diffuse = max(dot(NORMAL, LIGHT), 0.0) * (1.0 / PI);
	DIFFUSE_LIGHT += LIGHT_COLOR * diffuse * ATTENUATION * (LIGHT_IS_DIRECTIONAL ? cloud_transmission : 1.0);
}
