extends SceneTree

const Atmosphere := preload("res://render/atmosphere.gd")
const Config := preload("res://environment/sky_appearance_config.gd")
const Cache := preload("res://render/cloud_shadow_map.gd")

func _initialize() -> void:
	# Synthetic published textures exercise material bindings; no GPU bake is claimed.
	OS.set_environment("OPENRC_CLOUD_SHADOW_MAP", "1")
	for seed in [1253, 105982, 210711, 315440]:
		var texture := ImageTexture.create_from_image(Image.create(2, 2, false, Image.FORMAT_RGH))
		Cache._tiles[seed] = {"status": "ready", "attempts": 1, "failure": "", "texture": texture}
	var rows := []
	for preset: String in Config.EXPECTED_PRESET_IDS:
		var selection := Config.for_preset(preset)
		var accepted := Atmosphere.configure_appearance(selection)
		var mat := Atmosphere.sky_material()
		var base_seed: int = mat.get_shader_parameter("cloud_seed")
		var layered: bool = mat.get_shader_parameter("layered_appearance") == true
		var layers := PackedInt32Array()
		var count := 0
		var motion := PackedVector4Array()
		if layered:
			layers = mat.get_shader_parameter("appearance_layer_seeds")
			count = mat.get_shader_parameter("appearance_layer_count")
			motion = mat.get_shader_parameter("appearance_layer_motion")
		var ground := ShaderMaterial.new()
		ground.shader = Atmosphere.GROUND_SHADER
		Atmosphere.update_ground_material(ground)
		var actual_layers := []
		for i in count:
			actual_layers.append({"layer": i, "seed": layers[i], "shape": motion[i].w, "relief_shape_eligible": int(motion[i].w) not in [1, 2], "matches_bound_sky_seed": layers[i] == base_seed})
		rows.append({"preset": preset, "accepted": accepted, "layered": mat.get_shader_parameter("layered_appearance"),
			"base_sky_seed": base_seed, "bound_sky_map_seed": mat.get_shader_parameter("cloud_shadow_map_seed"),
			"sky_map_enabled": mat.get_shader_parameter("cloud_shadow_map_enabled"),
			"sky_detail_enabled": mat.get_shader_parameter("cloud_shadow_map_detail_enabled"),
			"layers": actual_layers, "ground_map_seed": ground.get_shader_parameter("cloud_shadow_map_seed"),
			"ground_shadow_seed": ground.get_shader_parameter("appearance_shadow_seed")})
	print("CLOUD_SEED_PROOF ", JSON.stringify(rows))
	print("CLOUD_SEED_PROOF_COMPLETE")
	quit(0)
