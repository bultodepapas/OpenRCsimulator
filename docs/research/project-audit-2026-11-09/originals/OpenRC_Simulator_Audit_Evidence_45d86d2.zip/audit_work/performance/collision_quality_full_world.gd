extends SceneTree

const FieldLoader := preload("res://data/field_loader.gd")
const CollisionSetup := preload("res://scenery/collision_setup.gd")
const Collision := preload("res://sim/scenery_collision.gd")
const SceneDetail := preload("res://render/scene_detail.gd")
const Scenery := preload("res://scenery/scenery.gd")
const RB := preload("res://physics/rigid_body.gd")

func _initialize() -> void:
	OS.set_environment("OPENRC_LANDSCAPE_UPGRADE", "on")
	OS.set_environment("OPENRC_SCENERY", "on")
	OS.unset_environment("OPENRC_SCENE_DETAIL")
	OS.unset_environment("OPENRC_SCENERY_QUALITY")
	OS.unset_environment("OPENRC_SCENERY_FILE")
	var field_result := FieldLoader.load_from()
	if not field_result.ok:
		printerr("FIELD_FAILED ", field_result.errors)
		quit(1)
		return
	# One valid 1/240 s, 24 m/s sweep crosses the bench-seat edge, outside the
	# seated person's capsule. The same minimal hull/state is used for every world.
	var previous := RB.make_state(PackedFloat64Array([-16.76, 12.2, -0.43]),
		PackedFloat64Array([24.0, 0.0, 0.0]), PackedFloat64Array([1.0, 0.0, 0.0, 0.0]),
		PackedFloat64Array([0.0, 0.0, 0.0]))
	var current := previous.duplicate()
	current[RB.POS] += 24.0 / 240.0
	var hull := PackedFloat64Array([0.0, 0.0, 0.0])
	var inertia := PackedFloat64Array([1.0, 1.2, 1.4, 0.0, 0.0, 0.0])
	var rows := []
	var passed := true
	for level: String in ["low", "medium", "high"]:
		SceneDetail.set_preference(level)
		var built := CollisionSetup.build(field_result.field)
		if not built.ok:
			printerr("WORLD_FAILED ", level, " ", built.errors)
			quit(1)
			return
		var world: Dictionary = built.world
		var bench_proxies := []
		var counts := {}
		for proxy: Dictionary in world.proxies:
			counts[proxy.kind] = int(counts.get(proxy.kind, 0)) + 1
			if proxy.damage_id == "prop:benches:02":
				bench_proxies.append(proxy.duplicate(true))
		var contacts := []
		var bench_contacts := 0
		for event: Collision.Event in Collision.contacts(previous, current, hull, world, 1, 2.0, inertia):
			contacts.append({"obstacle_id": event.obstacle_id, "damage_id": event.damage_id,
				"part": event.obstacle_part, "time_fraction": event.time_fraction,
				"terminal": event.terminal, "response_class": event.response_class,
				"normal_speed_mps": event.normal_speed_mps, "impact_energy_j": event.impact_energy_j})
			if event.damage_id == "prop:benches:02":
				bench_contacts += 1
		passed = passed and bench_proxies.size() == (2 if level == "high" else 0)
		passed = passed and bench_contacts == (1 if level == "high" else 0)
		rows.append({"scene_detail": level, "resolved_scenery_quality": Scenery.options().quality,
			"world_identity": world.identity, "proxy_count": world.proxies.size(), "counts_by_kind": counts,
			"bench_proxies": bench_proxies, "contacts": contacts})
		print("FULL_COLLISION_WORLD ", JSON.stringify({"scene_detail": level, "scenery_quality": Scenery.options().quality,
			"world_identity": world.identity, "proxy_count": world.proxies.size(), "bench_proxies": bench_proxies.size(),
			"contacts": contacts}))
	passed = passed and rows[0].world_identity != rows[1].world_identity and rows[1].world_identity != rows[2].world_identity
	var result := {"scope": "Actual production FieldLoader, SceneDetail, CollisionSetup.build, SceneryCollision.contacts; complete default-field obstacle inventories; minimal point hull rather than complete flight",
		"passed": passed, "previous_state": previous, "current_state": current, "hull": hull,
		"tick_duration_s": 1.0 / 240.0, "mass_kg": 2.0, "inertia": inertia, "worlds": rows}
	var output := FileAccess.open("/workspace/scratch/30a3be555435/audit_work/performance/collision_quality_full_world.json", FileAccess.WRITE)
	output.store_string(JSON.stringify(result, "\t") + "\n")
	print("FULL_COLLISION_PROOF_COMPLETE passed=", passed)
	quit(0 if passed else 1)
