extends SceneTree

# Extract unchanged pure functions and the literal catalog to avoid loading unrelated
# render assets in this sparse checkout. This witnesses selection, not a complete flight.
func _fragment(path: String, begin: String, end: String) -> String:
	var source := FileAccess.get_file_as_string(path)
	var first := source.find(begin)
	var last := source.find(end, first + begin.length())
	return source.substr(first, last - first)

func _initialize() -> void:
	var policy := GDScript.new()
	policy.source_code = "extends RefCounted\nconst Palette = preload(\"res://scenery/palette.gd\")\n\n" + _fragment("res://scenery/scenery.gd", "static func keep(", "\n\nstatic func ")
	var seeds := GDScript.new()
	seeds.source_code = "extends RefCounted\n\n" + _fragment("res://scenery/scenery_loader.gd", "static func _seed(", "\n\nstatic func ")
	var catalog_script := GDScript.new()
	catalog_script.source_code = "extends RefCounted\n\n" + _fragment("res://scenery/prefabs.gd", "const CATALOG := {", "\n\n\n## Draws")
	if policy.reload() != OK or seeds.reload() != OK or catalog_script.reload() != OK:
		quit(1)
		return
	var catalog: Dictionary = catalog_script.get_script_constant_map().CATALOG
	var raw: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/scenery/default.json"))
	var rows := []
	var counts := {"high": {}, "balanced": {}, "low": {}}
	var collidable_counts := {"high": 0, "balanced": 0, "low": 0}
	for group: Dictionary in raw.groups:
		if group.type != "instances":
			continue
		var choices: Array = group.get("prefabs", [group.get("prefab", "")])
		var placement_rows: Array = group.placements.value
		var group_seed: int = seeds.call("_seed", group.id)
		for i in placement_rows.size():
			var chosen: String = choices[i % choices.size()] if choices.size() == 1 else choices[int(seeds.call("_seed", "%s/%d" % [group.id, i])) % choices.size()]
			if not catalog.has(chosen) or catalog[chosen].tier != "ornament":
				continue
			var seed: int = (group_seed + i * 7919) & 0x7fffffff
			var kept := {}
			# All ornament prefabs except flower_clump have an explicit collision branch
			# in collision_world.gd:360-384; count placements, not individual proxies.
			var collidable: bool = chosen != "flower_clump"
			for quality: String in counts:
				kept[quality] = policy.call("keep", "ornament", seed, quality)
				if kept[quality]:
					counts[quality][chosen] = int(counts[quality].get(chosen, 0)) + 1
					if collidable:
						collidable_counts[quality] += 1
			rows.append({"group": group.id, "source_index": i, "prefab": chosen,
				"position_ne_heading": placement_rows[i], "seed": seed,
				"has_collision_branch": collidable, "kept": kept})
	var result := {"scope": "Unchanged production pure keep/_seed functions and prefab catalog; source layout; not full rendered world or flown trajectory",
		"ornament_placements": rows.size(), "counts": counts, "collidable_placement_counts": collidable_counts, "placements": rows}
	var output := FileAccess.open("/workspace/scratch/30a3be555435/audit_work/performance/collision_quality_census.json", FileAccess.WRITE)
	output.store_string(JSON.stringify(result, "\t") + "\n")
	print("COLLISION_QUALITY_CENSUS ", JSON.stringify({"ornament_placements": rows.size(), "counts": counts, "collidable_placement_counts": collidable_counts}))
	for row: Dictionary in rows:
		if row.group == "benches" and row.source_index == 2:
			print("COLLISION_QUALITY_WITNESS ", JSON.stringify(row))
	print("COLLISION_QUALITY_CENSUS_COMPLETE")
	quit(0)
