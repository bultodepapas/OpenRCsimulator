"""Inventory literal eager resource edges from main.gd; bytes are encoded source sizes, not memory."""
import collections
import json
import pathlib
import re

ROOT = pathlib.Path('/workspace/scratch/30a3be555435/OpenRCsimulator')
OUT = ROOT.parent / 'audit_work/performance'
METADATA = json.loads((ROOT.parent / 'audit_work/asset_sizes.json').read_text())
EDGE = re.compile(r'\b(?:preload\s*\(\s*|extends\s+)[\"\']res://([^\"\']+)[\"\']')

def strip_comment(line):
    quote = None
    escape = False
    for at, character in enumerate(line):
        if escape:
            escape = False
        elif character == '\\' and quote:
            escape = True
        elif quote:
            if character == quote:
                quote = None
        elif character in '\"\'':
            quote = character
        elif character == '#':
            return line[:at]
    return line

pending = ['app/main.gd']
visited = set()
edges = []
owners = collections.defaultdict(set)
parent = {}
while pending:
    owner = pending.pop()
    if owner in visited:
        continue
    visited.add(owner)
    for lineno, line in enumerate((ROOT / owner).read_text().splitlines(), 1):
        for match in EDGE.finditer(strip_comment(line)):
            child = (ROOT / 'app' / match.group(1)).resolve().relative_to(ROOT).as_posix()
            edges.append({'owner': owner, 'line': lineno, 'resource': child})
            parent.setdefault(child, owner)
            if child.endswith('.gd'):
                pending.append(child)
            else:
                owners[child].add(owner)

assets = []
for path, direct_owners in sorted(owners.items()):
    chain = [path]
    while chain[-1] != 'app/main.gd':
        chain.append(parent[chain[-1]])
    assets.append({'path': path, 'owners': sorted(direct_owners), 'chain_from_main': chain[::-1], **METADATA.get(path, {})})
result = {'root': 'app/main.gd', 'script_count': len(visited), 'direct_resource_count': len(assets),
          'catalogued_asset_count': sum('size' in a for a in assets),
          'encoded_bytes': sum(a.get('size', 0) for a in assets),
          'notes': 'Literal preload/extends edges only; source sizes not imported size, RAM, VRAM, or measured loading time. Dynamic load and transitive glTF/scene references excluded.',
          'scripts': sorted(visited), 'assets': assets, 'edges': edges}
(OUT / 'preload_asset_inventory.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('scripts', 'assets', 'edges')}))
for owner in ['app/render/lake/water_effects.gd', 'app/aircraft/timber_visual_details.gd',
              'app/aircraft/ugly_stik_equipment.gd', 'app/render/landscape_upgrade/ridges.gd',
              'app/scenery/building_roofs.gd', 'app/render/rc_ground_material.gd']:
    subset = [a for a in assets if owner in a['owners']]
    print(json.dumps({'owner': owner, 'direct_assets': len(subset), 'encoded_bytes': sum(a.get('size', 0) for a in subset)}))
