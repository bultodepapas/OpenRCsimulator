extends SceneTree

# Audit witness: load the unchanged optional material module, never configure it.
const PATHS := [
	"res://assets/landscape/rc-ground/dirt-albedo.jpg",
	"res://assets/landscape/rc-ground/dirt-normal.jpg",
	"res://assets/landscape/rc-ground/dirt-roughness.jpg",
	"res://assets/landscape/rc-ground/grass-albedo.jpg",
	"res://assets/landscape/rc-ground/grass-normal.jpg",
	"res://assets/landscape/rc-ground/grass-roughness.jpg",
]

func rss_kib() -> int:
	var status := FileAccess.get_file_as_string("/proc/self/status")
	for line in status.split("\n"):
		if line.begins_with("VmRSS:"):
			return int(line.trim_prefix("VmRSS:").strip_edges().get_slice(" ", 0))
	return -1

func _initialize() -> void:
	var cached_before := []
	for path: String in PATHS:
		cached_before.append(ResourceLoader.has_cached(path))
	var memory_before := OS.get_static_memory_usage()
	var peak_before := OS.get_static_memory_peak_usage()
	var rss_before := rss_kib()
	var library: Script = load("res://render/rc_ground_material.gd")
	var memory_after := OS.get_static_memory_usage()
	var peak_after := OS.get_static_memory_peak_usage()
	var rss_after := rss_kib()
	if library == null:
		push_error("Audit could not load the production material module")
		quit(1)
		return
	var cached_after := []
	var textures := []
	for path: String in PATHS:
		cached_after.append(ResourceLoader.has_cached(path))
		var texture: Texture2D = load(path)
		textures.append({path = path, width = texture.get_width(), height = texture.get_height()})
	var report := {
		engine = Engine.get_version_info().string,
		display = DisplayServer.get_name(),
		module = "res://render/rc_ground_material.gd",
		configure_called = false,
		configure_field_called = false,
		cached_before = cached_before,
		cached_after = cached_after,
		textures = textures,
		debug_static_bytes_before = memory_before,
		debug_static_bytes_after = memory_after,
		debug_static_bytes_delta = memory_after - memory_before,
		debug_peak_bytes_before = peak_before,
		debug_peak_bytes_after = peak_after,
		process_rss_kib_before = rss_before,
		process_rss_kib_after = rss_after,
		measurement_scope = "headless process module load; no viewport rendering or GPU memory measurement",
	}
	print("RC_MATERIAL_PRELOAD ", JSON.stringify(report))
	print("AUDIT_RC_MATERIAL_PRELOAD_COMPLETE")
	quit(0)
