extends SceneTree

const AD := preload("res://physics/aircraft_data.gd")
const Aero := preload("res://physics/aero.gd")
const Air := preload("res://physics/air_data.gd")
const RB := preload("res://physics/rigid_body.gd")
const M := preload("res://physics/math3d.gd")
const ZERO := {elevator = 0.0, aileron_right = 0.0, aileron_left = 0.0, rudder = 0.0}

func state(w:float) -> PackedFloat64Array:
	return RB.make_state(M.v3(0,0,-100),M.v3(-20,0,w),M.q_identity(),M.v3(1,0,0))

func sample(model: Dictionary,w:float) -> Dictionary:
	var s := state(w)
	var air := Air.compute(s,M.v3(0,0,0))
	return {state=Array(s),loads=Array(Aero.loads(s,air,ZERO,model,1.225)),held_wake_loads=Array(Aero.loads(s,air,ZERO,model,1.225,0.0)),angles=Array(Aero._wing_flow(s,air,ZERO,model).angles),wake=Aero.wing_wake_velocity(s,air,ZERO,model)}

func _initialize() -> void:
	var loaded:Dictionary = AD.load_file("res://data/aircraft/gp_extra_300s_60.json")
	if not loaded.get("ok",false):
		print(JSON.stringify(loaded))
		quit(1)
		return
	var model:Dictionary=loaded.model
	var ablated:Dictionary=model.duplicate(true)
	var ablated_factors:PackedFloat64Array=ablated.envelope.wing_polar.strip_factor.duplicate()
	ablated_factors.fill(1.0)
	ablated.envelope.wing_polar.strip_factor=ablated_factors
	for strip in [0,1,2]:
		var y:float = model.reference.arp_le[1]-model.cg_le[1]+model.envelope.station_ys[strip]
		var lo:float=-y-0.01
		var hi:float=-y+0.01
		for _k in 60:
			var mid:float=(lo+hi)*0.5
			var s:=state(mid)
			var angle:float=Aero._wing_flow(s,Air.compute(s,M.v3(0,0,0)),ZERO,model).angles[strip]
			if angle < 0.0: lo=mid
			else: hi=mid
		var boundary:float=(lo+hi)*0.5
		for epsilon in [1e-4,1e-6,1e-8,1e-10]:
			var above:=sample(model,boundary+epsilon)
			var below:=sample(model,boundary-epsilon)
			var delta:Array=[]
			for k in 6:delta.append(above.loads[k]-below.loads[k])
			var held_delta:Array=[]
			for k in 6:held_delta.append(above.held_wake_loads[k]-below.held_wake_loads[k])
			var ablated_above:=sample(ablated,boundary+epsilon)
			var ablated_below:=sample(ablated,boundary-epsilon)
			var ablated_delta:Array=[]
			for k in 6:ablated_delta.append(ablated_above.loads[k]-ablated_below.loads[k])
			var ablated_held_delta:Array=[]
			for k in 6:ablated_held_delta.append(ablated_above.held_wake_loads[k]-ablated_below.held_wake_loads[k])
			var acceleration_delta:=RB.inertia_mul(RB.inertia_inverse(model.inertia),PackedFloat64Array(delta.slice(3,6)))
			var held_acceleration_delta:=RB.inertia_mul(RB.inertia_inverse(model.inertia),PackedFloat64Array(held_delta.slice(3,6)))
			print(JSON.stringify({strip=strip,factor=model.envelope.wing_polar.strip_factor[strip],mass=model.mass_kg,inertia=Array(model.inertia),boundary_w=boundary,epsilon_mps=epsilon,above=above,below=below,delta=delta,angular_acceleration_delta_radps2=Array(acceleration_delta),ablated_delta=ablated_delta,held_wake_delta=held_delta,held_wake_angular_acceleration_delta_radps2=Array(held_acceleration_delta),ablated_held_wake_delta=ablated_held_delta}))
	print("AUDIT_STRIP_SEAM_COMPLETE")
	quit(0)
