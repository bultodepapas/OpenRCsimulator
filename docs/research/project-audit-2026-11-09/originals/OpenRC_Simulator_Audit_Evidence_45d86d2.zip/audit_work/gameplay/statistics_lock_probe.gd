extends SceneTree

func _initialize() -> void:
	var store_script: Script = load("res://statistics/store.gd")
	var root_uri := "user://audit_statistics_lock_%d" % Time.get_ticks_usec()
	var store: RefCounted = store_script.new()
	var initially_opened: bool = store.open(root_uri)
	var first_writable: bool = store.writable
	var first_generation: int = int(store.data.get("generation", -1))
	store.close()
	var pid := OS.create_process("/bin/true", PackedStringArray())
	OS.delay_msec(50)
	var exited_child := not OS.is_process_running(pid)
	var lock_path := ProjectSettings.globalize_path(root_uri).path_join(".writer_lock")
	var lock_error := DirAccess.make_dir_absolute(lock_path)
	var owner := {"format": "openrc-flight-statistics-lock", "pid": pid, "token": "audit-stale-owner"}
	var encoded := JSON.stringify(owner)
	var file := FileAccess.open(lock_path.path_join("owner.json"), FileAccess.WRITE)
	file.store_string(encoded)
	file.close()
	var parsed: Dictionary = JSON.parse_string(encoded)
	var attempts: Array = []
	for attempt in 2:
		var reopened: RefCounted = store_script.new()
		var opened: bool = reopened.open(root_uri)
		attempts.append({"opened": opened, "writable": reopened.writable, "note": reopened.note,
			"snapshot_generation": reopened.data.get("generation", -1)})
		reopened.close()
	print("AUDIT_STATS_LOCK ", JSON.stringify({"engine": Engine.get_version_info().string,
		"root": ProjectSettings.globalize_path(root_uri), "initial_opened": initially_opened,
		"initial_writable": first_writable, "generation": first_generation,
		"child_pid": pid, "child_exited": exited_child, "lock_mkdir_error": lock_error,
		"writer_pid_type": type_string(typeof(owner.pid)), "parsed_pid_type": type_string(typeof(parsed.pid)),
		"attempts": attempts}))
	var reproduced: bool = initially_opened and first_writable and exited_child and lock_error == OK \
		and typeof(parsed.pid) == TYPE_FLOAT and not attempts[0].writable and not attempts[1].writable \
		and str(attempts[0].note).contains("malformed")
	print("AUDIT_STATS_LOCK_REPRODUCED=", reproduced)
	quit(0 if reproduced else 1)
