"""Portable adapter; original receipt probes and reports are never overwritten."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
PIN='45d86d250f6e38a3d9b60d30c01bdc2396571efe'
ORIGINAL_WORK='/workspace/scratch/30a3be555435/audit_work/'
commands={x['label']:x for x in json.loads((ROOT/'audit_commands.json').read_text())}
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('run',choices=[*commands,'inventory'])
p.add_argument('--godot',type=Path,help='Official Godot 4.8-beta2 executable; required for Godot probes')
p.add_argument('--repo',type=Path,help='Complete checkout at the pinned commit; required except isolated statistics/cloud')
p.add_argument('--out',type=Path,required=True,help='New empty output directory; preserves original receipts')
args=p.parse_args(); out=args.out.resolve()
if out.exists(): p.error('--out must be a new directory')
subprocess.run([sys.executable,str(ROOT/'verify.py')],check=True)
if args.repo:
 args.repo=args.repo.resolve()
 head=subprocess.check_output(['git','-C',str(args.repo),'rev-parse','HEAD'],text=True).strip()
 if head!=PIN: p.error('repository HEAD differs from pinned commit')
if args.run=='inventory':
 if not args.repo: p.error('--repo is required')
 out.mkdir(parents=True)
 original=ROOT/'audit_work/performance/inventory_preloads.py'
 text=original.read_text()
 text=text.replace("ROOT = pathlib.Path('/workspace/scratch/30a3be555435/OpenRCsimulator')",'ROOT = pathlib.Path('+repr(str(args.repo))+')')
 text=text.replace("OUT = ROOT.parent / 'audit_work/performance'",'OUT = pathlib.Path('+repr(str(out))+')')
 text=text.replace("ROOT.parent / 'audit_work/asset_sizes.json'",'pathlib.Path('+repr(str(ROOT/'audit_work/asset_sizes.json'))+')')
 adapter=out/'inventory_preloads_adapter.py'; adapter.write_text(text)
 (out/'adapter_provenance.json').write_text(json.dumps({'original':str(original),'adapter':str(adapter),'changes':'ROOT, OUT, and asset_sizes.json path only; no analysis logic changed'},indent=2)+'\n')
 raise SystemExit(subprocess.run([sys.executable,str(adapter)]).returncode)
if not args.godot: p.error('--godot is required')
engine=args.godot.resolve(); version=subprocess.check_output([str(engine),'--version'],text=True).strip()
if version!='4.8.beta2.official.cafc17a19': p.error('engine version differs from receipt: '+version)
item=commands[args.run]; r=json.loads((ROOT/item['receipt']).read_text()); cmd=list(r['command']); cmd[0]=str(engine)
project=cmd[cmd.index('--path')+1]
if project=='app':
 if not args.repo: p.error('--repo is required for this probe; materialize all assets and import first')
 project=str(args.repo/'app')
else:
 if not project.startswith(ORIGINAL_WORK): p.error('unrecognized original project')
 source=ROOT/'audit_work'/project[len(ORIGINAL_WORK):]
 out.mkdir(parents=True)
 target=out/'isolated_project'; shutil.copytree(source,target)
 project=str(target)
out.mkdir(parents=True,exist_ok=True)
cmd[cmd.index('--path')+1]=project
script_index=cmd.index('--script')+1; original_script=cmd[script_index]
if original_script.startswith(ORIGINAL_WORK):
 source=ROOT/'audit_work'/original_script[len(ORIGINAL_WORK):]
 text=source.read_text()
 if ORIGINAL_WORK in text:
  # Collision probes write a sidecar JSON to a historical absolute path.
  # Explicitly substitute only that output-root string in a copied adapter.
  output_root=out/'sidecars'; (output_root/'performance').mkdir(parents=True)
  target=out/(source.stem+'_output_path_adapter.gd')
  target.write_text(text.replace(ORIGINAL_WORK,str(output_root)+'/'))
  (out/'adapter_provenance.json').write_text(json.dumps({'original':str(source),'adapter':str(target),'replaced_output_prefix':ORIGINAL_WORK,'replacement_output_prefix':str(output_root)+'/'},indent=2)+'\n')
  cmd[script_index]=str(target)
 else: cmd[script_index]=str(source)
runner=ROOT/'production/tools/godot/run_checked.py'
wrapper=[sys.executable,str(runner),'--timeout',str(r['timeout_seconds']),'--out-dir',str(out/'checks'),'--label',r['label']+'-replay']
for marker in r['required_text']: wrapper+=['--require-text',marker]
wrapper+=['--',*cmd]
(out/'replay_command.json').write_text(json.dumps({'command':wrapper,'original_receipt':item['receipt'],'original_receipt_ok':r['ok'],'original_process_exit':r['process_exit'],'engine_version':version},indent=2)+'\n')
print('Original receipt expected ok='+str(r['ok'])+', process_exit='+str(r['process_exit']),flush=True)
raise SystemExit(subprocess.run(wrapper,cwd=str(args.repo or out)).returncode)
