"""Verify original receipts, packaged files, and optionally pinned Git source blobs."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(); p.add_argument('--repo',type=Path); args=p.parse_args()
issues=[]; count=0
for line in (ROOT/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1); path=ROOT/name; count+=1
 if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected: issues.append(name)
for item in json.loads((ROOT/'receipt_hash_verification.json').read_text()):
 folder=ROOT/item['receipt']; r=json.loads((folder/'report.json').read_text()); b=(folder/'engine.log').read_bytes()
 if hashlib.sha256(b).hexdigest()!=r['log_sha256'] or len(b)!=r['log_bytes']: issues.append(item['receipt'])
sources=json.loads((ROOT/'production_source_manifest.json').read_text())
for item in sources:
 b=(ROOT/item['packaged_path']).read_bytes()
 if hashlib.sha256(b).hexdigest()!=item['sha256']: issues.append(item['packaged_path'])
 # Git blob identity is independently computable without a checkout.
 oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if oid!=item['git_blob_oid']: issues.append(item['packaged_path']+' git-blob')
 if args.repo:
  data=subprocess.check_output(['git','-C',str(args.repo),'show',item['commit']+':'+item['repository_path']])
  if data!=b: issues.append(item['packaged_path']+' pinned-repository-source')
print(json.dumps({'checked_manifest_files':count,'original_receipts':9,'verified_source_copies':len(sources),'issues':issues},indent=2))
raise SystemExit(1 if issues else 0)
