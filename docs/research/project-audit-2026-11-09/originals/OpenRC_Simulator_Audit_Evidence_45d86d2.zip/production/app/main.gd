extends Node3D

## Set by the interactive shell before the session enters the tree.
var external_controller_selection := false
## External capture owners set this before tree entry when they must finish their own artifact cleanup.
var frametimes_auto_quit := true
## Override the inferred frame-time route when an external owner supplies pilot commands.
var frametimes_route: String = ""
# The game shell: world, airplane rendering, camera, panel, keys, captures and headless traces.
# The flight itself (aircraft data, trim, commands, simulation) lives in sim/flight_session.gd.

const Spec := preload("res://spec.gd")
const Scripted := preload("res://sim/scripted.gd")
const Frames := preload("res://render/frames.gd")
const AirplaneBuilder := preload("res://render/airplane.gd")
const AircraftLightingRig := preload("res://render/lighting/aircraft_lighting_rig_3d.gd")
const LightingProfile := preload("res://render/lighting/lighting_profile.gd")
const GroundGear := preload("res://render/ground_gear.gd")
const TimberVisualMotion := preload("res://aircraft/timber_visual_motion.gd")
const PropellerBlur := preload("res://render/propeller_blur.gd")
const EngineSmoke := preload("res://render/smoke/exhaust.gd")
const Propulsion := preload("res://physics/propulsion.gd")
const Slipstream := preload("res://physics/slipstream.gd")
const SmokeAssignment := preload("res://ui/smoke_aux_assignment.gd")
const PilotCamera := preload("res://render/pilot_camera.gd")
const CameraRig := preload("res://render/camera/camera_rig.gd")
const CameraSettings := preload("res://render/camera/camera_settings.gd")
const Magnifier := preload("res://render/camera/magnifier.gd")
const CameraCollision := preload("res://render/camera/camera_collision.gd")
const GroundTerrain := preload("res://physics/ground_terrain.gd")
const Commands := preload("res://input/commands.gd")
const ControlSurfaces := preload("res://physics/control_surfaces.gd")
const InputPanel := preload("res://render/panel.gd")
const FlightSession := preload("res://sim/flight_session.gd")
const FailureConfig := preload("res://failures/config.gd")
const OutOfTrim := preload("res://sim/out_of_trim.gd")
## D6-TRIM-01: one rudder trim press in maximum-throw units, like the aileron's 0.5 %.
const RUDDER_TRIM_STEP := 0.005
const CompanionConfig := preload("res://ai/companions/config.gd")
const CompanionManager := preload("res://ai/companions/manager.gd")
const UiTheme := preload("res://ui/ui_theme.gd")
const CrashDirector = preload("res://render/crash/director.gd")
const CrashPresentationContext = preload("res://render/crash/presentation_context.gd")
const AccidentIncident = preload("res://economy/incident.gd")
const AccidentSettlement = preload("res://economy/settlement.gd")
const AccidentReport = preload("res://ui/accident_report.gd")
const SceneryDamageDirector = preload("res://render/crash/scenery_damage.gd")
const ImpactSnapshot = preload("res://physics/impact_snapshot.gd")
const Recorder := preload("res://sim/recorder.gd")
const FlightLog := preload("res://sim/flight_log.gd")
const FlightLogCliHost := preload("res://tools/flight_log_cli_host.gd")
const NativeQualification := preload("res://tools/native_qualification.gd")
const RB := preload("res://physics/rigid_body.gd")
const Catalog := preload("res://app_state/aircraft_catalog.gd")
const Preferences := preload("res://app_state/preferences.gd")
const MoonConfig := preload("res://environment/moon_config.gd")
const ScenarioConfig := preload("res://scenarios/scenario_config.gd")
const EngineSound := preload("res://render/engine_sound.gd")
const FlightAudio = preload("res://audio/flight_audio.gd")
const VisualTimeline = preload("res://environment/visual_timeline.gd")
const VisualCheckpoint = preload("res://app_state/visual_checkpoint.gd")
const LightingConfig = preload("res://environment/time_of_day_config.gd")
const TimeOfDayLighting = preload("res://render/time_of_day_lighting.gd")
const Atmosphere := preload("res://render/atmosphere.gd")
const SkyConfig := preload("res://environment/sky_appearance_config.gd")
const SkyCheckpoint := preload("res://app_state/sky_checkpoint.gd")
const Lightning := preload("res://render/weather/lightning.gd")
const ShaderClock := preload("res://render/shader_clock.gd")
const Shadow := preload("res://render/shadow.gd")
const Ground := preload("res://render/ground.gd") # legacy atmosphere fixture only
const FieldLoader = preload("res://data/field_loader.gd")
const Landscapes = preload("res://landscapes/catalog.gd")
const RcTrackOption = preload("res://scenery/rc_track_option.gd")
const RcTrack = preload("res://physics/ground_vehicle/airfield_track.gd")
const FieldBuilder = preload("res://render/field.gd")
const LakeWorld = preload("res://render/lake/lake_world.gd")
const LakeReflection = preload("res://render/lake/lake_reflection.gd")
const World := preload("res://render/world/world.gd")
const FieldError = preload("res://ui/field_error.gd")
const Hud := preload("res://render/hud.gd")
const FrameSamples := preload("res://render/frame_samples.gd")
const SceneDetail := preload("res://render/scene_detail.gd")
const ViewportColor := preload("res://render/viewport_color.gd")
const Reconstruction := preload("res://render/reconstruction.gd")
const Air := preload("res://physics/air_data.gd")
const M := preload("res://physics/math3d.gd")
const VisualEvidence = preload("res://render/visual_evidence.gd")
const BuildInfo := preload("res://app_state/build_info.gd")
const LatencyPatch = preload("res://input/latency_patch.gd")
const OverlayManager := preload("res://render/overlays/overlay_manager.gd")
const WATER_CHECKPOINT_FORMAT := "openrc-visual-water-checkpoint v1"
const WATER_CHECKPOINT_FIELDS: Array[String] = ["format", "visual", "water_render", "payload_sha256"]
const INSTALLATION_GEOMETRY_HOLD := "accepted propeller geometry could not be displayed"

## [Esc] outside the calibration wizard: the pilot asks for the pause menu (app_root owns menus; without one, nothing).
signal pause_requested
signal restart_requested
## The player changed the flight overlays (X, [F2], [F3]); Home saves them (docs/plans/flight-overlays.md).
signal overlay_settings_changed(settings: Dictionary)
signal latency_marker_changed(enabled: bool)
signal scenario_changed(scenario: Dictionary)

## Data path is injectable before entering the tree; normal routes use the packaged default.
var field_path: String = FieldLoader.DEFAULT_PATH
var landscape_id: String = Landscapes.DEFAULT_ID
var field: Dictionary = {}

var session: Node
var recorder: RefCounted
var flight_log: RefCounted
var _flight_log_label: Label
## The catalog aircraft to fly. Set before adding the node (Home does); otherwise --aircraft=<id>, else the Ugly Stik.
var aircraft_id := ""
## Detached Workshop compilation; aircraft_id remains the catalog visual identity.
var workshop_trial: Dictionary = {}
## NR: accepted resolved selection, outside the sealed physics/weather/checkpoint contracts.
var flight_scenario: Dictionary = {}
## Session origin survives checkpoint restore, which deliberately clears scenario provenance.
var remember_lighting_selection: bool = true
var _experimental_aircraft_path := ""
var _electric_demo: String = ""
## BAT-13: "ideal" (the aircraft's main data) or "pack" (its finite-pack data). Home sets it; else --battery=<mode>;
## empty means the aircraft's default (the finite pack where the catalog provides one).
var battery_mode: String = ""
## FUEL-07: start fill of a finite-fuel tank (0, 1]. Home sets it; else --fuel=<fraction>; 1 = full tank.
var fuel_start_fill: float = 1.0
## F4U-16: paint scheme of the visual model; "" is the default paint. Home sets it; else --livery=<id>. A Workshop
## trial flies the default paint its appearance profile was authored on.
var livery: String = ""
## Home supplies its selection. Quick Flight defaults to runway; technical routes keep their reference start.
var start_choice: String = "airborne"
## D6e-R4: Home and Quick Flight trim every airplane for level flight at this throttle, in the air or as the runway
## start's flying trim; technical routes keep the reference trim (NAN) unless they select airborne_half_power.
var trim_throttle: float = NAN
var weather_config: Dictionary = {}
## Airborne companion choices are resolved at launch/restart; direct flights ignore Home preferences.
var companion_config: Dictionary = CompanionConfig.defaults()
## Accepted launch settings, retained even when an Off launch creates no manager.
var _companion_admitted_config: Dictionary = {}
var companions: Node
var _companions_initialized := false
var _companions_reset_pending := false
var _companions_reset_generation := -1
var _companions_reset_session_id := 0
var _companions_reset_roster := false
var _companions_resume_after_reset := false
var _companions_application_focused := true
var _companions_error := ""
## Resolved only when this flight is created. Session reset retains its draw and onset.
var failure_config: Dictionary = FailureConfig.defaults()
var failure_seed: int = -1
var failure_notifications: bool = true
## D6-TRIM-01: natural out-of-trim airframes, resolved when this flight is created like the failure settings.
## The shell shares `out_of_trim_airframes` across its flights (first flight only keeps an airframe all session).
var out_of_trim_config: Dictionary = OutOfTrim.defaults()
var out_of_trim_seed: int = -1
var out_of_trim_airframes: Dictionary = {}
var _failure_notice: CanvasLayer
var _failure_label: Label
var _failure_overlays_visible: bool = true
## TOD: immutable selection for this flight; no preference reads on the direct route.
var lighting_config: Dictionary = {}
var sky_config: Dictionary = SkyConfig.defaults()
var _sky_edits: Array = []
var _storm_fx: Node3D
## FW-71: visual-only field lighting and campfire choices; direct launches resolve these from CLI defaults/flags.
var night_options: Dictionary = Preferences.NIGHT_DEFAULTS.duplicate(true)
## AppRoot passes the same argument list it used to choose the direct route; standalone launches use the OS list.
var user_args: PackedStringArray = OS.get_cmdline_user_args()
var _lighting: Dictionary = {}
var _visual_timeline: Dictionary = {}
var _visual_context_status: String = "present"
var _field_world_lighting: bool = false
var _world_environment: WorldEnvironment
var _sun: DirectionalLight3D
var _field_node: Node3D


func _failure_options(options: Dictionary) -> Dictionary:
	var config: Dictionary = failure_config.duplicate(true)
	var seed_value: int = failure_seed
	if options.has("failures"):
		if typeof(options.failures) != TYPE_STRING or not str(options.failures).is_valid_int():
			return {ok = false, errors = ["--failures needs an integer from 0 to 100"]}
		config.probability_percent = str(options.failures).to_int()
	for key: String in ["catastrophic", "failure-notices"]:
		if options.has(key):
			if options[key] not in ["on", "off"]:
				return {ok = false, errors = ["--%s must be on or off" % key]}
			config["include_catastrophic" if key == "catastrophic" else "notify"] = options[key] == "on"
	# EM-29: severity, onset window and excluded types; values are validated by FailureConfig.
	if options.has("failure-severity"):
		config.severity = str(options["failure-severity"])
	if options.has("failure-onset"):
		config.onset = str(options["failure-onset"])
	if options.has("failure-exclude"):
		var excluded: Array[String] = []
		for item: String in str(options["failure-exclude"]).split(",", false):
			excluded.append(item.strip_edges())
		config.excluded_ids = excluded
	if options.has("failure-seed"):
		if typeof(options["failure-seed"]) != TYPE_STRING or not str(options["failure-seed"]).is_valid_int():
			return {ok = false, errors = ["--failure-seed needs an integer from 0 to 4294967295"]}
		seed_value = str(options["failure-seed"]).to_int()
		if seed_value < 0:
			return {ok = false, errors = ["--failure-seed must be non-negative"]}
	var checked: Dictionary = FailureConfig.validate(config)
	if not checked.ok:
		return checked
	if seed_value < -1 or seed_value > 4294967295:
		return {ok = false, errors = ["Failure seed must fit an unsigned 32-bit integer"]}
	if seed_value == -1:
		# A local RNG never perturbs weather/scenery or the failure generator's resolved sequence.
		var random_source := RandomNumberGenerator.new()
		random_source.randomize()
		seed_value = random_source.randi() if checked.config.probability_percent > 0 else 0
	return {ok = true, config = checked.config, seed = seed_value, errors = []}


## D6-TRIM-01: --out-of-trim=<0..100> enables it at that intensity, --out-of-trim-mode=first-flight|every-flight,
## --out-of-trim-seed=<n> fixes the airframe draws. Otherwise the shell's (Home's) selection.
func _out_of_trim_options(options: Dictionary) -> Dictionary:
	var config: Dictionary = out_of_trim_config.duplicate(true)
	var seed_value: int = out_of_trim_seed
	if options.has("out-of-trim"):
		if typeof(options["out-of-trim"]) != TYPE_STRING or not str(options["out-of-trim"]).is_valid_int():
			return {ok = false, errors = ["--out-of-trim needs an integer from 0 to 100"]}
		config.enabled = true
		config.intensity_percent = str(options["out-of-trim"]).to_int()
	if options.has("out-of-trim-mode"):
		if options["out-of-trim-mode"] not in ["first-flight", "every-flight"]:
			return {ok = false, errors = ["--out-of-trim-mode must be first-flight or every-flight"]}
		config.mode = str(options["out-of-trim-mode"]).replace("-", "_")
	if options.has("out-of-trim-seed"):
		if typeof(options["out-of-trim-seed"]) != TYPE_STRING or not str(options["out-of-trim-seed"]).is_valid_int():
			return {ok = false, errors = ["--out-of-trim-seed needs an integer from 0 to 4294967295"]}
		seed_value = str(options["out-of-trim-seed"]).to_int()
		if seed_value < 0:
			return {ok = false, errors = ["--out-of-trim-seed must be non-negative"]}
	var checked: Dictionary = OutOfTrim.validate(config)
	if not checked.ok:
		return checked
	if seed_value > 4294967295:
		return {ok = false, errors = ["Out-of-trim seed must fit an unsigned 32-bit integer"]}
	if seed_value == -1:
		var random_source := RandomNumberGenerator.new()
		random_source.randomize()
		seed_value = random_source.randi() if checked.config.enabled else 0
	return {ok = true, config = checked.config, seed = seed_value, errors = []}


## One built airframe per catalog aircraft (its battery or fuel choice does not rebuild it); a Workshop trial is its own.
func _out_of_trim_airframe_key() -> String:
	return aircraft_id if workshop_trial.is_empty() else "workshop:" + str(workshop_trial.identity.get("trial_id", ""))


## Direct/technical launches never read interactive preferences. All values remain SI/full precision.
func _weather_options(options: Dictionary) -> Dictionary:
	var raw: Variant = weather_config.duplicate(true) if not weather_config.is_empty() else FlightSession.WeatherConfig.defaults()
	if options.has("weather") and options.has("weather-file"):
		return {ok = false, config = {}, errors = PackedStringArray(["choose --weather or --weather-file, not both"])}
	if options.has("weather"):
		if typeof(options.weather) != TYPE_STRING:
			return {ok = false, config = {}, errors = PackedStringArray(["--weather needs a preset ID"])}
		raw = FlightSession.WeatherConfig.preset(options.weather)
		if raw.is_empty():
			return {ok = false, config = {}, errors = PackedStringArray(["unknown weather preset '%s'" % options.weather])}
	if options.has("weather-file"):
		if typeof(options["weather-file"]) != TYPE_STRING or not FileAccess.file_exists(options["weather-file"]):
			return {ok = false, config = {}, errors = PackedStringArray(["--weather-file needs an existing JSON file"])}
		var parser: JSON = JSON.new()
		if parser.parse(FileAccess.get_file_as_string(options["weather-file"])) != OK:
			return {ok = false, config = {}, errors = PackedStringArray(["weather JSON is invalid: " + parser.get_error_message()])}
		raw = parser.data
	var mappings: Dictionary = {"wind-speed": "speed_mps", "wind-from": "from_deg", "gust-speed": "gust_mps", "gust-up": "gust_up_mps", "gust-duration": "gust_duration_s", "gust-period": "gust_period_s", "gust-delay": "gust_delay_s"}
	for key: String in mappings:
		if not options.has(key):
			continue
		if not raw is Dictionary or typeof(options[key]) != TYPE_STRING or not str(options[key]).is_valid_float():
			return {ok = false, config = {}, errors = PackedStringArray(["--%s needs a finite number" % key])}
		raw[mappings[key]] = str(options[key]).to_float()
	return FlightSession.WeatherConfig.validate(raw)


func _render_wind(time_s: float) -> Vector3:
	if _scripted or session == null:
		return Vector3.ZERO
	return Frames.ned_to_render(Array(session.wind_at(time_s)))


## Read-only datum observation; presentation does not need aerodynamic station receipts.
func _observer_air(state: PackedFloat64Array, sample_time_s: float) -> Dictionary:
	return Air.compute(state, session.wind_at(sample_time_s, state), session.air_density(state))


var interactive_start: bool = false
## UI-34c: optional presentation-only checkpoints. Direct/capture/trace routes stay synchronous.
var startup_checkpoint := Callable()
## Polled on the main thread while a private numeric trim job runs.
var startup_cancel_requested := Callable()
## UI-34c: owned privately until world construction and final setup validation finish.
var _preparing_session: Node
var startup_preparation_metrics: Dictionary = {}
var startup_complete := false
signal startup_finished
signal frame_time_report_written(exit_code: int)
## UI-06d: Home injects the saved diagnostic choice; technical launches retain their explicit marker flag.
var latency_marker_enabled: bool = false
## Flight overlays instead of the legacy text labels: Home sets it with the saved settings; the direct route uses
## --hud=overlays (default --hud=legacy, so captures and automation keep their picture).
var overlays_enabled: bool = false
var overlay_settings: Variant = {}
## CAM-17: the player's camera settings (display.cfg [camera]); Home sets them, direct routes leave them empty and keep
## --view/--autozoom.
var camera_preferences: Dictionary = {}
var startup_error: String = ""
var _airplane: Dictionary
var _camera: Camera3D
## CAM-02: views, zoom and camera input (render/camera/camera_rig.gd); built with the world.
var _rig: CameraRig
## CAM-18: the magnifier inset (off unless the player chose it).
var _magnifier: Magnifier
## CAM-09: the scenery collision world the cameras keep clear of (a reference, built once with the session's).
var _camera_obstacles: Dictionary = {}
## RC-TRACK: this flight's RC car circuit, decided once; it feeds the field build, the wheels and the obstacles.
var _rc_track: Dictionary = {}
## The view a flight starts in: --view=<pilot|chase|orbit|closeup>, or closeup with --inspect.
var _initial_view := "pilot"
var _camera_dt := 0.0
var _panel: Label
## The historical close-up switch, kept for fixtures that set it: true selects the close-up view, false the pilot view.
var _inspect: bool:
	get:
		return _rig.view == "closeup" if _rig != null else _initial_view == "closeup"
	set(on):
		if _rig != null:
			_rig.set_view("closeup" if on else "pilot")
		else:
			_initial_view = "closeup" if on else "pilot"
var _capturing := false
var _capture_settle_frames := 0
var _t := 0.0
var _prop_angle := 0.0
## --scripted: the Stage 0/1 scripted circle instead of the physics simulation.
var _scripted := false
var _engine_audio: AudioStreamPlayer3D
var _soundscape_audio: FlightAudio
var _lake_ambience: AudioStreamPlayer3D
## Technical fixtures can retain the original diagnostic freeze route.
var crash_effects_enabled := true
## CR-30/32: independent from visual effects; technical fixtures can opt out.
var accident_reports_enabled := true
var accident_archive_path := "user://last_accident.json"
var _accident_incident: RefCounted
var _accident_report: CanvasLayer
var _accident_restored := false
var _accident_bindings: Dictionary = {}
var _accident_evidence_warning_pending := false
var _accident_source_hash := ""
var _accident_archive_error := OK
var _accident_settlement: RefCounted
var _accident_settled_pending := false
var _accident_ground_stable := false
var _accident_reload_pending := false
var _accident_checkpoint_restoring := false
var _accident_paired_history := false
var _crash_director: CrashDirector
var _history_crash_camera_active := false
var _people_crash_clock_s := 0.0 # SC-HUM-05 presentation time since the player's crash
## VQ-01c-R1: the windsock/people and profile-smoke observers advance once per rendered frame.
const PresentationCadence := preload("res://render/presentation_cadence.gd")
var _windsock_cadence := PresentationCadence.new()
var _profile_smoke_cadence := PresentationCadence.new()
var _scenery_damage_director: SceneryDamageDirector
var _cg_model := Vector3.ZERO
var _env: Environment
## Landscape review view (L0): (azimuth, elevation) in degrees from the pilot's eye, or (NAN, NAN) to follow the airplane.
var _look := Vector2(NAN, NAN)
var _look_height := 1.7 # m above the pilot station (L0b top-down view: 30)
var _shadow: MeshInstance3D
## Ground shadow mode: "sun" (projected along the light, L3, default), "vertical" (the D7 pilot aid) or "off".
## [V] cycles; Gate L decides the default.
const SHADOW_MODES := ["sun", "vertical", "off"]
var _shadow_mode := "sun"
var _shadow_cli_override := false
var _shadow_preference := ""
var _shadow_settings_revision := -1
var _night_kit: Node3D # FW-35c: lazy presentation kit; state belongs to this flight.
var _rgb_lighting: Node3D
var _rgb_applied_rig_id := 0
var _rgb_applied_mode := ""
var _rgb_applied_gain := -1.0
var _lighting_reacts_to_airspeed := false
var _aircraft_lights := World.AircraftLightState.new()
var _aircraft_lights_hud_dirty := true
var _extent := Vector2(1.5, 1.3) # airplane span and length (m), measured from the built model
var _hud: Label
var _overlays: CanvasLayer = null # OverlayManager when overlays_enabled
var _auto_zoom := true
var _show_perf := true
var _frame_times := PackedFloat64Array()
## VQ-01b frame-time logger; raw wall deltas and the engine's delta are both retained.
var _frametimes_path: String = ""
var _frametimes_warmup_s: float = 1.0
var _frametimes_duration: float = 20.0
var _frametime_samples: RefCounted = null
var _frame_diagnostics: RefCounted = null
var _frametimes_elapsed: float = 0.0
var _frametimes_active: bool = false
var _frametimes_clock_primed: bool = false
var _frametimes_scripted_fixed: bool = false
var _frametimes_last_usec: int = 0
var _frametimes_sim_start_s: float = 0.0
var _frametimes_sim_start_tick: int = 0
var _frametimes_previous_drawn: int = -1
var _frametimes_draw_counter_resets: int = 0
var _frametimes_no_draw_intervals: int = 0
var _frametimes_undrawable_samples: int = 0
## Last one-off message (reload result), shown in the panel.
var _note := ""
var _wheel_brake_key_held := false
var _visual_pose: Dictionary = {}
const ProfileSmoke := preload("res://render/smoke/smoke_system.gd")
const StockSmoke := preload("res://render/smoke/stock_profile.gd")
const AircraftCustomization := preload("res://render/aircraft_customization.gd")
var _profile_smoke: Node3D
var _stock_smoke_profile := false
var _profile_smoke_tick := 0
var _profile_last_accepted_tick := -1
var _profile_presented_s := -1.0
var _profile_request_tape: Array = []
var _profile_source_tape: Array = []
var _profile_last_request := -1.0
var _profile_last_running := false
var _profile_presented_request := 0.0
var _profile_presented_running := false
var _profile_last_level := -1.0
var _profile_presented_level := 0.0
var _profile_last_wash := Vector3.ZERO
var _profile_presented_wash := Vector3.ZERO
var _smoke: EngineSmoke
var _smoke_key_on := false
## F4U-17: wing-fold mechanism state (0 spread and locked, 1 folded) and its target. Presentation only; while not
## spread and locked the session holds the throttle at idle.
var _wing_fold := 0.0
var _wing_fold_target := 0.0
## F4U-21: auxiliary mechanism states by key (0 closed or stowed, 1 open or lowered) and their targets. Presentation only.
var _mechanisms := {}
var _mechanism_targets := {}
var _smoke_assignment: SmokeAssignment
var _smoke_assignment_was_paused := false
var _last_render_pose: Dictionary = {}
var _treeline_hidden: bool = false # L6c background-only capture (--hide_treeline)


func _ready() -> void:
	# A fixed diagnostic runs in this same executable and owns its exit; it never starts a flight scene.
	for argument: String in user_args:
		if argument.begins_with("--native-qualification"):
			set_process(false)
			set_process_input(false)
			set_process_unhandled_input(false)
			var qualification := NativeQualification.new()
			add_child(qualification)
			qualification.start(user_args)
			return
		if argument.begins_with("--flight-log-cli"):
			set_process(false)
			set_process_input(false)
			set_process_unhandled_input(false)
			var log_host := FlightLogCliHost.new()
			add_child(log_host)
			log_host.start(user_args)
			return
	if startup_checkpoint.is_valid():
		process_mode = Node.PROCESS_MODE_DISABLED
	await _prepare_flight()
	await _cancel_preparing_session()
	var startup_args := _user_args()
	var prime_pose := (interactive_start and startup_checkpoint.is_valid()) or startup_args.has("quick-flight")
	if prime_pose and not _capturing and not _scripted and not startup_args.has("capture") and not startup_args.has("trace") \
			and startup_error.is_empty() \
			and not _startup_cancel_requested() and is_instance_valid(session) and session.is_flyable():
		# Loading and quick-flight may draw before our first _process. Present the validated
		# tick-zero model and camera without advancing simulation, clocks or input.
		_render_pose(_current_pose(), session.surfaces(), _prop_angle)
	startup_complete = true
	startup_finished.emit()


func _startup_stage(label: String) -> bool:
	if startup_checkpoint.is_valid():
		return await startup_checkpoint.call(label)
	return true


func _startup_cancel_requested() -> bool:
	return not is_inside_tree() or (startup_cancel_requested.is_valid() and bool(startup_cancel_requested.call()))


## Freeze the same foreground setup as the historical path; selected weather/fuel still apply later.
func _new_flight_setup(args: Dictionary) -> Dictionary:
	var next_session := FlightSession.new()
	# The app requests native physics by default; tools and replay retain their reference default.
	if (not _scripted or args.has("physics-backend")) \
			and (not next_session.setup_stage_backend(str(args.get("physics-backend", "native"))) or _scripted):
		printerr("physics backend refused: ", next_session.stage_backend_error if not _scripted else "requires a physics flight")
		next_session.free()
		next_session = null
		get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return {}
	next_session.external_controller_selection = external_controller_selection
	next_session.physics_enabled = not _scripted
	# This explicit airborne operating point must be selected before setup solves trim.
	# Runway selection still waits for field/contact configuration below.
	next_session.trim_throttle = trim_throttle # D6e-R4: setup() solves it for airborne and runway launches alike
	if start_choice == FlightSession.START_HALF_POWER:
		next_session.start_choice = start_choice
	if args.has("shaft-integrator") and (not next_session.setup_shaft_integrator(args["shaft-integrator"]) or _scripted):
		printerr("shaft integrator refused: ", next_session.shaft_error if not _scripted else "requires a physics flight")
		next_session.free() # refused before add_child(): this owner would otherwise remain orphaned
		next_session = null
		get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return {}
	var physics_path: String = _experimental_aircraft_path if not _experimental_aircraft_path.is_empty() else (Catalog.data_for(aircraft_id, battery_mode) if _electric_demo.is_empty() else "res://data/aircraft/synthetic_stik_electric_%s.json" % _electric_demo.replace("-", "_"))
	var expected_id: String = aircraft_id if _electric_demo.is_empty() and _experimental_aircraft_path.is_empty() else ""
	var frozen_data: Dictionary = {}
	if not workshop_trial.is_empty():
		next_session.workshop_identity = workshop_trial.identity.duplicate(true)
		next_session.workshop_presentation_identity = workshop_trial.get("presentation_identity", {}).duplicate(true)
		physics_path = "workshop://" + str(workshop_trial.identity.trial_id)
		expected_id = str(workshop_trial.data.model.id)
		frozen_data = workshop_trial.data
	return {session = next_session, path = physics_path, expected_id = expected_id, frozen_data = frozen_data}


## Controlled cancellation waits without joining a live worker. Raw removal uses the Session's orphan drain.
func _cancel_preparing_session() -> void:
	if not is_instance_valid(_preparing_session):
		return
	var owned: Node = _preparing_session
	var tree: SceneTree = get_tree()
	if tree != null:
		# Never await a coroutine owned by this detached Session: _exit_tree may free it
		# while the worker drains. The saved tree signal keeps this wait in Main's lifetime.
		var frame: Signal = tree.process_frame
		owned.cancel_staged_setup(frame)
		while is_instance_valid(owned) and owned.staged_setup_pending():
			await frame
	if is_instance_valid(owned):
		if is_same(_preparing_session, owned):
			_preparing_session = null
		owned.free()


func _prepare_flight() -> void:
	var args := _user_args()
	var companion_options: Dictionary = CompanionConfig.from_args(user_args, companion_config)
	if not companion_options.ok:
		startup_error = "; ".join(companion_options.errors)
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		return
	companion_config = companion_options.config
	var variant_launch: Dictionary = preload("res://workshop/launch.gd").from_args(args)
	if not variant_launch.ok:
		startup_error = "; ".join(PackedStringArray(variant_launch.errors))
		printerr(startup_error)
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start: get_tree().quit(ERR_INVALID_PARAMETER)
		return
	if variant_launch.requested:
		workshop_trial = variant_launch.trial.duplicate(true)
		aircraft_id = variant_launch.base_id
	if not interactive_start:
		if args.has("start"):
			start_choice = str(args.start)
		elif args.has("quick-flight"):
			# X8-07: Quick Flight's ground start is the hand launch for an airplane without landing gear.
			var quick_id: String = aircraft_id if not aircraft_id.is_empty() else str(args.get("aircraft", Catalog.DEFAULT_ID))
			start_choice = FlightSession.START_HAND_LAUNCH if Catalog.hand_launch_supported(quick_id) else FlightSession.START_RUNWAY
		if args.has("quick-flight"):
			trim_throttle = FlightSession.CRUISE_TRIM_THROTTLE # D6e-R4: the player's shortcut launches trimmed like Home
		if start_choice not in [FlightSession.START_RUNWAY, FlightSession.START_AIRBORNE, FlightSession.START_HALF_POWER,
				FlightSession.START_HAND_LAUNCH]:
			printerr("--start must be runway, airborne, airborne_half_power or hand_launch")
			set_process(false)
			set_process_unhandled_input(false)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
	var night_result: Dictionary = Preferences.validate_night_options(night_options) if interactive_start \
		else Preferences.night_options_from_args(args)
	if not night_result.get("ok", false):
		startup_error = "; ".join(night_result.errors)
		printerr("night lighting: " + startup_error)
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	night_options = night_result.options.duplicate(true)
	# The field-world route owns --date when paired with its time selection.
	var lighting_args: Dictionary = args.duplicate()
	if (args.has("time_of_day") or args.has("time")) and not (args.has("time-of-day") or args.has("lighting") or args.has("lighting-config")):
		lighting_args.erase("date")
	var selected_light: Dictionary = LightingConfig.validate(LightingConfig.defaults() if lighting_config.is_empty() else lighting_config) if interactive_start else LightingConfig.from_args(lighting_args)
	if not selected_light.ok:
		startup_error = "; ".join(selected_light.errors)
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr("lighting: " + startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		return
	lighting_config = selected_light.config.duplicate(true)
	var selected_sky: Dictionary = SkyConfig.validate(sky_config) if interactive_start else SkyConfig.from_args(args)
	if not selected_sky.ok:
		startup_error = "; ".join(selected_sky.errors)
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr("sky: " + startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		return
	sky_config = selected_sky.config
	_lighting = TimeOfDayLighting.snapshot(lighting_config)
	_visual_timeline = VisualTimeline.create(lighting_config).timeline
	var latency_args: Dictionary = args.duplicate()
	if interactive_start and latency_marker_enabled:
		latency_args["latency-patch"] = true
	var latency_options: Dictionary = LatencyPatch.options(latency_args)
	if not latency_options.ok:
		printerr(latency_options.error)
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	var trace_ticks: int = -1
	if args.has("trace"):
		var duration_text: String = str(args.get("t", Spec.CAPTURE.time))
		var duration: float = duration_text.to_float() if duration_text.is_valid_float() else NAN
		var rounded_ticks: float = roundf(duration * Engine.physics_ticks_per_second)
		if typeof(args.trace) != TYPE_STRING or str(args.trace).is_empty() \
			or not is_finite(duration) or duration <= 0.0 or not is_finite(rounded_ticks) \
			or rounded_ticks < 1.0 or rounded_ticks >= float(9223372036854775807):
			push_error("--trace requires a path and finite positive --t that rounds to at least one tick and fits the tick counter")
			set_process(false)
			set_process_unhandled_input(false)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
		trace_ticks = int(rounded_ticks)
	landscape_id = str(args.get("landscape", landscape_id))
	if not Landscapes.has(landscape_id):
		startup_error = "Unknown landscape: " + landscape_id
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	if field_path == FieldLoader.DEFAULT_PATH:
		field_path = Landscapes.entry(landscape_id).field_path
	if not await _startup_stage("Checking landscape"):
		return
	var loaded_field: Dictionary = FieldLoader.load_from(field_path)
	if not loaded_field.ok:
		if interactive_start:
			startup_error = "; ".join(loaded_field.errors)
			set_process(false)
			set_process_unhandled_input(false)
			return
		FieldError.report(self, loaded_field.errors)
		return
	field = loaded_field.field
	if not interactive_start and not args.has("start") and field.id != "default":
		start_choice = FlightSession.START_AIRBORNE
	var frametime_options: Dictionary = FrameSamples.options(args)
	if not frametime_options.ok:
		push_error(str(frametime_options.error))
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	var pose_error: String = VisualEvidence.validate_pose(args)
	if pose_error != "":
		push_error(pose_error)
		set_process(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	if args.has("visual_pose"):
		_visual_pose = VisualEvidence.synthetic_pose(str(args.visual_pose), float(args.visual_distance), float(field.pilot.eye_height) - float(field.pilot.down),
			float(args.get("visual_elevation", VisualEvidence.DEFAULT_ELEVATION_DEG)), float(args.get("visual_azimuth", VisualEvidence.DEFAULT_AZIMUTH_DEG)))
		_visual_pose.pos += Frames.ned_to_render([field.pilot.north, field.pilot.east, 0.0])
	# Deliver input events at once: with accumulation, joypad events reach the game a frame late on Linux/macOS.
	Input.use_accumulated_input = false
	_inspect = args.has("inspect")
	if args.has("view"):
		_initial_view = str(args.view)
		if not CameraRig.is_view(_initial_view) or (args.has("visual_pose") and _initial_view != "pilot"):
			push_error("--view must be one of %s (visual poses need the pilot view)" % ", ".join(CameraRig.VIEWS))
			set_process(false)
			set_process_unhandled_input(false)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
	_scripted = args.has("scripted")
	# RC-TRACK: one decision per flight for the rendered circuit, the wheels' terrain and the collision world.
	_rc_track = {} if _scripted or landscape_id != Landscapes.DEFAULT_ID or _capture_scene_id() != "field" \
		else RcTrackOption.resolve(field, interactive_start)
	if aircraft_id == "":
		aircraft_id = str(args.get("aircraft", Catalog.DEFAULT_ID))
	# Frozen Workshop builds retain their own original base and exact snapshot identity.
	if workshop_trial.is_empty():
		aircraft_id = Catalog.canonical_id(aircraft_id)
	if not Catalog.has(aircraft_id) or (not Catalog.can_fly(aircraft_id) and not _scripted):
		# Never another airplane in its place, and never a preview "flying" without flight data (it would be a
		# ballistic throw). A preview may still fly the scripted circle (--scripted): visual only.
		push_error("aircraft '%s' refused: %s" % [aircraft_id, "not in the catalog (%s)" % ", ".join(Catalog.ids()) if not Catalog.has(aircraft_id) else "preview only, no flight data (use --scripted)"])
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(1)
		return
	_electric_demo = str(args.get("electric-demo", ""))
	if args.has("electric-demo") and (_electric_demo not in ["4s", "6s", "4s-battery", "6s-battery"] or aircraft_id != Catalog.DEFAULT_ID or _scripted):
		printerr("electric demo requires 4s, 6s, 4s-battery or 6s-battery, the default visual airframe, and a physics flight")
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	if args.has("fuel"):
		var fuel_arg := str(args.get("fuel", ""))
		fuel_start_fill = float(fuel_arg) if fuel_arg.is_valid_float() else NAN
	if not is_finite(fuel_start_fill) or fuel_start_fill <= 0.0 or fuel_start_fill > 1.0:
		printerr("fuel fill refused: use --fuel=<fraction> with 0 < fraction <= 1 (1 = full tank)")
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	if args.has("livery"):
		livery = str(args.get("livery", ""))
	if not livery.is_empty() and not AirplaneBuilder.livery_choices(aircraft_id).any(func(choice: Dictionary) -> bool: return choice.id == livery):
		printerr("livery refused: '%s' is not a paint scheme of %s" % [livery, aircraft_id])
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	if args.has("battery"):
		battery_mode = str(args.get("battery", ""))
	if battery_mode.is_empty():
		battery_mode = "ideal" if not _electric_demo.is_empty() or not workshop_trial.is_empty() else Catalog.default_battery_mode(aircraft_id)
	if not Catalog.has_battery_mode(aircraft_id, battery_mode) or (battery_mode != "ideal" and not _electric_demo.is_empty()):
		printerr("battery mode '%s' refused for '%s': use ideal, or pack where the catalog declares battery_data" % [battery_mode, aircraft_id])
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	var experimental_input_sha256 := ""
	if args.has("experimental-aircraft-data"):
		var experimental: Dictionary = _validate_experimental_aircraft_data(
			args.get("experimental-aircraft-data"), aircraft_id, _scripted, args.has("electric-demo"))
		if not experimental.ok:
			printerr("experimental aircraft data refused: ", experimental.error)
			set_process(false)
			set_process_unhandled_input(false)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
		_experimental_aircraft_path = experimental.path
		experimental_input_sha256 = experimental.input_sha256
		_note = "EXPERIMENTAL: wing polar; aircraft-specific flight validation pending."
		print("EXPERIMENTAL AIRCRAFT DATA: wing polar, aircraft-specific flight validation pending: ", _experimental_aircraft_path)
	_auto_zoom = str(args.get("autozoom", "1")) != "0"
	var hud_mode := str(args.get("hud", "overlays" if overlays_enabled else "legacy"))
	if hud_mode != "legacy" and hud_mode != "overlays":
		printerr("--hud must be legacy or overlays")
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	overlays_enabled = hud_mode == "overlays"
	if args.has("look_az"):
		_look = Vector2(float(args.look_az), float(args.get("look_el", 0.0)))
		_look_height = float(args.get("look_alt", field.pilot.eye_height))
	# Reject session-independent options before building render resources or solving launch trim.
	var failure_options: Dictionary = _failure_options(args)
	if not failure_options.ok or (_scripted and failure_options.config.probability_percent > 0):
		startup_error = "; ".join(failure_options.errors) if not failure_options.ok else "Failures require a physics flight."
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	var trim_options: Dictionary = _out_of_trim_options(args)
	if not trim_options.ok or (_scripted and trim_options.config.enabled):
		startup_error = "; ".join(trim_options.errors) if not trim_options.ok else "Out-of-trim airframes require a physics flight."
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	var conditions: Dictionary = _weather_options(args)
	if not conditions.ok:
		startup_error = "; ".join(conditions.errors)
		if not interactive_start:
			printerr("weather refused: ", startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	Atmosphere.engine_shadows = Atmosphere.engine_shadows_enabled(args, interactive_start)
	var overlap_setup := interactive_start and startup_checkpoint.is_valid() and not _scripted
	startup_preparation_metrics = {overlapped = overlap_setup, acquire_usec = 0,
		workers_before = FlightSession.launch_trim_cache_stats().staged_workers_started}
	if overlap_setup:
		var acquire_began := Time.get_ticks_usec()
		var setup_request: Dictionary = _new_flight_setup(args)
		if setup_request.is_empty():
			return
		_preparing_session = setup_request.session
		if not _preparing_session.begin_staged_setup(setup_request.path, setup_request.expected_id,
				setup_request.frozen_data, _startup_cancel_requested):
			return
		startup_preparation_metrics.acquire_usec = Time.get_ticks_usec() - acquire_began
	_initialize_shadow_mode(args)
	var world_began := Time.get_ticks_usec()
	var world_ready: bool = await _build_world()
	startup_preparation_metrics.world_usec = Time.get_ticks_usec() - world_began
	if not world_ready:
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_DATA)
		return
	_rig.set_view(_initial_view)
	_rig.auto_zoom = _auto_zoom
	_rig.look = _look
	_rig.look_height = _look_height
	if not camera_preferences.is_empty():
		CameraSettings.apply_at_start(_rig, camera_preferences)
	if args.has("hide_airplane"):
		# L0c readability: the same view without the airplane (and its pilot-aid shadow) is the background reference.
		_airplane.root.visible = false
		_shadow.visible = false
	if args.has("hide_treeline"):
		# L6c: the same view without the vegetation gives the exact tree mask behind the airplane. A field with
		# nothing to hide (the atmosphere fixture) must fail, never pass off a view with trees as the tree-free one.
		if not _hide_field_objects():
			push_error("--hide_treeline refused: this field has no objects to hide")
			set_process(false)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
	if not await _startup_stage("Checking flight"):
		return
	var finish_began := Time.get_ticks_usec()
	if is_instance_valid(_preparing_session):
		# Main can survive raw removal while _exit_tree frees its detached Session.
		# Own the wait here instead of awaiting a coroutine on that shorter-lived node.
		var owned: Node = _preparing_session
		var frame: Signal = get_tree().process_frame
		owned.finish_staged_setup(frame, _startup_cancel_requested)
		while is_instance_valid(owned) and owned.staged_setup_pending():
			await frame
		if not is_instance_valid(owned) or not owned.staged_setup_completed() or _startup_cancel_requested():
			return
		# Publication stays after world construction, final validation and the unchanged initial reset.
		session = _preparing_session
		_preparing_session = null
	else:
		var setup_request: Dictionary = _new_flight_setup(args)
		if setup_request.is_empty():
			return
		session = setup_request.session
		if startup_checkpoint.is_valid():
			if not await session.setup_staged(setup_request.path, setup_request.expected_id, setup_request.frozen_data,
					get_tree().process_frame, _startup_cancel_requested):
				return
		else:
			session.setup(setup_request.path, setup_request.expected_id, setup_request.frozen_data)
	startup_preparation_metrics.finish_setup_usec = Time.get_ticks_usec() - finish_began
	startup_preparation_metrics.workers_after = FlightSession.launch_trim_cache_stats().staged_workers_started
	if not await _startup_stage("Preparing flight model"):
		return
	if not _sync_accepted_installation_geometry(true):
		push_error("render/airplane.gd: validated glow model has no applicable propeller diameter")
		session.free()
		session = null
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_DATA)
		return
	if session.aircraft.get("ok", false) and session.aircraft.model.propulsion.get("glow", {}).is_empty() and startup_checkpoint.is_valid():
		_sync_shadow_preference()
		Shadow.bind_model(_shadow, _airplane.root, {}, _shadow_proxy_context(), _shadow_mode)
	# D6e-R5: sport gives keyboard/gamepad full roll travel with normal pitch/yaw.
	# --rates selects the high/low starting profile; radios retain transmitter rates.
	var rates := str(args.get("rates", "sport"))
	if rates not in ["normal", "sport", "full"]:
		printerr("--rates must be normal, sport or full")
		session.free()
		session = null
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	session.rate_profile = rates
	if not _experimental_aircraft_path.is_empty():
		var candidate_model: Dictionary = session.aircraft.get("model", {}) if session.aircraft.get("ok", false) else {}
		var candidate_envelope: Dictionary = candidate_model.get("envelope", {})
		if not session.aircraft.get("ok", false) or candidate_model.get("id", "") != Catalog.DEFAULT_ID or not candidate_envelope.has("wing_polar") or session.aircraft.get("input_identity", {}).get("sha256", "") != experimental_input_sha256:
			var load_reason := "; ".join(session.aircraft.get("errors", PackedStringArray())) if not session.aircraft.get("ok", false) else "loaded model identity/polar is missing, or candidate changed during validation"
			printerr("experimental aircraft data refused after load: ", load_reason)
			session.free()
			session = null
			set_process(false)
			set_process_unhandled_input(false)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
	if args.has("shaft-integrator") and not session.is_flyable():
		printerr("shaft integrator refused: ", session.pause_reason)
		session.free()
		session = null
		get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	if not await _startup_stage("Preparing contacts"):
		return
	session.set_field(field) # E3a: the wheels roll on this field's runway, mown and rough surfaces
	# The accepted scene definition also owns the float64 contact surface. Never fly a refused lake.
	var lake_context: Dictionary = _field_node.get_meta("lake_context", {}) if _field_node != null else {}
	var lake_error: String = str(_field_node.get_meta("lake_error", "")) if _field_node != null else ""
	if not lake_error.is_empty() or not session.set_lake_context(lake_context):
		startup_error = "Lake configuration refused: " + lake_error
		session.free()
		session = null
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_DATA)
		return
	# RC-TRACK: the wheels roll on exactly the circuit the field drew; never fly one without the other.
	var drawn_track: String = str(_field_node.get_meta("rc_track_identity", "")) if _field_node != null else ""
	if drawn_track != RcTrack.identity(_rc_track) or not session.set_rc_track(_rc_track):
		startup_error = "RC circuit configuration refused"
		session.free()
		session = null
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_DATA)
		return
	if not _scripted and _capture_scene_id() == "field":
		var obstacles: Dictionary = Landscapes.collision_world(landscape_id, field, _rc_track)
		if obstacles.ok:
			_camera_obstacles = obstacles.world
		if not obstacles.ok or not session.set_collision_world(obstacles.world):
			startup_error = "Scenery collision inventory refused: " + "; ".join(obstacles.errors)
			session.free()
			session = null
			set_process(false)
			set_process_unhandled_input(false)
			if not interactive_start:
				printerr(startup_error)
				get_tree().quit(ERR_INVALID_DATA)
			return
	session.start_choice = start_choice
	failure_config = failure_options.config.duplicate(true)
	failure_seed = failure_options.seed
	failure_notifications = failure_config.notify
	if not _scripted and not session.setup_failures(failure_config, failure_seed):
		startup_error = session.failure_error
		session.free()
		session = null
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	out_of_trim_config = trim_options.config.duplicate(true)
	out_of_trim_seed = trim_options.seed
	if not _scripted and not session.setup_out_of_trim(out_of_trim_config, out_of_trim_seed, out_of_trim_airframes,
			_out_of_trim_airframe_key()):
		startup_error = session.out_of_trim_error
		session.free()
		session = null
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	if not session.setup_weather(conditions.config):
		startup_error = session.weather_error
		session.free()
		session = null
		if not interactive_start:
			printerr("weather refused: ", startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	if not await _startup_stage("Preparing start"):
		return
	_update_cg_model()
	Atmosphere.configure_appearance(sky_config, SkyConfig.mean_wind_ned(session.weather_configuration()))
	if args.has("alt"):
		session.set_start_altitude(float(args.alt))
	# Setup already trimmed this inventory. Only a changed fill needs a new solve;
	# the session also checks that the selected tank contains usable fuel.
	if fuel_start_fill != session.fuel_start_fill and not session.set_fuel_start_fill(fuel_start_fill):
		startup_error = "Fuel fill refused: the selected amount must exceed the tank's unusable fuel."
		session.free()
		session = null
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		set_process(false)
		set_process_unhandled_input(false)
		return
	session.name = "FlightSession" # a stable path for tools and reports
	add_child(session)
	if startup_checkpoint.is_valid():
		session.hold("loading")
	# The windsock is a read-only presentation consumer; uploads happen in World.update. It samples the
	# committed wind at the last accepted tick before each rendered frame (VQ-01c-R1; per tick with cadence 0).
	if not _scripted:
		session.sim.stepped.connect(_advance_windsock)
	Input.joy_connection_changed.connect(_on_smoke_connection_changed)
	if latency_options.enabled:
		var latency_patch: LatencyPatch = LatencyPatch.new()
		latency_patch.session = session
		latency_patch.axis = latency_options.axis
		latency_patch.threshold = latency_options.threshold
		latency_patch.left_side = _overlays != null # HUD: the overlays hold the right-hand side
		add_child(latency_patch)
		latency_marker_enabled = true
		latency_patch.closed.connect(func() -> void: set_latency_marker_enabled(false))
	recorder = Recorder.new(session.sim, session.electrical_state, session.mass_properties)
	session.resetting.connect(_on_resetting)
	if str(args.get("soundscape", "on")) == "legacy" and session.aircraft.ok and not _scripted and session.aircraft.model.propulsion.get("kind", "glow_prop") != "electric_prop":
		_engine_audio = EngineSound.create(_airplane.root, session.sim, session.aircraft.model.propulsion.max_rpm)
	session.reset()
	GroundGear.attach(_airplane, session)
	TimberVisualMotion.attach(_airplane, session)
	# VQ-05: speed-driven propeller blur beside the model (never inside it); it only reads sim.aux[0] each frame.
	PropellerBlur.attach(_airplane, session, self)
	Magnifier.tag(get_node_or_null("PropellerBlur")) # CAM-18: the blur disc belongs in the magnifier too
	# A frozen profile replaces the legacy exhaust rig. Global smoke-off suppresses
	# either runtime, while technical trace/capture routes may still render a profile.
	if not await _startup_stage("Preparing effects"):
		return
	var selected_smoke_profile: Dictionary = workshop_trial.get("presentation_profile", {})
	# Stock effects use authored show mounts, never inferred engine exhaust. A saved
	# Workshop appearance (including an empty smoke selection) owns its own choices.
	if workshop_trial.is_empty() and str(args.get("smoke-backend", "profile")) != "legacy" and not _scripted and not args.has("capture") and not args.has("trace") and session.aircraft.get("ok", false):
		selected_smoke_profile = StockSmoke.for_aircraft(_airplane.get("customization_bindings", {}), session.aircraft.model.propulsion)
		_stock_smoke_profile = not selected_smoke_profile.is_empty()
	var profile_smoke_entries: Array = selected_smoke_profile.get("smoke", [])
	if not profile_smoke_entries.is_empty():
		if str(args.get("smoke", "on")) != "off":
			_smoke_key_on = str(args.get("smoke-pump", "off")) == "on"
			var described := AircraftCustomization.describe(aircraft_id)
			_profile_smoke = ProfileSmoke.new()
			_profile_smoke.name = "Smoke"
			add_child(_profile_smoke)
			if not described.get("ok", false) or not _profile_smoke.configure(selected_smoke_profile, described.get("bindings", {})):
				startup_error = "The aircraft smoke profile is no longer available."
				return
			_profile_smoke.play()
			session.sim.stepped.connect(_sample_profile_smoke)
	elif workshop_trial.is_empty() and str(args.get("smoke-backend", "profile")) == "legacy" and str(args.get("smoke", "on")) != "off" and not _scripted and not args.has("capture") and not args.has("trace") and session.aircraft.get("ok", false):
		var mouths: Array = _airplane.get("exhausts", [])
		if mouths.size() == 1 and EngineSmoke.valid_anchor(mouths[0]) \
				and Propulsion.source_kind(session.aircraft.model.propulsion) == mouths[0].kind:
			_smoke = EngineSmoke.new()
			_smoke.name = "Smoke"
			add_child(_smoke)
			_smoke.configure(mouths[0])
			_smoke_key_on = str(args.get("smoke-pump", "off")) == "on" # explicit technical capture/profile request
	if not _experimental_aircraft_path.is_empty() and (not session.is_flyable() or not session.surface_error.is_empty()):
		var candidate_flight_error: String = session.start_error if not session.start_error.is_empty() else session.pause_reason
		if candidate_flight_error.is_empty():
			candidate_flight_error = session.surface_error if not session.surface_error.is_empty() else "candidate did not produce a flyable start"
		printerr("experimental aircraft data refused before flight: ", candidate_flight_error)
		session.sim.set_paused(true)
		session.sim.process_mode = Node.PROCESS_MODE_DISABLED
		set_process(false)
		set_process_unhandled_input(false)
		get_tree().quit(ERR_INVALID_PARAMETER)
		return
	if not _scripted and not session.is_flyable():
		startup_error = session.start_error if not session.start_error.is_empty() else session.pause_reason
		if startup_error.is_empty():
			startup_error = "Aircraft data or starting condition invalid."
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr("Flight start refused: " + startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		return
	# E3d1: interactive flights get soft hull contacts (a wingtip brush or belly slide continues); scripted, capture
	# and trace routes keep "any hull contact is a crash". -- --soft-contacts=off restores it interactively.
	session.soft_hull_contacts = not _scripted and not args.has("capture") and not args.has("trace") \
			and str(args.get("soft-contacts", "on")) != "off"
	if not _scripted:
		# Include the requested and active backend plus any fallback reason, including for headless traces.
		print("physics backend: ", JSON.stringify(session.stage_backend_status()))
	if args.has("trace"):
		if not session.aircraft.ok or not session.surface_error.is_empty():
			# Never record a "flight" on invalid data (it would be a ballistic throw): fail the run instead.
			push_error("--trace refused: %s" % ("aircraft data invalid" if not session.aircraft.ok else session.surface_error))
			get_tree().quit(1)
			return
		# Headless trace: record from the start to t, save, quit. No window needed.
		_write_trace_and_quit(trace_ticks, str(args.trace))
		return
	if not await _startup_stage("Preparing sound"):
		return
	if not _scripted and not args.has("capture") and str(args.get("soundscape", "on")) == "on":
		_soundscape_audio = FlightAudio.new()
		_soundscape_audio.name = "FlightAudio"
		add_child(_soundscape_audio)
		_soundscape_audio.configure(self)
		if session.aircraft.model.propulsion.get("kind", "glow_prop") != "electric_prop":
			_engine_audio = _soundscape_audio.soundscape.voices[0] # retain legacy combustion/turbine inspection interface
	elif str(args.get("soundscape", "on")) == "off":
		FlightAudio.silence_legacy_ambience(self)
	_lake_ambience = LakeWorld.ambience_player(_field_node)
	if _lake_ambience != null:
		if _soundscape_audio != null:
			_soundscape_audio.soundscape.buses_releasing.connect(_lake_ambience.stop)
			var soundscape_buses: Variant = _soundscape_audio.soundscape.get("_bus_names")
			if soundscape_buses is Array and soundscape_buses.size() >= 3:
				LakeWorld.set_ambience_bus(_field_node, StringName(soundscape_buses[2]))
		_lake_ambience.stream_paused = not session.holds.is_empty()
	if not _scripted and _field_node != null and _capture_scene_id() == "field":
		_scenery_damage_director = SceneryDamageDirector.new()
		_scenery_damage_director.name = "SceneryDamageDirector"
		add_child(_scenery_damage_director)
		_scenery_damage_director.configure(self)
	if crash_effects_enabled and not _scripted and not args.has("capture") and str(args.get("crash-effects", "on")) != "off":
		_crash_director = CrashDirector.new()
		_crash_director.name = "CrashDirector"
		add_child(_crash_director)
		var crash_context := CrashPresentationContext.new()
		var model_bindings := CrashPresentationContext.ModelBindings.new()
		model_bindings.root = _airplane.get("root") as Node3D
		model_bindings.propeller = _airplane.get("propeller") as Node3D
		model_bindings.empty = _airplane.is_empty()
		crash_context.session = session
		crash_context.model_bindings = model_bindings
		crash_context.field = field
		crash_context.aircraft_id = aircraft_id
		crash_context.workshop_trial = workshop_trial
		crash_context.aircraft_data_path = session.aircraft_path
		crash_context.cg_model = _cg_model
		crash_context.pose_provider = Callable(self, "_current_pose")
		crash_context.wind_provider = Callable(self, "_render_wind")
		crash_context.shadow = _shadow
		crash_context.sun = _sun
		crash_context.propeller_blur = get_node_or_null("PropellerBlur") as Node3D
		if _crash_director.configure(crash_context, str(args.get("soundscape", "on")) != "off"):
			session.crash_auto_restart = false
		else:
			push_error("Main: crash presentation context was refused; crash effects are unavailable.")
			_crash_director.queue_free()
			_crash_director = null
	if accident_reports_enabled and not _scripted and not args.has("capture") and not args.has("trace") \
		and str(args.get("accident-report", "on")) != "off":
		_accident_incident = AccidentIncident.new()
		_accident_settlement = AccidentSettlement.new()
		_accident_incident.archive_path = accident_archive_path
		_begin_accident_ledger()
		_accident_report = AccidentReport.new()
		_accident_report.name = "AccidentReport"
		add_child(_accident_report)
		_accident_incident.assessment_changed.connect(_on_accident_assessment)
		_accident_report.restart_requested.connect(_request_restart)
		_accident_report.costing_mode_requested.connect(_on_accident_costing_mode_requested)
		_accident_report.purchase_package_requested.connect(_on_accident_purchase_package_requested)
		session.contact_events_changed.connect(_on_accident_contacts)
		var archived: Dictionary = _accident_incident.load_archive()
		if not archived.is_empty():
			_accident_report.show_archived(archived)
		elif not _accident_incident.archive_load_error.is_empty():
			_note = tr("The saved accident report could not be opened. A new flight can still begin.")
		session.crash_auto_restart = false
	if companion_config.enabled and not await _startup_stage("Preparing companions"):
		return
	var companion_launch: Dictionary = _start_companions()
	if not companion_launch.ok:
		startup_error = "; ".join(companion_launch.errors)
		session.hold("companions-start-refused")
		set_process(false)
		set_process_unhandled_input(false)
		if not interactive_start:
			printerr(startup_error)
			get_tree().quit(ERR_INVALID_PARAMETER)
		return
	_companions_initialized = true
	flight_log = FlightLog.new(session)
	var fleet_capture: Dictionary = CompanionConfig.recording_options(user_args)
	if not str(fleet_capture.directory).is_empty():
		var capture_started: Dictionary = companions.start_recording(str(fleet_capture.directory))
		if not capture_started.ok:
			startup_error = "; ".join(capture_started.errors)
			session.hold("companion-capture-refused")
			printerr(startup_error)
			if not interactive_start: get_tree().quit(ERR_CANT_CREATE)
			return
		_update_flight_log_label()
	if args.has("flight-log"):
		if typeof(args["flight-log"]) != TYPE_STRING or str(args["flight-log"]).is_empty() or _scripted or args.has("capture"):
			push_error("--flight-log requires a new file path and a physics flight.")
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
		if flight_log.start(str(args["flight-log"])) != OK:
			get_tree().quit(ERR_CANT_CREATE)
			return
		_update_flight_log_label()
	if bool(frametime_options.enabled):
		_frametimes_path = str(frametime_options.path)
		_frametimes_warmup_s = float(frametime_options.warmup_s)
		_frametimes_duration = float(frametime_options.sample_s)
		if not str(frametime_options.get("stream_path", "")).is_empty() and FileAccess.file_exists(_frametimes_path):
			push_error("Streaming frame-time report already exists: " + _frametimes_path)
			get_tree().quit(1)
			return
		_frametime_samples = FrameSamples.new()
		if not _frametime_samples.configure(_frametimes_warmup_s, _frametimes_duration, int(frametime_options.max_frames), str(frametime_options.get("stream_path", ""))):
			push_error("Invalid frame-time options: " + _frametime_samples.failure)
			get_tree().quit(ERR_INVALID_PARAMETER)
			return
		_frametimes_active = true
		if bool(frametime_options.diagnostics):
			_frame_diagnostics = load("res://render/frame_diagnostics.gd").new()
			_frame_diagnostics.start(get_viewport())
		_frametimes_scripted_fixed = _scripted
		if _frametimes_scripted_fixed:
			session.input_enabled = false
			_show_perf = false
			set_process_unhandled_input(false)
	if args.has("capture"):
		_capturing = true
		_show_perf = false # wall-clock numbers would make captures differ run to run
		session.input_enabled = false
		# Settled commands from arguments (the limiter is skipped), so captures are deterministic.
		var c := {
			roll = float(args.get("roll", 0)), pitch = float(args.get("pitch", 0)),
			yaw = float(args.get("yaw", 0)), throttle = float(args.get("throttle", 0.5)),
		}
		var t := float(args.get("t", Spec.CAPTURE.time))
		await _capture(t, c, args.get("out", "user://capture.png"))


## Simulation.stepped observer. A reset, seek or gap advances at once; consecutive ticks wait for
## _flush_presentation_observers(). The cloth and heads integrate the elapsed time in fixed steps.
func _advance_windsock(_tick: int, time_s: float, state: PackedFloat64Array,
		_loads: PackedFloat64Array, _inputs: PackedFloat64Array, _aux: PackedFloat64Array) -> void:
	if _windsock_cadence.on_tick(_tick):
		_advance_windsock_to(_tick, time_s, state)


## VQ-01c-R1: once per rendered frame, before World.update and the smoke presentation read them.
func _flush_presentation_observers() -> void:
	if session == null or session.sim == null:
		return
	var sim: Node = session.sim
	if _windsock_cadence.take(sim.tick):
		_advance_windsock_to(sim.tick, sim.time(), sim.state)
	if _profile_smoke_cadence.take(sim.tick):
		_sample_profile_smoke_at(sim.tick, sim.time(), sim.state, sim.aux)


func _advance_windsock_to(_tick: int, time_s: float, state: PackedFloat64Array) -> void:
	var wind_ned: Array = Array(session.wind_at(time_s))
	var sampler: Callable = session.environment.wind_world if session.environment.weather.is_spatial() else Callable()
	if _tick == 0:
		FieldBuilder.reset_wind(_field_node, time_s, wind_ned, sampler)
	else:
		FieldBuilder.advance_wind(_field_node, time_s, wind_ned, sampler)
	# SC-HUM-03/04: field people follow the aircraft; flight-line pilots follow their companion
	# (render-only head state; companions are read before they advance this tick).
	FieldBuilder.advance_people(_field_node, time_s, [state[0], state[1], state[2]], _tick == 0, _companion_positions(),
		not session.crash.is_empty())


## SC-HUM-05: a crash pauses the simulation, so the crash glance runs on the same presentation
## clock as the crash director: crash time plus the frame time accumulated since.
func _advance_people_after_crash(dt: float) -> void:
	if session.crash.is_empty() or _scripted:
		_people_crash_clock_s = 0.0
		return
	if not session.holds.is_empty():
		return # menus hold the aftermath, as the crash director does
	_people_crash_clock_s += maxf(0.0, dt)
	var s: PackedFloat64Array = session.sim.state
	FieldBuilder.advance_people(_field_node, session.sim.time() + _people_crash_clock_s, [s[0], s[1], s[2]], false,
		_companion_positions(), true)


## Companion aircraft positions (NED) by slot, or null for one that has faulted. Read-only.
func _companion_positions() -> Array:
	var positions: Array = []
	if companions == null:
		return positions
	for agent: Node in companions.agents:
		if not is_instance_valid(agent) or not str(agent.failure).is_empty() or agent.session == null:
			positions.append(null)
			continue
		var s: PackedFloat64Array = agent.session.sim.state
		positions.append([s[0], s[1], s[2]])
	return positions


func _process(delta: float) -> void:
	_flush_presentation_observers()
	if not interactive_start and Engine.get_process_frames() % 60 == 0:
		Reconstruction.guard_runtime_failure(get_viewport())
	if _accident_report != null:
		_accident_report.suspend(not session.holds.is_empty())
		_update_accident_report()
	if flight_log != null and _flight_log_label != null:
		_update_flight_log_label()
	if _capturing:
		_clear_wheel_brake()
		return
	var dt := minf(delta, 0.1) # a stalled window must not jump the propeller or the scripted circle
	_advance_wing_fold(dt)
	_advance_mechanisms(dt)
	if _frametimes_active:
		if not _frametimes_clock_primed:
			_frametimes_last_usec = Time.get_ticks_usec()
			_frametimes_clock_primed = true
			_frametimes_previous_drawn = Engine.get_frames_drawn()
			_frametimes_sim_start_s = session.sim.time()
			_frametimes_sim_start_tick = session.sim.tick
		else:
			_log_frame_time(delta)
	var visual_clock_s: float = session.sim.time()
	if _frametimes_scripted_fixed:
		visual_clock_s = _frametimes_elapsed
	World.update(_env, visual_clock_s, _render_wind(visual_clock_s), _last_render_pose.get("pos"), _camera) # deterministic wind and field-world adaptation
	_update_aircraft_lights(visual_clock_s, false)
	_frame_times.append(delta)
	if _frame_times.size() > Hud.FRAMES:
		_frame_times.remove_at(0)
	var sim: Node = session.sim
	if _wheel_brake_key_held and (sim.paused or not session.crash.is_empty() or not session.wheel_brake_available()
		or not Input.is_physical_key_pressed(KEY_B)):
		_clear_wheel_brake()
	if _smoke_assignment != null and (not session.radio.connected or session.radio.device_id != _smoke_assignment.device_id):
		_end_smoke_assignment(true)
	_t += dt
	if _frametimes_scripted_fixed:
		_t = _frametimes_elapsed
	# Any pause (menu, focus, failsafe, calibration, crash) freezes the picture and the sound with the simulation:
	# the propeller stops where it is and the engine's generator stops being drained (stream_paused), so no stale
	# buzz at flying rpm plays on (UI-02, research 19).
	var frozen: bool = sim.paused and not _scripted
	if _frametimes_scripted_fixed:
		_prop_angle = fposmod(TAU * (sim.aux[0] / 60.0) * _frametimes_elapsed, TAU)
	elif not frozen:
		_prop_angle = fposmod(_prop_angle + TAU * (sim.aux[0] / 60.0) * dt, TAU)
	if _engine_audio != null and _soundscape_audio == null:
		_engine_audio.stream_paused = frozen
		if not frozen:
			EngineSound.update(_engine_audio, 0.0, sim.aux[0], session.aircraft.model.propulsion.max_rpm)
	if is_instance_valid(_lake_ambience):
		_lake_ambience.stream_paused = not session.holds.is_empty()
	var surfaces: Dictionary = session.surfaces()
	# Keep an initial diagnostic snapshot for evidence readers; hidden panels need no
	# per-frame formatting, air-data queries or label layout. Revealing them refreshes
	# on the next frame, at the same cadence as visible diagnostics.
	var diagnostics_visible: bool = _failure_overlays_visible and (_overlays == null or (_overlays.visible and _overlays.frames.diagnostics.visible))
	if diagnostics_visible or _panel.text.is_empty():
		InputPanel.update(_panel, session.raw, session.commands, _view_name(), _status(), surfaces, session.throws_deg())
	_camera_dt = dt
	CameraRig.release_cursor_if_up()
	_render_pose(_current_pose(), surfaces, _prop_angle)
	_update_storm(visual_clock_s, frozen)
	var smoke_clock_s: float = sim.time()
	if not _scripted and _visual_pose.is_empty() and session.crash.is_empty() and sim.tick > 0:
		smoke_clock_s = maxf(0.0, sim.time() - sim.dt() + Engine.get_physics_interpolation_fraction() * sim.dt())
	_update_smoke(smoke_clock_s)
	# Lighting uses the same displayed pose clock, independent of whether smoke is installed.
	var lighting_clock_s: float = sim.time() if frozen else smoke_clock_s
	if is_instance_valid(_rgb_lighting):
		var lighting_airspeed := float(_observer_air(sim.state, sim.time()).get("V", 0.0)) if _lighting_reacts_to_airspeed else 0.0
		_rgb_lighting.advance(lighting_clock_s, {
			"lighting_priority": 100, # Preserve the player's decorative grant before companion shows.
			"throttle": session.propulsion_throttle(),
			"speed_mps": (_last_render_pose.get("vel", Vector3.ZERO) as Vector3).length(),
			"airspeed": lighting_airspeed,
			"roll_rate": sim.state[RB.RATE], "pitch_rate": sim.state[RB.RATE + 1],
			"maneuver": clampf(sqrt(pow(sim.state[RB.RATE], 2.0) + pow(sim.state[RB.RATE + 1], 2.0) + pow(sim.state[RB.RATE + 2], 2.0)) / TAU, 0.0, 1.0),
			"exposure": World.Exposure.last,
			"distance_m": _camera.global_position.distance_to(_airplane.root.global_position) if is_instance_valid(_camera) else 0.0,
			"effects_allowed": not sim.paused and session.crash.is_empty() and sim.fault_reason.is_empty(),
		})
	_advance_people_after_crash(dt)
	var crash_camera_active := false
	if _crash_director != null:
		_crash_director.update(dt)
		crash_camera_active = _crash_director.active and is_nan(_look.x)
		if crash_camera_active:
			# CAM-27: the pilot keeps the director's view of the impact; the other views follow the wreck through the rig.
			if _rig.view == "pilot":
				_crash_director.aim(_camera, false)
			else:
				_rig.focus(_crash_director.focus_point(), _ground_height, _camera_clearance)
		if _crash_director.active and diagnostics_visible:
			_panel.text = _crash_director.description()
	if crash_camera_active != _history_crash_camera_active:
		Reconstruction.request_history_reset(get_viewport(), "camera_crash_focus_changed")
		_history_crash_camera_active = crash_camera_active
	var performance_visible: bool = _overlays == null or (_overlays.visible and _overlays.frames.performance.visible)
	_update_hud(diagnostics_visible or _hud.text.is_empty(), performance_visible)
	if _overlays != null:
		if _overlays.tick(dt):
			_overlays.refresh_numbers(_overlay_snapshot())
		_overlays.refresh_sticks(OverlayManager.sticks(session) if not _scripted and _visual_pose.is_empty() else {})


## Read only the accepted installation after startup or F5. Absolute scaling also
## makes a refused/no-op reload preserve the accepted geometry without parsing status text.
func _sync_accepted_installation_geometry(force_refresh := false) -> bool:
	if not session.aircraft.get("ok", false):
		return true
	var glow: Dictionary = session.aircraft.model.propulsion.get("glow", {})
	if glow.is_empty():
		return true
	var diameter_m: float = float(glow.get("propeller", {}).get("diameter_m", NAN))
	var changed: bool = float(_airplane.get("propeller_diameter_m", NAN)) != diameter_m
	if not AirplaneBuilder.apply_propeller_diameter(_airplane, diameter_m):
		return false
	if not changed and not force_refresh:
		return true
	_extent = Shadow.model_extent(_airplane.root)
	_sync_shadow_preference()
	Shadow.bind_model(_shadow, _airplane.root, {}, _shadow_proxy_context(), _shadow_mode)
	if force_refresh or not is_equal_approx(float(_rig.get("_span")), _extent.x):
		_rig.set_span(_extent.x)
	return true


func _update_cg_model() -> void:
	if session.aircraft.ok:
		var datum := AirplaneBuilder.datum(aircraft_id) # the data file's le frame in this aircraft's model
		var scale_factor: float = float(workshop_trial.get("scale", 1.0))
		_cg_model = Frames.cg_in_model_frame(session.aircraft.model.cg_le, datum.x * scale_factor, datum.y * scale_factor)


func _update_smoke(presentation_time_s: float = -1.0) -> void:
	_update_profile_smoke(presentation_time_s)
	if _smoke == null or session == null:
		return
	var sim: Node = session.sim
	if sim.paused:
		return # all pause owners freeze smoke on the last presented interval
	var clock_s: float = sim.time()
	if not sim.paused and sim.tick > 0:
		clock_s = maxf(0.0, clock_s - sim.dt() + Engine.get_physics_interpolation_fraction() * sim.dt())
	var prop: Dictionary = session.aircraft.model.propulsion
	var request: float = session.radio.smoke_amount() if session.radio.connected else (1.0 if _smoke_key_on else 0.0)
	var wash := Vector3.ZERO
	if prop.has("slipstream"):
		var air: Dictionary = _observer_air(sim.state, clock_s)
		var rho: float = session.air_density()
		var output: PackedFloat64Array = Propulsion.thrust_torque(air.v_air, sim.aux[0], prop, rho)
		var flow: Dictionary = Slipstream.wake(air.v_air, output[0], output[1], prop, rho)
		var axis: PackedFloat64Array = Propulsion.axis(prop)
		wash = _airplane.root.global_basis * Vector3(-axis[1], axis[2], axis[0]) * maxf(flow.w, 0.0)
	_smoke.advance(clock_s, _airplane.root.global_transform, Propulsion.source_kind(prop), sim.aux[0],
		float(prop.get("idle_rpm", 0.0)), float(prop.get("max_rpm", 0.0)), sim.inputs[3], _render_wind(clock_s),
		request, session.propulsion_source_running() and session.crash.is_empty() and sim.fault_reason.is_empty(), _camera.global_position.distance_to(_airplane.root.global_position), wash)


func _begin_smoke_assignment() -> void:
	if not _supports_show_smoke() or not session.radio.connected or session.calibration != null or _smoke_assignment != null:
		_note = tr("Connect a radio before assigning smoke AUX.")
		return
	_smoke_key_on = false
	_smoke_assignment_was_paused = session.sim.paused
	session.hold("smoke AUX assignment")
	var layer := CanvasLayer.new()
	layer.name = "SmokeAuxLayer"
	layer.layer = 20
	add_child(layer)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	_smoke_assignment = SmokeAssignment.new()
	center.add_child(_smoke_assignment)
	_smoke_assignment.profile_ready.connect(func(profile: Dictionary) -> void:
		var saved := false
		if session.persist_full_controller_profile.is_valid():
			var result: Dictionary = session.persist_full_controller_profile.call(profile)
			saved = bool(result.get("ok", false))
			if not saved:
				_note = tr("Could not save the updated controller profile; the existing profile is unchanged.")
		else:
			var gamepad: bool = profile.get("kind", "") == "gamepad"
			var applied: bool = session.radio.use_profile(profile, "gamepad" if gamepad else "calibrated")
			var write_error: Error = ERR_INVALID_DATA
			if applied:
				write_error = session.RcCalibration.save_smoke_binding(session.profiles_path, session.radio.device_key, profile.aux.smoke) if gamepad \
					else session.RcCalibration.save_profile(session.profiles_path, session.radio.device_key, profile)
			saved = applied and write_error == OK
			if not applied:
				_note = tr("The current controller profile could not be updated.")
			elif not saved:
				_note = tr("Smoke AUX assigned for this flight; profile could not be saved.")
		if saved:
			_note = tr("Smoke AUX assigned. Move throttle and smoke control to OFF before resuming.")
		_end_smoke_assignment(false))
	_smoke_assignment.cancelled.connect(func() -> void: _end_smoke_assignment(true))
	_smoke_assignment.begin(session.radio.device_id, session.radio.profile, session.radio.device_key, session.profiles_path, session.radio.axes)


func _on_smoke_connection_changed(_device: int, _connected: bool) -> void:
	_smoke_key_on = false
	if _smoke != null:
		_smoke.levels.pump = 0.0
		_smoke.pump.emitting = false


## UI-31 (UI-30 PS-4): the shell's Pause owns the frozen flight; an open assignment is cancelled, not left holding.
func cancel_smoke_assignment() -> void:
	if _smoke_assignment != null:
		_end_smoke_assignment(true)


func _end_smoke_assignment(cancelled: bool) -> void:
	var layer := get_node_or_null("SmokeAuxLayer")
	_smoke_assignment = null
	if layer != null:
		layer.queue_free()
	session.release("smoke AUX assignment")
	if cancelled and not _smoke_assignment_was_paused:
		session.resume()


func _update_hud(telemetry_visible: bool = true, performance_visible: bool = true) -> void:
	_update_failure_notice()
	if _crash_director != null and _crash_director.active:
		_hud.text = ""
		return
	if _overlays != null and performance_visible:
		_overlays.performance_label.text = Hud.perf_line(_frame_times, session.sim.step_usec).trim_suffix("  [F3]")
	if not telemetry_visible and not _aircraft_lights_hud_dirty:
		return
	_aircraft_lights_hud_dirty = false
	var lines := PackedStringArray()
	if _scripted or not session.aircraft.ok:
		lines.append("synthetic inspection" if not _visual_pose.is_empty() else ("scripted circle" if _scripted else "no flight data"))
	else:
		var s: PackedFloat64Array = session.sim.state
		var air: Dictionary = _observer_air(s, session.sim.time())
		lines.append(Hud.flight_line(air.V, -s[RB.POS + 2], rad_to_deg(air.alpha), session.sim.inputs[3]))
		var gear: Dictionary = session.gear_state()
		if bool(gear.get("available", false)):
			var gear_line := tr("Landing gear: %s") % _gear_status_label(gear)
			if bool(gear.get("inhibited", false)):
				gear_line += " — " + tr("retraction blocked while on wheels")
			lines.append(gear_line)
		var flaps: Dictionary = session.flap_state()
		if bool(flaps.get("available", false)):
			var actual_deg := float(flaps.get("angle_deg", 0.0))
			var target_deg := float(flaps.get("target_deg", 0.0))
			var flap_line := tr("Flaps: %.1f° actual → %.1f° target") % [actual_deg, target_deg]
			var flap_limit := float(flaps.get("limit_mps", NAN))
			lines.append(flap_line)
			if bool(flaps.get("overspeed", false)) and is_finite(flap_limit) and flap_limit > 0.0:
				lines.append(tr("Flaps above estimated speed limit: %.0f m/s EAS") % flap_limit)
		else:
			lines.append(tr("Flaps are unavailable on this aircraft."))
		if AirplaneBuilder.has_folds(_airplane):
			lines.append(_wing_fold_line())
		if AirplaneBuilder.has_mechanism(_airplane, "canopy"):
			lines.append(_mechanism_line("canopy", tr("Canopy: closed  [U] open"), tr("Canopy: open  [U] close"),
				tr("Canopy: opening %d%%"), tr("Canopy: closing %d%%")))
		if AirplaneBuilder.has_mechanism(_airplane, "tailhook"):
			lines.append(_mechanism_line("tailhook", tr("Tailhook: up  [Y] lower"), tr("Tailhook: down  [Y] raise"),
				tr("Tailhook: lowering %d%%"), tr("Tailhook: raising %d%%")))
		if not session.weather_is_calm():
			var wind: PackedFloat64Array = session.wind_at(session.sim.time())
			lines.append(_weather_hud_line(s, wind))
		if not session.atmosphere_is_reference():
			var field_air: Dictionary = session.atmosphere_configuration()
			lines.append(tr("EAS %.1f m/s  air %.3f kg/m³  density altitude %.0f m") % [air.V * M.sqrt_(field_air.sigma), field_air.rho_kgm3, field_air.density_altitude_m])
	if _overlays == null and _show_perf:
		lines.append(Hud.perf_line(_frame_times, session.sim.step_usec))
	if not _experimental_aircraft_path.is_empty():
		lines.append("EXPERIMENTAL: wing polar; aircraft-specific flight validation pending.")
	if not _scripted and session != null and session.has_method("glow_is_active") and session.glow_is_active():
		var glow: Dictionary = session.glow_state()
		if glow.get("ok", false):
			var family: String = str(glow.get("family", ""))
			var family_label := "2-stroke" if family == "glow_2t" else "4-stroke" if family == "glow_4t" else family
			var temperature_c: float = float(glow.get("temperature_k", 273.15)) - 273.15
			# FUEL-01b: volume at the installed blend's density; "~" because that density is itself an estimate.
			var fuel_ml: float = float(glow.get("fuel_volume_m3", 0.0)) * 1.0e6
			var engine_mode: String = "running" if glow.get("running", false) else str(glow.get("stop_reason", "stopped")).replace("_", " ")
			lines.append("Glow %s  %.0f rpm  head %.0f °C  fuel ~%.0f mL  %s  φ %.2f" % [
				family_label, float(glow.get("rpm", 0.0)), temperature_c, fuel_ml, engine_mode,
				float(glow.get("mixture_command", 0.0))])
			if glow.get("above_recommended_rpm", false):
				lines.append("ABOVE RECOMMENDED RPM")
			lines.append("[F6] cut  [F7] starter  [F8] lean  [F9] rich")
	lines.append("[L] " + _aircraft_lights_text())
	_hud.text = "\n".join(lines)


## An optional incident card, independent of the ordinary telemetry HUD and its preset.
func _update_failure_notice() -> void:
	if not failure_notifications or not _failure_overlays_visible:
		if _failure_notice != null:
			_failure_notice.visible = false
		return
	var status: Dictionary = session.failure_status() if session != null else {}
	if not bool(status.get("active", false)):
		if _failure_notice != null:
			_failure_notice.visible = false
		return
	if _failure_notice == null:
		_failure_notice = CanvasLayer.new()
		_failure_notice.name = "FailureNotice"
		_failure_notice.layer = 70
		add_child(_failure_notice)
		var card := PanelContainer.new()
		card.theme = UiTheme.build()
		card.set_anchors_preset(Control.PRESET_CENTER_TOP)
		card.offset_left = -250.0
		card.offset_right = 250.0
		card.offset_top = 84.0
		card.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_failure_notice.add_child(card)
		_failure_label = Label.new()
		_failure_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_failure_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_failure_label.custom_minimum_size.x = 470.0
		_failure_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(_failure_label)
	_failure_label.text = tr("Failure: %s") % tr(str(status.get("label", ""))) + "\n" + tr(str(status.get("hint", "")))
	_failure_notice.visible = true


## Ground speed is horizontal NED speed. A vertical-only air current has no compass bearing.
func _weather_hud_line(s: PackedFloat64Array, wind: PackedFloat64Array) -> String:
	var horizontal: float = M.sqrt_(wind[0] * wind[0] + wind[1] * wind[1])
	var bearing: String = "--"
	if horizontal > 0.0:
		bearing = "%03.0f°" % fposmod(rad_to_deg(M.atan2_(-wind[1], -wind[0])), 360.0)
	var q: PackedFloat64Array = M.quat(s[RB.ATT], s[RB.ATT + 1], s[RB.ATT + 2], s[RB.ATT + 3])
	var velocity: PackedFloat64Array = M.q_rotate(q, M.v3(s[RB.VEL], s[RB.VEL + 1], s[RB.VEL + 2]))
	var ground_speed: float = M.sqrt_(velocity[0] * velocity[0] + velocity[1] * velocity[1])
	return tr("ground speed %.1f m/s  wind %.1f m/s from %s  up %+.1f m/s") % [ground_speed, horizontal, bearing, -wind[2]]


func _status() -> String:
	if not _visual_pose.is_empty():
		return "mode: synthetic inspection (not flight)"
	if _scripted:
		return "mode: scripted circle"
	if not session.aircraft.ok:
		return "AIRCRAFT DATA INVALID: %s" % session.aircraft.errors[0]
	var sim: Node = session.sim
	var s: PackedFloat64Array = sim.state
	var trims: Dictionary = session.trims
	var speed := sqrt(s[RB.VEL] ** 2 + s[RB.VEL + 1] ** 2 + s[RB.VEL + 2] ** 2)
	var line := "sim %5.2f s  alt %5.1f m  speed %5.1f m/s  engine %5.0f rpm" % [sim.time(), -s[RB.POS + 2], speed, sim.aux[0]]
	if session.rates_active():
		line += "  " + tr(session.rate_profile_label())
	if not _electric_demo.is_empty():
		line = "Synthetic electric test airframe (%s)\n" % _electric_demo.to_upper() + line
		if session.battery_is_dynamic():
			var battery: Dictionary = session.electrical_state()
			if battery.get("ok", false):
				line = "Battery %.1f%% | %.2f V | %.1f A%s\n" % [100.0 * battery.soc, battery.bus_voltage_v, battery.pack_current_a, " | depleted" if battery.exhausted else ""] + line
	line += "\ntrims: ail %+.3f  elev %+.3f  rud %+.3f" % [trims.roll, trims.pitch, trims.yaw]
	line += "\n" + session.radio.describe()
	if _smoke != null:
		line += "\n" + tr("[H] smoke pump %s  [J] assign radio AUX") % ("on" if _smoke.levels.pump > 0.0 else "off")
	elif _supports_show_smoke():
		line += "\n" + tr("[H] show smoke %s  [J] assign radio AUX") % ("on" if _profile_last_request > 0.0 else "off")
	if session.calibration != null:
		line += "\nCALIBRATION %s  [Esc] cancel" % session.calibration.prompt()
		if session.calibration.error != "":
			line += "\n  " + session.calibration.error
		line += "\n  axes " + " ".join(Array(session.radio.axes).map(func(v): return "%+.2f" % v))
	if _crash_director != null and _crash_director.active:
		line += "\n" + _crash_director.description()
	elif sim.paused:
		line += "\nPAUSED%s  [P] resume" % ("" if session.pause_reason == "" else " (%s)" % session.pause_reason)
	if recorder.recording:
		line += "\nREC %.1f s  [T] stop and save" % recorder.seconds()
	elif recorder.note != "":
		line += "\n" + recorder.note
	else:
		line += "\n[T] record trace"
	line += "\n[Z] auto-zoom %s  [V] shadow: %s  [F5] reload aircraft data" % ["on" if _rig.auto_zoom else "off", _shadow_mode]
	line += "\n[L] " + _aircraft_lights_text()
	if _note != "":
		line += "\n" + _note
	return line


## Pose to draw: { pos: Vector3, basis: Basis } in render axes.
func _current_pose() -> Dictionary:
	if not _visual_pose.is_empty():
		return _visual_pose
	if _scripted:
		var p := Scripted.pose_at(_t)
		return { pos = Frames.ned_to_render(p.ned), basis = Frames.attitude_to_render(p.yaw, p.pitch, p.roll) }
	# CR-01c: presentation reads the estimate; the observed tick state stays authoritative.
	if not session.crash.is_empty():
		var impact: ImpactSnapshot.Snapshot = session.crash.get("impact") as ImpactSnapshot.Snapshot
		if impact != null:
			if impact.crossing != null and impact.crossing.available:
				var position: PackedFloat64Array = impact.crossing.position_ned
				return { pos = Frames.ned_to_render([position[0], position[1], position[2]]),
					basis = Frames.quat_to_render(impact.crossing.attitude) }
			return _pose_of(impact.detected_state)
		return _pose_of(session.sim.state)
	# The engine interpolation clock keeps moving while this session is held.
	var fraction := 1.0 if session.sim.paused else Engine.get_physics_interpolation_fraction()
	return _pose_of(session.sim.interpolated(fraction))


## vel: the CG's inertial velocity in render axes (body FRD velocity rotated by the attitude), for the camera rig.
func _pose_of(s: PackedFloat64Array) -> Dictionary:
	var attitude := Frames.quat_to_render(s.slice(RB.ATT, RB.ATT + 4))
	return { pos = Frames.ned_to_render([s[RB.POS], s[RB.POS + 1], s[RB.POS + 2]]), basis = attitude,
		vel = attitude * Frames.ned_to_render([s[RB.VEL], s[RB.VEL + 1], s[RB.VEL + 2]]) }


## Semantic gamepad actions share operations with keyboard shortcuts.
## This presentation/routing contract advertises only implemented aircraft equipment.
func controller_capabilities() -> Dictionary:
	return {
		"gear": session != null and session.gear_is_retractable(),
		"smoke": _supports_show_smoke(),
		"flaps": session != null and session.flaps_available(),
		"rates": session != null and session.aircraft.get("ok", false) and session.aircraft.model.controls.has("rates") and not session.external_driver_enabled,
	}


func accident_menu_active() -> bool:
	return _accident_report != null and _accident_report.wants_controller_menu() and session.holds.is_empty()


func controller_action(action: String) -> bool:
	if session == null: return false
	if _accident_report != null and _accident_report.controller_action(action):
		return true
	match action:
		"camera_cycle": _rig.cycle(1)
		"camera_previous": _rig.cycle(-1)
		"camera_pilot": _rig.set_view("pilot")
		"camera_chase": _rig.select_view("chase")
		"camera_orbit": _rig.set_view("orbit")
		"camera_zoom_in": _rig.zoom(1.0)
		"camera_zoom_out": _rig.zoom(-1.0)
		"camera_auto_zoom": _rig.toggle_auto_zoom()
		"view_reset": _rig.reset_view()
		"lights_cycle": _cycle_night_lights()
		"smoke_toggle":
			if session.sim.paused: return true
			if not _supports_show_smoke():
				_note = tr("Smoke is not available on this aircraft.")
			elif session.radio.auxiliary_action(action):
				_note = tr("Smoke pump: on") if session.radio.smoke_amount() > 0.0 else tr("Smoke pump: off")
		"flaps_up", "flaps_down", "flaps_cycle":
			if not session.sim.paused:
				_request_flaps_action(action)
		"gear_toggle":
			if session.sim.paused: return true
			if _has_gear_aux_binding():
				_note = tr("Landing gear is controlled by its AUX input.")
			elif not session.gear_is_retractable():
				_note = tr("Landing gear is fixed on this aircraft.")
			else:
				var accepted: bool = session.toggle_gear()
				var gear: Dictionary = session.gear_state()
				_note = _gear_command_note() if accepted or bool(gear.get("inhibited", false)) else tr("Landing gear command was refused.")
		"trim_left": session.adjust_aileron_trim(-0.005)
		"trim_right": session.adjust_aileron_trim(0.005)
		"trim_up": session.adjust_elevator_trim(-0.1)
		"trim_down": session.adjust_elevator_trim(0.1)
		"trim_yaw_left": session.adjust_rudder_trim(-RUDDER_TRIM_STEP)
		"trim_yaw_right": session.adjust_rudder_trim(RUDDER_TRIM_STEP)
		"overlay_preset":
			if _overlays != null: _overlays.cycle_preset()
		"rates_toggle":
			if session.toggle_rate_profile():
				_note = tr(session.rate_profile_label())
			elif session.radio.connected and session.radio.profile.get("kind", "radio") == "radio":
				_note = tr("The radio sets its own rates.")
			else:
				_note = tr("This aircraft has no rate profile.")
		"throttle_cut": session.controller_throttle_cut()
		"calibrate": session.start_calibration()
		"accept":
			if session.calibration != null: session.advance_calibration()
			elif session.sim.paused: session.resume()
		"back", "pause":
			if session.calibration != null: session.cancel_calibration()
			else: pause_requested.emit()
		_: return false
	return true

## Keyboard detents follow the active model's full-down angle and recommended takeoff fraction.
func _flap_detents() -> Array[float]:
	var takeoff_fraction: float = float(session.aircraft.model.flaps.get("takeoff_fraction", 0.4))
	var detents: Array[float] = [0.0]
	if takeoff_fraction > 0.0 and takeoff_fraction < 1.0:
		detents.append(takeoff_fraction)
	detents.append(1.0)
	return detents


func _flap_detent_after(requested: float, direction: int) -> float:
	var detents := _flap_detents()
	var nearest := 0
	var distance := INF
	for i in detents.size():
		var candidate_distance := absf(requested - detents[i])
		if candidate_distance < distance:
			nearest = i
			distance = candidate_distance
	return detents[posmod(nearest + direction, detents.size())]


func _request_flaps_amount(amount: float) -> bool:
	if session == null:
		return false
	var state: Dictionary = session.flap_state()
	if not bool(state.get("available", false)):
		_note = tr("Flaps are unavailable on this aircraft.")
		return false
	if session.sim.paused:
		return false
	var normalized := clampf(amount, 0.0, 1.0)
	if session.radio.connected and not session.radio.set_flaps_action_amount(normalized):
		_note = tr("Flaps are controlled by the radio AUX input.")
		return false
	if not session.set_flaps(normalized):
		_note = tr("Flaps request was refused.")
		return false
	_note = tr("Flaps request accepted.")
	return true


func _request_flaps_action(action: String) -> bool:
	if session == null:
		return false
	var state: Dictionary = session.flap_state()
	if not bool(state.get("available", false)):
		_note = tr("Flaps are unavailable on this aircraft.")
		return false
	var requested := float(state.get("requested", 0.0))
	match action:
		"flaps_up": return _request_flaps_amount(0.0)
		"flaps_down": return _request_flaps_amount(1.0)
		"flaps_cycle": return _request_flaps_amount(_flap_detent_after(requested, 1))
	return false


## F4U-17: fold or spread the wings, only stopped on the wheels. The throttle stays at idle until spread and locked.
func _toggle_wing_fold() -> void:
	if session == null or session.sim.paused:
		return
	if not AirplaneBuilder.has_folds(_airplane):
		_note = tr("Wings do not fold on this aircraft.")
		return
	if not _stopped_on_wheels():
		_note = tr("Wings fold only on the ground, stopped.")
		return
	_wing_fold_target = 0.0 if _wing_fold_target > 0.5 else 1.0
	_note = tr("Wings folding") if _wing_fold_target > 0.5 else tr("Wings spreading")


func _stopped_on_wheels() -> bool:
	var s: PackedFloat64Array = session.sim.state
	var on_wheels := false
	for compression: float in session.gear_compressions(s):
		on_wheels = on_wheels or compression > 0.0
	return on_wheels and session.crash.is_empty() and Vector3(s[RB.VEL], s[RB.VEL + 1], s[RB.VEL + 2]).length() < 0.5


func _advance_wing_fold(dt: float) -> void:
	if session == null or not AirplaneBuilder.has_folds(_airplane):
		return
	if not session.sim.paused and _wing_fold != _wing_fold_target:
		var longest := 0.0
		for fold: Dictionary in _airplane.folds.values():
			longest = maxf(longest, float(fold.get("time_s", 0.0)))
		_wing_fold = move_toward(_wing_fold, _wing_fold_target, dt / (longest if longest > 0.0 else 8.0))
	session.set_throttle_hold("wing_fold", _wing_fold > 0.0 or _wing_fold_target > 0.0)


func _wing_fold_line() -> String:
	var line: String
	if _wing_fold <= 0.0 and _wing_fold_target <= 0.0:
		line = tr("Wings: spread  [O] fold")
	elif _wing_fold >= 1.0 and _wing_fold_target >= 1.0:
		line = tr("Wings: folded  [O] spread")
	else:
		line = (tr("Wings: folding %d%%") if _wing_fold_target > 0.5 else tr("Wings: spreading %d%%")) % roundi(100.0 * _wing_fold)
	if session.throttle_holds.has("wing_fold"):
		line += " — " + tr("throttle held at idle")
	return line


## F4U-21: open or close the canopy, lower or raise the tailhook. Presentation only, at any time.
func _toggle_mechanism(key: String) -> void:
	if session == null or session.sim.paused:
		return
	if not AirplaneBuilder.has_mechanism(_airplane, key):
		_note = tr("This aircraft has no sliding canopy.") if key == "canopy" else tr("This aircraft has no tailhook.")
		return
	var opening := float(_mechanism_targets.get(key, 0.0)) < 0.5
	_mechanism_targets[key] = 1.0 if opening else 0.0
	if key == "canopy":
		_note = tr("Canopy opening") if opening else tr("Canopy closing")
	else:
		_note = tr("Tailhook lowering") if opening else tr("Tailhook raising")


func _advance_mechanisms(dt: float) -> void:
	if session == null or session.sim.paused:
		return
	var mechanisms: Dictionary = _airplane.get("mechanisms", {})
	for key: String in mechanisms:
		var target := float(_mechanism_targets.get(key, 0.0))
		var state := float(_mechanisms.get(key, 0.0))
		if state != target:
			_mechanisms[key] = move_toward(state, target, dt / float(mechanisms[key].time_s))


func _mechanism_line(key: String, stowed: String, deployed: String, opening: String, closing: String) -> String:
	var state := float(_mechanisms.get(key, 0.0))
	var target := float(_mechanism_targets.get(key, 0.0))
	if state <= 0.0 and target <= 0.0:
		return stowed
	if state >= 1.0 and target >= 1.0:
		return deployed
	return (opening if target > 0.5 else closing) % roundi(100.0 * state)


func _step_flaps(direction: int) -> void:
	if session == null or session.sim.paused:
		return
	var state: Dictionary = session.flap_state()
	if not bool(state.get("available", false)):
		_note = tr("Flaps are unavailable on this aircraft.")
		return
	_request_flaps_amount(_flap_detent_after(float(state.get("requested", 0.0)), direction))


func _gear_status_label(gear: Dictionary) -> String:
	match str(gear.get("status", "")):
		"up": return tr("Up")
		"down": return tr("Down")
		"extending": return tr("Extending")
		"retracting": return tr("Retracting")
	return tr("Unknown")


func _gear_command_note() -> String:
	var gear: Dictionary = session.gear_state()
	if not bool(gear.get("available", false)):
		return tr("Landing gear is fixed on this aircraft.")
	if bool(gear.get("inhibited", false)):
		return tr("Gear retraction is blocked while the aircraft is on its wheels.")
	return tr("Landing gear: %s") % _gear_status_label(gear)


func _has_gear_aux_binding() -> bool:
	if session == null:
		return false
	var aux_value: Variant = session.radio.profile.get("aux", {})
	if typeof(aux_value) != TYPE_DICTIONARY:
		return false
	var aux: Dictionary = aux_value
	var binding_value: Variant = aux.get("gear", {})
	if typeof(binding_value) != TYPE_DICTIONARY:
		return false
	var binding: Dictionary = binding_value
	return str(binding.get("type", "")) in ["axis", "button", "switch"]


func _clear_wheel_brake() -> void:
	if session != null:
		session.set_wheel_brake(0.0) # Brake release remains valid during pause and focus loss.
	_wheel_brake_key_held = false


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.physical_keycode == KEY_B and not event.pressed:
		_clear_wheel_brake()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		_companions_application_focused = false
		_companions_resume_after_reset = false
		_clear_wheel_brake()
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN:
		_companions_application_focused = true


## The shell resumes successful restarts when controls are ready and keeps recovery failures visible.
func _request_restart() -> void:
	if restart_requested.has_connections():
		restart_requested.emit()
	else:
		session.reset() # standalone research/test scenes have no shell


func _unhandled_input(event: InputEvent) -> void:
	if _smoke_assignment != null:
		return
	if event.is_action_pressed("smoke_pump") and not event.is_echo() and _supports_show_smoke() and not session.sim.paused and not session.radio.connected:
		_smoke_key_on = not _smoke_key_on
		get_viewport().set_input_as_handled()
		return
	if _camera_input(event):
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if not _scripted and session != null and session.has_method("glow_is_active") and session.glow_is_active():
			var glow_action_ok := false
			var action_label := ""
			match event.physical_keycode:
				KEY_F6:
					glow_action_ok = session.glow_cut()
					action_label = "cut"
				KEY_F7:
					glow_action_ok = session.glow_start()
					action_label = "starter"
				KEY_F8, KEY_F9:
					var glow_model: Dictionary = session.aircraft.model.propulsion.glow
					var nominal_phi: float = float(glow_model.profile.operation.nominal_mixture)
					var target_phi: float = nominal_phi * (0.85 if event.physical_keycode == KEY_F8 else 1.15)
					glow_action_ok = session.glow_set_mixture(target_phi)
					action_label = "lean mixture φ %.2f" % target_phi if event.physical_keycode == KEY_F8 else "rich mixture φ %.2f" % target_phi
			if action_label != "":
				_note = "Glow %s %s." % [action_label, "accepted" if glow_action_ok else "refused"]
				get_viewport().set_input_as_handled()
				return
		match event.physical_keycode:
			KEY_F10:
				if companions != null and companions.recording_status().active:
					companions.stop_recording("stopped by F10")
					get_viewport().set_input_as_handled()
				elif flight_log != null and not _scripted:
					if flight_log.recording: flight_log.stop()
					else: flight_log.start()
					_update_flight_log_label()
					get_viewport().set_input_as_handled()
			KEY_F11:
				if companions != null and companions.recording_status().active:
					companions.mark_recording()
					get_viewport().set_input_as_handled()
				elif flight_log != null and flight_log.recording:
					flight_log.mark()
					_note = "Flight log marker at tick %d" % session.sim.tick
					get_viewport().set_input_as_handled()
			KEY_G:
				controller_action("gear_toggle")
				get_viewport().set_input_as_handled()
			KEY_F:
				_step_flaps(-1 if event.shift_pressed else 1)
				get_viewport().set_input_as_handled()
			KEY_O:
				_toggle_wing_fold()
				get_viewport().set_input_as_handled()
			KEY_U:
				_toggle_mechanism("canopy")
				get_viewport().set_input_as_handled()
			KEY_Y:
				_toggle_mechanism("tailhook")
				get_viewport().set_input_as_handled()
			KEY_N:
				controller_action("rates_toggle")
				get_viewport().set_input_as_handled()
			KEY_B:
				if not session.sim.paused and session.wheel_brake_available() and session.set_wheel_brake(1.0):
					_wheel_brake_key_held = true
					get_viewport().set_input_as_handled()
			KEY_BRACKETLEFT, KEY_BRACKETRIGHT:
				if session.adjust_aileron_trim(-0.005 if event.physical_keycode == KEY_BRACKETLEFT else 0.005):
					_note = tr("Aileron trim: %+.1f%%") % (session.trims.roll * 100.0)
					get_viewport().set_input_as_handled()
			KEY_PAGEUP, KEY_PAGEDOWN:
				if session.adjust_elevator_trim(-0.1 if event.physical_keycode == KEY_PAGEUP else 0.1):
					_note = tr("Elevator trim: %+.1f° (PgUp down / PgDn up)") % (session.trims.pitch * session.throws_deg().elevator)
					get_viewport().set_input_as_handled()
			KEY_COMMA, KEY_PERIOD:
				if session.adjust_rudder_trim(-RUDDER_TRIM_STEP if event.physical_keycode == KEY_COMMA else RUDDER_TRIM_STEP):
					_note = tr("Rudder trim: %+.1f%%") % (session.trims.yaw * 100.0)
					get_viewport().set_input_as_handled()
			KEY_J:
				_begin_smoke_assignment()
			KEY_R:
				_request_restart()
				get_viewport().set_input_as_handled()
			KEY_P:
				session.resume()
			KEY_T:
				if recorder.recording:
					recorder.stop()
				elif not _scripted:
					recorder.start(_trace_meta(), true)
			KEY_C:
				_rig.cycle(-1 if event.shift_pressed else 1)
			KEY_1:
				_rig.set_view("pilot")
			KEY_2:
				_rig.select_view("chase") # again: 3D follow (CAM-09)
			KEY_4:
				_rig.set_view("flyby")
			KEY_5:
				_rig.set_view("orbit")
			KEY_EQUAL:
				_rig.zoom(1.0)
			KEY_MINUS:
				_rig.zoom(-1.0)
			KEY_BACKSPACE:
				_rig.reset_view()
			KEY_K:
				session.start_calibration()
			KEY_ENTER, KEY_KP_ENTER:
				if session.calibration != null:
					session.advance_calibration()
					if session.calibration == null:
						pause_requested.emit() # UI-31: the result shows in Pause, never a frozen flight without a menu
			KEY_ESCAPE:
				session.cancel_calibration() # Esc leaves a running wizard (its profile stays) and shows Pause
				pause_requested.emit()
			KEY_Z:
				_rig.toggle_auto_zoom()
			KEY_V:
				_cycle_shadow_mode()
			KEY_L:
				_cycle_night_lights()
			KEY_F3:
				if _overlays != null:
					_overlays.toggle_developer()
				else:
					_show_perf = not _show_perf
			KEY_F2:
				if _overlays != null:
					_overlays.cycle_preset()
			KEY_F5:
				_note = session.reload() if _experimental_aircraft_path.is_empty() else "Experimental polar is fixed for this flight; restart the application to load another file."
				if not _sync_accepted_installation_geometry():
					# The physical reload already committed. Keep it accepted and pause
					# explicitly instead of presenting a stale collision/visual pairing.
					session.hold(INSTALLATION_GEOMETRY_HOLD)
					session.pause_reason = INSTALLATION_GEOMETRY_HOLD
					_note += "; " + session.pause_reason + "; simulation paused"
				else:
					session.release(INSTALLATION_GEOMETRY_HOLD)
				_update_cg_model()
				print(_note)


## FW-35c: existing keyboard/controller cycle establishes a flight-local manual override.
func _cycle_night_lights() -> void:
	_aircraft_lights.cycle_mode()
	_aircraft_lights_hud_dirty = true
	_update_aircraft_lights()


## Shared selection API for UI/adapters: AUTO clears the override; invalid modes are refused.
func set_aircraft_lights(mode: String) -> bool:
	if not _aircraft_lights.set_mode(mode):
		return false
	_aircraft_lights_hud_dirty = true
	_update_aircraft_lights()
	return true


func _aircraft_lights_text() -> String:
	if workshop_trial.get("presentation_profile", {}).get("lighting", {}).get("selection", "inherit") == "disabled":
		return tr("Night lights: disabled by build")
	var text := tr("Night lights: " + _aircraft_lights.active_mode)
	return text + " · " + tr("Night lights: auto") if _aircraft_lights.selection == "auto" else text


func _update_aircraft_lights(clock_s: float = -1.0, force_rgb := true) -> void:
	if _airplane.is_empty():
		return
	if clock_s < 0.0:
		clock_s = session.sim.time() if session != null else 0.0
	var elevation := World.aircraft_sun_elevation(_lighting)
	if _aircraft_lights.update(World.aircraft_local_seconds(lighting_config, clock_s),
			1.0 if elevation < World.NIGHT_KIT_BELOW_SUN_DEG else 0.0):
		_aircraft_lights_hud_dirty = true
	if is_instance_valid(_rgb_lighting):
		_apply_rgb_lighting_mode(force_rgb)
		return
	if not is_instance_valid(_night_kit) and _aircraft_lights.active_mode != "off":
		_night_kit = World.AircraftLights.attach(_airplane.root)
		if is_instance_valid(_night_kit):
			Magnifier.tag(_night_kit)
	if is_instance_valid(_night_kit) and str(_night_kit.get_meta("mode", "")) != _aircraft_lights.active_mode:
		World.AircraftLights.set_mode(_night_kit, _aircraft_lights.active_mode)
	World.AircraftLights.set_emission_mode(World.AircraftLights.prepare_emission(_airplane.root),
		_aircraft_lights.active_mode, _aircraft_lights.gain)


## Explicit calls remain synchronous reconciliation points. The frame loop can
## skip an unchanged mode; advance() still updates telemetry, gates and effects.
func _apply_rgb_lighting_mode(force: bool) -> void:
	var changed := force or _rgb_applied_rig_id != _rgb_lighting.get_instance_id() \
		or _rgb_applied_mode != _aircraft_lights.active_mode or _rgb_applied_gain != _aircraft_lights.gain
	if not changed:
		return
	_rgb_lighting.set_mode(_aircraft_lights.active_mode, _aircraft_lights.gain)
	_rgb_applied_rig_id = _rgb_lighting.get_instance_id()
	_rgb_applied_mode = _aircraft_lights.active_mode
	_rgb_applied_gain = _aircraft_lights.gain


## CAM-17: Settings changed during a Home flight; the rig applies what changed (direct routes keep their arguments).
func apply_camera_preferences(config: Dictionary) -> void:
	if camera_preferences.is_empty() or _rig == null:
		return
	CameraSettings.apply_changes(_rig, camera_preferences, config)
	camera_preferences = CameraSettings.normalized(config)


## CAM-04: mouse wheel zooms the current view; a right-button drag turns the orbit view. True when used.
func _camera_input(event: InputEvent) -> bool:
	if _rig == null:
		return false
	if event is InputEventMouseButton and event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
		var notches: float = event.factor if event.factor > 0.0 else 1.0
		_rig.zoom(notches if event.button_index == MOUSE_BUTTON_WHEEL_UP else -notches)
		get_viewport().set_input_as_handled()
		return true
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
		CameraRig.hold_cursor(event.pressed and _rig.view == "orbit")
	if event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_RIGHT) != 0:
		_rig.drag(event.relative)
		get_viewport().set_input_as_handled()
		return true
	return false


## CAM-09: share of a camera boom (render points) clear of the scenery's collision proxies; 1 without a world.
func _camera_clearance(from: Vector3, to: Vector3) -> float:
	return CameraCollision.free_fraction(_camera_obstacles, from, to)


## Terrain height (render y) under a render-space point, from the session's own ground table; NAN when unknown.
func _ground_height(x: float, z: float) -> float:
	if session == null:
		return 0.0
	var terrain: PackedFloat64Array = GroundTerrain.sample(-z, x, session.ground_surfaces)
	return terrain[0] if _rc_track.is_empty() else RcTrack.composed(terrain, _rc_track, -z, x)[0]


## What the flight overlays show this frame; {} when there is no physics flight to describe.
func _overlay_snapshot() -> Dictionary:
	if _scripted or not _visual_pose.is_empty() or session == null:
		return {}
	var forward: Vector3 = -_camera.global_transform.basis.z
	var view_heading: float = OverlayManager.Telemetry.heading_of_render_forward(forward.x, forward.z)
	var snap := OverlayManager.snapshot(session, field.pilot, _extent.x, not _experimental_aircraft_path.is_empty(), view_heading)
	if snap.has("control_guide"):
		snap.control_guide.capabilities = controller_capabilities()
		snap.control_guide.equipment_state = {
			gear = session.gear_state().get("status", "unavailable"),
			smoke = "on" if _smoke_requested_for_presentation() else "off",
			flaps = session.flap_state(),
			rates = session.rate_profile_label(),
		}
	return snap


func _smoke_requested_for_presentation() -> bool:
	if _profile_smoke != null:
		return _profile_smoke_request() > 0.0
	return _smoke != null and float(_smoke.levels.pump) > 0.0


## Shows or hides the flight's text overlays (input panel and HUD). A menu hides them: the paused picture then
## shows the airplane alone, and the panel's "[P] resume" never contradicts the menu.
func set_overlays_visible(on: bool) -> void:
	_failure_overlays_visible = on
	if _failure_notice != null:
		_failure_notice.visible = on and failure_notifications and bool(session.failure_status().get("active", false))
	for label in [_panel, _hud]:
		var n: Node = label
		while n != null and not n is CanvasLayer:
			n = n.get_parent()
		if n != null:
			n.visible = on
	var latency_marker := get_node_or_null("LatencyPatch") as CanvasLayer
	if latency_marker != null:
		latency_marker.visible = on and latency_marker_enabled
	if _flight_log_label != null: # UI-31 (UI-30 PS-10): its layer 25 would otherwise draw over every menu
		(_flight_log_label.get_parent() as CanvasLayer).visible = on


## Optional camera target. Closing it persists independently of pause/menu visibility.
func set_latency_marker_enabled(on: bool) -> void:
	latency_marker_enabled = on
	var patch := get_node_or_null("LatencyPatch") as CanvasLayer
	if on and patch == null:
		patch = LatencyPatch.new()
		patch.session = session
		patch.left_side = _overlays != null
		patch.closed.connect(func() -> void: set_latency_marker_enabled(false))
		add_child(patch)
	if patch != null:
		patch.visible = on and _failure_overlays_visible
	latency_marker_changed.emit(on)


## Called by the Home launch transaction, after the real model/session have accepted their inputs.
func bind_scenario(raw: Variant) -> Dictionary:
	var checked: Dictionary = ScenarioConfig.validate(raw)
	if not checked.ok:
		return checked
	var selected: Dictionary = checked.scenario
	var sources: Dictionary = ScenarioConfig.validate_sources(selected, field_path)
	if not sources.ok:
		return sources
	if not interactive_start or session == null or not session.is_flyable() or not workshop_trial.is_empty() \
			or not _experimental_aircraft_path.is_empty() or not _electric_demo.is_empty() \
			or aircraft_id != selected.aircraft_id or start_choice != selected.start_choice \
			or session.weather_configuration() != selected.weather_config or lighting_config != selected.lighting_config \
			or session.aircraft.get("input_identity", {}).get("sha256", "") != selected.aircraft_identity \
			or _airplane.get("model_manifest_sha256", "") != selected.model_identity or field.get("id", "") != selected.field_id:
		return {ok = false, errors = ["Prepared flight does not match the random scenario."]}
	flight_scenario = selected.duplicate(true)
	_note = tr("Natural Random") if selected.provenance == "generated" else tr("Custom from Natural Random")
	return {ok = true, errors = []}


func _forget_scenario() -> void:
	if not flight_scenario.is_empty():
		flight_scenario = {}
		if _note in [tr("Natural Random"), tr("Custom from Natural Random")]:
			_note = ""
		scenario_changed.emit({})


## TOD-08a: paired technical replay checkpoint; native Variant encoding preserves physics bits.
## This is not a live-input save game or a rendered trace player.
func checkpoint() -> Dictionary:
	if companions != null and not companions.agents.is_empty():
		return {} # The paired checkpoint does not yet represent a fleet.
	if session == null or _scripted or _capturing or _field_world_lighting or _capture_scene_id() != "field":
		return {}
	var selection: Dictionary = VisualTimeline.evaluate(_visual_timeline, session.sim.tick)
	if not selection.ok or selection.config != lighting_config:
		return {} # refuse an unrecorded visual edit
	var saved: Dictionary = VisualCheckpoint.make(session.checkpoint(), _visual_timeline, _field_identity())
	if not saved.ok:
		return {}
	var paired: Dictionary = saved.checkpoint
	if sky_config != SkyConfig.defaults() or not _sky_edits.is_empty():
		paired = SkyCheckpoint.make(paired, sky_config, Atmosphere.cloud_transport_checkpoint(), _sky_edits)
		if paired.is_empty():
			return {}
	if _crash_director != null:
		var water_render: Dictionary = _crash_director.water_checkpoint()
		if not water_render.is_empty():
			var wrapped: Dictionary = {
				"format": WATER_CHECKPOINT_FORMAT,
				"visual": paired,
				"water_render": water_render,
			}
			wrapped["payload_sha256"] = _water_checkpoint_digest(paired, water_render)
			paired = wrapped
	if _accident_incident != null and _accident_incident.has_damage():
		if _accident_reload_pending:
			return {}
		var ledger: Dictionary = _accident_incident.checkpoint(session.sim.tick, _accident_bindings)
		if ledger.is_empty():
			return {}
		paired = AccidentIncident.Checkpoint.wrap(paired, {ledger = ledger,
			settlement = _accident_settlement.checkpoint(),
			presentation = {ground_stable = _accident_ground_stable, settled_pending = _accident_settled_pending}})
	return paired


## Validate both halves and prepare detached shadow geometry before the physics owner commits.
## No await: an invalid record cannot change the live world, recording or simulation.
func restore_checkpoint(candidate: Variant) -> Dictionary:
	if companions != null and not companions.agents.is_empty():
		return {ok = false, errors = ["Remove companions before restoring a player-only checkpoint."]}
	if session == null or _scripted or _capturing or _field_world_lighting or _capture_scene_id() != "field" or not startup_error.is_empty():
		return {ok = false, errors = ["visual checkpoint requires a ready production flight"]}
	var economic_restore: Dictionary = {}
	if candidate is Dictionary and candidate.get("format") == AccidentIncident.Checkpoint.ENVELOPE:
		if _accident_incident == null:
			return {ok = false, errors = ["Economics checkpoint requires accident reporting."]}
		var unwrapped: Dictionary = AccidentIncident.Checkpoint.unwrap(candidate)
		if not unwrapped.ok:
			return unwrapped
		economic_restore = unwrapped.economy
		if economic_restore.is_empty():
			return {ok = false, errors = ["Paired economics checkpoint has no ledger."]}
		candidate = unwrapped.visual
	var visual_candidate: Variant = candidate
	var water_restore: Dictionary = {}
	var has_water_render: bool = false
	if typeof(candidate) == TYPE_DICTIONARY and candidate.get("format") == WATER_CHECKPOINT_FORMAT:
		if not _has_exact_keys(candidate, WATER_CHECKPOINT_FIELDS) \
				or typeof(candidate.get("visual")) != TYPE_DICTIONARY \
				or typeof(candidate.get("water_render")) != TYPE_DICTIONARY \
				or typeof(candidate.get("payload_sha256")) != TYPE_STRING \
				or candidate.payload_sha256 != _water_checkpoint_digest(candidate.visual, candidate.water_render):
			return {ok = false, errors = ["water visual checkpoint envelope is invalid"]}
		if _crash_director == null:
			return {ok = false, errors = ["water visual checkpoint requires the crash director"]}
		water_restore = _crash_director.prepare_water_restore(candidate.water_render)
		if water_restore.is_empty():
			return {ok = false, errors = ["water aftermath checkpoint is invalid or incompatible"]}
		visual_candidate = candidate.visual
		has_water_render = true
	var sky_restore: Dictionary = SkyCheckpoint.read(visual_candidate)
	if not sky_restore.ok:
		return sky_restore
	var decoded: Dictionary = VisualCheckpoint.read(sky_restore.visual, _field_identity())
	if not decoded.ok:
		return decoded
	var prepared_economics: Dictionary = {}
	if not economic_restore.is_empty():
		if not AccidentIncident.Checkpoint.keys(economic_restore, ["ledger", "settlement", "presentation"]) \
			or not AccidentSettlement.valid_checkpoint(economic_restore.settlement, decoded.physics.simulation.tick) \
			or not economic_restore.presentation is Dictionary \
			or not AccidentIncident.Checkpoint.keys(economic_restore.presentation, ["ground_stable", "settled_pending"]) \
			or not economic_restore.presentation.ground_stable is bool or not economic_restore.presentation.settled_pending is bool:
			return {ok = false, errors = ["Invalid economics settlement or presentation checkpoint."]}
		if economic_restore.presentation.settled_pending and (not economic_restore.settlement.settled or not economic_restore.presentation.ground_stable):
			return {ok = false, errors = ["Settled report requires completed dwell and stable ground contact."]}
		prepared_economics = _accident_incident.prepare_restore(economic_restore.ledger, decoded.physics.simulation.tick, _accident_bindings)
		if not prepared_economics.ok:
			return prepared_economics
	var restored_time: float = float(decoded.physics.simulation.tick) * float(decoded.physics.simulation.dt)
	var restored_mean: Array = SkyConfig.mean_wind_ned(decoded.physics.get("weather_config", {}))
	if not sky_restore.legacy and (float(sky_restore.transport.anchor_time_s) > restored_time + 1.0e-9 \
			or not Atmosphere.validate_cloud_transport_for(sky_restore.config, sky_restore.transport, restored_mean)):
		return {ok = false, errors = ["cloud transport disagrees with checkpoint time or weather"]}
	for edit: Dictionary in sky_restore.edits:
		if edit.tick > decoded.physics.simulation.tick or not Atmosphere.validate_cloud_transport_for(edit.config, edit.transport, restored_mean):
			return {ok = false, errors = ["sky edit disagrees with checkpoint tick or weather"]}
	# TOD-09c1 defines progressing records before the live controller consumes them.
	# Refuse even a stopped v2 history: its restart selection and fractional phase
	# cannot be represented by this controller's fixed-time reset path yet.
	if decoded.timeline.format != VisualTimeline.FORMAT:
		return {ok = false, errors = ["progressing visual checkpoints require the solar progression controller"]}
	var staged: Dictionary = _prepare_checkpoint_lighting(decoded.config)
	if not staged.ok:
		return {ok = false, errors = ["could not prepare checkpoint lighting"]}
	_accident_checkpoint_restoring = not prepared_economics.is_empty()
	var physics_restored: bool = session.restore_checkpoint(decoded.physics)
	_accident_checkpoint_restoring = false
	if not physics_restored:
		return {ok = false, errors = ["physics checkpoint is invalid or incompatible"]}
	if not prepared_economics.is_empty():
		_accident_report.clear_report()
		_accident_restored = false
		_accident_paired_history = true
		_accident_reload_pending = false
		_accident_settlement.restore_checkpoint(economic_restore.settlement)
		_accident_ground_stable = economic_restore.presentation.ground_stable
		_accident_settled_pending = economic_restore.presentation.settled_pending or (economic_restore.settlement.settled and _accident_ground_stable)
		_accident_incident.commit_restore(prepared_economics)
	# Existing checkpoints contain no scenario envelope. Never label a restored flight with stale seed provenance.
	_forget_scenario()
	sky_config = sky_restore.config.duplicate(true)
	_sky_edits = sky_restore.edits.duplicate(true)
	Atmosphere.configure_appearance(sky_config, SkyConfig.mean_wind_ned(session.weather_configuration()))
	if not sky_restore.legacy:
		Atmosphere.restore_cloud_transport(sky_restore.transport)
	if not _commit_lighting(staged, decoded.config):
		return {ok = false, physics_restored = true, economics_restored = not prepared_economics.is_empty(), errors = ["physics restored, but visual scene changed during restoration"]}
	_visual_timeline = decoded.timeline.duplicate(true)
	_smoke_key_on = false
	_reset_profile_smoke()
	if _smoke != null:
		_smoke.reset() # a physical checkpoint carries no particle history
	if _scenery_damage_director != null:
		_scenery_damage_director.sync(true)
	_visual_context_status = decoded.context_status
	_prop_angle = 0.0 # propeller phase was never part of the physical checkpoint contract
	if _engine_audio != null and _soundscape_audio == null: # AUD-07 F12: the soundscape owns its voices
		_engine_audio.stream_paused = true
	_render_pose(_current_pose(), session.surfaces(), _prop_angle)
	_refresh_sky()
	if _storm_fx != null:
		_storm_fx.reset()
		_update_storm(session.sim.time(), session.sim.paused)
	if has_water_render:
		if not _crash_director.restore_water_checkpoint(water_restore):
			return {ok = false, physics_restored = true, economics_restored = not prepared_economics.is_empty(), errors = ["physics restored, but water aftermath could not be restored"]}
	elif _crash_director != null:
		_crash_director.reset()
	_note = "Checkpoint restored; visual context: " + _visual_context_status
	return {ok = true, context_status = _visual_context_status, economics_restored = not prepared_economics.is_empty(), errors = []}


func _water_checkpoint_digest(visual: Dictionary, water_render: Dictionary) -> String:
	var hashing := HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(var_to_bytes([visual, water_render]))
	return hashing.finish().hex_encode()


func _has_exact_keys(source: Dictionary, expected: Array[String]) -> bool:
	if source.size() != expected.size():
		return false
	for key: Variant in source.keys():
		if typeof(key) != TYPE_STRING or not expected.has(str(key)):
			return false
	return true


## FW-78/82: validate a paused appearance edit before any lighting/preferences are committed.
func prepare_sky_edit(raw: Variant) -> Dictionary:
	var checked: Dictionary = SkyConfig.validate(raw)
	if not checked.ok:
		return checked
	if session == null or not session.sim.paused or _scripted or _capturing or _env == null or not startup_error.is_empty():
		return {ok = false, errors = ["sky editing requires a paused production flight"]}
	if _sky_edits.size() >= 4096 and checked.config != sky_config:
		return {ok = false, errors = ["sky edit history is full; restart before another edit"]}
	return checked


func apply_sky_config(raw: Variant) -> Dictionary:
	var checked: Dictionary = prepare_sky_edit(raw)
	if not checked.ok:
		return checked
	if checked.config == sky_config:
		return {ok = true, changed = false, errors = []}
	if not Atmosphere.configure_appearance(checked.config, SkyConfig.mean_wind_ned(session.weather_configuration()), session.sim.time()):
		return {ok = false, errors = ["could not prepare cloud appearance"]}
	sky_config = checked.config
	_refresh_sky()
	_sky_edits.append({tick = session.sim.tick, config = sky_config.duplicate(true), transport = Atmosphere.cloud_transport_checkpoint()})
	if recorder != null and recorder.recording:
		recorder.trace.meta.sky_context = JSON.stringify(_sky_context(), "", true, true)
	return {ok = true, changed = true, errors = []}


func _sky_context() -> Dictionary:
	return {config = sky_config.duplicate(true), config_identity = SkyConfig.identity(sky_config),
		profile = SkyConfig.validate(sky_config).profile, transport = Atmosphere.cloud_transport_checkpoint(),
		edits = _sky_edits.duplicate(true)}


## Restore the retained flight's renderer after a Workshop world used the shared sky uniforms.
func restore_sky_presentation(transport: Dictionary) -> void:
	var retained_exposure: float = _env.tonemap_exposure
	Atmosphere.configure_appearance(sky_config, SkyConfig.mean_wind_ned(session.weather_configuration()))
	Atmosphere.restore_cloud_transport(transport)
	_refresh_sky(retained_exposure)


func _refresh_sky(retained_exposure: float = -1.0) -> void:
	var snapshot: Dictionary = _lighting if lighting_config.get("mode", "legacy") != "legacy" else {}
	Atmosphere.update_environment(_env, snapshot)
	if retained_exposure > 0.0:
		# A retained paused world already has an adapted exposure; do not reset it to the sky baseline.
		_env.tonemap_exposure = retained_exposure
		World.Exposure.set_value(retained_exposure)
	Atmosphere.update_sun(_sun, snapshot)
	Atmosphere.update_cloud_appearance(_field_node)
	Atmosphere.update_clouds(_env, session.sim.time())
	World.refresh_star_cloud_appearance(_env)
	World.refresh_weather_appearance(_env, session.sim.time())
	if _storm_fx != null:
		_storm_fx.configure(sky_config)
		_update_storm(session.sim.time(), session.sim.paused)


func _update_storm(clock_s: float, paused: bool) -> void:
	if _storm_fx == null or _camera == null or sky_config.preset != "electrical_storm":
		return
	_storm_fx.bind_storm_bank(World.storm_bank_node(_env))
	_storm_fx.set_cell_transport(Atmosphere.cloud_transport_checkpoint())
	_storm_fx.set_cloud_state(Atmosphere.cloud_state_snapshot())
	if _soundscape_audio != null:
		_storm_fx.get_node("StormAudio").bind_soundscape(_soundscape_audio.soundscape)
		_storm_fx.set_sound_speed(_soundscape_audio.sound_speed_mps())
	_storm_fx.update_at(clock_s, _camera.global_position, paused, _env.tonemap_exposure)


## Apply a visual-only edit while paused. Never restore physical state or change live input ownership.
func apply_lighting_config(raw: Variant) -> Dictionary:
	var prepared := _prepare_lighting_edit(raw)
	if not prepared.ok or not prepared.changed:
		return prepared
	if not _commit_lighting(prepared.staged, prepared.config):
		return {ok = false, changed = false, errors = ["visual scene changed during lighting edit"]}
	_publish_lighting_edit(prepared)
	return {ok = true, changed = true, errors = []}


## Stage the complete Pause draft before the first scene mutation. After the
## field commit succeeds all remaining operations publish already validated data.
func apply_visual_conditions(raw: Variant, sky_raw: Variant, night_raw: Variant, moon_raw: Variant, night_only := false) -> Dictionary:
	var sky := prepare_sky_edit(sky_raw)
	if not sky.ok:
		return sky
	var night := Preferences.validate_night_options(night_raw)
	if not night.ok:
		return night
	var moon := MoonConfig.validate(moon_raw)
	if not moon.ok:
		return moon
	var lighting := {ok = true, changed = false}
	if not night_only:
		lighting = _prepare_lighting_edit(raw)
		if not lighting.ok:
			return lighting
	var sky_changed: bool = sky.config != sky_config
	var night_changed: bool = night.options != night_options
	var moon_changed: bool = moon.config != World.moon_config()
	if not lighting.changed and not sky_changed and not night_changed and not moon_changed:
		return {ok = true, changed = false, errors = []}
	var appearance := {}
	if sky_changed:
		appearance = Atmosphere.prepare_appearance(sky.config, SkyConfig.mean_wind_ned(session.weather_configuration()), session.sim.time())
		if not appearance.ok:
			return {ok = false, errors = ["could not prepare cloud appearance"]}
	if lighting.changed and not _commit_lighting(lighting.staged, lighting.config):
		return {ok = false, errors = ["visual scene changed during lighting edit"]}
	if sky_changed:
		Atmosphere.commit_appearance(appearance)
		sky_config = sky.config.duplicate(true)
		_sky_edits.append({tick = session.sim.tick, config = sky_config.duplicate(true), transport = Atmosphere.cloud_transport_checkpoint()})
	set_night_options(night.options.field_lighting, night.options.campfire, night.options.field_activation)
	MoonConfig.session_config = moon.config.duplicate(true)
	World.set_moon_config(moon.config)
	_refresh_sky()
	if recorder != null and recorder.recording and sky_changed:
		recorder.trace.meta.sky_context = JSON.stringify(_sky_context(), "", true, true)
	if lighting.changed:
		_publish_lighting_edit(lighting)
	return {ok = true, changed = true, errors = []}


func _prepare_lighting_edit(raw: Variant) -> Dictionary:
	if session == null or _scripted or _capturing or _field_world_lighting or _capture_scene_id() != "field" or not startup_error.is_empty():
		return {ok = false, changed = false, errors = ["lighting edit requires a ready production flight"]}
	if not session.sim.paused:
		return {ok = false, changed = false, errors = ["pause the flight before editing lighting"]}
	var checked: Dictionary = LightingConfig.validate(raw)
	if not checked.ok:
		return {ok = false, changed = false, errors = checked.errors}
	if checked.config == lighting_config:
		return {ok = true, changed = false, errors = []}
	var next_scenario: Dictionary = {}
	if not flight_scenario.is_empty():
		next_scenario = ScenarioConfig.customize_lighting(flight_scenario, checked.config)
		if next_scenario.is_empty():
			return {ok = false, changed = false, errors = ["Could not prepare the customized flight scenario."]}
	var edited: Dictionary = VisualTimeline.append_config_edit(_visual_timeline, session.sim.tick, checked.config)
	if not edited.ok:
		return {ok = false, changed = false, errors = edited.errors}
	var staged: Dictionary = _prepare_checkpoint_lighting(checked.config)
	if not staged.ok:
		return {ok = false, changed = false, errors = ["could not prepare lighting"]}
	# Prepare the prior context without publishing it until the scene update succeeds.
	var initial_context: String = JSON.stringify(TimeOfDayLighting.context(lighting_config, _lighting), "", true, true)
	return {ok = true, changed = true, config = checked.config, staged = staged,
		timeline = edited.timeline, scenario = next_scenario, initial_context = initial_context, errors = []}


func _publish_lighting_edit(prepared: Dictionary) -> void:
	if recorder.recording and not recorder.trace.meta.has("visual_context"):
		recorder.trace.meta.visual_context = prepared.initial_context
	_visual_timeline = prepared.timeline
	if recorder.recording:
		recorder.trace.meta.visual_timeline = JSON.stringify(_visual_timeline, "", true, true)
	if not flight_scenario.is_empty():
		flight_scenario = prepared.scenario
		_note = tr("Custom from Natural Random")
		if recorder.recording:
			# Preserve the trace's initial scenario; append edits at their physical tick boundary.
			var edits: Array = JSON.parse_string(recorder.trace.meta.get("flight_scenario_edits", "[]"))
			edits.append({tick = session.sim.tick, scenario = flight_scenario.duplicate(true)})
			recorder.trace.meta.flight_scenario_edits = JSON.stringify(edits, "", true, true)
		scenario_changed.emit(flight_scenario.duplicate(true))
	_render_pose(_current_pose(), session.surfaces(), _prop_angle)


## TOD-09b: publish in place; no await or physical-session mutation here.
func _commit_lighting(staged: Dictionary, config: Dictionary) -> bool:
	var updated: bool = FieldBuilder.commit_lighting(_field_node, staged.field)
	if staged.field.changed and not updated:
		return false
	Atmosphere.update_environment(_env, staged.lighting)
	Atmosphere.update_sun(_sun, staged.lighting)
	lighting_config = config.duplicate(true)
	_lighting = staged.lighting
	_update_aircraft_lights()
	var current_time: float = session.sim.time()
	ShaderClock.update(current_time, _render_wind(current_time))
	Atmosphere.update_clouds(_env, current_time)
	return true


func _field_identity() -> String:
	var hashing: HashingContext = HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(var_to_bytes(field))
	if _field_node != null and _field_node.has_meta("lake_identity"):
		hashing.update(str(_field_node.get_meta("lake_identity")).to_utf8_buffer())
	return hashing.finish().hex_encode()


## Prepare the only replaceable geometry before publishing; the field, Sun and Environment retain ownership.
func _prepare_checkpoint_lighting(config: Dictionary) -> Dictionary:
	var snapshot: Dictionary = TimeOfDayLighting.snapshot(config)
	var prepared_field: Dictionary = FieldBuilder.prepare_lighting(_field_node, snapshot)
	return {ok = prepared_field.ok, field = prepared_field, lighting = snapshot}


## The session's trace header plus which build flew it (UI-04a): the exported smoke test compares app_build with
## the ZIP name. "development" when running from the source tree.
func _trace_meta() -> Dictionary:
	var meta: Dictionary = session.trace_meta()
	if sky_config != SkyConfig.defaults() or not _sky_edits.is_empty():
		meta.sky_context = JSON.stringify(_sky_context(), "", true, true)
	meta.aircraft_visual_family = str(_airplane.get("visual_family", ""))
	meta.aircraft_model_manifest_sha256 = str(_airplane.get("model_manifest_sha256", ""))
	var build := BuildInfo.current()
	meta.app_build = build.describe if build.source == "export" else "development"
	meta.app_version = build.parsed.semver if build.source == "export" else build.version + " (development)"
	meta.visual_night_options = JSON.stringify(night_options, "", true, true)
	if not flight_scenario.is_empty():
		meta.flight_scenario = JSON.stringify(flight_scenario, "", true, true)
	if _visual_context_status != "present":
		meta.visual_context_status = _visual_context_status
	if _visual_context_status != "present" or not _visual_timeline.events.is_empty():
		meta.visual_timeline = JSON.stringify(_visual_timeline, "", true, true)
	if lighting_config.get("mode", "legacy") != "legacy" or _visual_context_status != "present" or not _visual_timeline.events.is_empty():
		# Self-contained optional header, copied/frozen by Recorder; CSV columns and physics identity stay unchanged.
		meta.visual_context = JSON.stringify(TimeOfDayLighting.context(lighting_config, _lighting), "", true, true)
	return meta


func _update_flight_log_label() -> void:
	if _flight_log_label == null:
		var layer := CanvasLayer.new()
		layer.layer = 25
		layer.visible = _failure_overlays_visible # created under a menu stays hidden with the other overlays
		add_child(layer)
		_flight_log_label = Label.new()
		layer.add_child(_flight_log_label)
		_flight_log_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
		_flight_log_label.offset_left = -520
		_flight_log_label.offset_right = -16
		_flight_log_label.offset_top = -54
		_flight_log_label.offset_bottom = -16
		_flight_log_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		_flight_log_label.clip_text = true
		var background := StyleBoxFlat.new()
		background.bg_color = Color(0.03, 0.05, 0.08, 0.86)
		background.content_margin_left = 12
		background.content_margin_right = 12
		_flight_log_label.add_theme_stylebox_override("normal", background)
		_flight_log_label.add_theme_color_override("font_shadow_color", Color.BLACK)
		_flight_log_label.add_theme_constant_override("shadow_offset_x", 1)
		_flight_log_label.add_theme_constant_override("shadow_offset_y", 1)
		_flight_log_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if companions != null and companions.recording_status().active:
		var capture: Dictionary = companions.recording_status()
		_flight_log_label.text = "FLEET REC %.1f s · F10 stop · F11 mark" % (float(capture.last_tick) / 240.0)
		_flight_log_label.tooltip_text = str(capture.directory)
		return
	if companions != null and not flight_log.recording and flight_log.note.is_empty():
		var capture: Dictionary = companions.recording_status()
		if not str(capture.directory).is_empty():
			_flight_log_label.text = "Fleet capture saved" if capture.complete else "Fleet capture incomplete"
			_flight_log_label.tooltip_text = str(capture.error) if not str(capture.error).is_empty() else str(capture.directory)
			return
	_flight_log_label.text = "REC %.1f s · F10 stop · F11 mark" % flight_log.seconds() if flight_log.recording else flight_log.note
	_flight_log_label.tooltip_text = flight_log.note


## CR-30: only accepted contact evidence enters costs. VFX severity never enters this path.
func _on_accident_contacts() -> void:
	if _accident_incident == null or _accident_checkpoint_restoring:
		return
	if _accident_source_hash != str(session.aircraft.get("input_identity", {}).get("sha256", "")):
		_accident_reload_pending = true
		return # Rebind at the frame boundary; no catalog or archive I/O in an accepted callback.
	_accident_restored = _accident_restored or (not _accident_paired_history and session.pause_reason == "checkpoint restored (recorded inputs)")
	var admitted: Dictionary = _accident_incident.observe(session.contact_events(), _accident_bindings, not session.crash.is_empty(), _accident_restored)
	if not admitted.get("ok", false):
		# Rejected evidence cannot mutate the financial ledger. Surface the gap in its live view.
		_accident_evidence_warning_pending = true
	if _accident_incident.has_damage() and not _accident_incident.terminal:
		_observe_accident_settlement()


func _observe_accident_settlement() -> void:
	var state: PackedFloat64Array = session.sim.state
	var speed_squared := 0.0
	var rate_squared := 0.0
	for axis in 3:
		speed_squared += state[RB.VEL + axis] * state[RB.VEL + axis]
		rate_squared += state[RB.RATE + axis] * state[RB.RATE + axis]
	var grounded := false
	for compression: float in session.gear_compressions(state):
		grounded = grounded or compression > 0.00001
	if not grounded:
		grounded = session.touches_ground(state) # A belly slide can settle with its wheels clear.
	var speed := sqrt(speed_squared)
	var rate := sqrt(rate_squared)
	_accident_ground_stable = AccidentSettlement.is_stable(grounded, speed, rate)
	if _accident_settlement.observe(session.sim.tick, session.sim.dt(), grounded, speed, rate):
		_accident_settled_pending = true
	if not _accident_ground_stable:
		if _accident_settled_pending:
			_accident_settlement.reset() # Nothing was shown; a later landing can earn a fresh dwell.
		_accident_settled_pending = false # A go-around before the next frame cannot open a stale card.


## All valuation, UI publication and persistence run outside accepted simulation callbacks.
func _update_accident_report() -> void:
	if _accident_evidence_warning_pending:
		_accident_evidence_warning_pending = false
		_note = tr("Accident cost evidence is incomplete; some contact observations were rejected.")
		_accident_report.mark_evidence_unavailable()
	if _accident_reload_pending:
		var archived: Dictionary = _accident_incident.archive()
		_begin_accident_ledger()
		_accident_report.clear_report()
		if not archived.is_empty():
			_accident_report.show_archived(archived)
		_accident_restored = true # Earlier contacts under the changed identity were not retained.
		_on_accident_contacts()
	var archive_result: int = _accident_incident.flush()
	if archive_result != OK and archive_result != _accident_archive_error:
		_note = tr("Accident report could not be saved; it remains available for this session.")
	_accident_archive_error = archive_result
	if _accident_settled_pending and not _accident_incident.terminal:
		_accident_report.show_settled(_accident_incident.report)
		_accident_settled_pending = false
	elif not _accident_ground_stable:
		_accident_report.dismiss_settled()


func _begin_accident_ledger() -> void:
	_accident_evidence_warning_pending = false
	session.cost_observations_enabled = true
	_accident_source_hash = str(session.aircraft.get("input_identity", {}).get("sha256", ""))
	_accident_bindings = session.contact_contract()
	_accident_incident.begin(aircraft_id, _accident_source_hash)
	_accident_restored = false
	_accident_paired_history = false
	_accident_settlement.reset()
	_accident_settled_pending = false
	_accident_ground_stable = false
	_accident_reload_pending = false


func _on_accident_assessment(report: Dictionary, terminal: bool) -> void:
	_accident_report.show_assessment(report, terminal)


func _on_accident_costing_mode_requested(mode: String) -> void:
	if _accident_incident == null or mode not in ["diy", "paid"]:
		return
	var result: Dictionary = _accident_incident.set_costing_mode(mode)
	if not result.get("ok", false):
		_note = tr("The cost option could not be applied. The previous estimate is retained.")


func _on_accident_purchase_package_requested(package_id: String) -> void:
	if _accident_incident == null:
		return
	var result: Dictionary = _accident_incident.set_purchase_package(package_id)
	if not result.get("ok", false):
		_note = tr("The cost option could not be applied. The previous estimate is retained.")


func _exit_tree() -> void:
	if _frametimes_active and _frametime_samples != null:
		_frametime_samples.abort("flight closed before collection completed")
		var interrupted: Dictionary = _frametime_samples.report()
		interrupted["interruption"] = "flight closed; session endpoint metadata unavailable"
		var written: Dictionary = FrameSamples.write_json(_frametimes_path, interrupted)
		if not written.ok:
			push_error("Cannot write interrupted frame-time report: " + error_string(int(written.error)))
		_frametimes_active = false
	if is_instance_valid(_preparing_session):
		_preparing_session.free()
		_preparing_session = null
	if is_instance_valid(_rgb_lighting):
		_rgb_lighting.dispose()
	CameraRig.hold_cursor(false) # never leave the menus with a held cursor (CAM-29)
	# A cancelled staged build can stop before attaching these owners to the scene.
	if not _airplane.is_empty() and is_instance_valid(_airplane.get("root")) and _airplane.root.get_parent() == null:
		_airplane.root.free()
		_airplane = {}
	if is_instance_valid(session) and session.get_parent() == null:
		session.free()
		session = null
	if companions != null and is_instance_valid(companions):
		companions.stop_recording("flight closed")
	if _frame_diagnostics != null:
		_frame_diagnostics.stop()
	if _accident_incident != null:
		_accident_incident.archive()
	if flight_log != null:
		flight_log.stop("flight closed")


## One file never mixes two flights.
func _on_resetting() -> void:
	_history_crash_camera_active = false # rig.reset() below already invalidates this flight's history.
	if _overlays != null:
		_overlays.reset_flight()
	_queue_companion_transition()
	_aircraft_lights.reset()
	if is_instance_valid(_rgb_lighting):
		_rgb_lighting.reset()
	_aircraft_lights_hud_dirty = true
	World.flow_to(0.0)
	_update_aircraft_lights(0.0)
	if _accident_incident != null and not _accident_checkpoint_restoring:
		var archived: Dictionary = _accident_incident.archive()
		_begin_accident_ledger()
		_accident_report.clear_report()
		if not archived.is_empty():
			_accident_report.show_archived(archived)
	_sky_edits.clear()
	Atmosphere.configure_appearance(sky_config, SkyConfig.mean_wind_ned(session.weather_configuration()))
	if _storm_fx != null:
		_storm_fx.reset()
	if not flight_scenario.is_empty() and (session.aircraft.get("input_identity", {}).get("sha256", "") != flight_scenario.aircraft_identity \
			or session.weather_configuration() != flight_scenario.weather_config):
		_forget_scenario() # developer reload/environment replacement is no longer the accepted random draw
	_smoke_key_on = false
	_wing_fold = 0.0
	_wing_fold_target = 0.0
	session.set_throttle_hold("wing_fold", false)
	_mechanisms.clear()
	_mechanism_targets.clear()
	_reset_profile_smoke()
	if _smoke != null:
		_smoke.reset()
	_visual_timeline = VisualTimeline.create(lighting_config).timeline
	_visual_context_status = "present"
	_t = 0.0
	if _rig != null:
		_rig.reset()
	if recorder.recording:
		recorder.stop()
	if _engine_audio != null and _soundscape_audio == null and _engine_audio.playing:
		# A new flight: discard the prior flight's audio queue and oscillator state.
		EngineSound.restart(_engine_audio)


func _companion_options(raw: Dictionary) -> Dictionary:
	var checked: Dictionary = CompanionConfig.validate(raw)
	if not checked.ok or not checked.config.enabled:
		return checked
	var args := _user_args()
	if _scripted or args.has("capture") or args.has("trace") or not workshop_trial.is_empty() \
			or not flight_scenario.is_empty() or not _experimental_aircraft_path.is_empty() or not _electric_demo.is_empty():
		return {ok = false, errors = ["Companions require a normal fixed-wing flight at Club field."]}
	return CompanionManager.validate_context(session, field, landscape_id, checked.config)


func set_companion_config(raw: Dictionary) -> Dictionary:
	var checked: Dictionary = _companion_options(raw)
	if checked.ok:
		companion_config = checked.config.duplicate(true)
		if companions != null:
			companions.apply_presentation(companion_config)
	return checked


func companion_status() -> Dictionary:
	var result: Dictionary = companions.status() if companions != null else {
		active = 0, airborne = 0, requested = int(companion_config.count) if companion_config.enabled else 0}
	var requested: Dictionary = companion_config.duplicate(true)
	var admitted: Dictionary = _companion_admitted_config.duplicate(true)
	result.requested_count = int(requested.count) if requested.enabled else 0
	result.admitted_count = int(admitted.get("count", 0)) if admitted.get("enabled", false) else 0
	result.pending_count = result.requested_count
	result.pending_restart = _companion_flight_settings(requested) != _companion_flight_settings(admitted)
	result.requested_config = requested
	result.admitted_config = admitted
	result.in_flight = true
	if not _companions_error.is_empty():
		result.error = _companions_error
	return result


## Presentation changes take effect immediately and do not require a roster rebuild.
func _companion_flight_settings(config: Dictionary) -> Dictionary:
	var flight_settings := config.duplicate(true)
	for key: String in ["engine_volume", "show_labels", "label_distance_m"]:
		flight_settings.erase(key)
	return flight_settings


func remove_companions_now() -> void:
	# A removal after an accepted start wins over its queued roster creation.
	# The matching deferred completion still releases its start hold normally.
	_companions_reset_roster = false
	if companions != null:
		companions.remove_now()


func _start_companions() -> Dictionary:
	_companion_admitted_config = {}
	var checked: Dictionary = _companion_options(companion_config)
	if not checked.ok:
		return checked
	if not companion_config.enabled:
		_companion_admitted_config = checked.config.duplicate(true)
		return checked
	var candidate := CompanionManager.new()
	candidate.name = "FlightCompanions"
	var prepared: Dictionary = candidate.configure(session, field, landscape_id, companion_config,
		true, str(_user_args().get("soundscape", "on")) != "off")
	if not prepared.ok:
		candidate.free()
		return prepared
	_companion_admitted_config = prepared.config.duplicate(true)
	companions = candidate
	add_child(companions)
	return prepared


## Reset notifications also close recorders for restore and pending configuration.
## Only an accepted physical start authorizes a roster rebuild and later resume.
func _queue_companion_transition() -> void:
	var transition: Dictionary = session.last_transition()
	_companions_reset_generation = int(transition.get("generation", -1))
	_companions_reset_session_id = session.get_instance_id()
	if _companions_reset_pending:
		session.release("companions-reset")
	_companions_reset_pending = false
	_companions_reset_roster = false
	_companions_resume_after_reset = false
	# Debug rewind restores Session directly, outside the paired Main facade.
	# A player-only restored clock cannot keep the previous fleet's sessions.
	if transition.get("kind", "") == FlightSession.TRANSITION_RESTORE and companions != null:
		companions.remove_now()
	if transition.get("kind", "") != FlightSession.TRANSITION_START:
		return
	if not _companions_initialized or (companions == null and not companion_config.enabled):
		return
	_companions_reset_pending = true
	_companions_reset_roster = true
	_companions_resume_after_reset = _companions_application_focused
	session.hold("companions-reset")
	call_deferred("_restart_companions", _companions_reset_generation, _companions_reset_session_id)


func _restart_companions(generation: int, source_session_id: int) -> void:
	# A stale callback owns neither the current roster nor its shared hold.
	if not _companions_reset_pending or generation != _companions_reset_generation \
			or source_session_id != _companions_reset_session_id:
		return
	if not is_inside_tree() or session == null:
		return
	_companions_reset_pending = false
	var resume_authorized: bool = _companions_resume_after_reset
	_companions_resume_after_reset = false
	if source_session_id != session.get_instance_id():
		return
	var transition: Dictionary = session.last_transition()
	if int(transition.get("generation", -1)) != generation \
			or transition.get("kind", "") != FlightSession.TRANSITION_START:
		session.release("companions-reset")
		return
	if not session.start_error.is_empty() or not session.sim.fault_reason.is_empty() or session.sim.tick != 0:
		_companions_error = "Flight restart was refused; the previous companions are retained."
		session.release("companions-reset")
		return
	if _companions_reset_roster:
		if companions != null:
			remove_child(companions)
			companions.free()
			companions = null
		var result: Dictionary = _start_companions()
		_companions_error = "" if result.ok else "; ".join(result.errors)
	_companions_reset_roster = false
	session.release("companions-reset")
	# Focus loss, an explicit failsafe or controller readiness may have paused
	# this accepted start after its publication. Completion cannot clear that cue.
	if resume_authorized and session.pause_reason.is_empty():
		session.resume()


## Saved preferences establish a flight-local cue. V may then change it without
## unrelated graphics settings resetting the pilot's choice.
func _initialize_shadow_mode(args: Dictionary) -> void:
	_shadow_cli_override = args.has("shadow")
	_shadow_mode = str(args.get("shadow", "sun"))
	_shadow_preference = ""
	_shadow_settings_revision = -1
	_sync_shadow_preference()


func _sync_shadow_preference() -> void:
	if not interactive_start or _shadow_cli_override or _shadow_settings_revision == Atmosphere.ShadowSettings.revision:
		return
	var receipt: Dictionary = Atmosphere.ShadowSettings.describe()
	_shadow_settings_revision = Atmosphere.ShadowSettings.revision
	var selected := str(receipt.requested.get("shadow_aircraft_cue", "auto"))
	if selected == _shadow_preference:
		return
	_shadow_preference = selected
	_shadow_mode = "sun" if selected == "auto" else selected


func _cycle_shadow_mode() -> void:
	_sync_shadow_preference()
	_shadow_mode = SHADOW_MODES[(SHADOW_MODES.find(_shadow_mode) + 1) % SHADOW_MODES.size()]


## Arguments after `--`: --capture, --inspect, --scripted, --t=3.0, --roll=1, --out=/path.png, --trace=/path.csv,
## --alt=4 (start altitude, m), --autozoom=0, --view=pilot|chase|orbit|closeup (CAM-04), --look_az=90 --look_el=10 --look_alt=30 (fixed landscape review view),
## --hide_airplane (readability reference), --hide_treeline (L6c tree-mask reference; refused without field objects),
## --visual_pose=level --visual_distance=100 [--visual_elevation=1.6 --visual_azimuth=0] (synthetic inspection,
## with --scripted and an explicit --autozoom), --frametimes=<file.json>, --shadow=sun|vertical|off, --engine_shadows,
## --aircraft=<catalog id> (default the Ugly Stik; a preview aircraft only with --scripted),
## --quick-flight (runway default; every airplane trimmed for 50 % throttle like Home, D6e-R4),
## --start=runway|airborne|airborne_half_power|hand_launch (explicit launch override; without --quick-flight the reference trim;
## hand_launch only for airplanes without landing gear, X8-07),
## --rates=normal|sport|full (D6e-R5: low rates, full roll with normal pitch/yaw, or all maximum throws),
## --field-lighting=club|airfield|off, --field-activation=auto|on|off, --campfire=on|off (FW-71 visual options; direct routes ignore saved preferences),
## --experimental-aircraft-data=<absolute JSON path> (research-only Ugly Stik wing-polar candidate)
func _user_args() -> Dictionary:
	var args := {}
	for a in user_args:
		var kv := a.trim_prefix("--").split("=", true, 1)
		args[kv[0]] = kv[1] if kv.size() > 1 else true
	return args


func set_user_args(args: PackedStringArray) -> void:
	user_args = args.duplicate()


func _validate_experimental_aircraft_data(path: Variant, selected_aircraft_id: String, scripted: bool, electric_demo: bool) -> Dictionary:
	if typeof(path) != TYPE_STRING or str(path).is_empty():
		return {ok = false, error = "--experimental-aircraft-data needs an absolute JSON file path"}
	var candidate_path: String = str(path)
	if not candidate_path.is_absolute_path() or candidate_path.get_extension().to_lower() != "json":
		return {ok = false, error = "--experimental-aircraft-data needs an absolute JSON file path"}
	if not FileAccess.file_exists(candidate_path):
		return {ok = false, error = "candidate file does not exist: %s" % candidate_path}
	if selected_aircraft_id != Catalog.DEFAULT_ID or scripted or electric_demo:
		return {ok = false, error = "candidate route requires a physics flight of the catalog default Ugly Stik only"}
	var candidate_parser := JSON.new()
	var candidate_bytes := FileAccess.get_file_as_bytes(candidate_path)
	if candidate_parser.parse(candidate_bytes.get_string_from_utf8()) != OK or typeof(candidate_parser.data) != TYPE_DICTIONARY:
		return {ok = false, error = "candidate must be a JSON object: %s" % candidate_path}
	var candidate: Dictionary = candidate_parser.data
	if typeof(candidate.get("id")) != TYPE_STRING or candidate.get("id") != Catalog.DEFAULT_ID:
		return {ok = false, error = "candidate id must match the catalog default Ugly Stik"}
	if typeof(candidate.get("aero")) != TYPE_DICTIONARY or typeof(candidate.aero.get("wing_polar")) != TYPE_DICTIONARY:
		return {ok = false, error = "candidate must contain aero.wing_polar as an object"}
	var reference_path: String = str(Catalog.entry(Catalog.DEFAULT_ID).get("data", ""))
	var reference_parser := JSON.new()
	if reference_path.is_empty() or reference_parser.parse(FileAccess.get_file_as_string(reference_path)) != OK or typeof(reference_parser.data) != TYPE_DICTIONARY:
		return {ok = false, error = "catalog default aircraft reference data is unavailable"}
	var candidate_reference: Dictionary = candidate.duplicate(true)
	var catalog_reference: Dictionary = reference_parser.data.duplicate(true)
	candidate_reference["aero"].erase("wing_polar")
	catalog_reference["aero"].erase("wing_polar")
	if candidate_reference != catalog_reference:
		return {ok = false, error = "candidate may change only aero.wing_polar from catalog default data; reference geometry and other data must match"}
	var digest := HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	digest.update(candidate_bytes)
	return {ok = true, path = candidate_path, input_sha256 = digest.finish().hex_encode()}


func _view_name() -> String:
	if not _visual_pose.is_empty():
		return "fixed inspection"
	return _rig.view_name()


## Workshop trials (even unit-scale customizations) and inspection fixtures are outside proxy qualification.
func _shadow_proxy_context() -> Dictionary:
	var args := _user_args()
	if not workshop_trial.is_empty() or _scripted or args.has("capture") or args.has("trace"):
		return {}
	return {stock_session = true, model_manifest_sha256 = str(_airplane.get("model_manifest_sha256", ""))}


func _build_world() -> bool:
	if not await _startup_stage("Preparing aircraft"):
		return false
	_airplane = AirplaneBuilder.build(aircraft_id, NAN, workshop_trial.get("presentation", {}), livery if workshop_trial.is_empty() else "")
	if _airplane.is_empty():
		startup_error = "Aircraft model failed its manifest and scene binding checks: " + aircraft_id
		return false
	if not workshop_trial.is_empty():
		var applied := AircraftCustomization.apply(_airplane, workshop_trial.get("presentation_profile", {}))
		if not applied.get("ok", false):
			startup_error = "; ".join(PackedStringArray(applied.get("errors", [])))
			_airplane.root.free()
			_airplane = {}
			return false
	var snapshot: Dictionary = _lighting if lighting_config.get("mode", "legacy") != "legacy" else {}
	Atmosphere.configure_appearance(sky_config)
	var built: Dictionary
	if startup_checkpoint.is_valid():
		built = await World.build_staged(self, field, _build_field_staged, {}, snapshot, night_options, startup_checkpoint)
		if built.get("cancelled", false): return false
	else:
		built = World.build(self, field, _build_field, {}, snapshot, night_options)
	_field_world_lighting = bool(built.conditions.time_of_day)
	_env = built.environment
	_world_environment = built.world_environment
	_sun = built.sun
	if not await _startup_stage("Preparing aircraft lighting"):
		return false

	_airplane.root.scale = Vector3.ONE * float(workshop_trial.get("scale", 1.0))
	add_child(_airplane.root)
	_extent = Shadow.model_extent(_airplane.root) * float(workshop_trial.get("scale", 1.0))
	_sync_shadow_preference() # Staged construction can yield while settings change.
	_shadow = Shadow.create(self, _shadow_mode)
	# Bind the aircraft silhouette before fitting luminous geometry.
	if not startup_checkpoint.is_valid():
		Shadow.bind_model(_shadow, _airplane.root, {}, _shadow_proxy_context(), _shadow_mode)
	# Legacy profiles keep the established lazy kit and imported-material behavior.
	var lighting_profile: Dictionary = workshop_trial.get("presentation_profile", {}).get("lighting", LightingProfile.defaults())
	if lighting_profile.get("selection", "inherit") != "inherit":
		for zone: Dictionary in lighting_profile.get("zones", []):
			_lighting_reacts_to_airspeed = _lighting_reacts_to_airspeed or zone.get("reactive", {}).get("source", "none") == "airspeed"
		_rgb_lighting = AircraftLightingRig.new()
		_rgb_lighting.name = "AircraftLightingRig"
		add_child(_rgb_lighting)
		var lighting_result: Dictionary = _rgb_lighting.configure(_airplane.root, lighting_profile)
		if not bool(lighting_result.get("ok", false)):
			startup_error = "; ".join(PackedStringArray(lighting_result.get("errors", [])))
			return false
		for luminous: VisualInstance3D in _rgb_lighting.luminous_nodes():
			luminous.layers |= Magnifier.LAYER
	_update_aircraft_lights(0.0) # after the extent is measured; fixed TOD and field-world clocks share the policy
	_camera = PilotCamera.create(self, field.pilot)
	_storm_fx = Lightning.new()
	_storm_fx.name = "ElectricalStorm"
	add_child(_storm_fx)
	_storm_fx.configure(sky_config)
	var storm_args: Dictionary = _user_args()
	_storm_fx.set_audio_enabled(not _scripted and not storm_args.has("capture") and str(storm_args.get("soundscape", "on")) != "off")
	_rig = CameraRig.new(_camera, _extent.x)
	_magnifier = Magnifier.new()
	_magnifier.name = "MagnifierLayer"
	add_child(_magnifier)
	if not await _startup_stage("Preparing instruments"):
		return false
	if overlays_enabled:
		_overlays = OverlayManager.new(overlay_settings, TranslationServer.get_locale().substr(0, 2))
		_overlays.settings_changed.connect(func(settings: Dictionary) -> void: overlay_settings_changed.emit(settings))
		add_child(_overlays)
		_panel = _overlays.diagnostics_panel
		_hud = _overlays.diagnostics_hud
	else:
		_panel = InputPanel.create(self)
		_hud = Hud.create(self)
	return true


## Commits a validated presentation change to this flight's field world.
func set_night_options(profile: String, campfire: bool, activation: String = "auto") -> bool:
	var checked: Dictionary = Preferences.validate_night_options({"field_lighting": profile, "campfire": campfire,
		"field_activation": activation})
	if not checked.get("ok", false):
		return false
	night_options = checked.options.duplicate(true)
	World.set_night_options(profile, campfire, activation)
	return true


## Production field seam. The atmosphere fixture overrides only these ground meshes.
func _build_field() -> void:
	_field_node = Landscapes.build(landscape_id, field, _lighting if lighting_config.get("mode", "legacy") != "legacy" else {},
		_rc_track)
	add_child(_field_node)


func _build_field_staged() -> Dictionary:
	_field_node = await Landscapes.build_staged(landscape_id, field,
		_lighting if lighting_config.get("mode", "legacy") != "legacy" else {}, startup_checkpoint, _rc_track)
	if _field_node == null:
		return {cancelled = true}
	var attach_begin := Time.get_ticks_usec()
	add_child(_field_node)
	return {cancelled = false, field_build_ms = float(_field_node.get_meta("field_build_ms", 0.0))
		+ (Time.get_ticks_usec() - attach_begin) / 1000.0}


## Hides every field object (today: the treeline and its L8a-R1 3D front trees) for a background-only
## capture. False when there is none.
func _hide_field_objects() -> bool:
	var hidden := false
	for object_data: Dictionary in field.get("objects", []):
		var node: Node3D = get_node_or_null(NodePath("Field/%s" % str(object_data.id))) as Node3D
		if node != null:
			node.visible = false
			hidden = true
		var detail: Node3D = get_node_or_null(NodePath("Field/%sDetail" % str(object_data.id))) as Node3D
		if detail != null:
			detail.visible = false
	_treeline_hidden = hidden
	return hidden


func _capture_scene_id() -> String:
	return "field"


func _surface_rotations_for_render(c: Dictionary) -> Dictionary:
	if _scripted:
		return Commands.hinge_rotations(c, session.throws_deg())
	return ControlSurfaces.hinge_rotations_from_surfaces(session.surface_angles_deg())


## Apply the current flight-local cue to the presentation carrier.
func _update_aircraft_shadow(pose: Dictionary, snapshot_lighting: bool) -> Vector3:
	_sync_shadow_preference()
	# FW-MOON-03: field-world time passes no lighting dictionary; its strength fades the moon's shadow with the phase.
	var strength: float = (Atmosphere.shadow_strength(_lighting) if snapshot_lighting else Atmosphere.shadow_strength()) \
		if _shadow_mode == "sun" else 1.0
	_shadow.visible = _shadow_mode != "off" and _airplane.root.visible and strength > 0.0
	var direction: Vector3 = Atmosphere.sun_direction(_lighting) if snapshot_lighting else Atmosphere.shadow_direction()
	Shadow.update(_shadow, pose.basis, pose.pos, _extent.x, _extent.y, direction, strength, _shadow_mode)
	return direction


func _render_pose(pose: Dictionary, c: Dictionary, prop_angle: float) -> void:
	_last_render_pose = pose
	_airplane.root.transform = Frames.root_transform(pose.basis, pose.pos, _cg_model)
	# root_transform replaces the basis each frame; restore the presentation-only uniform scale.
	_airplane.root.scale = Vector3.ONE * float(workshop_trial.get("scale", 1.0))
	_airplane.propeller.rotation.z = prop_angle * float(_airplane.get("propeller_spin_sign", 1.0))
	AirplaneBuilder.apply_controls(_airplane, _surface_rotations_for_render(c), float(c.get("throttle", 0.0)))
	if session != null and session.flaps_available():
		var flap_state: Dictionary = session.flap_state()
		AirplaneBuilder.apply_flaps(_airplane, float(flap_state.get("angle_deg", 0.0)))
	if AirplaneBuilder.has_folds(_airplane):
		var fractions := {}
		for key: String in _airplane.folds:
			fractions[key] = _wing_fold
		AirplaneBuilder.apply_folds(_airplane, fractions)
	var mechanisms := _mechanisms
	if float(_mechanisms.get("tailhook", 0.0)) > 0.0:
		# The lowered hook rides on the runway, as the real one rides the deck.
		mechanisms = _mechanisms.duplicate()
		mechanisms.tailhook = AirplaneBuilder.ground_limited_fraction(_airplane, "tailhook", _mechanisms.tailhook, _ground_height)
	AirplaneBuilder.apply_mechanisms(_airplane, mechanisms)
	var snapshot_lighting: bool = lighting_config.get("mode", "legacy") != "legacy"
	var direction := _update_aircraft_shadow(pose, snapshot_lighting)
	var paused: bool = session != null and session.sim.paused and not _scripted
	_rig.light_direction = direction # CAM-14: the fly-by stands with the sun behind it
	_rig.update(pose.pos, _airplane.root.transform, pose.basis, _camera_dt, paused, _ground_height, pose.get("vel", Vector3.INF),
		_camera_clearance)
	if _magnifier != null:
		_magnifier.mode = _rig.magnifier
		_magnifier.update(_camera, pose.pos, _extent.x, _airplane.root, _rig.view == "pilot" and is_nan(_look.x)
			and _airplane.root.visible and (session == null or session.crash.is_empty()))


func _write_trace_and_quit(ticks: int, path: String) -> void:
	session.input_enabled = false
	session.sim.process_mode = Node.PROCESS_MODE_DISABLED
	if not session.is_flyable() or session.sim.tick != 0:
		push_error("--trace refused: flight did not start in a valid state at tick zero")
		get_tree().quit(1)
		return
	recorder.start(_trace_meta())
	for i in ticks:
		session.sim.step()
		if not session.sim.fault_reason.is_empty() or session.sim.tick != i + 1:
			recorder.recording = false
			push_error("--trace aborted at tick %d: %s" % [session.sim.tick, session.sim.fault_reason])
			get_tree().quit(1)
			return
	if recorder.trace.row_count() != ticks + 1:
		recorder.recording = false
		push_error("--trace aborted: recorder did not receive every tick")
		get_tree().quit(1)
		return
	get_tree().quit(recorder.stop(path))


func _capture(t: float, c: Dictionary, out: String) -> void:
	var sim: Node = session.sim
	if _scripted:
		_t = t
	else:
		# Step the simulation synchronously to time t, then freeze it for the capture.
		for i in roundi(t / sim.dt()):
			sim.step()
		sim.set_paused(true)
		c = session.commands # physics captures show the real commands, not capture arguments
	# Surfaces as flown: physics captures draw the servos' actual positions (trims included), like live rendering.
	var surfaces: Dictionary = c if _scripted else session.surfaces()
	InputPanel.update(_panel, Commands.neutral_raw(), c, _view_name(), _status(), surfaces, session.throws_deg())
	var pose := _current_pose() if _scripted else _pose_of(sim.state)
	_render_pose(pose, surfaces, TAU * Commands.prop_rev_per_sec(c) * t)
	var clock_s: float = t if _scripted else sim.time()
	World.update(_env, clock_s, _render_wind(clock_s), pose.pos, _camera)
	_update_aircraft_lights(clock_s)
	_update_storm(clock_s, false) # deterministic capture includes the selected event phase
	_update_hud()
	_capture_settle_frames = Reconstruction.capture_settle_frames(get_viewport().scaling_3d_mode, get_viewport().scaling_3d_scale)
	for _frame: int in _capture_settle_frames:
		await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(out).get_base_dir())
	var capture_image := ViewportColor.display_image(get_viewport().get_texture().get_image(), get_viewport().use_hdr_2d)
	var err := capture_image.save_png(out)
	# Render counters of the captured frame (L0): deterministic for a fixed view, so landscape budgets are testable.
	var manifest_err := _write_manifest(out, err)
	var sun_px := _camera.unproject_position(_camera.global_position + Atmosphere.disc_direction(_lighting) * 1000.0)
	var sun_visible: bool = Atmosphere.light_energy(_lighting) > 0.0 and not _camera.is_position_behind(_camera.global_position + Atmosphere.disc_direction(_lighting) * 1000.0)
	# L3: where the sun shadow of the airplane's CG falls on the ground (along the light, onto y = 0), on screen.
	var cg: Vector3 = pose.pos
	var sd := Atmosphere.sun_direction(_lighting)
	var shadow_available: bool = sd.y > 0.00001 and Atmosphere.shadow_strength(_lighting) > 0.0
	# Match the visible footprint's low-angle bound instead of logging an unbounded physical projection.
	var projection_direction: Vector3 = sd
	projection_direction.y = maxf(projection_direction.y, 0.05)
	var shadow_point: Vector3 = cg - projection_direction * (cg.y / projection_direction.y) if shadow_available else Vector3(cg.x, 0.0, cg.z)
	var shadow_px := _camera.unproject_position(shadow_point)
	var shadow_seen: bool = shadow_available and not _camera.is_position_behind(shadow_point)
	var below_px := _camera.unproject_position(Vector3(cg.x, 0.0, cg.z)) # straight below: where a vertical shadow would be
	print("saved %s (error %d) draw_calls=%d primitives=%d sun_px=%s sim_clock=%s shadow_px=%s below_px=%s" % [out, err,
		Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),
		("%.1f,%.1f" % [sun_px.x, sun_px.y]) if sun_visible else "behind", str(ShaderClock.last_clock),
		("%.1f,%.1f" % [shadow_px.x, shadow_px.y]) if shadow_seen else "behind", "%.1f,%.1f" % [below_px.x, below_px.y]])
	get_tree().quit(err if err != OK else manifest_err)


## L0b determinism manifest next to each capture (<name>.json): image hash, per-pass render counters, renderer,
## Mesa and Godot versions, llvmpipe thread count. Two fixed runs must give identical manifests; sky-only views can have zero visible mesh counters.
func _write_manifest(png_path: String, err: Error) -> Error:
	var vp := get_viewport().get_viewport_rid()
	var info := func(type: int, what: int) -> int: return RenderingServer.viewport_get_render_info(vp, type, what)
	var visible := RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE
	var shadow := RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW
	var m := {
		format = "openrc-capture v1",
		visual_evidence = capture_evidence(),
		capture_scene = _capture_scene_id(),
		renderer = RenderingServer.get_current_rendering_method(),
		image = png_path.get_file(),
		sha256 = FileAccess.get_sha256(png_path) if err == OK else "",
		draw_calls = { visible = info.call(visible, RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME), shadow = info.call(shadow, RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME) },
		primitives = { visible = info.call(visible, RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME), shadow = info.call(shadow, RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME) },
		objects = { visible = info.call(visible, RenderingServer.VIEWPORT_RENDER_INFO_OBJECTS_IN_FRAME), shadow = info.call(shadow, RenderingServer.VIEWPORT_RENDER_INFO_OBJECTS_IN_FRAME) },
		video_memory_bytes = int(Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED)),
		adapter = RenderingServer.get_video_adapter_name(),
		api = RenderingServer.get_video_adapter_api_version(),
		godot = Engine.get_version_info().string,
		lp_num_threads = OS.get_environment("LP_NUM_THREADS"),
		args = " ".join(user_args).replace(png_path, png_path.get_file()),
	}
	var f := FileAccess.open(png_path.get_basename() + ".json", FileAccess.WRITE)
	if f == null:
		var open_error := FileAccess.get_open_error()
		push_error("Cannot write capture manifest: %s" % error_string(open_error))
		return open_error
	f.store_string(JSON.stringify(m, "  ", true) + "\n")
	f.flush()
	var write_error := f.get_error()
	f.close()
	if write_error != OK:
		push_error("Cannot save capture manifest: %s" % error_string(write_error))
	return write_error


## VQ-01b: records raw monotonic frame intervals after warm-up. Legacy summary fields use wall-clock deltas;
## engine `delta` stays available in engine_* fields. Use --warmup=<seconds> (default 1) and --t=<seconds> (20).
func _log_frame_time(delta: float) -> void:
	var now_usec: int = Time.get_ticks_usec()
	var wall_delta_usec: int = now_usec - _frametimes_last_usec
	_frametimes_last_usec = now_usec
	var sim: Node = session.sim
	var drawn: int = Engine.get_frames_drawn()
	var draw_reset := _frametimes_previous_drawn >= 0 and drawn < _frametimes_previous_drawn
	var interval_draws := drawn - _frametimes_previous_drawn if _frametimes_previous_drawn >= 0 and not draw_reset else 0
	if draw_reset:
		_frametimes_draw_counter_resets += 1
	elif _frametimes_previous_drawn >= 0 and drawn == _frametimes_previous_drawn:
		_frametimes_no_draw_intervals += 1
	_frametimes_previous_drawn = drawn
	var native_display := DisplayServer.get_name() != "headless"
	var window_drawable := native_display and DisplayServer.window_can_draw()
	if native_display and not window_drawable:
		_frametimes_undrawable_samples += 1
	var raw_metrics: Dictionary = {
		sim_time_s = sim.time(),
		sim_tick = sim.tick,
		physics_step_usec = sim.step_usec,
		fps_monitor = Performance.get_monitor(Performance.TIME_FPS),
		process_time_s = Performance.get_monitor(Performance.TIME_PROCESS),
		physics_process_time_s = Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS),
		object_count = Performance.get_monitor(Performance.OBJECT_COUNT),
		node_count = Performance.get_monitor(Performance.OBJECT_NODE_COUNT),
		draw_calls = Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),
		primitives = Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),
		physics_3d_active_objects = Performance.get_monitor(Performance.PHYSICS_3D_ACTIVE_OBJECTS),
		physics_3d_collision_pairs = Performance.get_monitor(Performance.PHYSICS_3D_COLLISION_PAIRS),
		render_frames_drawn = drawn,
		render_interval_draws = interval_draws,
		render_interval_counter_reset = int(draw_reset),
		render_window_drawable = int(window_drawable),
		render_counter_resets = _frametimes_draw_counter_resets,
		render_no_draw_intervals = _frametimes_no_draw_intervals,
		render_undrawable_samples = _frametimes_undrawable_samples,
	}
	if _frame_diagnostics != null:
		var poll_start_usec: int = Time.get_ticks_usec()
		raw_metrics.merge(_frame_diagnostics.sample())
		raw_metrics.observer_poll_usec = Time.get_ticks_usec() - poll_start_usec
	if not _frametime_samples.record_frame(delta, wall_delta_usec, now_usec, raw_metrics):
		push_error("Frame-time measurement failed: " + _frametime_samples.failure)
		_finish_frame_time(1)
		return
	_frametimes_elapsed = float(_frametime_samples.elapsed_wall_usec) / 1000000.0
	if not _frametime_samples.finished:
		return
	_finish_frame_time()


func _finish_frame_time(exit_code: int = OK) -> void:
	if exit_code != OK and not _frametime_samples.finished:
		_frametime_samples.abort("frame collection interrupted by external owner")
	var sim: Node = session.sim
	var report: Dictionary = _frametime_samples.report()
	report.render_progress = _render_progress(report, DisplayServer.get_name())
	if _frame_diagnostics != null:
		_frame_diagnostics.stop()
		report.frame_diagnostics = _frame_diagnostics.metadata()
		if report.render_progress.status not in ["observed", "headless"]:
			report.frame_diagnostics.render_timing_available = false
			report.frame_diagnostics.render_timing_unavailable_reason = \
				"Render progress is %s; recorded viewport timings may be stale." % report.render_progress.status
	else:
		report.frame_diagnostics = {enabled = false}
	var sim_end_s: float = sim.time()
	var sim_end_tick: int = sim.tick
	var sample_metrics: Dictionary = report.raw_metrics
	var sample_times: PackedFloat64Array = sample_metrics.get("sim_time_s", PackedFloat64Array())
	var sample_ticks: PackedFloat64Array = sample_metrics.get("sim_tick", PackedFloat64Array())
	if report.get("format", "") == FrameSamples.STREAM_FORMAT:
		var endpoints: Dictionary = report.get("sample_endpoints", {})
		var first: Dictionary = endpoints.get("first", {})
		var last: Dictionary = endpoints.get("last", {})
		if first.has("sim_time_s") and last.has("sim_time_s"):
			sample_times = PackedFloat64Array([first.sim_time_s, last.sim_time_s])
		if first.has("sim_tick") and last.has("sim_tick"):
			sample_ticks = PackedFloat64Array([first.sim_tick, last.sim_tick])
	var sample_simulation: Dictionary = {
		scope = "first sampled frame end through last sampled frame end; excludes the first sampled interval",
		start_time_s = sample_times[0] if not sample_times.is_empty() else sim_end_s,
		end_time_s = sample_times[sample_times.size() - 1] if not sample_times.is_empty() else sim_end_s,
		start_tick = int(sample_ticks[0]) if not sample_ticks.is_empty() else sim_end_tick,
		end_tick = int(sample_ticks[sample_ticks.size() - 1]) if not sample_ticks.is_empty() else sim_end_tick,
		ticks = int(sample_ticks[sample_ticks.size() - 1] - sample_ticks[0]) if sample_ticks.size() > 1 else 0,
	}
	var run_args: Dictionary = _user_args()
	# The current preference can describe the NEXT world. Read the installed props and
	# collision inventory instead of inferring them from SceneDetail.level().
	var installed_scenery: Node = _field_node.get_node_or_null("Scenery") if is_instance_valid(_field_node) else null
	var scenery_stats: Dictionary = installed_scenery.get_meta("stats", {}) if installed_scenery != null else {}
	var installed_world: Dictionary = session.collision_world()
	var meadow: Node = _field_node.get_node_or_null("RunwayMeadow") if is_instance_valid(_field_node) else null
	var detail_instances := FrameSamples.field_tree_detail_instances(_field_node, field)
	var route_name: String = frametimes_route if not frametimes_route.is_empty() else \
		("scripted-fixed" if _frametimes_scripted_fixed else "live-input")
	# Endpoint evidence is read once after sampling; no new per-tick observer.
	# Pacing alone cannot qualify a fleet whose sessions stopped or lost clock sync.
	var companion_evidence := {enabled = companion_config.enabled, roster = []}
	if companions != null:
		companion_evidence.status = companions.status()
		for agent: Node in companions.agents:
			companion_evidence.roster.append({id = "companion-%d" % agent.slot_id,
				tick = agent.session.sim.tick, time_s = agent.session.sim.time(),
				paused = agent.session.sim.paused, fault = agent.session.sim.fault_reason,
				failure = agent.failure, crashed = not agent.session.crash.is_empty(),
				world_identity = agent.session.collision_world().get("identity", "")})
	report.merge({
		case_id = str(run_args.get("case", route_name)),
		route = route_name,
		preset = "high-experimental" if Atmosphere.HighGraphics.active() else "current-default",
		graphics_profile = Atmosphere.HighGraphics.describe(),
		scene_at_report = {
			scope = "end of collection only; not settings or visibility history",
			landscape_id = landscape_id,
			collision_world_status = "installed" if not installed_world.is_empty() else "absent",
			collision_world_identity = installed_world.get("identity", ""),
			scenery_present = installed_scenery != null,
			installed_scenery_quality = scenery_stats.get("quality", "absent" if installed_scenery == null else "unknown"),
			requested_scene_detail = SceneDetail.level(),
			mesh_lod_threshold_px = get_viewport().mesh_lod_threshold,
			field_tree_detail_instances = detail_instances,
			runway_meadow = {present = meadow != null,
				plants = meadow.get_meta("plants", 0) if meadow != null else 0,
				source_triangles = meadow.get_meta("source_triangles", 0) if meadow != null else 0},
		},
		shadows = Atmosphere.ShadowSettings.describe(),
		backend = RenderingServer.get_current_rendering_method(),
		rendering_driver = RenderingServer.get_current_rendering_driver_name(),
		render_settings = {msaa_3d = get_viewport().msaa_3d, screen_space_aa = get_viewport().screen_space_aa,
			projected_aircraft_geometry = _shadow.get_meta("projected_shadow_geometry", {}) if is_instance_valid(_shadow) else {},
			use_hdr_2d = get_viewport().use_hdr_2d,
			scaling_3d_scale = get_viewport().scaling_3d_scale, scaling_3d_mode = get_viewport().scaling_3d_mode,
			reconstruction = Reconstruction.describe(get_viewport()),
			lake_reflections = LakeReflection.describe(_field_node)},
		camera = {
			fov_deg = _camera.fov,
			autozoom = _rig.auto_zoom,
			near_m = _camera.near,
			far_m = _camera.far,
			mode = _view_name(),
			projection = _camera.projection,
			keep_aspect = _camera.keep_aspect,
			viewport = [get_viewport().get_visible_rect().size.x, get_viewport().get_visible_rect().size.y],
			transform = VisualEvidence.transform(_camera.global_transform),
		},
		physics_us_per_tick = sim.step_usec,
		adapter = RenderingServer.get_video_adapter_name(),
		api = RenderingServer.get_video_adapter_api_version(),
		godot = Engine.get_version_info().string,
		os = OS.get_name(),
		os_version = OS.get_version(),
		architecture = Engine.get_architecture_name(),
		pid = OS.get_process_id(),
		window = "%dx%d" % [get_viewport().get_visible_rect().size.x, get_viewport().get_visible_rect().size.y],
		window_size_at_report = [DisplayServer.window_get_size().x, DisplayServer.window_get_size().y],
		vsync = DisplayServer.window_get_vsync_mode() != DisplayServer.VSYNC_DISABLED,
		# A CLI cap can differ from the shipped default even when VSync is enabled.
		max_fps = Engine.max_fps,
		vsync_mode = DisplayServer.window_get_vsync_mode(),
		display_server = DisplayServer.get_name(),
		screen_index = DisplayServer.window_get_current_screen(),
		screen_refresh_hz = DisplayServer.screen_get_refresh_rate() if DisplayServer.get_name() != "headless" else -1.0,
		aircraft_id = aircraft_id,
		input_enabled = session.input_enabled,
		flight_companions = companion_evidence,
		# Reasons and holds are independent: a menu/focus hold may leave the reason empty.
		# Read once after sampling; this is context, not a history or a resume action.
		session_at_report = {
			scope = "end of collection only; not pause history",
			pause_reason = session.pause_reason,
			holds = session.holds.keys(),
			crashed = not session.crash.is_empty(),
			window_focused = get_window().has_focus(),
		},
		simulation = {
			scope = "first _process clock prime through sample completion; includes warm-up",
			start_time_s = _frametimes_sim_start_s,
			end_time_s = sim_end_s,
			elapsed_time_s = sim_end_s - _frametimes_sim_start_s,
			start_tick = _frametimes_sim_start_tick,
			end_tick = sim_end_tick,
			ticks = sim_end_tick - _frametimes_sim_start_tick,
			physics_ticks_per_second = Engine.physics_ticks_per_second,
			physics_enabled = session.physics_enabled,
			paused = sim.paused,
			fault = sim.fault_reason,
			step_usec_smoothed = sim.step_usec,
		},
		measured_simulation = sample_simulation,
		effective_grass = FrameSamples.effective_grass_state(_field_node),
		code_provenance = VisualEvidence.provenance(),
		note = "Frame intervals use monotonic Time.get_ticks_usec wall time; legacy seconds/fps_mean/frame_ms use that clock. Godot delta is recorded separately under engine_*. The first _process call primes the clock, excluding ready/startup. The scripted-fixed route disables input and advances its visual clock from elapsed wall time. preset=current-default reports current rendering settings; the app has no named performance presets. Software renderers such as llvmpipe are not target-hardware performance numbers.",
	}, true)
	var write_result: Dictionary = FrameSamples.write_json(_frametimes_path, report)
	_frametimes_active = false
	var frame_stats: Dictionary = report.frame_ms
	print("frame times: p50 %.2f ms, p95 %.2f ms, p99 %.2f ms over %d frames (complete=%s) → %s" % [frame_stats.p50, frame_stats.p95, frame_stats.p99, report.frames, str(report.complete), _frametimes_path])
	var final_exit_code := exit_code
	if not write_result.ok:
		push_error("Cannot write frame-time report '%s': %s" % [_frametimes_path, error_string(int(write_result.error))])
		final_exit_code = 1
	frame_time_report_written.emit(final_exit_code)
	if frametimes_auto_quit:
		get_tree().quit(final_exit_code)


## Render-server calls are not presentation timestamps. The first interval begins at
## the priming observation, before the first retained frame (including after warmup).
static func _render_progress(report: Dictionary, display: String) -> Dictionary:
	var result := {status = "insufficient_samples", sample_intervals = maxi(0, int(report.get("frames", 0))),
		frames_drawn_at_start = -1, frames_drawn_first = -1, frames_drawn_last = -1, frames_drawn_delta = -1,
		undrawable_samples = -1, counter_resets = -1, no_draw_intervals = -1,
		scope = "render-server draw calls and main-window drawability; not GPU completion or presentation"}
	if display == "headless":
		result.status = "headless"
		return result
	var first: Dictionary = {}
	var last: Dictionary = {}
	if report.get("format", "") == FrameSamples.STREAM_FORMAT:
		var endpoints: Dictionary = report.get("sample_endpoints", {})
		first = endpoints.get("first", {})
		last = endpoints.get("last", {})
	else:
		var metrics: Dictionary = report.get("raw_metrics", {})
		for key in ["render_frames_drawn", "render_interval_draws", "render_interval_counter_reset", "render_window_drawable", "render_counter_resets", "render_no_draw_intervals", "render_undrawable_samples"]:
			var values: Variant = metrics.get(key, PackedFloat64Array())
			if not values is PackedFloat64Array or values.is_empty():
				return result
			first[key] = values[0]
			last[key] = values[values.size() - 1]
	if result.sample_intervals < 1:
		return result
	for key in ["render_frames_drawn", "render_interval_draws", "render_interval_counter_reset", "render_window_drawable", "render_counter_resets", "render_no_draw_intervals", "render_undrawable_samples"]:
		if not first.has(key) or not last.has(key):
			return result
	result.frames_drawn_first = int(first.render_frames_drawn)
	result.frames_drawn_last = int(last.render_frames_drawn)
	result.frames_drawn_at_start = result.frames_drawn_first - int(first.render_interval_draws)
	result.counter_resets = int(last.render_counter_resets) - int(first.render_counter_resets) \
		+ int(first.render_interval_counter_reset)
	result.no_draw_intervals = int(last.render_no_draw_intervals) - int(first.render_no_draw_intervals) \
		+ (1 if int(first.render_interval_draws) == 0 and int(first.render_interval_counter_reset) == 0 else 0)
	result.undrawable_samples = int(last.render_undrawable_samples) - int(first.render_undrawable_samples) \
		+ (1 if int(first.render_window_drawable) == 0 else 0)
	if result.counter_resets != 0 or result.frames_drawn_last < result.frames_drawn_first \
			or result.frames_drawn_at_start < 0:
		result.status = "counter_reset"
		return result
	result.frames_drawn_delta = result.frames_drawn_last - result.frames_drawn_at_start
	if result.undrawable_samples > 0:
		result.status = "window_not_drawable"
	elif result.undrawable_samples < 0 or result.no_draw_intervals < 0:
		result.status = "counter_reset"
	elif result.frames_drawn_delta == 0:
		result.status = "no_draw"
	elif result.no_draw_intervals > 0 or result.frames_drawn_delta < result.sample_intervals:
		result.status = "partial_draw"
	else:
		result.status = "observed"
	return result


## Actual rendered state, not just the requested CLI flags. Shared with the UI transition fixture.
func capture_evidence() -> Dictionary:
	var args: Dictionary = _user_args()
	var pilot: Vector3 = Frames.ned_to_render([field.pilot.north, field.pilot.east, float(field.pilot.down) - float(field.pilot.eye_height)])
	var position: Vector3 = _last_render_pose.get("pos", Vector3.ZERO)
	var basis: Basis = _last_render_pose.get("basis", Basis.IDENTITY)
	return {
		format = "openrc-visual-evidence v1", lighting = TimeOfDayLighting.context(lighting_config, _lighting),
		world_lighting = {enabled = _field_world_lighting, state = Atmosphere.state.duplicate(true) if _field_world_lighting else {}},
		storm_bank = World.weather_snapshot(_env),
		electrical_storm = _storm_fx.snapshot() if _storm_fx != null else {},
		sky = _sky_context(),
		night_options = night_options.duplicate(true), provenance = VisualEvidence.provenance(),
		case_id = str(args.get("case", "unspecified")), aircraft = aircraft_id,
		field_data = {id = field.id, path = field_path, sha256 = FileAccess.get_sha256(field_path)},
		visual_pose = str(args.get("visual_pose", "")), visual_distance_m = float(args.get("visual_distance", 0.0)),
		visual_elevation_deg = float(args.get("visual_elevation", VisualEvidence.DEFAULT_ELEVATION_DEG)),
		visual_azimuth_deg = float(args.get("visual_azimuth", VisualEvidence.DEFAULT_AZIMUTH_DEG)),
		light = {direction = VisualEvidence.vector(Atmosphere.sun_direction(_lighting)), energy = Atmosphere.light_energy(_lighting), color = str(_lighting.sun_color)},
		route = "synthetic-inspection" if not _visual_pose.is_empty() else ("scripted-circle" if _scripted else "physics-fixed"),
		preset = "current-default", backend = RenderingServer.get_current_rendering_method(),
		pose = VisualEvidence.transform(Transform3D(basis, position)), coordinate_frame = "render: east/up/south; metres",
		distance_to_pilot_m = position.distance_to(pilot), distance_to_camera_m = position.distance_to(_camera.global_position),
		camera = {transform = VisualEvidence.transform(_camera.global_transform), fov_deg = _camera.fov,
			autozoom = _rig.auto_zoom, near_m = _camera.near, far_m = _camera.far, mode = _view_name(),
			projection = _camera.projection, keep_aspect = _camera.keep_aspect,
			viewport = [get_viewport().get_visible_rect().size.x, get_viewport().get_visible_rect().size.y]},
		exposure = _env.tonemap_exposure, tonemapper = _env.tonemap_mode,
		render_settings = {msaa_3d = get_viewport().msaa_3d, screen_space_aa = get_viewport().screen_space_aa,
			use_hdr_2d = get_viewport().use_hdr_2d,
			scaling_3d_scale = get_viewport().scaling_3d_scale, scaling_3d_mode = get_viewport().scaling_3d_mode,
			reconstruction = Reconstruction.describe(get_viewport()),
			lake_reflections = LakeReflection.describe(_field_node)},
		clock_s = ShaderClock.last_clock, simulation_time_s = session.sim.time(), simulation_tick = session.sim.tick,
		capture_settle_frames = _capture_settle_frames,
		state = {paused = session.sim.paused, aircraft_visible = _airplane.root.visible, treeline_visible = not _treeline_hidden, shadow = _shadow_mode,
			engine_shadows = Atmosphere.engine_shadows, physics_state = Array(session.sim.state),
			controls = session.commands, surfaces = session.surfaces(), propeller_angle_rad = _airplane.propeller.rotation.z},
		seed = {kind = "not-used", note = "procedural shaders use fixed analytic noise; no RNG"},
		presentation_identity = session.workshop_presentation_identity.duplicate(true),
		smoke_effects = _smoke_evidence(),
	}


func _smoke_evidence() -> Dictionary:
	if _stock_smoke_profile:
		return {mode = "stock", preset = StockSmoke.preset_id(_airplane.get("customization_bindings", {}), session.aircraft.model.propulsion), disabled = _profile_smoke == null,
			requested = _profile_smoke != null and _profile_smoke_request() > 0.0,
			source_running = _profile_presented_running,
			allocation = _profile_smoke.budget_info() if _profile_smoke != null else {}}
	if _profile_smoke != null:
		return {mode = "profile", profile_identity = session.workshop_presentation_identity.duplicate(true),
			requested = _smoke_requested_for_presentation(), source_running = _profile_presented_running,
			allocation = _profile_smoke.budget_info()}
	if workshop_trial.has("presentation_profile"):
		return {mode = "profile", profile_identity = session.workshop_presentation_identity.duplicate(true),
			requested = false, disabled = true}
	if _smoke != null:
		return {mode = "legacy", active = float(_smoke.levels.pump) > 0.0}
	return {mode = "none"}


## Simulation.stepped observer; a rewind samples (and resets) at once, consecutive ticks once per frame.
func _sample_profile_smoke(tick: int, _time: float, _state: PackedFloat64Array,
		_loads: PackedFloat64Array, _inputs: PackedFloat64Array, _aux: PackedFloat64Array) -> void:
	if _profile_smoke_cadence.on_tick(tick):
		_sample_profile_smoke_at(tick, _time, _state, _aux)


## Accepted source/request changes enter the tapes keyed by the observed tick.
func _sample_profile_smoke_at(tick: int, _time: float, _state: PackedFloat64Array, _aux: PackedFloat64Array) -> void:
	if _profile_smoke == null: return
	if _profile_last_accepted_tick >= 0 and tick < _profile_last_accepted_tick:
		_reset_profile_smoke()
	_profile_last_accepted_tick = tick
	var request := _profile_smoke_request()
	var running: bool = session.propulsion_source_running() and session.crash.is_empty() and session.sim.fault_reason.is_empty()
	if request != _profile_last_request:
		_profile_request_tape.append({tick = tick, level = request})
		_profile_last_request = request
	var level := _profile_source_level()
	var wash := _profile_smoke_wash(session.aircraft.model.propulsion, _state, _aux[0], _time, running)
	if running != _profile_last_running or not is_equal_approx(level, _profile_last_level) or not wash.is_equal_approx(_profile_last_wash):
		_profile_source_tape.append({tick = tick, kind = Propulsion.source_kind(session.aircraft.model.propulsion),
			running = running, level = level, wash_mps = wash})
		_profile_last_running = running
		_profile_last_level = level
		_profile_last_wash = wash
	# Event tapes are bounded even while the renderer is not presenting this world.
	if _profile_request_tape.size() > 256 or _profile_source_tape.size() > 256:
		_reset_profile_smoke()


func _update_profile_smoke(presentation_time_s: float = -1.0) -> void:
	if _profile_smoke == null or session == null: return
	var accepted_tick: int = session.sim.tick
	if _profile_last_accepted_tick >= 0 and accepted_tick < _profile_last_accepted_tick:
		_reset_profile_smoke()
	_profile_last_accepted_tick = accepted_tick
	if session.sim.paused: return
	# Manual captures present accepted endpoints; live flight passes the exact
	# interpolated clock used for the displayed model pose.
	var clock_s: float = session.sim.time() if presentation_time_s < 0.0 else presentation_time_s
	var tick := floori(clock_s * 240.0 + 0.000001)
	# A resumed interpolation fraction can revisit an earlier point inside the
	# same accepted tick. Retain puffs and queued events until it catches up.
	if clock_s < _profile_presented_s: return
	var prop: Dictionary = session.aircraft.model.propulsion
	var transforms := AircraftCustomization.smoke_transforms(_airplane)
	var request_changes: Array = []
	var source_changes: Array = []
	var future_requests: Array = []
	var future_sources: Array = []
	for event: Dictionary in _profile_request_tape:
		if int(event.tick) <= tick: request_changes.append(event)
		else: future_requests.append(event)
	for event: Dictionary in _profile_source_tape:
		if int(event.tick) <= tick: source_changes.append(event)
		else: future_sources.append(event)
	var sample := {kind = Propulsion.source_kind(prop), running = _profile_presented_running,
		level = _profile_presented_level, source_id = str(prop.get("id", "$propulsion")),
		wash_mps = _profile_presented_wash, changes = source_changes}
	if _profile_presented_s < 0.0:
		# A reset/seek primes at this pose; never draw a bridge from a stale origin.
		_profile_smoke.advance(0.0, {tick = tick, presentation_time_s = clock_s, slot_transforms = transforms},
			_render_wind(clock_s), 0.0, {kind = sample.kind, running = false, level = 0.0})
	else:
		_profile_smoke.advance(clock_s - _profile_presented_s,
			{tick = tick, presentation_time_s = clock_s, slot_transforms = transforms,
			camera_distance_m = _camera.global_position.distance_to(_airplane.root.global_position),
			safety_stop = not session.crash.is_empty() or not session.sim.fault_reason.is_empty()},
			_render_wind(clock_s), {level = _profile_presented_request, changes = request_changes},
			{kind = sample.kind, running = sample.running, level = sample.level, changes = source_changes,
				sources = ProfileSmoke.source_map(sample)})
	# Only presented events become the next interval's baseline; accepted future
	# events stay queued until the interpolated aircraft reaches their timestamp.
	for event: Dictionary in request_changes: _profile_presented_request = float(event.level)
	for event: Dictionary in source_changes:
		_profile_presented_running = bool(event.running)
		_profile_presented_level = float(event.level)
		_profile_presented_wash = event.get("wash_mps", _profile_presented_wash)
	_profile_request_tape = future_requests
	_profile_source_tape = future_sources
	_profile_smoke_tick = tick
	_profile_presented_s = clock_s


## The stock tailpipe display follows accepted source state, including fuel exhaustion.
## Custom show profiles keep their independent, user-authored scheduling semantics.
func _profile_smoke_request() -> float:
	if not session.crash.is_empty() or not session.sim.fault_reason.is_empty():
		return 0.0
	if _stock_smoke_profile and not session.propulsion_source_running():
		return 0.0
	return session.radio.smoke_amount() if session.radio.connected else (1.0 if _smoke_key_on else 0.0)


func _supports_show_smoke() -> bool:
	return (_profile_smoke != null and int(_profile_smoke.budget_info().get("show_emitters", 0)) > 0) \
		or (_smoke != null and _smoke.supports_pump())


func _reset_profile_smoke() -> void:
	_profile_smoke_tick = session.sim.tick if session != null else 0
	_profile_last_accepted_tick = session.sim.tick if session != null else -1
	_profile_presented_s = -1.0
	_profile_request_tape.clear()
	_profile_source_tape.clear()
	_profile_last_request = -1.0
	_profile_last_running = false
	_profile_last_level = -1.0
	_profile_presented_level = 0.0
	_profile_last_wash = Vector3.ZERO
	_profile_presented_wash = Vector3.ZERO
	_profile_presented_request = 0.0
	_profile_presented_running = false
	if _profile_smoke != null:
		_profile_smoke.reset()
		_profile_smoke.play()


## Read-only visual observations. Source state remains owned by FlightSession.
func _profile_source_level() -> float:
	if _profile_smoke == null or int(_profile_smoke.get("_profile").get("version", 1)) < 2:
		return 1.0 # historical v1 scheduling semantics
	var prop: Dictionary = session.aircraft.model.propulsion
	var observation := ProfileSmoke.source_observation(prop, session.sim.aux[0], session.sim.inputs[3],
		session.propulsion_source_running())
	return float(observation.level)


func _profile_smoke_wash(prop: Dictionary, accepted_state: PackedFloat64Array,
		accepted_rpm: float, accepted_time_s: float, accepted_running: bool) -> Vector3:
	# Historical profiles did not receive wash. The v2 observation is detached at
	# the accepted tick; rendering never reevaluates the source or scales velocity.
	if _profile_smoke == null or int(_profile_smoke.get("_profile").get("version", 1)) < 2:
		return Vector3.ZERO
	if not prop.has("slipstream") or not accepted_running or accepted_state.size() < RB.SIZE \
			or not is_finite(accepted_rpm) or not is_finite(accepted_time_s):
		return Vector3.ZERO
	var air: Dictionary = _observer_air(accepted_state, accepted_time_s)
	var rho: float = session.air_density(accepted_state)
	var output: PackedFloat64Array = Propulsion.thrust_torque(air.v_air, accepted_rpm, prop, rho)
	var flow: Dictionary = Slipstream.wake(air.v_air, output[0], output[1], prop, rho)
	var axis: PackedFloat64Array = Propulsion.axis(prop)
	var rotation := Frames.quat_to_render(accepted_state.slice(RB.ATT, RB.ATT + 4))
	return rotation * Vector3(-axis[1], axis[2], axis[0]) * clampf(float(flow.w), 0.0, 30.0)
