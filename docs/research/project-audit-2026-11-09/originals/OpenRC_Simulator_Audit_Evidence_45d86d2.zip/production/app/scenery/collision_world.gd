## LU-05: immutable scalar obstacle inventory built once from normalized field/scenery/light inputs.
## Coordinates are world N/E/down metres; no render-space transform reaches the flight solver.
extends RefCounted

const Treeline := preload("res://render/treeline.gd")
const Prefabs := preload("res://scenery/prefabs.gd")
const Models := preload("res://scenery/models.gd")
const ParkedAircraft := preload("res://scenery/parked_aircraft.gd")
const Palette := preload("res://scenery/palette.gd")
const VegetationPlacement := preload("res://scenery/vegetation_placement.gd")
const SupportSurfaces := preload("res://scenery/support_surfaces.gd")
const FlightlineBarrier := preload("res://render/flightline_barrier.gd")
const FenceParts := preload("res://scenery/fence_parts.gd")
const RcTrack := preload("res://physics/ground_vehicle/airfield_track.gd")

const FORMAT := "openrc-collision-world v1"
const CELL_SIZE_M := 32.0
const MAX_BIN_REFERENCES := 250000
const MAX_BUILD_CACHE_BYTES := 8 * 1024 * 1024
const MAX_CACHE_VALUE_DEPTH := 64
const TREE_TRUNK_RADIUS_M := 0.18 # estimated gameplay envelope; visual source is a tree card, not a trunk mesh
const TREE_TRUNK_HEIGHT_FRACTION := 0.34
const SHADE_TREE_TRUNK_RADIUS_FRACTION := 0.05
const SHADE_TREE_TRUNK_HEIGHT_FRACTION := 0.355
const SHADE_TREE_TRUNK_HEIGHT_VARIATION_FRACTION := 0.025
# Lowest indexed leaf-triangle vertex over source height, rounded down so the complete
# source leaves stay covered: Quercus 13.3190126/59.5558777 = 0.223639, Fagus
# 0.1272657/1.0192933 = 0.124857, Quercus 2 22.9070053/71.8539352 = 0.318800.
# Pine leaves start at 0.409726, above the generic trunk-top crown edge.
const LANDSCAPELAB_CROWN_BOTTOM_FRACTIONS := {
	"landscapelab_quercus": 0.22,
	"landscapelab_fagus": 0.12,
	"landscapelab_quercus2": 0.31,
}
# Oak/pine use occupied pixel centres at alpha 0.5. Beech's measured card width is
# 0.2880859375; retain the previous maple width so Extreme's rear 3D trees do not
# lose collision coverage when their permanent proxy follows this card path.
const FIELD_TREE_ALPHA_HALF_WIDTH_FRACTIONS := [0.3701171875, 0.3017578125, 0.1669921875]
const FIELD_TREE_CARD_FRAME_SIZE_M := 1.125001 # source frame size multiplied by Treeline.identity.height in shader
const FIELD_TREE_WIND_LEAN_M := 0.24 # maximum lean in render/tree_wind.gdshaderinc (L15b)
# Oak/pine foliage extents come from the source-material mask. Beech unions the
# new card's lower leaves with the previous box: [.133, 1.003] contains both
# [.136352, .982301] (new card) and [.194877, 1.002877] (previous proxy).
# This is a conservative gameplay envelope shared by every visual preset.
const TREE_CROWN_VERTICAL_HALF_EXTENT_FRACTIONS := [0.366, 0.435, 0.289]
const TREE_CROWN_CENTER_FRACTIONS := [0.612061, 0.568, 0.704346]

const BUILDINGS: Array[String] = ["pavilion", "shed", "barn", "silo", "farmhouse", "church", "village_house"]
const VEHICLES: Array[String] = ["car_sedan", "car_hatch", "car_suv", "car_sport", "tractor"]

# Only the main thread touches this one-entry cache. Retained serialized key and world bytes together stay within
# MAX_BUILD_CACHE_BYTES; temporary keys, build results, decoded copies, and caller-owned worlds are not retained.
static var _build_cache_key := PackedByteArray()
static var _build_cache_world := PackedByteArray()
static var _build_cache_hits := 0
static var _build_cache_misses := 0
static var _build_cache_bypasses := 0

## `rc_track`: the validated RC-TRACK circuit whose solid dressing joins the inventory; {} for none.
static func build(field: Dictionary, scenery: Dictionary, lights: Dictionary = {}, rc_track: Dictionary = {}) -> Dictionary:
	var input_error: String = _input_shape_error(field, scenery, lights)
	if not input_error.is_empty():
		return _failure(input_error)
	if not rc_track.is_empty() and not RcTrack.valid(rc_track):
		return _failure("RC circuit must be validated before collision inventory construction")
	var parked_info: Dictionary = _parked_aircraft_snapshots(scenery)
	if not Thread.is_main_thread():
		return _build_uncached(field, scenery, lights, parked_info, rc_track)
	var key_bytes: PackedByteArray = _make_build_cache_key(field, scenery, lights, parked_info, rc_track)
	if key_bytes.is_empty():
		_build_cache_bypasses += 1
		return _build_uncached(field, scenery, lights, parked_info, rc_track)
	if not _build_cache_key.is_empty() and key_bytes == _build_cache_key:
		var cached_world: Variant = bytes_to_var(_build_cache_world)
		if typeof(cached_world) == TYPE_DICTIONARY:
			_build_cache_hits += 1
			return {ok = true, errors = PackedStringArray(), world = cached_world}
		# A cache payload is produced by this script; fail closed if it cannot be decoded as expected.
		_build_cache_key = PackedByteArray()
		_build_cache_world = PackedByteArray()
	_build_cache_misses += 1
	var result: Dictionary = _build_uncached(field, scenery, lights, parked_info, rc_track)
	if not result.get("ok", false) or typeof(result.get("world")) != TYPE_DICTIONARY:
		return result
	var world: Dictionary = result.world
	# This builder creates only scalar values, arrays, dictionaries, and packed arrays; serialize once and
	# enforce the exact combined retained-byte limit without walking the generated broadphase a second time.
	var world_bytes: PackedByteArray = var_to_bytes(world)
	if key_bytes.size() + world_bytes.size() <= MAX_BUILD_CACHE_BYTES:
		_build_cache_key = key_bytes
		_build_cache_world = world_bytes
	else:
		_build_cache_bypasses += 1
	return result


static func clear_cache() -> void:
	if not Thread.is_main_thread():
		return
	_build_cache_key = PackedByteArray()
	_build_cache_world = PackedByteArray()
	_build_cache_hits = 0
	_build_cache_misses = 0
	_build_cache_bypasses = 0


static func cache_diagnostics() -> Dictionary:
	if not Thread.is_main_thread():
		return {"main_thread": false}
	return {
		"main_thread": Thread.is_main_thread(),
		"hits": _build_cache_hits,
		"misses": _build_cache_misses,
		"bypasses": _build_cache_bypasses,
		"entry_bytes": _build_cache_key.size() + _build_cache_world.size(),
		"budget_bytes": MAX_BUILD_CACHE_BYTES,
	}


static func _build_uncached(field: Dictionary, scenery: Dictionary, lights: Dictionary,
		parked_info: Dictionary, rc_track: Dictionary = {}) -> Dictionary:
	var input_error: String = _input_shape_error(field, scenery, lights)
	if not input_error.is_empty():
		return _failure(input_error)
	var errors := PackedStringArray()
	var proxies: Array[Dictionary] = []
	var support_surfaces := SupportSurfaces.build(scenery)
	_add_field_trees(proxies, field)
	_add_flightline_barrier(proxies, field)
	_add_scenery(proxies, scenery, support_surfaces, parked_info)
	_add_lights(proxies, lights)
	_add_rc_track(proxies, rc_track)
	_assign_damage_profiles(proxies)
	proxies.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return str(a.id) < str(b.id))
	for proxy: Dictionary in proxies:
		if not _proxy_is_valid(proxy):
			errors.append("invalid obstacle proxy '%s'" % str(proxy.get("id", "?")))
	if not errors.is_empty():
		return {ok = false, errors = errors, world = {}}
	var bins: Dictionary = _build_bins(proxies)
	if bins.is_empty() and not proxies.is_empty():
		return _failure("collision broadphase exceeded its bounded bin-reference budget")
	var identity_parts: Array = [FORMAT, CELL_SIZE_M]
	for proxy: Dictionary in proxies:
		identity_parts.append([
			proxy.id, proxy.kind, proxy.part, proxy.shape, proxy.response_class, proxy.damage_id, proxy.damage_profile,
			proxy.north, proxy.east, proxy.down, proxy.radius, proxy.half_length,
			proxy.half_x, proxy.half_down, proxy.half_z, proxy.sin_heading, proxy.cos_heading,
			proxy.bounds_north_min, proxy.bounds_north_max, proxy.bounds_east_min, proxy.bounds_east_max,
			proxy.bounds_down_min, proxy.bounds_down_max,
		])
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(var_to_bytes(identity_parts))
	var world := {
		"format": FORMAT,
		"identity": hash.finish().hex_encode(),
		"cell_size_m": CELL_SIZE_M,
		"proxies": proxies,
		"bins": bins,
	}
	return {ok = true, errors = PackedStringArray(), world = world}


static func _input_shape_error(field: Dictionary, scenery: Dictionary, lights: Dictionary) -> String:
	if typeof(field.get("pilot")) != TYPE_DICTIONARY or typeof(field.get("objects")) != TYPE_ARRAY:
		return "field must be normalized before collision inventory construction"
	if typeof(scenery.get("groups")) != TYPE_ARRAY:
		return "scenery must be normalized before collision inventory construction"
	if not lights.is_empty() and typeof(lights.get("fixtures")) != TYPE_ARRAY:
		return "lights must be normalized before collision inventory construction"
	return ""


static func _parked_aircraft_snapshots(scenery: Dictionary) -> Dictionary:
	var snapshots: Dictionary = {}
	for group_value: Variant in scenery.get("groups", []):
		if typeof(group_value) != TYPE_DICTIONARY:
			continue
		var group: Dictionary = group_value
		if str(group.get("type", "")) != "fleet":
			continue
		var placements: Variant = group.get("placements", [])
		if typeof(placements) != TYPE_ARRAY:
			continue
		for placement_value: Variant in placements:
			if typeof(placement_value) != TYPE_DICTIONARY:
				continue
			var placement: Dictionary = placement_value
			var aircraft_id: String = str(placement.get("aircraft", ""))
			var configuration: String = str(placement.get("configuration", "assembled"))
			var by_configuration: Dictionary = snapshots.get(aircraft_id, {})
			if not by_configuration.has(configuration):
				by_configuration[configuration] = ParkedAircraft.info(aircraft_id, configuration)
				snapshots[aircraft_id] = by_configuration
	return snapshots


static func _make_build_cache_key(field: Dictionary, scenery: Dictionary, lights: Dictionary,
		parked_info: Dictionary, rc_track: Dictionary = {}) -> PackedByteArray:
	var cache_value: Array = [field, scenery, lights, parked_info]
	if not rc_track.is_empty():
		cache_value.append(rc_track) # absent for every world without the circuit, so their keys are unchanged
	var estimate: Array[int] = [0]
	if not _cache_value_is_safe(cache_value, 0, estimate):
		return PackedByteArray()
	var key_bytes: PackedByteArray = var_to_bytes(cache_value)
	return key_bytes if key_bytes.size() <= MAX_BUILD_CACHE_BYTES else PackedByteArray()


static func _cache_value_is_safe(value: Variant, depth: int, estimate: Array[int]) -> bool:
	if depth > MAX_CACHE_VALUE_DEPTH:
		return false # Also bounds recursive container graphs before var_to_bytes sees them.
	var value_type: int = typeof(value)
	if value_type in [TYPE_OBJECT, TYPE_CALLABLE, TYPE_RID, TYPE_SIGNAL]:
		return false
	if value_type == TYPE_ARRAY:
		var array_value: Array = value
		if not _cache_add_estimate(estimate, 16 + array_value.size() * 8):
			return false
		for item: Variant in array_value:
			if not _cache_value_is_safe(item, depth + 1, estimate):
				return false
		return true
	if value_type == TYPE_DICTIONARY:
		var dictionary_value: Dictionary = value
		if not _cache_add_estimate(estimate, 24 + dictionary_value.size() * 16):
			return false
		for key: Variant in dictionary_value:
			if not _cache_value_is_safe(key, depth + 1, estimate) \
					or not _cache_value_is_safe(dictionary_value[key], depth + 1, estimate):
				return false
		return true
	if value_type == TYPE_STRING or value_type == TYPE_STRING_NAME:
		var string_value: String = str(value)
		if string_value.length() > MAX_BUILD_CACHE_BYTES:
			return false
		return _cache_add_estimate(estimate, string_value.to_utf8_buffer().size() + 16)
	if value_type == TYPE_PACKED_BYTE_ARRAY:
		return _cache_add_estimate(estimate, (value as PackedByteArray).size() + 16)
	if value_type in [TYPE_PACKED_INT32_ARRAY, TYPE_PACKED_FLOAT32_ARRAY]:
		return _cache_add_estimate(estimate, (value.size() * 4) + 16)
	if value_type in [TYPE_PACKED_INT64_ARRAY, TYPE_PACKED_FLOAT64_ARRAY]:
		return _cache_add_estimate(estimate, (value.size() * 8) + 16)
	if value_type == TYPE_PACKED_STRING_ARRAY:
		var strings: PackedStringArray = value
		if not _cache_add_estimate(estimate, strings.size() * 8 + 16):
			return false
		for item: String in strings:
			if not _cache_value_is_safe(item, depth + 1, estimate):
				return false
		return true
	if value_type == TYPE_PACKED_VECTOR2_ARRAY:
		return _cache_add_estimate(estimate, value.size() * 8 + 16)
	if value_type == TYPE_PACKED_VECTOR3_ARRAY:
		return _cache_add_estimate(estimate, value.size() * 12 + 16)
	if value_type == TYPE_PACKED_VECTOR4_ARRAY or value_type == TYPE_PACKED_COLOR_ARRAY:
		return _cache_add_estimate(estimate, value.size() * 16 + 16)
	if value_type in [TYPE_NIL, TYPE_BOOL, TYPE_INT, TYPE_FLOAT]:
		return _cache_add_estimate(estimate, 8)
	if value_type in [TYPE_VECTOR2, TYPE_VECTOR2I, TYPE_RECT2, TYPE_RECT2I]:
		return _cache_add_estimate(estimate, 24)
	if value_type in [TYPE_VECTOR3, TYPE_VECTOR3I, TYPE_PLANE]:
		return _cache_add_estimate(estimate, 32)
	return _cache_add_estimate(estimate, 128)


static func _cache_add_estimate(estimate: Array[int], amount: int) -> bool:
	if amount < 0 or estimate[0] > MAX_BUILD_CACHE_BYTES - amount:
		return false
	estimate[0] += amount
	return true


static func nearby(world: Dictionary, north: float, east: float, down: float, radius: float) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if not _world_header_is_valid(world) or not _finite_all([north, east, down, radius]) or radius < 0.0:
		return out
	var indices := _candidate_indices(world, north - radius, north + radius, east - radius, east + radius,
		down - radius, down + radius)
	for index: int in indices:
		var proxy: Dictionary = world.proxies[index]
		if _aabb_sphere_overlap(proxy, north, east, down, radius):
			out.append(proxy.duplicate())
	return out


static func _add_field_trees(proxies: Array[Dictionary], field: Dictionary) -> void:
	var pilot: Dictionary = field.pilot
	var pilot_north := float(pilot.get("north", NAN))
	var pilot_east := float(pilot.get("east", NAN))
	var pilot_down := float(pilot.get("down", 0.0))
	for object_value: Variant in field.get("objects", []):
		if typeof(object_value) != TYPE_DICTIONARY:
			continue
		var object: Dictionary = object_value
		if str(object.get("type", "")) != "treeline":
			continue
		var tree_id := str(object.get("id", "trees"))
		var front_azimuth := Treeline.front_azimuth_deg(field)
		for index: int in object.get("positions", []).size():
			var point: Array = object.positions[index]
			if point.size() != 3:
				continue
			var local_north := float(point[0])
			var local_east := float(point[1])
			var base_down := pilot_down + float(point[2])
			var north := pilot_north + local_north
			var east := pilot_east + local_east
			var tree: Dictionary = Treeline.identity(local_north, local_east)
			var detail_asset := Treeline.detail_asset(local_north, local_east, front_azimuth)
			if not detail_asset.is_empty():
				_add_field_detail_tree_proxies(proxies, "%s:%04d" % [tree_id, index], north, east, base_down,
					float(tree.height), detail_asset, rad_to_deg(float(tree.yaw)), index)
				continue
			_add_field_tree_proxies(proxies, "%s:%04d" % [tree_id, index], north, east,
				base_down, float(tree.height), int(tree.species), float(tree.yaw))


static func _add_scenery(proxies: Array[Dictionary], scenery: Dictionary,
		support_surfaces: Array[Dictionary], parked_info: Dictionary) -> void:
	for group_value: Variant in scenery.get("groups", []):
		if typeof(group_value) != TYPE_DICTIONARY:
			continue
		var group: Dictionary = group_value
		var group_id := str(group.get("id", "group"))
		if str(group.get("type", "")) == "fleet":
			for index: int in group.get("placements", []).size():
				var placement: Dictionary = group.placements[index]
				var aircraft_id := str(placement.get("aircraft", ""))
				_add_parked_aircraft(proxies, group_id, index, aircraft_id, placement, parked_info)
			continue
		if str(group.get("type", "")) in ["hedge", "fence"]:
			_add_line_obstacles(proxies, group)
			continue
		for index: int in group.get("placements", []).size():
			var first_proxy := proxies.size()
			var placement: Dictionary = group.placements[index]
			var prefab := str(placement.get("prefab", group.get("prefab", "")))
			var north := float(placement.get("north", NAN))
			var east := float(placement.get("east", NAN))
			var heading := float(placement.get("heading", 0.0))
			if prefab == "pit_shelter":
				_add_pit_shelter(proxies, "%s:%02d" % [group_id, index], north, east, heading)
			elif prefab == "pavilion":
				_add_pavilion(proxies, "%s:%02d" % [group_id, index], north, east, heading)
			elif prefab == "avanti_cradle":
				_add_avanti_cradle(proxies, "%s:%02d" % [group_id, index], north, east, heading)
			elif prefab == "shade_tree":
				_add_imported_tree_proxies(proxies, "%s:%02d" % [group_id, index], prefab, north, east, heading,
					int(placement.get("seed", 0)))
			elif prefab == "sapling":
				_add_imported_tree_proxies(proxies, "%s:%02d" % [group_id, index], prefab, north, east, heading,
					int(placement.get("seed", 0)))
			elif BUILDINGS.has(prefab):
				var spec: Dictionary = Prefabs.CATALOG[prefab]
				var size: Vector3 = spec.size
				_add_box(proxies, "building:%s:%02d:%s" % [group_id, index, prefab], "building", prefab,
					"hard_terminal", north, east, size.x, size.y, size.z, heading)
			elif VEHICLES.has(prefab):
				var spec: Dictionary = Prefabs.CATALOG[prefab] if Prefabs.CATALOG.has(prefab) else Models.CATALOG[prefab]
				var size: Vector3 = spec.size
				_add_box(proxies, "vehicle:%s:%02d:%s" % [group_id, index, prefab], "vehicle", prefab,
					"hard_terminal", north, east, size.x, size.y, size.z, heading)
			elif prefab in ["flagpole", "club_sign"]:
				_add_sign_and_pole(proxies, group_id, index, prefab, north, east, heading)
			elif prefab in ["picnic_table", "bench"]:
				_add_table_or_bench(proxies, group_id, index, prefab, north, east, heading)
			elif prefab in ["round_bale", "bale_stack"]:
				var size: Vector3 = Prefabs.CATALOG[prefab].size
				if prefab == "round_bale":
					_add_capsule(proxies, "equipment:%s:%02d:bale" % [group_id, index], "equipment", prefab,
						"frangible_impulse", north, east, -size.y * 0.5, size.x * 0.5, 0.0)
				else:
					_add_box(proxies, "equipment:%s:%02d:%s" % [group_id, index, prefab], "equipment", prefab,
						"hard_terminal", north, east, size.x, size.y, size.z, heading)
			elif prefab in ["person_pilot", "person_standing", "person_sitting", "person_working"]:
				var foot_height := SupportSurfaces.height_at(north, east, support_surfaces)
				if prefab == "person_sitting":
					foot_height += SupportSurfaces.SEATED_OFFSET_M
				_add_person_proxy(proxies, group_id, index, prefab, north, east, heading, foot_height)
			elif prefab == "bush":
				_add_bush_proxy(proxies, "%s:%02d" % [group_id, index], north, east, heading,
					int(placement.get("seed", 0)), group_id)
			elif prefab in ["cow", "sheep"]:
				var size: Vector3 = Models.CATALOG[prefab].size
				_add_box(proxies, "animal:%s:%02d:%s" % [group_id, index, prefab], "animal", prefab,
					"light_airframe_impulse", north, east, size.x, size.y, size.z, heading)
			elif prefab == "turbine":
				var size: Vector3 = Prefabs.CATALOG[prefab].size
				_add_capsule(proxies, "landmark:%s:%02d:tower" % [group_id, index], "landmark", "turbine_tower",
					"hard_terminal", north, east, -size.y * 0.5, size.x * 0.16, size.y * 0.5 - size.x * 0.16)
			elif prefab == "pylon":
				_add_pylon(proxies, group_id, index, north, east, heading)

			for proxy_index: int in range(first_proxy, proxies.size()):
				proxies[proxy_index]["damage_id"] = "prop:%s:%02d" % [group_id, int(placement.get("source_index", index))]
				if prefab in ["shade_tree", "sapling"]:
					proxies[proxy_index].damage_id += ":" + str(proxies[proxy_index].part)


## Gameplay material profiles, separate from the aircraft contact response and immutable world identity.
static func _assign_damage_profiles(proxies: Array[Dictionary]) -> void:
	for proxy: Dictionary in proxies:
		if not proxy.has("damage_id"):
			proxy.damage_id = str(proxy.id)
		if proxy.has("damage_profile"):
			continue
		var profile := "none"
		match str(proxy.kind):
			"fence": profile = "wire" if proxy.part == "wire" else "wood"
			"aircraft_support": profile = "wood"
			"equipment": profile = "straw" if proxy.part in ["round_bale", "bale_stack"] else "wood"
			"fixture": profile = "wood" if proxy.part == "club_sign" else "metal"
			"vehicle", "lamp": profile = "metal"
			"building": profile = "masonry"
			"tree_trunk": profile = "wood_mark"
			"tree_foliage": profile = "foliage" if proxy.part == "bush" else "foliage_mark"
		proxy.damage_profile = profile


## Static aircraft scenery uses its authored collision parts, not one filled aircraft-sized box.
## Its base is local y=0; the placement adds the chosen scale and elevation in scalar NED space.
static func _add_parked_aircraft(proxies: Array[Dictionary], group_id: String, index: int,
		aircraft_id: String, placement: Dictionary, parked_info: Dictionary) -> void:
	var configuration := str(placement.get("configuration", "assembled"))
	var by_configuration: Dictionary = parked_info.get(aircraft_id, {})
	var info: Dictionary = by_configuration.get(configuration, {})
	if info.is_empty() or not _positive_xyz(info.get("size")):
		return
	var parts: Variant = info.get("collision_parts", [])
	if typeof(parts) != TYPE_ARRAY:
		return
	var scale_value: Variant = placement.get("scale", 1.0)
	var elevation_value: Variant = placement.get("elevation", 0.0)
	if not _finite_number(scale_value) or float(scale_value) <= 0.0 or not _finite_number(elevation_value):
		return
	var scale := float(scale_value)
	var elevation := float(elevation_value)
	var north := float(placement.get("north", NAN))
	var east := float(placement.get("east", NAN))
	var heading := float(placement.get("heading", NAN))
	if not _finite_all([north, east, heading]):
		return
	var placement_id := "fleet:%s:%02d:%s" % [group_id, index, aircraft_id]
	for part_index: int in parts.size():
		var part_value: Variant = parts[part_index]
		if typeof(part_value) != TYPE_DICTIONARY:
			continue
		var part: Dictionary = part_value
		var center: Variant = part.get("center", [])
		var size: Variant = part.get("size", [])
		if not _finite_xyz(center) or not _positive_xyz(size):
			continue
		_placement_box(proxies, "%s:part:%02d" % [placement_id, part_index], "parked_aircraft",
			"airframe_%02d" % part_index, "light_airframe_impulse", north, east, heading,
			center as Array, size as Array, scale, elevation)
		var proxy: Dictionary = proxies.back()
		proxy["damage_id"] = placement_id
		proxy["damage_profile"] = "none" # a parked aircraft is fixed scenery; only the flying aircraft is affected


static func _finite_xyz(value: Variant) -> bool:
	if typeof(value) != TYPE_ARRAY or (value as Array).size() != 3:
		return false
	for component: Variant in value:
		if not _finite_number(component):
			return false
	return true


static func _positive_xyz(value: Variant) -> bool:
	if not _finite_xyz(value):
		return false
	for component: Variant in value:
		if float(component) <= 0.0:
			return false
	return true


static func _finite_number(value: Variant) -> bool:
	return (typeof(value) == TYPE_INT or typeof(value) == TYPE_FLOAT) and is_finite(float(value))


static func _add_flightline_barrier(proxies: Array[Dictionary], field: Dictionary) -> void:
	for cue: Dictionary in field.get("flight_cues", []):
		if str(cue.get("type", "")) != "flightline_barrier":
			continue
		var seen := {}
		for part: Dictionary in FlightlineBarrier.parts(cue):
			if seen.has(part.id):
				continue
			seen[part.id] = true
			var size: Vector3 = part.size
			var base: Vector3 = part.base
			if part.profile == "metal":
				size.y = float(cue.height)
			_add_box_at_down(proxies, str(part.id), "fence", "barrier", "hard_terminal",
				float(cue.north) - base.z, float(cue.east) + base.x, -(base.y + size.y * 0.5),
				size.x, size.y, size.z, 0.0)
			proxies.back()["damage_profile"] = str(part.profile)


## RC-TRACK: the circuit's walls, tyre stacks, signs, timing posts, tape and cabinet. Its raised dirt is
## ground, not an obstacle: the flight session tests the hull against that exact surface itself.
static func _add_rc_track(proxies: Array[Dictionary], track: Dictionary) -> void:
	for item: Dictionary in RcTrack.dressing(track):
		_add_box_at_down(proxies, str(item.id), "rc_track", str(item.part), str(item.response),
			float(item.north), float(item.east), -(float(item.up) + float(item.height) * 0.5),
			float(item.width), float(item.height), float(item.length), float(item.heading_deg))
		proxies.back()["damage_profile"] = str(item.damage_profile)


static func _add_field_tree_proxies(proxies: Array[Dictionary], id: String, north: float, east: float,
		base_down: float, height: float, species: int, yaw: float) -> void:
	var trunk_half_length := maxf(0.0, (height * TREE_TRUNK_HEIGHT_FRACTION - 2.0 * TREE_TRUNK_RADIUS_M) * 0.5)
	_add_capsule(proxies, "tree:%s:trunk" % id, "tree_trunk", "trunk", "hard_terminal",
		north, east, base_down - height * TREE_TRUNK_HEIGHT_FRACTION * 0.5,
		TREE_TRUNK_RADIUS_M, trunk_half_length)
	var species_index := clampi(species, 0, FIELD_TREE_ALPHA_HALF_WIDTH_FRACTIONS.size() - 1)
	var horizontal_half_extent := height * FIELD_TREE_CARD_FRAME_SIZE_M \
		* float(FIELD_TREE_ALPHA_HALF_WIDTH_FRACTIONS[species_index]) + FIELD_TREE_WIND_LEAN_M
	var vertical_half_extent := height * float(TREE_CROWN_VERTICAL_HALF_EXTENT_FRACTIONS[species_index])
	# The box bounds every occupied atlas row, including the low broadleaf crowns.
	# It deliberately encloses the gaps between the crossed cards; wind is a further radial .24 m allowance.
	_add_box_at_down(proxies, "tree:%s:crown" % id, "tree_foliage", "crown", "soft_foliage_impulse",
		north, east, base_down - height * float(TREE_CROWN_CENTER_FRACTIONS[species_index]),
		horizontal_half_extent * 2.0, vertical_half_extent * 2.0, horizontal_half_extent * 2.0,
		rad_to_deg(-yaw))


## L8a-R1: a 3D field tree uses the club trees' imported envelope at its hashed height and heading.
static func _add_field_detail_tree_proxies(proxies: Array[Dictionary], id: String, north: float, east: float,
		base_down: float, height: float, asset_id: String, heading: float, seed: int) -> void:
	var vegetation: Dictionary = VegetationPlacement.asset_spec(asset_id, height)
	if vegetation.is_empty():
		return
	var wind_margin := float(vegetation.wind_margin)
	var trunk_height := height * (SHADE_TREE_TRUNK_HEIGHT_FRACTION
		+ SHADE_TREE_TRUNK_HEIGHT_VARIATION_FRACTION * Palette.hash01(seed, 2))
	var trunk_radius := minf(float(vegetation.width), float(vegetation.depth)) \
		* SHADE_TREE_TRUNK_RADIUS_FRACTION + wind_margin
	_add_capsule(proxies, "tree:%s:trunk" % id, "tree_trunk", "trunk", "hard_terminal",
		north, east, base_down - trunk_height * 0.5, trunk_radius, maxf(0.0, trunk_height * 0.5 - trunk_radius))
	var crown_bottom_height := minf(trunk_height,
		height * float(LANDSCAPELAB_CROWN_BOTTOM_FRACTIONS.get(asset_id, 1.0)))
	var crown_center := _placement_point(north, east, heading,
		float(vegetation.crown_offset_x), float(vegetation.crown_offset_z))
	_add_box_at_down(proxies, "tree:%s:crown" % id, "tree_foliage", "crown", "soft_foliage_impulse",
		crown_center[0], crown_center[1], base_down - (crown_bottom_height + height) * 0.5,
		float(vegetation.width) + 2.0 * wind_margin, maxf(0.001, height - crown_bottom_height),
		float(vegetation.depth) + 2.0 * wind_margin, heading)


static func _add_imported_tree_proxies(proxies: Array[Dictionary], id: String, prefab: String,
		north: float, east: float, heading: float, seed: int) -> void:
	# Use the same canonical imported asset and uniform target height as the rendered plant.
	var vegetation: Dictionary = VegetationPlacement.spec(prefab, seed)
	if vegetation.is_empty():
		return
	var height := float(vegetation.height)
	var wind_margin := float(vegetation.wind_margin)
	var trunk_height := height * (SHADE_TREE_TRUNK_HEIGHT_FRACTION
		+ SHADE_TREE_TRUNK_HEIGHT_VARIATION_FRACTION * Palette.hash01(seed, 2))
	var trunk_radius := minf(float(vegetation.width), float(vegetation.depth)) \
		* SHADE_TREE_TRUNK_RADIUS_FRACTION + wind_margin
	var trunk_half := maxf(0.0, trunk_height * 0.5 - trunk_radius)
	var id_prefab := "shade-tree" if prefab == "shade_tree" else prefab
	_add_capsule(proxies, "tree:%s:%s:trunk" % [id_prefab, id], "tree_trunk", "trunk", "hard_terminal",
		north, east, -trunk_height * 0.5, trunk_radius, trunk_half)
	var crown_bottom_height := trunk_height
	var crown_bottom_fraction := float(LANDSCAPELAB_CROWN_BOTTOM_FRACTIONS.get(str(vegetation.get("asset_id", "")), 1.0))
	crown_bottom_height = minf(crown_bottom_height, height * crown_bottom_fraction)
	var crown_height := maxf(0.001, height - crown_bottom_height)
	var crown_center := _placement_point(north, east, heading,
		float(vegetation.get("crown_offset_x", 0.0)), float(vegetation.get("crown_offset_z", 0.0)))
	_add_box_at_down(proxies, "tree:%s:%s:crown" % [id_prefab, id], "tree_foliage", "crown",
		"soft_foliage_impulse", crown_center[0], crown_center[1], -(crown_bottom_height + height) * 0.5,
		float(vegetation.width) + 2.0 * wind_margin, crown_height,
		float(vegetation.depth) + 2.0 * wind_margin, heading)


static func _add_bush_proxy(proxies: Array[Dictionary], id: String, north: float, east: float,
		heading: float, seed: int, group_id: String) -> void:
	var vegetation: Dictionary = VegetationPlacement.spec("bush", seed, group_id)
	if vegetation.is_empty():
		return
	var wind_margin := float(vegetation.wind_margin)
	var height := float(vegetation.height)
	_add_box_at_down(proxies, "vegetation:%s:bush" % id, "tree_foliage", "bush",
		"soft_foliage_impulse", north, east, -height * 0.5,
		float(vegetation.width) + 2.0 * wind_margin, height,
		float(vegetation.depth) + 2.0 * wind_margin, heading)


static func _add_line_obstacles(proxies: Array[Dictionary], group: Dictionary) -> void:
	var group_id := str(group.get("id", "line"))
	var points: Array = group.get("points", [])
	if points.size() < 2:
		return
	var group_type := str(group.get("type", ""))
	var height := float(group.get("height", 0.0))
	if group_type == "hedge":
		var width := float(group.get("width", 1.0))
		for index: int in range(points.size() - 1):
			_add_line_box(proxies, "hedge:%s:%02d" % [group_id, index], "tree_foliage", "hedge",
				"soft_foliage_impulse", points[index], points[index + 1], width, height, -height * 0.5)
		return
	var points_xz := PackedVector2Array()
	for point: Vector2 in points:
		points_xz.append(Vector2(point.y, -point.x))
	for piece: Dictionary in FenceParts.build(points_xz, str(group.get("style", "wire")), int(group.get("seed", 0))):
		var id := "fence:%s:%s" % [group_id, piece.id]
		var a: Vector3 = piece.a
		var b: Vector3 = piece.b
		var center := (a + b) * 0.5
		if piece.part == "post":
			_add_box_at_down(proxies, id, "fence", "post", "hard_terminal", -center.z, center.x, -center.y,
				float(piece.width) + absf(b.x - a.x), absf(b.y - a.y), float(piece.width), 0.0)
		else:
			_add_line_box(proxies, id, "fence", str(piece.part), "hard_terminal",
				Vector2(-a.z, a.x), Vector2(-b.z, b.x), float(piece.width), float(piece.width), -center.y)


static func _add_line_box(proxies: Array[Dictionary], id: String, kind: String, part: String,
		response: String, a: Variant, b: Variant, width: float, height: float, center_down: float) -> void:
	var start := Vector2(a.x, a.y) if a is Vector2 else Vector2(float(a[0]), float(a[1]))
	var finish := Vector2(b.x, b.y) if b is Vector2 else Vector2(float(b[0]), float(b[1]))
	var delta := finish - start
	var length := delta.length()
	if not is_finite(length) or length <= 1.0e-9:
		return
	var center_north := (start.x + finish.x) * 0.5
	var center_east := (start.y + finish.y) * 0.5
	var heading := rad_to_deg(atan2(delta.y, delta.x))
	_add_box_at_down(proxies, id, kind, part, response, center_north, center_east, center_down,
		width, height, length, heading)


static func _add_sign_and_pole(proxies: Array[Dictionary], group_id: String, index: int, prefab: String,
		north: float, east: float, heading: float) -> void:
	if prefab == "flagpole":
		_add_capsule(proxies, "fixture:%s:%02d:flagpole" % [group_id, index], "fixture", "flagpole",
			"hard_terminal", north, east, -4.0, 0.06, 3.94)
		return
	_add_box(proxies, "fixture:%s:%02d:sign" % [group_id, index], "fixture", "club_sign",
		"hard_terminal", north, east, 2.5, 2.2, 0.14, heading)


static func _add_table_or_bench(proxies: Array[Dictionary], group_id: String, index: int, prefab: String,
		north: float, east: float, heading: float) -> void:
	if prefab == "picnic_table":
		_add_box_at_down(proxies, "equipment:%s:%02d:tabletop" % [group_id, index], "equipment", "tabletop",
			"hard_terminal", north, east, -0.71, 1.8, 0.05, 0.75, heading)
		for side: int in 2:
			var local_z := -0.6 if side == 0 else 0.6
			var seat := _placement_point(north, east, heading, 0.0, local_z)
			_add_box_at_down(proxies, "equipment:%s:%02d:seat:%d" % [group_id, index, side], "equipment", "seat",
				"hard_terminal", seat[0], seat[1], -0.42, 1.8, 0.05, 0.25, heading)
		return
	_add_box_at_down(proxies, "equipment:%s:%02d:bench_seat" % [group_id, index], "equipment", "bench_seat",
		"hard_terminal", north, east, -0.43, 1.8, 0.05, 0.42, heading)
	var back := _placement_point(north, east, heading, 0.0, 0.25)
	_add_box_at_down(proxies, "equipment:%s:%02d:bench_back" % [group_id, index], "equipment", "bench_back",
		"hard_terminal", back[0], back[1], -0.675, 1.8, 0.35, 0.05, heading)


static func _add_person_proxy(proxies: Array[Dictionary], group_id: String, index: int, prefab: String,
		north: float, east: float, _heading: float, foot_height_m: float = 0.0) -> void:
	var size: Vector3 = Prefabs.CATALOG[prefab].size
	var radius := maxf(size.x, size.z) * 0.5
	_add_capsule(proxies, "person:%s:%02d" % [group_id, index], "person", prefab, "soft_foliage_impulse",
		north, east, -(maxf(0.0, foot_height_m) + size.y * 0.5), radius,
		maxf(0.0, size.y * 0.5 - radius))


static func _add_pylon(proxies: Array[Dictionary], group_id: String, index: int, north: float, east: float,
		heading: float) -> void:
	# Match the downloaded 30 m tower while leaving its lattice open. Its four legs taper from about ±3 m X / ±4 m Z
	# at the foot to a narrow mast. Vertical capsules in three overlapping bands conservatively follow that taper without
	# turning the whole tower into a solid box. All coordinates remain scalar N/E/down for the float64 collision kernel.
	var leg_sections: Array[Dictionary] = [
		{local_x = 2.6, local_z = 3.2, up = 5.0, radius = 1.5, half_length = 5.0},
		{local_x = 1.1, local_z = 1.7, up = 14.5, radius = 1.0, half_length = 5.0},
		{local_x = 0.6, local_z = 0.65, up = 24.5, radius = 0.75, half_length = 5.5},
	]
	for corner: int in 4:
		var sign_x := -1.0 if corner in [0, 3] else 1.0
		var sign_z := -1.0 if corner < 2 else 1.0
		for section: int in leg_sections.size():
			var geometry: Dictionary = leg_sections[section]
			var at := _placement_point(north, east, heading,
				sign_x * float(geometry.local_x), sign_z * float(geometry.local_z))
			var suffix := "" if section == 0 else ":section:%d" % section
			_add_capsule(proxies, "landmark:%s:%02d:pylon_leg:%d%s" % [group_id, index, corner, suffix],
				"landmark", "pylon_leg", "hard_terminal", at[0], at[1], -float(geometry.up),
				float(geometry.radius), float(geometry.half_length))
	# The source arms are horizontal in the tower's local X axis. In the N/E collision frame that axis is also the
	# _placement_point X axis, so use the placement heading directly (not heading + 90 degrees).
	var arm_centers_up: Array[float] = [17.5, 22.9, 28.4]
	var arm_half_widths: Array[float] = [4.4, 4.05, 3.85]
	var arm_half_heights: Array[float] = [0.75, 0.8, 0.75]
	var arm_half_depths: Array[float] = [1.7, 1.05, 0.65]
	for arm: int in arm_centers_up.size():
		_add_box_at_down(proxies, "landmark:%s:%02d:pylon_arm:%d" % [group_id, index, arm], "landmark", "pylon_arm",
			"hard_terminal", north, east, -arm_centers_up[arm], 2.0 * arm_half_widths[arm],
			2.0 * arm_half_heights[arm], 2.0 * arm_half_depths[arm], heading)


static func _add_pit_shelter(proxies: Array[Dictionary], id: String, north: float, east: float, heading: float) -> void:
	# The shelter is an open pole structure: 9 posts on each long side and one roof slab.
	# There is deliberately no enclosing solid box and no floor collider.
	var length := 28.0
	var depth := 5.0
	var post_h := 3.35
	for row: int in 2:
		var local_z := (-1.0 if row == 0 else 1.0) * (depth * 0.5 - 0.1)
		for post_index: int in 9:
			var local_x := -length * 0.5 + float(post_index) * length / 8.0
			var at := _placement_point(north, east, heading, local_x, local_z)
			_add_box(proxies, "building:%s:post:%d:%d" % [id, row, post_index], "building", "shelter_post",
				"hard_terminal", at[0], at[1], 0.16, post_h, 0.16, heading)
	var roof := _placement_point(north, east, heading, 0.0, 0.0)
	_add_box_at_down(proxies, "building:%s:roof" % id, "building", "shelter_roof", "hard_terminal",
		roof[0], roof[1], -3.22, 29.0, 0.14, 6.6, heading)


static func _add_pavilion(proxies: Array[Dictionary], id: String, north: float, east: float, heading: float) -> void:
	# Match the open front veranda in Prefabs._pavilion: slab, main shell, posts, rails,
	# built-in bench and thin roof bounds. The two center step bays stay open.
	_add_local_box(proxies, "building:%s:pavilion:slab" % id, "building", "pavilion_slab", "hard_terminal",
		north, east, heading, 0.0, 0.075, -1.3, 10.0, 0.15, 9.6)
	_add_local_box(proxies, "building:%s:pavilion:main" % id, "building", "pavilion_main", "hard_terminal",
		north, east, heading, 0.0, 1.5, 0.0, 9.0, 2.7, 6.0)
	# The prefab's hip roof spans x ±5, z ±3.5 and y 2.85–4.65. This AABB
	# conservatively covers the pitched surfaces and the volume below their slopes.
	_add_local_box(proxies, "building:%s:pavilion:main_roof" % id, "building", "pavilion_main_roof", "hard_terminal",
		north, east, heading, 0.0, 3.75, 0.0, 10.0, 1.8, 7.0)
	for post_index: int in 4:
		var local_x: float = [-4.2, -1.4, 1.4, 4.2][post_index]
		_add_local_box(proxies, "building:%s:pavilion:porch_post:%02d" % [id, post_index], "building", "pavilion_porch_post",
			"hard_terminal", north, east, heading, local_x, 1.375, -5.85, 0.14, 2.45, 0.14)
	# The fascia reaches y=2.48; include it in the conservative thin porch-roof AABB.
	_add_local_box(proxies, "building:%s:pavilion:porch_roof" % id, "building", "pavilion_porch_roof", "hard_terminal",
		north, east, heading, 0.0, 2.715, -4.6, 9.4, 0.47, 3.2)
	# The prefab's built-in bench is a seat, two feet and a narrow sloped back; this
	# small AABB contains that measured envelope without extending into the step bay.
	_add_local_box(proxies, "building:%s:pavilion:bench" % id, "building", "pavilion_bench", "hard_terminal",
		north, east, heading, -2.8, 0.575, -3.455, 1.8, 0.85, 0.49)
	for segment_index: int in 2:
		var segment: Array = [[-4.2, -1.4], [1.4, 4.2]][segment_index]
		var rail_start := _placement_point(north, east, heading, float(segment[0]), -5.85)
		var rail_end := _placement_point(north, east, heading, float(segment[1]), -5.85)
		_add_line_box(proxies, "building:%s:pavilion:porch_rail:%d" % [id, segment_index], "building", "pavilion_porch_rail",
			"hard_terminal", rail_start, rail_end, 0.06, 0.06, -0.95)


static func _add_local_box(proxies: Array[Dictionary], id: String, kind: String, part: String, response: String,
		north: float, east: float, heading: float, local_x: float, center_up: float, local_z: float,
		width: float, height: float, length: float) -> void:
	var center: PackedFloat64Array = _placement_point(north, east, heading, local_x, local_z)
	_add_box_at_down(proxies, id, kind, part, response, center[0], center[1], -center_up,
		width, height, length, heading)


static func _placement_box(proxies: Array[Dictionary], id: String, kind: String, part: String, response: String,
		north: float, east: float, heading: float, local_center: Array, local_size: Array,
		scale: float, elevation: float) -> void:
	var center: PackedFloat64Array = _placement_point(north, east, heading,
		float(local_center[0]) * scale, float(local_center[2]) * scale)
	_add_box_at_down(proxies, id, kind, part, response, center[0], center[1],
		-(elevation + float(local_center[1]) * scale),
		float(local_size[0]) * scale, float(local_size[1]) * scale, float(local_size[2]) * scale, heading)


static func _add_avanti_cradle(proxies: Array[Dictionary], id: String, north: float, east: float,
		heading: float) -> void:
	# Two padded crossbars and their four low trestle feet support the parked gear-up Vantage Jet.
	for row: int in 2:
		var local_z := -0.62 if row == 0 else 0.62
		for side: int in 2:
			var local_x := -0.20 if side == 0 else 0.20
			var foot := _placement_point(north, east, heading, local_x, local_z)
			_add_box_at_down(proxies, "support:%s:leg:%d:%d" % [id, row, side], "aircraft_support", "cradle_leg",
				"hard_terminal", foot[0], foot[1], -0.20, 0.055, 0.40, 0.055, heading)
		var crossbar := _placement_point(north, east, heading, 0.0, local_z)
		_add_box_at_down(proxies, "support:%s:pad:%d" % [id, row], "aircraft_support", "cradle_pad",
			"hard_terminal", crossbar[0], crossbar[1], -0.40, 0.70, 0.07, 0.34, heading)


static func _add_lights(proxies: Array[Dictionary], lights: Dictionary) -> void:
	var installations: Variant = lights.get("installations", [])
	var has_installations := installations is Array and not (installations as Array).is_empty()
	if has_installations:
		for installation_value: Variant in installations:
			if typeof(installation_value) != TYPE_DICTIONARY:
				continue
			var installation: Dictionary = installation_value
			var installation_id := str(installation.get("id", "fixture"))
			var kind := str(installation.get("type", ""))
			var north := float(installation.get("north", NAN))
			var east := float(installation.get("east", NAN))
			var height := float(installation.get("height", 0.0))
			if kind in ["mast", "low_light_mount"]:
				var radius := float(installation.get("collision_radius", 0.07))
				_add_capsule(proxies, "lamp:%s:pole" % installation_id, "lamp", "flood_pole", "frangible_impulse",
					north, east, -height * 0.5, radius, maxf(0.0, height * 0.5 - radius))
			elif kind == "campfire_base":
				var width := float(installation.get("width", 1.0))
				var depth := float(installation.get("depth", 1.0))
				_add_box(proxies, "fixture:%s:base" % installation_id, "fixture", "campfire_base", "frangible_impulse",
					north, east, width, height, depth, float(installation.get("heading", 0.0)))
				proxies.back()["damage_id"] = "installation:%s" % installation_id
				proxies.back()["damage_profile"] = "wood"
	# Historical normalized inputs without an installation table retain their per-flood poles.
	for fixture_value: Variant in lights.get("fixtures", []):
		if typeof(fixture_value) != TYPE_DICTIONARY:
			continue
		var fixture: Dictionary = fixture_value
		var fixture_id := str(fixture.get("id", "lamp"))
		var height := float(fixture.get("height", 0.0))
		if str(fixture.get("type", "")) == "flood" and not has_installations:
			_add_capsule(proxies, "lamp:%s:pole" % fixture_id, "lamp", "flood_pole", "frangible_impulse",
				float(fixture.get("north", NAN)), float(fixture.get("east", NAN)), -height * 0.5,
				0.07, maxf(0.0, height * 0.5 - 0.07))
		elif str(fixture.get("type", "")) == "stake_row":
			for index: int in fixture.get("points", []).size():
				var point: Array = fixture.points[index]
				if point.size() != 2:
					continue
				_add_capsule(proxies, "lamp:%s:%02d" % [fixture_id, index], "lamp", "stake", "frangible_impulse",
					float(point[0]), float(point[1]), -height * 0.5, 0.035, maxf(0.0, height * 0.5 - 0.035))


static func _placement_point(center_north: float, center_east: float, heading_deg: float, local_x: float, local_z: float) -> PackedFloat64Array:
	var heading := deg_to_rad(heading_deg)
	var sin_heading := sin(heading)
	var cos_heading := cos(heading)
	return PackedFloat64Array([
		center_north - sin_heading * local_x - cos_heading * local_z,
		center_east + cos_heading * local_x - sin_heading * local_z,
	])


static func _add_box(proxies: Array[Dictionary], id: String, kind: String, part: String, response: String,
		north: float, east: float, width: float, height: float, length: float, heading_deg: float) -> void:
	_add_box_at_down(proxies, id, kind, part, response, north, east, -height * 0.5, width, height, length, heading_deg)


static func _add_box_at_down(proxies: Array[Dictionary], id: String, kind: String, part: String, response: String,
		north: float, east: float, down: float, width: float, height: float, length: float, heading_deg: float) -> void:
	var half_x := width * 0.5
	var half_down := height * 0.5
	var half_z := length * 0.5
	var heading := deg_to_rad(heading_deg)
	var sin_heading := sin(heading)
	var cos_heading := cos(heading)
	var north_extent := absf(sin_heading) * half_x + absf(cos_heading) * half_z
	var east_extent := absf(cos_heading) * half_x + absf(sin_heading) * half_z
	proxies.append({
		"id": id, "kind": kind, "part": part, "shape": "box", "response_class": response,
		"north": north, "east": east, "down": down, "radius": 0.0, "half_length": 0.0,
		"half_x": half_x, "half_down": half_down, "half_z": half_z,
		"sin_heading": sin_heading, "cos_heading": cos_heading,
		"bounds_north_min": north - north_extent, "bounds_north_max": north + north_extent,
		"bounds_east_min": east - east_extent, "bounds_east_max": east + east_extent,
		"bounds_down_min": down - half_down, "bounds_down_max": down + half_down,
	})


static func _add_capsule(proxies: Array[Dictionary], id: String, kind: String, part: String, response: String,
		north: float, east: float, down: float, radius: float, half_length: float) -> void:
	proxies.append({
		"id": id, "kind": kind, "part": part, "shape": "capsule", "response_class": response,
		"north": north, "east": east, "down": down, "radius": radius, "half_length": half_length,
		"half_x": 0.0, "half_down": 0.0, "half_z": 0.0, "sin_heading": 0.0, "cos_heading": 1.0,
		"bounds_north_min": north - radius, "bounds_north_max": north + radius,
		"bounds_east_min": east - radius, "bounds_east_max": east + radius,
		"bounds_down_min": down - half_length - radius, "bounds_down_max": down + half_length + radius,
	})


static func _build_bins(proxies: Array[Dictionary]) -> Dictionary:
	var bins: Dictionary = {}
	var references := 0
	for index: int in proxies.size():
		var proxy: Dictionary = proxies[index]
		var min_n := floori(float(proxy.bounds_north_min) / CELL_SIZE_M)
		var max_n := floori(float(proxy.bounds_north_max) / CELL_SIZE_M)
		var min_e := floori(float(proxy.bounds_east_min) / CELL_SIZE_M)
		var max_e := floori(float(proxy.bounds_east_max) / CELL_SIZE_M)
		var min_d := floori(float(proxy.bounds_down_min) / CELL_SIZE_M)
		var max_d := floori(float(proxy.bounds_down_max) / CELL_SIZE_M)
		var item_references := (max_n - min_n + 1) * (max_e - min_e + 1) * (max_d - min_d + 1)
		if item_references <= 0 or item_references > MAX_BIN_REFERENCES or references + item_references > MAX_BIN_REFERENCES:
			return {}
		references += item_references
		for n_cell: int in range(min_n, max_n + 1):
			for e_cell: int in range(min_e, max_e + 1):
				for d_cell: int in range(min_d, max_d + 1):
					var key := _cell_key(n_cell, e_cell, d_cell)
					if not bins.has(key):
						bins[key] = PackedInt64Array()
					bins[key].append(index)
	return bins


static func _candidate_indices(world: Dictionary, north_min: float, north_max: float, east_min: float,
		east_max: float, down_min: float, down_max: float) -> Array[int]:
	var candidates: Dictionary = {}
	var result: Array[int] = []
	var min_n := floori(north_min / CELL_SIZE_M)
	var max_n := floori(north_max / CELL_SIZE_M)
	var min_e := floori(east_min / CELL_SIZE_M)
	var max_e := floori(east_max / CELL_SIZE_M)
	var min_d := floori(down_min / CELL_SIZE_M)
	var max_d := floori(down_max / CELL_SIZE_M)
	var cells: int = (max_n - min_n + 1) * (max_e - min_e + 1) * (max_d - min_d + 1)
	if cells <= 0 or cells > 4096:
		for index: int in world.proxies.size():
			result.append(index)
		return result
	for n_cell: int in range(min_n, max_n + 1):
		for e_cell: int in range(min_e, max_e + 1):
			for d_cell: int in range(min_d, max_d + 1):
				var key := _cell_key(n_cell, e_cell, d_cell)
				if not world.bins.has(key):
					continue
				for index: int in world.bins[key]:
					candidates[index] = true
	for key: Variant in candidates.keys():
		result.append(int(key))
	result.sort()
	return result


static func _cell_key(north_cell: int, east_cell: int, down_cell: int) -> String:
	return "%d,%d,%d" % [north_cell, east_cell, down_cell]


static func _aabb_sphere_overlap(proxy: Dictionary, north: float, east: float, down: float, radius: float) -> bool:
	var dn := maxf(float(proxy.bounds_north_min) - north, maxf(0.0, north - float(proxy.bounds_north_max)))
	var de := maxf(float(proxy.bounds_east_min) - east, maxf(0.0, east - float(proxy.bounds_east_max)))
	var dd := maxf(float(proxy.bounds_down_min) - down, maxf(0.0, down - float(proxy.bounds_down_max)))
	return dn * dn + de * de + dd * dd <= radius * radius


static func _proxy_is_valid(proxy: Dictionary) -> bool:
	for key: String in ["id", "kind", "part", "response_class", "shape"]:
		if typeof(proxy.get(key)) != TYPE_STRING or str(proxy[key]).is_empty():
			return false
	if proxy.shape not in ["box", "capsule"]:
		return false
	for key: String in ["north", "east", "down", "radius", "half_length", "half_x", "half_down", "half_z",
			"sin_heading", "cos_heading", "bounds_north_min", "bounds_north_max", "bounds_east_min",
			"bounds_east_max", "bounds_down_min", "bounds_down_max"]:
		if typeof(proxy.get(key)) != TYPE_FLOAT and typeof(proxy.get(key)) != TYPE_INT:
			return false
		if not is_finite(float(proxy[key])):
			return false
	if proxy.shape == "capsule":
		return float(proxy.radius) > 0.0 and float(proxy.half_length) >= 0.0
	return float(proxy.half_x) > 0.0 and float(proxy.half_down) > 0.0 and float(proxy.half_z) > 0.0


static func _world_header_is_valid(world: Dictionary) -> bool:
	return str(world.get("format", "")) == FORMAT and typeof(world.get("identity")) == TYPE_STRING \
		and typeof(world.get("proxies")) == TYPE_ARRAY and typeof(world.get("bins")) == TYPE_DICTIONARY \
		and float(world.get("cell_size_m", 0.0)) == CELL_SIZE_M


static func _finite_all(values: Array) -> bool:
	for value: Variant in values:
		if (typeof(value) != TYPE_FLOAT and typeof(value) != TYPE_INT) or not is_finite(float(value)):
			return false
	return true


static func _failure(message: String) -> Dictionary:
	return {ok = false, errors = PackedStringArray([message]), world = {}}
