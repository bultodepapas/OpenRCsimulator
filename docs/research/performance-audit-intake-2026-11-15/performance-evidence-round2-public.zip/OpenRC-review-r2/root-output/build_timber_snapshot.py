from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'repository/app/aircraft/timber_visual_details.gd'
text = source.read_text()
baseline = Path(__file__).resolve().parent / 'timber_visual_details_baseline.gd'
candidate = baseline.with_name('timber_visual_details_candidate.gd')
baseline.write_text(text)
new = text.replace(
    '\tcontext.update(PackedInt32Array([mesh.get_surface_count()]).to_byte_array())\n',
    '\tcontext.update(PackedInt32Array([mesh.get_surface_count()]).to_byte_array())\n'
    '\t# The native getter serializes every surface. Reuse it only within this\n'
    '\t# synchronous fingerprint; scripted/extension getters retain their call order.\n'
    '\tvar surface_records: Variant = null\n'
    '\tif mesh is ArrayMesh and mesh.get_script() == null and mesh.get_class() == "ArrayMesh" and mesh.get_surface_count() > 0:\n'
    '\t\tsurface_records = mesh.get("_surfaces")\n')
new = new.replace('var lods := _surface_lods(mesh as ArrayMesh, surface_index)', 'var lods := _surface_lods(mesh as ArrayMesh, surface_index, surface_records)')
new = new.replace('static func _surface_lods(mesh: ArrayMesh, surface_index: int) -> Dictionary:\n\tvar surfaces: Array = mesh.get("_surfaces")', 'static func _surface_lods(mesh: ArrayMesh, surface_index: int, surface_records: Variant = null) -> Dictionary:\n\tvar surfaces: Array = mesh.get("_surfaces") if surface_records == null else surface_records')
assert new != text
assert new.count('surface_records = mesh.get("_surfaces")') == 1
assert '_surface_lods(source_mesh, surface_index)' in new
candidate.write_text(new)
diff = ''.join(difflib.unified_diff(text.splitlines(True), new.splitlines(True), fromfile='a/app/aircraft/timber_visual_details.gd', tofile='b/app/aircraft/timber_visual_details.gd'))
(candidate.parent / 'timber-snapshot-experiment.diff').write_text(diff)
(candidate.parent / 'timber-snapshot-source-identity.json').write_text(json.dumps({
    'revision': 'ca529cb88476a22fbb1c8edf957d6917ab9b6042',
    'baseline_sha256': hashlib.sha256(baseline.read_bytes()).hexdigest(),
    'candidate_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
    'scope': 'Hash-local native ArrayMesh snapshot only; cold reconstruction getters unchanged. Unexecuted isolated prototype. No source-bound custom-paint identity has been changed.'
}, indent=2) + '\n')
print(diff)
