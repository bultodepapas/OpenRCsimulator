extends SceneTree

func _initialize() -> void:
	var paths := OS.get_cmdline_user_args()
	if paths.size() != 2:
		printerr("Expected the two missing source paths")
		quit(2)
		return
	for path: String in paths:
		if not FileAccess.file_exists(path) or FileAccess.file_exists(path + ".uid"):
			printerr("Refusing absent source or existing UID: ", path)
			quit(2)
			return
	for path: String in paths:
		var uid := ResourceUID.create_id()
		if uid == ResourceUID.INVALID_ID:
			quit(2)
			return
		ResourceUID.add_id(uid, path)
		var text := ResourceUID.id_to_text(uid)
		if ResourceUID.text_to_id(text) != uid:
			quit(2)
			return
		var output := FileAccess.open(path + ".uid", FileAccess.WRITE)
		if output == null:
			quit(2)
			return
		output.store_string(text + "\n")
		output.close()
		print(path, " ", text)
	print("Generated two missing UID sidecars with pinned Godot")
	quit(0)
