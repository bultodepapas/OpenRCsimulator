extends SceneTree
const Paint := preload("res://aircraft/custom_skin.gd")
const Adapter := preload("res://aircraft/procedural_skin.gd")
const FAMILY := "turbo-lumber-evolution"
const OLD_CURRENT := "45bd45bff9cd6617839d24b8ab84200f5edb6de82c226939df7bb2c3b280bf69"
func _initialize() -> void:
	var live := Adapter.identity(FAMILY)
	var legacy := String(Paint.kit(FAMILY).stock_sha256)
	var base := Paint.base_identity(FAMILY)
	var accepts := Paint._compatible_timber_template(FAMILY, legacy, live)
	var expected := OS.get_cmdline_user_args().has("--accept")
	var ok := live.length() == 64 and live != OLD_CURRENT and legacy == "1cfbbec926b1589005a35769d957edcd3e67e7edfe690278aefd2b5f627540e6" and accepts == expected and (base == legacy if expected else base.is_empty())
	var result := {live_identity = live, legacy_identity = legacy, admitted_base_identity = base, old_current_identity = OLD_CURRENT,
		compatible = accepts, expected = expected, ok = ok,
		details_sha256 = FileAccess.get_sha256("res://aircraft/timber_visual_details.gd")}
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file := FileAccess.open(arg.trim_prefix("--report="),FileAccess.WRITE)
			file.store_string(JSON.stringify(result,"  "))
	print("Timber identity gate: ", "PASS" if ok else "FAIL")
	print(JSON.stringify(result))
	quit(0 if ok else 1)
