extends SceneTree
func _initialize() -> void:
	var script := GDScript.new()
	var source_path := ""
	var report_path := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--source="): source_path = arg.trim_prefix("--source=")
		if arg.begins_with("--report="): report_path = arg.trim_prefix("--report=")
	script.source_code = FileAccess.get_file_as_string(source_path)
	if script.reload() != OK:
		quit(2)
		return
	var scene: PackedScene = load("res://assets/aircraft/turbo-lumber-evolution/timber.glb")
	var model := scene.instantiate() as Node3D
	script.call("_repair_painted_surface_poke_through", model)
	var records: Array = script.get("audit_insertions")
	var total := 0
	for count: int in records: total += count
	var result := {grid_insertions_by_mesh_order = records, total_grid_insertions = total,
		indexed_queries = script.get("audit_queries"), instrumented_source_sha256 = FileAccess.get_sha256(source_path),
		scope = "Diagnostic counters only, one cold imported-hierarchy repair; excluded from timing."}
	var output := FileAccess.open(report_path, FileAccess.WRITE)
	output.store_string(JSON.stringify(result, "  "))
	print("Timber grid work counts: ", JSON.stringify(result))
	model.free()
	quit()
