from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'repository/app'
PROJECT = Path(__file__).resolve().parent / 'wind-math-project'
PROJECT.mkdir(exist_ok=True)
(PROJECT / 'project.godot').write_text('config_version=5\n\n[application]\nconfig/name="OpenRC wind math experiment"\n\n[physics]\ncommon/physics_ticks_per_second=240\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
physics_dir = PROJECT / 'physics'
if physics_dir.exists():
    shutil.rmtree(physics_dir)
physics_dir.mkdir()
for name in ('math3d.gd', 'wind_spatial_field.gd', 'wind_spatial_config.gd', 'wind_thermal_field.gd'):
    shutil.copy2(SOURCE / 'physics' / name, physics_dir / name)
src = (SOURCE / 'physics/wind_spatial_field.gd').read_text()
base = src.replace('class_name WindSpatialField\n', '')
(PROJECT / 'wind_baseline.gd').write_text(base)
wall = base.replace('var wall_weight := _smooth5(wall_fraction)', 'var wall_weight := 1.0 if wall_fraction == 1.0 else _smooth5(wall_fraction)')
assert wall != base
(PROJECT / 'wind_wall.gd').write_text(wall)
helper = '''extends RefCounted

# Same four engine transcendental calls and vertical product, in source order.
# Caller owns a five-double output buffer for this query only.
static func phase_terms_into(phase: float, vertical_scale: float, height: float, out: PackedFloat64Array) -> void:
\tout[0] = cos(phase)
\tout[1] = sin(phase)
\tvar vertical_phase: float = vertical_scale * height
\tout[2] = sin(vertical_phase)
\tout[3] = cos(vertical_phase)
\tout[4] = vertical_phase
'''
(PROJECT / 'phase_math.gd').write_text(helper)
needle = '''\t\tvar cosine_phase := M.cos_(phase)
\t\tvar sine_phase := M.sin_(phase)
\t\tvar vertical_phase := k_down * height_agl
\t\tvar sine_vertical := M.sin_(vertical_phase)
\t\tvar cosine_vertical := M.cos_(vertical_phase)'''
replacement = '''\t\tPhaseMath.phase_terms_into(phase, k_down, height_agl, phase_terms)
\t\tvar cosine_phase: float = phase_terms[0]
\t\tvar sine_phase: float = phase_terms[1]
\t\tvar sine_vertical: float = phase_terms[2]
\t\tvar cosine_vertical: float = phase_terms[3]
\t\tvar vertical_phase: float = phase_terms[4]'''
assert needle in base
trigs = base.replace('const M :=', 'const PhaseMath := preload("res://phase_math.gd")\nconst M :=', 1)
trigs = trigs.replace('\tfor mode_offset: int in range(0, _modes.size(), MODE_SCALAR_COUNT):', '\tvar phase_terms := PackedFloat64Array([0.0, 0.0, 0.0, 0.0, 0.0])\n\tfor mode_offset: int in range(0, _modes.size(), MODE_SCALAR_COUNT):', 1)
trigs = trigs.replace(needle, replacement)
(PROJECT / 'wind_trigs.gd').write_text(trigs)
(PROJECT / 'wind_both.gd').write_text(trigs.replace('var wall_weight := _smooth5(wall_fraction)', 'var wall_weight := 1.0 if wall_fraction == 1.0 else _smooth5(wall_fraction)'))
manifest = {'base_revision': 'ca529cb88476a22fbb1c8edf957d6917ab9b6042', 'scope': 'isolated source-selected WindSpatialField methods; no production edit, no native/companion qualification', 'sources': {str(p.relative_to(PROJECT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(PROJECT.glob('*.gd'))}}
(PROJECT.parent / 'wind-math-source-identity.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'project': str(PROJECT), 'sources': manifest['sources']}))
