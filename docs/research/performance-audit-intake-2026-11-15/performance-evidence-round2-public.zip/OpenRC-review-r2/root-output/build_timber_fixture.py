from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'repository'
APP = REPO / 'app'
PROJECT = Path(__file__).resolve().parent / 'timber-focused-project'
PROJECT.mkdir(exist_ok=True)
tracked = set((ROOT / 'tracked-paths.txt').read_text().splitlines())
todo = [
    'tests/test_timber_visual_lods.gd',
    'aircraft/timber_visual_details.gd', 'aircraft/timber_visual_lighting.gd',
    'data/aircraft_models/turbo-lumber-evolution.json', 'assets/skin-kit/models.json',
    'assets/aircraft/turbo-lumber-evolution/timber.glb.import',
]
manifest = json.loads((APP / 'data/aircraft_models/turbo-lumber-evolution.json').read_text())
todo.extend(record['path'].removeprefix('res://') for record in manifest['dependencies'])
for record in [manifest['source_registry'], *manifest['authoring_sources']]:
    path = REPO / record['path']
    destination = PROJECT.parent / record['path']
    destination.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        shutil.copy2(path, destination)
    else:
        destination.write_bytes(subprocess.check_output(['git', 'show', 'ca529cb88476a22fbb1c8edf957d6917ab9b6042:' + record['path']], cwd=REPO))
seen = set()
records = []
while todo:
    relative = todo.pop()
    if relative in seen:
        continue
    seen.add(relative)
    path = APP / relative
    repo_path = 'app/' + relative
    if repo_path not in tracked:
        continue
    previous = PROJECT.parent / 'timber-project' / relative
    if path.is_file():
        data = path.read_bytes()
    elif previous.is_file():
        data = previous.read_bytes()
    elif relative == 'assets/aircraft/turbo-lumber-evolution/timber.glb':
        data = (ROOT / 'gpu-output/timber.glb').read_bytes()
    else:
        data = subprocess.check_output(['git', 'show', 'ca529cb88476a22fbb1c8edf957d6917ab9b6042:' + repo_path], cwd=REPO)
    destination = PROJECT / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    records.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    if path.suffix == '.gd':
        text = data.decode('utf-8')
        todo.extend(re.findall(r'preload\(["\']res://([^"\'\n]+)["\']\)', text))
    # Preserve authored import settings for every fetched visual resource.
    if repo_path + '.import' in tracked:
        todo.append(relative + '.import')
timber = ROOT / 'gpu-output/timber.glb'
destination = PROJECT / 'assets/aircraft/turbo-lumber-evolution/timber.glb'
if not destination.is_file():
    shutil.copy2(timber, destination)
    records.append({'path': str(destination.relative_to(PROJECT)), 'bytes': destination.stat().st_size, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
(PROJECT / 'project.godot').write_text('config_version=5\n\n[application]\nconfig/name="OpenRC Timber snapshot experiment"\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
(PROJECT.parent / 'timber-fixture-identity.json').write_text(json.dumps({'revision': 'ca529cb88476a22fbb1c8edf957d6917ab9b6042', 'files': records, 'project_scope': 'Minimal preload/runtime-literal dependency closure for Timber render-data checks, with original imported GLB and textures. No game or GPU-performance claim.'}, indent=2) + '\n')
print(json.dumps({'project': str(PROJECT), 'files': len(records), 'bytes': sum(x['bytes'] for x in records)}))
