extends SceneTree

const Config := preload("res://physics/wind_spatial_config.gd")
const SCRIPTS := [preload("res://wind_baseline.gd"), preload("res://wind_wall.gd"),
	preload("res://wind_trigs.gd"), preload("res://wind_both.gd")]
const NAMES := ["baseline", "wall_saturation", "trig_batch", "both"]
var checks := 0
var failures := 0
var sink := 0.0

func _init() -> void:
	call_deferred("_run")

func _fields(count: int) -> Array:
	var raw: Dictionary = Config.defaults()
	raw.identity.seed_u32 = 20261109
	raw.turbulence.mode_count = count
	raw.turbulence.rms_mps = 0.3
	var checked: Dictionary = Config.resolve(raw)
	_check(checked.ok, "valid fixture config")
	var fields: Array = []
	for script: Script in SCRIPTS:
		var field: Object = script.new()
		field._apply_config(checked.config, checked.content_hash, null, "", "")
		fields.append(field)
	return fields

func _check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		if failures < 20:
			print("FAIL ", label)

func _parity() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261109
	for count: int in [8, 24, 64]:
		var fields := _fields(count)
		for index: int in 300:
			var position := PackedFloat64Array([rng.randf_range(-500.0, 500.0), rng.randf_range(-500.0, 500.0), -rng.randf_range(0.0, 300.0)])
			var at: float = rng.randf_range(0.0, 10000.0)
			var expected: Dictionary = fields[0].sample_world(position, at)
			for arm: int in range(1, fields.size()):
				var actual: Dictionary = fields[arm].sample_world(position, at)
				_check(var_to_bytes(expected) == var_to_bytes(actual), "public sample bytes %d/%d/%d" % [count, index, arm])
		var modes: PackedFloat64Array = fields[0].get("_modes")
		var heights: Array[float] = [0.0, -0.0, -1.0, 0.000000001, 1.0, 5.0, 10.0, 25.0, 100.0, INF, -INF, NAN]
		for offset: int in range(0, modes.size(), 9):
			var seam: float = TAU / modes[offset + 2]
			heights.append(seam)
			heights.append(seam * (1.0 - pow(2.0, -50.0)))
			heights.append(seam * (1.0 + pow(2.0, -50.0)))
		for height: float in heights:
			for at: float in [0.0, 1.0, 4321.25, INF, NAN]:
				var expected: PackedFloat64Array = fields[0]._turbulence_wind(2.5, -3.0, height, at)
				for arm: int in range(1, fields.size()):
					var actual: PackedFloat64Array = fields[arm]._turbulence_wind(2.5, -3.0, height, at)
					_check(expected.to_byte_array() == actual.to_byte_array(), "internal boundary bytes")
		# Disabled turbulence never allocates/uses the query scratch.
		for field: Object in fields:
			field.set("_turbulence_rms", 0.0)
		for arm: int in range(1, fields.size()):
			_check(fields[0]._turbulence_wind(NAN, INF, -INF, NAN).to_byte_array() == fields[arm]._turbulence_wind(NAN, INF, -INF, NAN).to_byte_array(), "disabled turbulence")

func _measure(field: Object, points: Array, repeats: int) -> int:
	var started: int = Time.get_ticks_usec()
	var local_sink := 0.0
	for repetition: int in repeats:
		for point: PackedFloat64Array in points:
			var result: Dictionary = field.sample_world(point, 17.25)
			local_sink += result.wind_ned_mps[0]
	sink += local_sink
	return Time.get_ticks_usec() - started

func _run() -> void:
	_parity()
	print("WIND_MATH_PARITY checks=", checks, " failures=", failures)
	if failures > 0:
		quit(1)
		return
	var rows: Array = []
	for count: int in [8, 24, 64]:
		var fields := _fields(count)
		for height: float in [2.0, 25.0, 150.0]:
			var points: Array = []
			for index: int in 32:
				points.append(PackedFloat64Array([float(index) * 0.125, -float(index) * 0.75, -height]))
			var modes: PackedFloat64Array = fields[0].get("_modes")
			var saturated := 0
			for offset: int in range(0, modes.size(), 9):
				if clampf(modes[offset + 2] * height / TAU, 0.0, 1.0) == 1.0:
					saturated += 1
			for field: Object in fields:
				_measure(field, points, 2)
			for arm: int in range(1, fields.size()):
				for pair: int in 5:
					var order: Array = [0, arm, arm, 0] if pair % 2 == 0 else [arm, 0, 0, arm]
					for role: int in order:
						var elapsed: int = _measure(fields[role], points, 12)
						rows.append({modes=count, height=height, saturated=saturated, arm=NAMES[arm], role=NAMES[role], pair=pair, queries=384, elapsed_us=elapsed})
	var output := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--output="):
			output = arg.trim_prefix("--output=")
	var report := {format="openrc-isolated-wind-math-v1", revision="ca529cb88476a22fbb1c8edf957d6917ab9b6042", checks=checks, failures=failures, rows=rows, sink=sink, engine=Engine.get_version_info()}
	if not output.is_empty():
		var file := FileAccess.open(output, FileAccess.WRITE)
		if file == null:
			push_error("Cannot create output")
			quit(2)
			return
		file.store_string(JSON.stringify(report, "\t"))
	print("WIND_MATH_TIMING rows=", rows.size(), " failures=", failures)
	quit(0)
