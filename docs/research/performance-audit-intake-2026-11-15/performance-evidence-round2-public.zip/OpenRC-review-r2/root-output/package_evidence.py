from pathlib import Path
import hashlib,json,os,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables'
selected={}
allowed={'.json','.csv','.log','.gd','.gdshader','.uid','.py','.diff','.patch','.md','.txt','.html','.godot','.import'}
def add(path):
 if path.is_file() and path.suffix in allowed:
  selected[str(path.relative_to(ROOT))]=path
def tree(path, excluded=()):
 if not path.exists():return
 for base,dirs,files in os.walk(path):
  dirs[:]=[d for d in dirs if d not in {'.godot','__pycache__',*excluded} and not d.startswith('xdg')]
  for name in files:add(Path(base)/name)
for name in ['review-state.json','successor-state.json','closing-state.json']:add(ROOT/name)
for name in ['root-output','cpu-output','physics-output','gpu-output']:
 for p in (ROOT/name).iterdir():
  if p.is_file() and p.name not in {'carried-input-audio.patch'}:add(p)
 tree(ROOT/name/'checks')
for name in ['cpu-output/predictor-project','cpu-output/counter-project','cpu-output/prepared-probes','root-output/wind-math-project','physics-output/candidate']:
 tree(ROOT/name)
tree(ROOT/'cpu-output/pilot-full',excluded={'app'})
tree(ROOT/'cpu-output/head-300-integration',excluded={'app'})
tree(ROOT/'gpu-output/proxy-fixture',excluded={'assets'})
# Keep exact measured helper files and minimal project settings, not full asset/source replicas.
for name in ['physics-output/wind-combined-app/physics/wind_spatial_field.gd','physics-output/wind-combined-app/physics/phase_math.gd','root-output/timber-focused-project/project.godot','root-output/timber-integration-app/project.godot']:
 add(ROOT/name)
# Final production files, distinct from unpromoted experiment sources.
manifest=json.loads((ROOT/'root-output/final-patch-manifest.json').read_text())
for name in ['OpenRC-qualified-optimizations.patch','OpenRC-performance-followup.html']:
 selected[name]=OUT/name
checks=[]
for name,path in selected.items():
 if path.name=='report.json':
  try:d=json.loads(path.read_text())
  except Exception:continue
  if isinstance(d,dict) and d.get('format')=='openrc-godot-check v1':
   checks.append({'path':name,'label':d.get('label'),'ok':d.get('ok'),'complete':d.get('complete'),'counts':d.get('counts'),'reason':d.get('reason'),'missing_required_text':d.get('missing_required_text')})
checks.sort(key=lambda x:x['path'])
index={'scope':'All selected checked-runner receipts, including failed setup attempts. Use the report and owning findings to identify accepted evidence. No zero-exit-only inference.','passing':sum(x['ok'] is True for x in checks),'not_passing':sum(x['ok'] is not True for x in checks),'checks':checks}
(ROOT/'root-output/checked-runs-index.json').write_text(json.dumps(index,indent=2)+'\n')
selected['checked-runs-index.json']=ROOT/'root-output/checked-runs-index.json'
readme='''OPENRC SIMULATOR — QUALIFIED PERFORMANCE CHANGES AND EVIDENCE
9 November 2026

READ FIRST
OpenRC-performance-followup.html is the authoritative synthesis. It distinguishes
implemented code, old/merged work, measured components, estimates, rejected
experiments and target-hardware gaps. Source reports preserve their original
qualification scope and may describe a gate that was subsequently completed;
the final HTML and root-output/final-patch-manifest.json record final status.

PATCH TARGET
Repository: https://github.com/bultodepapas/OpenRCsimulator
Base: main, 300dc4e82cc6975b6f4e808cb4b2b845a0240ded
Local branch: perf/math-audit-20261109-r2
No commit, push, PR or merge performed.

Apply ONLY OpenRC-qualified-optimizations.patch as the qualified production
change. Other *.diff / experiment sources are research evidence and are NOT
recommended production patches. In a clean checkout of the exact base:

  git switch -c perf/math-review-20261109 300dc4e82cc6975b6f4e808cb4b2b845a0240ded
  git apply --check /absolute/path/OpenRC-qualified-optimizations.patch
  git apply /absolute/path/OpenRC-qualified-optimizations.patch

The patch was applied to a separate exact-base file fixture and every resulting
file matched the qualified worktree byte-for-byte. It has 11 changed files.
The patch and final file hashes identify the exact edits. Do not replace the
distributed Timber kit identity or weaken source-admission checks.

MEASURED AND IMPLEMENTED
1. Companion pilot: min(sqrt(q)) -> sqrt(min(q)) when traces are off;
   reuse the original first fully-ramped turn-rate result. Held-conflict command
   medians ~544.329->473.529 us (1 threat), 740.443->657.143 us (3 threats).
2. Timber: paired grid insertion/lookup uses existing integer cell coordinates
   directly. Complete cache-cold repair 395.0225->332.395 ms, ten faster adjacent
   pairs, 130821 formatting operations/argument arrays removed per cold repair.
These are headless component results, not displayed FPS or physical latency.

MAIN EVIDENCE
- root-output/environment.json: exact host and pinned engine identity.
- root-output/final-patch-manifest.json: final production file and patch hashes.
- root-output/uid-gate-final.json: final tracked-index sidecar check; not full CI.
- cpu-output/PILOT_QUALIFICATION.md and production-qualification-receipt.json.
- cpu-output/predictor-timing.json: all 360 timing trials across candidate arms.
- cpu-output/pilot-full/comparison.json: full feedback/CSV comparisons.
- root-output/timber-grid-final-summary.json and timber-grid-imported-probe.json.
- root-output/timber-grid-work-counts.json: untimed operation counters.
- root-output/timber-grid-identity-{reject-complete,accept}.json.
- physics-output/timber_grid_findings.md: 945 differential and 59 permanent checks.
- checked-runs-index.json: complete selected checked-runner receipt index.

SOURCE PINS AND ASSETS
Full circuit/encounter runs were frozen on ca529cb88476a22fbb1c8edf957d6917ab9b6042.
Their relevant physics/AI sources are unchanged at 300dc; current-head manager,
strict-profile and Timber-build overlays are recorded separately. They are not
presented as new full current-head flight campaigns.

The engine is 4.8.beta2.official.cafc17a19, source commit
cafc17a192acf67903910a68aeb3c076c0907a4b. Obtain the pinned editor using the
repository's existing get-godot workflow. Use its original asset/import settings.
Full repository copies, downloaded GLBs/textures, import caches and executables
are deliberately omitted; fetch them from the stated repository revision. Asset
and import receipts list Git/SHA identities. The Timber asset is
app/assets/aircraft/turbo-lumber-evolution/timber.glb, SHA-256
d75ae605aa3afdf3f417a0ec535c3bd3126c2a5a4eb7827393727152245c6722.
Raw check commands retain original absolute scratch paths for provenance; adapt
those paths to the extracted evidence and complete imported checkout.

FOCUSED CHECKS IN A COMPLETE IMPORTED CHECKOUT
Set GODOT to the pinned editor's absolute path. Use tools/godot/run_checked.py:

  python3 tools/godot/run_checked.py --label reachable-score --timeout 60 \
    --require-text "companion reachable score: 26 checks, 0 failed" -- \
    "$GODOT" --headless --audio-driver Dummy --path app \
    --script res://tests/test_companions_reachable_score.gd

  python3 tools/godot/run_checked.py --label timber-grid --timeout 60 \
    --require-text "Timber paint grid: 59 checks, 0 failures" -- \
    "$GODOT" --headless --audio-driver Dummy --path app \
    --script res://tests/test_timber_paint_grid.gd

Use the same checked runner for tests/test_timber_visual_lods.gd (58 checks),
and tests/test_skin_fleet.gd -- turbo-lumber-evolution (89 checks), plus the
existing companion profile/manager/session suites. The archived reports contain
actual arguments, log digests, engine diagnostic counts and completion markers.

TIMBER COMPONENT REPRODUCTION
Use the complete imported checkout's app path and the archived gpu-output/
timber-probe.gd. After the engine -- separator supply:
  --baseline-source=<evidence>/root-output/timber_visual_details_baseline.gd
  --candidate-source=<evidence>/root-output/timber_visual_details_grid_candidate.gd
  --report=<new-output.json> --groups=5
The marker is 'Timber imported-source probe: 33 checks, 0 failed'. This clears
only the repair cache, not process/import/driver caches. Avoid concurrent work.
The counter-instrumented source is diagnostic only and must not be timed.

PILOT COMPONENT REPRODUCTION
The small source-only cpu-output/predictor-project is included. Run its bench.gd
with --out=<new-output.json>; parity.gd provides the source-selected differential.
Full feedback reproduction uses the prepared pilot/encounter audit probes and
fixture receipts; their actual command lines live in pilot-full/checks.
Do not replace a full pilot run with recorded-command playback.

UNPROMOTED EXPERIMENTS
- Hash-local native ArrayMesh snapshot: fewer whole-mesh reads, inconclusive
  complete-repair benefit. Not combined with the delivered grid patch.
- Temporal wind phase cache: mixed full-step timings, zero-RMS overhead.
- Wind wall/trig-wrapper screen: promising spatial pairs but noisy unchanged
  control and an unresolved Math3D helper/native admission boundary.
- Proxy LOD decoder: 2092032 fewer logical temporary index bytes, no convincing
  complete-collection benefit. Native GPU/FPS impact was not measured here.

FAILURES AND LIMITS
Failed missing-asset/catalog/import/harness attempts remain in the archive and
are marked non-passing in the checked index. Successful reruns used exact
restored assets. The constructed parallel encounter still misses its separation
gate for both pilots and remains survey-only. Successful encounter checks have
six UID-to-path fallback warnings. The report preserves these qualifications.

Required hosted CI on base 300dc was red for two missing UID sidecars. This patch
supplies them and passes the narrow final-index gate, but no hosted full CI or
clean-source release preflight is claimed. Finish required CI, package/export
checks and the report's native 1080p CPU/GPU/frame-percentile/input-latency plan.
'''
# Avoid Python literal line continuations collapsing the command examples.
readme=readme.replace(' --require-text', ' --require-text')
readme_path=OUT/'evidence-README.txt';readme_path.write_text(readme)
selected['README.txt']=readme_path
rows=[{'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(selected.items())]
evidence_manifest={'format':'openrc-performance-evidence-v1','base_commit':manifest['base_commit'],'patch_sha256':manifest['patch_sha256'],'included_file_count':len(rows),'uncompressed_bytes':sum(x['bytes'] for x in rows),'files':rows}
mp=OUT/'evidence-manifest.json';mp.write_text(json.dumps(evidence_manifest,indent=2)+'\n')
selected['evidence-manifest.json']=mp
zip_path=OUT/'OpenRC-performance-evidence.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in sorted(selected.items()):z.write(path,'OpenRC-review-r2/'+name)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for row in rows:
  assert hashlib.sha256(z.read('OpenRC-review-r2/'+row['path'])).hexdigest()==row['sha256']
print(json.dumps({'zip':str(zip_path),'bytes':zip_path.stat().st_size,'included_file_count':len(selected),'uncompressed_bytes':sum(x['bytes'] for x in rows),'checked_passes':index['passing'],'checked_nonpasses_retained':index['not_passing'],'zip_integrity':'passed'},indent=2))
