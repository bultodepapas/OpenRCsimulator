from pathlib import Path
from html import escape
from html.parser import HTMLParser
import json
import re

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'root-output'
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
body = (WORK / 'report-body.html').read_text()
values = json.loads((WORK / 'report-sections.json').read_text())
for key, value in values.items():
    body = body.replace('@@' + key + '@@', value)
assert '@@' not in body, 'An unfinished report section remains'
toc = [(match[0], re.sub('<[^>]+>', '', match[1])) for match in re.findall(r'<section id="([^"]+)">\s*<h2>(.*?)</h2>', body)]
contents = '<nav aria-label="Contents"><strong>Contents</strong><ol>' + ''.join('<li><a href="#' + key + '">' + escape(label) + '</a></li>' for key, label in toc) + '</ol></nav>'
body = body.replace('</header>', '</header>' + contents, 1)
style = '''
:root{color-scheme:light;--ink:#193044;--muted:#536b7d;--blue:#176587;--line:#d4e1e9;--pale:#f0f6f9}
*{box-sizing:border-box}body{margin:0;background:#eaf0f4;color:var(--ink);font:16px/1.65 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
main{max-width:1160px;margin:32px auto;background:white;border-top:7px solid var(--blue);padding:42px 58px 70px;box-shadow:0 8px 28px #223f5510}
.eyebrow{text-transform:uppercase;letter-spacing:.12em;font-size:12px;color:var(--blue);font-weight:750}.subtitle{color:var(--muted);font-size:18px}
h1{font-size:38px;line-height:1.18;letter-spacing:-.035em;margin:14px 0 22px}h2{font-size:25px;line-height:1.3;border-top:1px solid var(--line);padding-top:28px;margin-top:42px;letter-spacing:-.02em}h3{font-size:19px;line-height:1.35;margin:27px 0 9px}
p{margin:12px 0}a{color:#075d91;text-decoration-thickness:1px;text-underline-offset:3px;overflow-wrap:anywhere}strong{font-weight:700}code{font:.86em/1.45 ui-monospace,SFMono-Regular,Consolas,monospace;background:#eef4f7;border-radius:3px;padding:1px 4px;overflow-wrap:anywhere}
pre{border:1px solid var(--line);background:#f6f9fb;padding:18px;overflow:auto;border-radius:6px;line-height:1.45}pre code{background:none;padding:0;overflow-wrap:normal;white-space:pre}
.table-wrap{overflow-x:auto;margin:22px 0;border:1px solid var(--line);border-radius:5px}table{width:100%;border-collapse:collapse;font-size:14px;line-height:1.45}th{background:#e8f0f5;text-align:left;font-weight:700}th,td{padding:11px 13px;border-bottom:1px solid var(--line);vertical-align:top}tbody tr:nth-child(even){background:#f8fafc}tbody tr:last-child td{border-bottom:0}
ul{padding-left:23px}li{margin:9px 0}nav{background:var(--pale);border-left:4px solid var(--blue);padding:16px 22px;margin:26px 0}nav strong{display:block;margin-bottom:8px}nav ol{columns:2;column-gap:36px;margin:0;padding-left:22px;font-size:14px}nav li{break-inside:avoid;margin:6px 0}.note{background:#f5f8ea;border-left:4px solid #809140;padding:14px 18px}footer{margin-top:45px;border-top:1px solid var(--line);padding-top:16px;font-size:13px;color:var(--muted)}
@media(max-width:760px){main{margin:0;padding:24px 19px}nav ol{columns:1}h1{font-size:29px}h2{font-size:22px}table{min-width:560px}}
@media print{body{background:white;font-size:10pt}main{max-width:none;box-shadow:none;margin:0;border:0;padding:0}nav{break-after:page}nav ol{columns:1}h2,h3{break-after:avoid}table{font-size:8.5pt}tr{break-inside:avoid}pre,pre code{white-space:pre-wrap}a{color:#174e70}h2{margin-top:24px}footer{font-size:8pt}}
'''
document = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OpenRC Simulator — Performance Follow-up</title><style>' + style + '</style></head><body><main>' + body + '<footer>Prepared 9 November 2026. Measurements retain their original revision, candidate identity, host and scope. The evidence archive includes the raw results and reproduction material.</footer></main></body></html>'

class Check(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack = []
        self.ids = set()
        self.anchors = []
        self.scripts = 0
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag not in {'meta', 'br', 'hr', 'img', 'link', 'input'}:
            self.stack.append(tag)
        if 'id' in attrs:
            assert attrs['id'] not in self.ids
            self.ids.add(attrs['id'])
        if tag == 'a' and attrs.get('href', '').startswith('#'):
            self.anchors.append(attrs['href'][1:])
        if tag == 'script':
            self.scripts += 1
    def handle_endtag(self, tag):
        assert self.stack and self.stack.pop() == tag, tag

check = Check()
check.feed(document)
assert not check.stack and not check.scripts
assert all(a in check.ids for a in check.anchors)
target = OUT / 'OpenRC-performance-followup.html'
target.write_text(document)
print(json.dumps({'path': str(target), 'bytes': target.stat().st_size, 'sections': len(toc), 'text_words': len(re.sub('<[^>]+>', ' ', body).split()), 'structural_check': 'passed'}))
