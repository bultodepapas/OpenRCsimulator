#!/usr/bin/env python3
"""Build a source-bound, asset-minimal Godot physics fixture in this output directory."""
from pathlib import Path
from shutil import copy2, copytree
import difflib
import hashlib
import json
import subprocess

here = Path(__file__).resolve().parent
workspace = here.parent
new_repo = workspace / "repository"
old = workspace.parent / "audit-review"
old_repo = old / "repository"
old_app = old / "physics-output/reference-app"
baseline = here / "baseline-app"
if baseline.exists():
    raise SystemExit("refusing to overwrite an existing fixture")
copytree(new_repo / "app", baseline)
asset_paths = []
for line in (old / "physics-output/retrieved-assets.sha256").read_text().splitlines():
    digest, size, path = line.split("  ", 2)
    asset_paths.append(path)
asset_paths.append("assets/landscape/rc-ground/dirt-albedo.jpg")
assets = []
for name in asset_paths:
    def tree_oid(repo, revision):
        return subprocess.check_output(["git", "rev-parse", f"{revision}:app/{name}"], cwd=repo, text=True).strip()
    new_oid = tree_oid(new_repo, "ca529cb88476a22fbb1c8edf957d6917ab9b6042")
    old_oid = tree_oid(old_repo, "8fb825a96dbc39fbbf99c1056ba643c9cde49b5d")
    if new_oid != old_oid:
        raise SystemExit(f"asset changed across commits; retrieve exact new blob: {name}")
    src = old_app / name
    if not src.is_file() or not src.stat().st_size:
        raise SystemExit(f"missing old reference blob: {name}")
    dst = baseline / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    copy2(src, dst)
    assets.append({"path": name, "git_blob": new_oid, "bytes": dst.stat().st_size,
                   "sha256": hashlib.sha256(dst.read_bytes()).hexdigest()})
project = baseline / "project.godot"
original = project.read_text()
fixture = "".join(line for line in original.splitlines(keepends=True)
                  if not line.startswith(("run/main_scene=", "InterfaceFonts=", "locale/translations=",
                                          "enabled=PackedStringArray(")))
project.write_text(fixture)
(here / "reference-project.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(True), fixture.splitlines(True), fromfile="committed project.godot",
    tofile="isolated physics fixture project.godot")))
(here / "fixture-assets.json").write_text(json.dumps({"baseline_commit": "ca529cb88476a22fbb1c8edf957d6917ab9b6042",
    "old_commit": "8fb825a96dbc39fbbf99c1056ba643c9cde49b5d", "same_git_blobs": True,
    "assets": assets}, indent=2) + "\n")
print(f"Prepared {baseline}; verified {len(assets)} exact same pinned asset blobs.")
