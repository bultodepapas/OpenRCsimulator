#!/usr/bin/env python3
"""Run the repository's unchanged full-session zero-RMS control in ABBA process order."""
from pathlib import Path
import os
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
repo = out.parent / "repository"
godot = out.parent.parent / "audit-review/repository/.tools/Godot_v4.8-beta2_linux.x86_64"
runner = repo / "tools/godot/run_checked.py"
aircraft = "jensen-das-ugly-stik-60"
cases = ["spatial-v5-zero-rms-24"]
for index, role in enumerate(("baseline", "candidate", "candidate", "baseline"), 1):
    result = out / f"zero-{role}-pair-{index}.json"
    if result.exists():
        raise SystemExit(f"refusing existing output {result}")
    label = f"zero-{role}-pair-{index}"
    command = [sys.executable, str(runner), "--out-dir", str(out / "checks"), "--label", label,
               "--timeout", "600"]
    for case in cases:
        command += ["--require-text", f"measured {aircraft} / {case}"]
    command += ["--", str(godot), "--headless", "--audio-driver", "Dummy",
                "--path", str(out / f"{role}-zero-app"), "--script", "res://tests/bench_spatial_wind.gd",
                "--", "--full-session", f"--aircraft={aircraft}",
                *[f"--case={case}" for case in cases], "--samples=3", "--ticks-per-sample=480",
                "--warmup-ticks=240", "--revision=ca529cb88476a22fbb1c8edf957d6917ab9b6042",
                f"--output={result}"]
    env = os.environ.copy()
    for kind in ("DATA", "CONFIG", "CACHE"):
        env[f"XDG_{kind}_HOME"] = str(out / f"xdg-{role}-{kind.lower()}")
    print(f"START {index}/4 {role}", flush=True)
    start = time.monotonic()
    with (out / f"{label}-console.log").open("wb") as log:
        completed = subprocess.run(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    print(f"END {index}/4 {role} exit={completed.returncode} wall_s={time.monotonic()-start:.3f}", flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)
