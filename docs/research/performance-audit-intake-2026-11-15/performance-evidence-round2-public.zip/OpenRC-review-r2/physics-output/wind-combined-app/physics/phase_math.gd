extends RefCounted

# Same four engine transcendental calls and vertical product, in source order.
# Caller owns a five-double output buffer for this query only.
static func phase_terms_into(phase: float, vertical_scale: float, height: float, out: PackedFloat64Array) -> void:
	out[0] = cos(phase)
	out[1] = sin(phase)
	var vertical_phase: float = vertical_scale * height
	out[2] = sin(vertical_phase)
	out[3] = cos(vertical_phase)
	out[4] = vertical_phase
