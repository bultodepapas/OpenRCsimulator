## Untimed diagnostic. Expects a separate app copy with a hit counter injected
## into the experimental weather routine; never use this copy for timing.
extends SceneTree

const Session := preload("res://sim/flight_session.gd")
const WeatherConfig := preload("res://physics/wind_config.gd")
const Flow := preload("res://physics/wind_aircraft_flow.gd")

func _initialize() -> void:
    _run.call_deferred()

func _run() -> void:
    var session: Node = Session.new()
    session.setup("res://data/aircraft/jensen_ugly_stik_60.json")
    root.add_child(session)
    var config: Dictionary = WeatherConfig.spatial_defaults()
    config.spatial_wind.profile.reference_speed_mps = 3.0
    config.spatial_wind.profile.reference_from_deg = 270.0
    config.spatial_wind.turbulence.rms_mps = 0.3
    config.spatial_wind.turbulence.mode_count = 24
    if not session.is_flyable() or not session.setup_weather(config):
        printerr("FAIL actual session setup or weather admission")
        session.free()
        quit(1)
        return
    session.reset()
    if not session.is_flyable() or session.sim.tick != 0 or Flow._phase_stage_scratch(session.environment) == null:
        printerr("FAIL session reset or standard callback admission")
        session.free()
        quit(1)
        return
    var provider: Variant = session.environment.weather.get("_spatial")
    provider.set("phase_test_hit_count", 0)
    var hit_counts := PackedInt64Array()
    var previous := 0
    for expected in [1, 2]:
        session.sim.step()
        if session.sim.tick != expected or not session.sim.fault_reason.is_empty():
            printerr("FAIL actual Simulation.step: ", session.sim.fault_reason)
            session.free()
            quit(1)
            return
        var current: int = provider.get("phase_test_hit_count")
        hit_counts.append(current - previous)
        previous = current
    if hit_counts[1] <= 0:
        printerr("FAIL actual session produced no temporal cache hits")
        session.free()
        quit(1)
        return
    print("phase actual-session cache hits: ", hit_counts)
    session.free()
    quit()
