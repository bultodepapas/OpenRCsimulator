# Stage-local spatial-wind time-factor experiment

Reviewed commit: `ca529cb88476a22fbb1c8edf957d6917ab9b6042`. The repository worktree was not edited. The four-file candidate is isolated under `candidate/` and `candidate-app/`; **do not promote it** on the present evidence. Four source identities would change, including the native mirror's source admission and the companion solver identity, and full native, replay, companion and release qualification has not run.

## Result

The intended optimization actually ran in a stock-Stik reference session and preserved the selected ending states, but its full-session timings did not establish a reliable speedup. Two 24-mode pairs had opposite signs. A separate zero-RMS control showed the candidate slower in both sampled pairs, with substantial shared-host variation. The added guard, dispatch, short-lived scratch and duplicate code can offset the removed remainder operations; their cost must be accounted for before any production change.

The established source calculation for each mode is:

```
epoch = stage_time + epoch_offset
spatial = k_north * north + k_east * east + phase_offset
reduced_time = fposmod(omega * epoch, TAU)
phase = fposmod(fposmod(spatial, TAU) + reduced_time, TAU)
```

Only the exact `reduced_time` is reused, not position, complete wind, trigonometric results, vector reductions, or RK states. For `M` modes and `Q` qualifying points in each of `S` separately owned groups, the maximum source-level reduction is `M*(Q-1)*S` products and remainders per tick, under a stable provider/time and finite, nonzero inputs. For 24 modes, 10 points and four ordinary RK stages at 240 accepted ticks/s, the conditional count is 207,360 of each operation per simulated second. The separate pre-step group may add another 51,840 only if independently eligible; zero epoch, zero RMS, refusals, event trials and other dispatch paths change the count. These counts are not timing results.

## Scope and lifecycle

The candidate recognizes the exact built-in `Environment`, `WindField` and spatial provider. It requires no thermal provider and either no turbulence callback or the exact built-in `FlightSession._turbulence_noise` callable attached to the same environment, with no OU turbulence. The callback is still invoked in its original order for every point. Generic or derived environments/weather and arbitrary/bound callbacks follow the original public methods. Thermal-enabled v2 uses the original route. The separately retained `StagePointSampler.delta_at` also keeps its original live-provider path.

One dictionary is scoped to a single synchronous `WindFlow._sample` invocation. It stores arrays of each original mode's omega and reduced time phase. On subsequent point calls the code checks the actual provider, epoch, layout, and each live finite nonzero omega; any mismatch recomputes the original expression. Zero epoch and zero RMS do not populate/use this cache. At 24 modes the two arrays contain 384 bytes of binary64 values, plus dictionary/array/runtime overhead; peak or resident memory was not measured. No scratch is intentionally retained by the Air receipt or shared between stages, ticks, resets or sessions.

This remains an experimental design, not an acceptance proof for arbitrary external threads or floating-point environment mutation. A deliberately poisoned scratch value in the isolated probe caused a mismatch, demonstrating why it must not escape or be mutable by outside code. Same-instance omega, epoch and mode-layout changes were checked with the guarded path; arbitrary mutating callback and derived environment/weather controls took the generic path. No tests establish all malformed binary64 modes, infinity-producing products, arbitrary thread interference, or every physical/weather domain. The duplicated methods and cross-layer dispatch need redesign before any production proposal.

## Checks and actual execution

- Pinned engine: Godot `4.8.beta2.official.cafc17a19`; Linux x86-64 AMD EPYC 9V74 shared host. Rendering, ordinary application observers, physical inputs and audio are outside the full-session measurement.
- Checked candidate parse and existing suites passed: wind-aircraft flow **91**, lean spatial-stage **738**, spatial wind field **155**, and prepared spatial wind **1,543** checks. The field suite first failed because three frozen JSON fixtures were absent from the sparse checkout; exact `ca529cb` blobs were fetched, and passing reruns and the failed receipt remain under `checks/`.
- `phase_differential.gd` passed **163 checks**, including built-in no-callback and real `FlightSession` callback admission, the poison negative control, 8/24/64 modes, time/domain errors, same-instance mutation, override dispatch and retained point sampler. These are focused tests, not exhaustive stage oracles.
- A **separate untimed instrumented copy**, excluded from timing, executed real `FlightSession` and `Simulation.step`: its first two accepted stock-Stik 24-mode ticks recorded **648 and 1,080 cached-mode hits**. The first is lower because epoch zero does not populate scratch. This demonstrates actual use, not a timing effect.
- The original `bench_spatial_wind.gd --full-session` verified baseline and candidate legacy steady, 24-mode spatial and 24-mode thermal cases before timing. Each case completed three 480-tick batches and three 240-tick warmups with nine out of nine restore checks. Final hashes matched baseline/candidate across all measured and verification runs. These are endpoint hashes, not a tick-by-tick replay or general proof of identical trajectories. Its counting replay recorded first-tick/480-tick totals of 5/2,400 for legacy and 50/24,000 for each spatial case.

Baseline solver SHA-256: `b98411b3c131e0a91bd7e2793799bf2f4d69264e1f29b058084e623ab20a1581`. Candidate: `4c18935ec5a4e739fc1d2d69eaf6690589da9b0f09899fcd55cfd9e7f3687846`. The original harness SHA-256 was `219978bc10463f42db409d5ba96d34e03ccd39b7398c8047608033ba01384a94` in all four timed runs. The two source-copy fixtures had an identical minimal project-settings diff removing unrelated startup/fonts/translations/editor plugins; 15 missing visual assets were restored only after their Git blob identities matched at both source revisions. No physics, collision or aircraft-data stub was used.

## Complete-step timing

Each process below is the median of three 480-tick batch means, with 240 warmup ticks per batch. Processes were ordered baseline, candidate, candidate, baseline; pair 1 compares the first two and pair 2 compares the last two. Values are microseconds per `Simulation.step`, not individual-tick percentiles or displayed frames. All initial/final hashes and requested tick/reset counts passed. The source/config/weather and execution identities are recorded in the raw reports.

| Workload | Pair 1 baseline | Pair 1 candidate | Pair 2 baseline | Pair 2 candidate | Interpretation |
| --- | ---: | ---: | ---: | ---: | --- |
| Legacy steady, 3 m/s | 551.690 | 603.740 | 608.329 | 598.485 | Opposite pair directions; no reliable difference. |
| Spatial, 24 modes, RMS 0.3 m/s | 4,188.431 | 3,761.646 | 3,857.313 | 4,134.942 | Opposite pair directions; no reliable gain. |
| Spatial 24 + active thermal, original fallback | 3,968.671 | 4,071.735 | 4,661.183 | 4,393.054 | Opposite pair directions; no reliable difference. |
| Spatial, 24 modes, RMS 0 | 2,259.071 | 2,267.102 | 2,183.388 | 2,557.900 | Candidate slower in both pairs; too few pairs/noisy host to establish a stable penalty. |

The zero-RMS row used the same minimal extension of the existing benchmark script in both disposable copies. `zero-harness.diff` retains the exact change and the harness SHA-256 is `84386605dec20d05d7a53c4497ab729568136f02a1a59fe4ab3cf10b10281f58`. It still uses the real `FlightSession`/`Simulation.step` and original weather/physics code for its respective role. Its first-tick and 480-tick query counts were 50 and 24,000; endpoint hashes matched in all four processes.

The paired process medians, pooled batch means, complete JSON reports and checked-runner logs are retained in `phase-abba-summary.json`, `zero-abba-summary.json`, the eight `*-pair-*.json` files, and `checks/`. Two process pairs cannot resolve a small effect on this host. No result establishes Apple Silicon, sustained 1080p or FPS benefit. Do not infer that the phase work caused the observed zero-RMS differences.

## Next actions if revisited

Reduce duplicate code and allocation/dispatch overhead while retaining generic override and mutation semantics. First prove the exact source-bound change with full RK stage/load/refusal arrays, nonfinite/overflow and signed-zero controls, rollback, resets, multiple aircraft, thermal/fallback, retained samplers, per-tick state and event tapes. Native mirrors and actual native qualification, companion solver rebind, golden/replay and required CI remain separate gates. Then use more alternating independent full-session pairs on a quiet target host, including zero-RMS and active thermal controls; follow with production-path 1080p measurements on the target platform. Any application performance claim requires those measurements, not this screen.

## References

- Repository entry points: `app/physics/wind_aircraft_flow.gd`, `app/sim/environment.gd`, `app/physics/wind_field.gd`, and `app/physics/wind_spatial_field.gd` at the pinned commit.
- NASA, [fourth-order Runge–Kutta implementation appendix](https://ntrs.nasa.gov/api/citations/20150014965/downloads/20150014965.pdf).
- Godot, [PackedFloat64Array ownership and duplication](https://docs.godotengine.org/en/4.4/classes/class_packedfloat64array.html) and [CPU optimization](https://docs.godotengine.org/en/stable/tutorials/performance/cpu_optimization.html).
