# Timber snapshot: focused adversarial differential

## Result

The frozen baseline and hash-local candidate passed **26 checks with zero failures** in the same focused Godot project. The checked runner reported process exit 0, `ok=true`, and no engine errors or warnings. The receipt and exact command are `root-output/checks/timber-adversarial-fixed2-euqgfc1y/report.json`; its `engine.log` contains the completion marker. This was a correctness run only, not a benchmark, GPU test, or complete application qualification.

The checks cover scripted `ArrayMesh._get` call counts and ordering, per-read mutable returned records, zero-surface native and scripted meshes, a valid zero-surface non-`ArrayMesh` direct hash, same-object native and scripted LOD mutation, and a scripted node transform getter that mutates a native mesh before the hash. Baseline and candidate hashes and observed call sequences match in these fixtures. A one-byte mutation of a retained LOD index buffer is deliberately made unequal, so the record comparison demonstrably includes the LOD bytes.

Baseline and candidate fixture meshes have independently created `StandardMaterial3D` objects. The comparison normalizes each material's object identity to its class, resource name, albedo color, roughness, metallic value and emission-enabled field. It retains all other serialized surface fields unchanged, including LOD thresholds, order, and packed index bytes. This checks the stated fixture material fields; it is not a general assertion that all arbitrary material properties or graphics-driver outcomes match. The existing separate Timber LOD suite and imported-model checks remain independent gates.

## Failed setup receipts retained

The original `root-output/checks/timber-adversarial-g421wu5i` run did **not** pass: it printed 24 checks with three failed comparisons. Those comparisons compared different material object IDs from independently built but otherwise equivalent fixture meshes. It also tried a nonempty `BoxMesh`, where both the baseline and candidate fail because this pinned script invokes an unsupported `surface_get_primitive_type` method; the empty resource name also caused both to report a hashing update error. That control did not establish BoxMesh support and was replaced by a named, zero-surface `PlaceholderMesh`; production code was not changed.

An intermediate `root-output/checks/timber-adversarial-fixed-o4co1z38` run failed parsing because an inferred `PlaceholderMesh` variable was tested against the statically unrelated `ArrayMesh` type. Giving it the declared base type `Mesh` corrected the fixture. Both failed receipts are retained; neither is relabeled as passing.

## Exact files

- Godot `4.8.beta2.official.cafc17a19`, headless with Dummy audio.
- Frozen baseline `root-output/timber_visual_details_baseline.gd`: SHA-256 `6b200f12db0e672624b044076457f71d0c67597cb1d69ba3a0cf73ff9ae4b945`.
- Frozen candidate `root-output/timber_visual_details_candidate.gd`: SHA-256 `7c8a21dd51f9e75c7aa8d6b08f60e51244c0b313e8a1a21ba64a6a5b750fd7fb`.
- Fixed test `physics-output/timber_snapshot_adversarial_diff.gd`: SHA-256 `1028dff3c401c348742efc45b67b9b70a7667ea5442b6828782dc7470d723238`.

The candidate remains subject to stock-asset, identity, package, rendering and target-platform gates. The test does not exercise a nonempty custom `Mesh` or a GDExtension-defined mesh.
