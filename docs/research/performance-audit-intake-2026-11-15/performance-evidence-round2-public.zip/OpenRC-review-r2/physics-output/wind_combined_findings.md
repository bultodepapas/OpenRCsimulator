# Combined spatial-wind math: isolated full-session screen

## Conclusion

At source revision `ca529cb88476a22fbb1c8edf957d6917ab9b6042`, a combined wall-taper shortcut and batch of four existing trigonometric calculations was faster in both short, adjacent 24-mode full-session comparisons on this shared Linux host. The paired median differences were −3.95% and −7.80%. The legacy-wind control also varied by −11.49% and −0.71%, so these few runs are a screen, not a stable estimate or target-platform performance claim. No production source was edited and no native backend, GPU, frame rate, or Apple Silicon performance was qualified.

The trial is **not ready to promote**: its separate `physics/phase_math.gd` calls engine trig directly, while `physics/math3d.gd:16` states the architecture's single-location trig contract. Put the equivalent batch helper in `Math3D`, then rerun the checks and complete-session comparison for that actual implementation. Its changed Math3D and spatial-field sources, native mirrored sources, native oracles, package/companion identities, replay/trace and other required gates must be requalified. The legacy, default zero-RMS, thermal, nonfinite and failure/rollback behavior needs the relevant full acceptance gates; a matching endpoint is not a complete trajectory or load-by-load proof.

## Candidate and numerical work

The pinned source `app/physics/wind_spatial_field.gd:_turbulence_wind()` evaluates each mode in this order: cosine of horizontal phase, sine of horizontal phase, `k_down * height`, sine of the vertical phase, then cosine of the vertical phase. Current `Math3D.cos_` and `sin_` wrappers each return the corresponding Godot built-in directly. The experiment keeps those four built-ins and their order, but calls one helper per mode and transfers five float64 values through a per-query `PackedFloat64Array`. It leaves temporal reduction, derivative, accumulation order and the original zero-RMS early return in place. The per-query scratch allocates only after that early return.

For the wall taper it substitutes exactly `1.0` only when the already-clamped fraction compares equal to `1.0`, otherwise it evaluates the original `_smooth5` expression. At exactly `1.0`, the original polynomial evaluates to `1.0` with exact small integer intermediates; the derivative path and its tests are unchanged. This does not authorize changing behavior for `0`, NaN, overflow, or any other input; the checked prototype retains the fallback expression for those values.

For the 24-mode reference case, the benchmark's untimed counting replay reports 50 provider point queries per accepted step, including the pre-step observer group, and 24 modes per query. That is 1,200 helper calls replacing 4,800 wrapper calls, or 3,600 fewer GDScript calls per measured step; it adds one scratch array per active query and five writes plus five reads per mode. The four built-in transcendental evaluations per mode are **not** eliminated. Realized performance depends on interpreter, allocations and weather, and the screen above measures the complete step rather than inferring its cost from this count.

The isolated implementation is `physics-output/wind-combined-app/physics/wind_spatial_field.gd` and `physics-output/wind-combined-app/physics/phase_math.gd`. Its math came from `root-output/wind-math-project/wind_both.gd` and `phase_math.gd`; assembly restores `class_name WindSpatialField` and relocates the helper preload to `res://physics/phase_math.gd`. Root's separate component screen is `root-output/wind-math-screen-fixed.json`; the complete-session results below are independent evidence, not a prediction from that screen.

## Correctness and source identity

The checked runner passed the candidate's existing wind-aircraft flow (91), lean spatial stage (738), spatial wind field (155) and prepared spatial wind (1,543) checks. Before timings, the unchanged benchmark verified three 480-tick batches with three 240-tick warmups for stock Stik legacy steady, seeded spatial v1 with 24 turbulence modes, and spatial v2 with active thermal and 24 modes. For all three, the candidate's final-state hash for every batch matched the previously verified pinned baseline, all nine restore checks passed, and counting-replay coverage matched production. All four timed ABBA processes also matched the corresponding baseline endpoints and passed restore and coverage checks. These checks establish the selected cases and endpoints, not all possible weather inputs, tick-by-tick identity, native execution, or target-hardware acceptance.

Source-copy project configuration removes unrelated visual startup/autoload/plugin resources; matching source and data are otherwise used, with missing visual assets restored by exact blob identity. It runs the actual reference `FlightSession` and `Simulation.step`, with no physics, collision or aircraft-data stub, but no display/rendering, actual controller, audio or normal application observers. The engine is Godot `4.8.beta2.official.cafc17a192acf67903910a68aeb3c076c0907a4b`, Linux x86-64, AMD EPYC 9V74 shared host, as recorded in the raw reports.

Exact identities:

- Baseline field bytes: `873800debb660a65567182f639bfa47e996b15ec67d31250e1d6b6d2d757e644`.
- Timed candidate field bytes: `89b3abae85f69856e65c264449c0d726198794211cf5b03eabd8bf80137f1a9e`.
- Timed helper bytes: `e31fa89135b4be4a6e03dc95491a53f7a0b75bff89cc5a38bdc1f483e14ea105`.
- Baseline `FlightLog.solver_identity()`: `b98411b3c131e0a91bd7e2793799bf2f4d69264e1f29b058084e623ab20a1581`.
- Candidate `FlightLog.solver_identity()`: `7af555bff2a76ad2a0e9468a15b625255099f21042ef12c0d2fdc35c3a085029`. This hash includes the helper: it hashes the sorted file paths and bytes of every `.gd` recursively under `physics`, `sim` and `failures`.
- Unchanged benchmark bytes: `219978bc10463f42db409d5ba96d34e03ccd39b7398c8047608033ba01384a94`. The revision is an annotation supplied to the benchmark, not proof of candidate content; the source and solver hashes identify the measured files.

## Full-session raw results

All numbers below are microseconds per complete accepted simulation tick; each bracket contains the three successive 480-tick batch means and the bold number is their median. Runs are in ABBA process order, with independent process startup and 240 warmup ticks per batch.

| Process | Legacy steady control | Spatial v1, 24 modes |
|---|---:|---:|
| A1 baseline | **562.169** [562.169, 622.777, 512.523] | **3,569.352** [3,650.731, 3,517.935, 3,569.352] |
| B2 combined | **497.579** [557.956, 496.071, 497.579] | **3,428.300** [3,499.056, 3,378.025, 3,428.300] |
| B3 combined | **523.054** [523.054, 514.035, 591.719] | **3,226.971** [3,277.038, 3,226.971, 3,218.706] |
| A4 baseline | **526.802** [517.942, 526.802, 635.308] | **3,499.917** [3,734.173, 3,470.921, 3,499.917] |

B2 versus A1 and B3 versus A4 were respectively −11.49% / −0.71% for the unchanged legacy control and −3.95% / −7.80% for the active spatial case. Treat this as a short shared-host comparison: no confidence interval, sustained frame-rate conclusion or causal split between the two optimizations is justified. Thermal has an endpoint/restore check, not a timed comparison; zero RMS has no timed control in this screen.

The checked commands, source-copy application and complete JSON/logs are under `physics-output`; `run_wind_combined.py` records the exact test, verify and ABBA invocation. `wind-combined-verify.json` and the `wind-combined-*-pair-*.json` files contain full weather, workload, reset and endpoint receipts.
