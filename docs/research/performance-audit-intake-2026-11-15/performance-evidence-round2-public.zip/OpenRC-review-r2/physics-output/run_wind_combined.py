#!/usr/bin/env python3
"""Check and compare the isolated combined wind candidate with the existing harness."""
from pathlib import Path
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT / 'repository'
GODOT = ROOT.parent / 'audit-review/repository/.tools/Godot_v4.8-beta2_linux.x86_64'
RUNNER = REPO / 'tools/godot/run_checked.py'
AIRCRAFT = 'jensen-das-ugly-stik-60'
CASES = ['legacy-v4-steady', 'spatial-v5-modes-24']
VERIFY_CASES = CASES + ['spatial-v5-thermals-24']
BASELINE = json.loads((OUT / 'baseline-verify.json').read_text())
EXPECTED = {c['case_id']: c['final_state_sha256_per_batch'] for c in BASELINE['aircraft'][0]['cases']}


def run(label, app, script, arguments=(), required=(), timeout=120):
    command = [sys.executable, str(RUNNER), '--out-dir', str(OUT / 'checks'), '--label', label,
               '--timeout', str(timeout)]
    for marker in required:
        command += ['--require-text', marker]
    command += ['--', str(GODOT), '--headless', '--audio-driver', 'Dummy', '--path', str(app),
                '--script', 'res://tests/' + script]
    if arguments:
        command += ['--', *arguments]
    env = os.environ.copy()
    for kind in ('DATA', 'CONFIG', 'CACHE'):
        env[f'XDG_{kind}_HOME'] = str(OUT / f'xdg-combined-{kind.lower()}')
    start = time.monotonic()
    print('START', label, flush=True)
    with (OUT / f'{label}-console.log').open('xb') as log:
        process = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
    print('END', label, 'exit=', process.returncode, 'wall_s=', round(time.monotonic() - start, 3), flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)


def benchmark(label, app, cases, verify=False):
    result = OUT / f'{label}.json'
    if result.exists():
        raise SystemExit(f'refusing existing output {result}')
    args = ['--full-session']
    if verify:
        args.append('--verify-only')
    args += [f'--aircraft={AIRCRAFT}', *[f'--case={case}' for case in cases], '--samples=3',
             '--ticks-per-sample=480', '--warmup-ticks=240',
             '--revision=ca529cb88476a22fbb1c8edf957d6917ab9b6042', f'--output={result}']
    verb = 'verified' if verify else 'measured'
    run(label, app, 'bench_spatial_wind.gd', args,
        [f'{verb} {AIRCRAFT} / {case}' for case in cases], timeout=600)
    report = json.loads(result.read_text())
    got = {c['case_id']: c for c in report['aircraft'][0]['cases']}
    if set(got) != set(cases):
        raise SystemExit(f'{label}: unexpected cases {list(got)}')
    for case, entry in got.items():
        if entry['final_state_sha256_per_batch'] != EXPECTED[case]:
            raise SystemExit(f'{label}: final state mismatch for {case}')
        if not entry['final_states_repeatable'] or entry['reset_checks_passed'] != entry['reset_checks_expected']:
            raise SystemExit(f'{label}: restore/repeat failure for {case}')
        if not entry['workload_coverage']['matches_production']:
            raise SystemExit(f'{label}: coverage mismatch for {case}')
    return report


if len(sys.argv) != 2 or sys.argv[1] not in ('check', 'measure'):
    raise SystemExit('usage: run_wind_combined.py check|measure')
app = OUT / 'wind-combined-app'
if sys.argv[1] == 'check':
    for test, marker in [
        ('test_wind_aircraft_flow.gd', 'wind aircraft flow: 91 checks, 0 failed'),
        ('test_spatial_stage_lean.gd', 'Spatial stage lean: 738 checks, 0 failed'),
        ('test_spatial_wind_field.gd', 'spatial wind field: 155 checks, 0 failed'),
        ('test_spatial_wind_prepared.gd', 'prepared spatial wind: 1543 checks, 0 failed'),
    ]:
        run('wind-combined-' + test.removesuffix('.gd'), app, test, required=[marker])
    benchmark('wind-combined-verify', app, VERIFY_CASES, verify=True)
    print('PASS candidate endpoint hashes, rollback checks and production workload coverage match baseline', flush=True)
else:
    for index, role in enumerate(('baseline', 'candidate', 'candidate', 'baseline'), 1):
        benchmark(f'wind-combined-{role}-pair-{index}', OUT / ('baseline-app' if role == 'baseline' else 'wind-combined-app'), CASES)
    print('PASS all four ABBA processes retain baseline final-state hashes and checks', flush=True)
