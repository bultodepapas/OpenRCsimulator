extends SceneTree

# Source-selected differential plus independent, explicit expected outcomes.
# Supply --baseline-source=<absolute path> and --candidate-source=<absolute path>
# after the Godot -- separator. Run using the repository's checked runner.

var checks := 0
var failures := 0


func _check(condition: bool, label: String, detail: Variant = null) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ", label, " ", str(detail))


func _load_source(path: String) -> Script:
	var script := GDScript.new()
	script.source_code = FileAccess.get_file_as_string(path)
	if script.source_code.is_empty() or script.reload() != OK:
		printerr("Cannot load Timber source: ", path)
		return null
	return script


func _face(id: String, material: String, a: Vector3, b: Vector3, c: Vector3, bounds: AABB) -> Dictionary:
	return {id = id, material = material, normal = Vector3(0, 0, 1), bounds = bounds,
		vertices = PackedVector3Array([a, b, c])}


func _index(details: Script, faces: Array[Dictionary]) -> Dictionary:
	return details.call("_build_paint_face_index", faces)


func _normalized_index(index: Dictionary) -> Dictionary:
	var normalized := {}
	for key: Variant in index:
		var label: String
		if key is Vector3i:
			var cell: Vector3i = key
			label = "%d:%d:%d" % [cell.x, cell.y, cell.z]
		elif key is String:
			label = key
		else:
			_check(false, "unexpected grid key type", typeof(key))
			continue
		var ids: Array[String] = []
		for face: Dictionary in index[key]:
			ids.append(str(face.id))
		_check(not normalized.has(label), "normalized coordinates remain unique", label)
		normalized[label] = ids
	return normalized


func _covered(details: Script, point: Vector3, normal: Vector3, faces: Array[Dictionary], index: Dictionary, max_distance: float = 0.02) -> Dictionary:
	return details.call("_covering_paint_at", point, normal, faces, max_distance, 0.7, index)


func _full(details: Script, a: Vector3, b: Vector3, c: Vector3, faces: Array[Dictionary], index: Dictionary) -> String:
	return str(details.call("_fully_covered_paint", a, b, c, Vector3(0, 0, 1), faces, 0.02, 0.7, index))


func _check_index_oracle(baseline: Script, candidate: Script) -> void:
	var v := Vector3.ZERO
	var faces: Array[Dictionary] = [
		_face("a", "red", v, v, v, AABB(Vector3(-0.009, -0.009, -0.001), Vector3(0.018, 0.018, 0.002))),
		_face("b", "blue", v, v, v, AABB(Vector3(0.005, 0.005, -0.001), Vector3(0.001, 0.001, 0.002))),
		_face("zero", "black", v, v, v, AABB(Vector3(0.0101, -0.0101, -0.009), Vector3.ZERO)),
		_face("negative-size", "black", v, v, v, AABB(Vector3(0.019, 0, 0), Vector3(-0.01, 0, 0))),
		# Both derived indices are within 250 of the int32 endpoints. The AABB is
		# zero-sized, so this extreme-coordinate control visits exactly one cell.
		_face("far", "black", v, v, v, AABB(Vector3(21474834, -21474834, 0), Vector3.ZERO)),
	]
	var expected := {
		"-1:-1:-1": ["a"], "-1:-1:0": ["a"], "-1:0:-1": ["a"], "-1:0:0": ["a"],
		"0:-1:-1": ["a"], "0:-1:0": ["a"], "0:0:-1": ["a", "b"], "0:0:0": ["a", "b"],
		"1:-2:-1": ["zero"], "2147483400:-2147483400:0": ["far"],
	}
	var original := _normalized_index(_index(baseline, faces))
	var proposed := _normalized_index(_index(candidate, faces))
	_check(original == expected, "baseline grid matches explicit signed/degenerate oracle", original)
	_check(proposed == expected, "candidate grid matches explicit signed/degenerate oracle", proposed)
	_check(original == proposed, "grid contents and bucket insertion order agree", [original, proposed])
	var none: Array[Dictionary] = []
	_check(_index(baseline, none).is_empty() and _index(candidate, none).is_empty(), "empty faces create an empty index")


func _check_covering(baseline: Script, candidate: Script) -> void:
	var a := Vector3(-0.03, -0.03, 0)
	var b := Vector3(0.03, -0.03, 0)
	var c := Vector3(0, 0.03, 0)
	var bounds := AABB(a, Vector3.ZERO).expand(b).expand(c).grow(0.012)
	var faces: Array[Dictionary] = [
		_face("red", "red", a, b, c, bounds),
		_face("blue", "blue", a, b, c, bounds),
		_face("red-repeat", "red", a, b, c, bounds),
	]
	var original := _index(baseline, faces)
	var proposed := _index(candidate, faces)
	_check(_normalized_index(original) == _normalized_index(proposed), "coincident face buckets preserve order")
	var points: Array[Vector3] = []
	for coordinate: float in [-0.0101, -0.01, -0.0099, -0.0001, 0.0, 0.0001, 0.0099, 0.01, 0.0101]:
		points.append(Vector3(coordinate, 0, 0))
		points.append(Vector3(0, coordinate, 0))
		points.append(Vector3(0, 0, coordinate))
	for point: Vector3 in points:
		var scan := _covered(baseline, point, Vector3(0, 0, 1), faces, {})
		var indexed := _covered(baseline, point, Vector3(0, 0, 1), faces, original)
		var candidate_indexed := _covered(candidate, point, Vector3(0, 0, 1), faces, proposed)
		var candidate_scan := _covered(candidate, point, Vector3(0, 0, 1), faces, {})
		_check(scan.keys() == ["red", "blue"], "scan has both coincident materials in insertion order at " + str(point), scan)
		_check(indexed == scan and indexed.keys() == scan.keys(), "baseline index agrees with scan at " + str(point), [scan, indexed])
		_check(candidate_indexed == scan and candidate_indexed.keys() == scan.keys(), "candidate index agrees with scan at " + str(point), [scan, candidate_indexed])
		_check(candidate_scan == scan and candidate_scan.keys() == scan.keys(), "empty-index fallback agrees at " + str(point), [scan, candidate_scan])
	_check(_full(baseline, a, b, c, faces, original) == "red", "baseline first material wins coincident tie")
	_check(_full(candidate, a, b, c, faces, proposed) == "red", "candidate first material wins coincident tie")
	var reversed: Array[Dictionary] = [faces[1], faces[0], faces[2]]
	_check(_full(baseline, a, b, c, reversed, _index(baseline, reversed)) == "blue", "baseline respects reversed tie order")
	_check(_full(candidate, a, b, c, reversed, _index(candidate, reversed)) == "blue", "candidate respects reversed tie order")
	_check(_covered(baseline, Vector3.ZERO, Vector3(0, 0, -1), faces, original).is_empty(), "opposite normal is refused")
	_check(_covered(candidate, Vector3.ZERO, Vector3(0, 0, -1), faces, proposed).is_empty(), "candidate refuses opposite normal")
	var above := Vector3(0, 0, 0.005)
	_check(_covered(baseline, above, Vector3(0, 0, 1), faces, original, 0.001).is_empty(), "distance threshold is enforced")
	_check(_covered(candidate, above, Vector3(0, 0, 1), faces, proposed, 0.001).is_empty(), "candidate enforces distance threshold")
	var remote: Array[Dictionary] = [_face("remote", "remote", a, b, c, AABB(Vector3(5, 5, 5), Vector3.ZERO))]
	_check(_covered(baseline, Vector3.ZERO, Vector3(0, 0, 1), faces, _index(baseline, remote)).is_empty(), "nonempty missing-cell index does not scan all faces")
	_check(_covered(candidate, Vector3.ZERO, Vector3(0, 0, 1), faces, _index(candidate, remote)).is_empty(), "candidate nonempty missing-cell behavior")
	var degenerate: Array[Dictionary] = [_face("degenerate", "none", Vector3.ZERO, Vector3.ZERO, Vector3.ZERO, AABB(Vector3.ZERO, Vector3.ZERO))]
	_check(_covered(baseline, Vector3.ZERO, Vector3(0, 0, 1), degenerate, _index(baseline, degenerate)).is_empty(), "zero-sized bounds cannot cover a point")
	_check(_covered(candidate, Vector3.ZERO, Vector3(0, 0, 1), degenerate, _index(candidate, degenerate)).is_empty(), "candidate zero-sized bounds cannot cover a point")


func _initialize() -> void:
	var baseline_path := ""
	var candidate_path := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--baseline-source="):
			baseline_path = arg.trim_prefix("--baseline-source=")
		elif arg.begins_with("--candidate-source="):
			candidate_path = arg.trim_prefix("--candidate-source=")
	if baseline_path.is_empty() or candidate_path.is_empty():
		printerr("Both --baseline-source and --candidate-source are required.")
		quit(2)
		return
	var baseline := _load_source(baseline_path)
	var candidate := _load_source(candidate_path)
	if baseline == null or candidate == null:
		quit(2)
		return
	_check_index_oracle(baseline, candidate)
	_check_covering(baseline, candidate)
	print("Timber grid differential: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
