# Timber paint-face grid: source review and focused differential

At review pin `ca529cb88476a22fbb1c8edf957d6917ab9b6042`, the isolated two-line candidate changes the paint-face grid's internal keys from decimal `x:y:z` strings to `Vector3i`, both where buckets are built and where they are queried. The only current production caller builds the index locally for that repair and then queries it; it does not retain or serialize the dictionary. For the existing synchronous path, both versions obtain each coordinate from an already-created `Vector3i`, preserving the same signed 32-bit cell coordinates and bucket insertion order. Decimal triples are unique for those coordinates; a matching `Vector3i` key identifies the same bucket. Hash collisions are resolved by dictionary key equality, rather than becoming bucket collisions.

This is an internal representation change, **not** universal dictionary-API equivalence: a third-party direct call that constructs an old nonempty string-key dictionary and passes it to the new query helper would no longer find those buckets. The current repository's producer and consumer are paired; external or cross-version callers would need to rebuild or adapt their indices. Nonfinite or enormous-range input behavior, concurrent mutation and every possible external caller are not established by the focused test.

## Checked differential

The frozen baseline and candidate passed **945 checks with zero failures** under the pinned Godot `4.8.beta2.official.cafc17a19` in the focused project. The checked-runner report is `root-output/checks/timber-grid-differential-final-puzrtbfr/report.json`. It is a correctness check, not a timing, rendering, target-hardware, identity-migration or release qualification.

The fixture normalizes only the dictionary key representation for comparisons and retains bucket contents and order. Explicit expected cell-to-face mappings independently test positive and negative coordinates, overlapping buckets, a zero-size AABB, a negative-size AABB and a single cell near the signed 32-bit endpoints. Covering queries at and on both sides of grid boundaries and zero on all three axes are checked against the original full-face scan. Coincident faces test material insertion/tie order and reversed order; additional controls cover repeated materials, opposite normals, distance limits, empty-index fallback, missing cells in a nonempty index, and degenerate geometry.

The test's explicit expected mappings and outcomes can be adapted into a permanent single-candidate CI regression, while its current two source arguments preserve baseline-versus-candidate evidence. It does not assume a baseline source file will remain available in a future application package.

The compact standalone regression is now prepared as `physics-output/test_timber_paint_grid.gd`, with pinned-engine-generated UID file `test_timber_paint_grid.gd.uid` (`uid://4wscadfbha6l`). It uses the ordinary `res://aircraft/timber_visual_details.gd` preload and explicit bucket and material-selection oracles, accepting either internal key representation. In separate private project copies, the exact same test passed **59 checks with zero failures** against the frozen baseline and then **59 checks with zero failures** against the grid candidate. Checked receipts: `checks/timber-grid-permanent-baseline-sa54fhkc/report.json` and `checks/timber-grid-permanent-candidate-3s0bf9m6/report.json`. The checked pinned-editor import that generated the UID is `checks/timber-grid-test-uid-import-3fed1zd8/report.json`; the UID was not present in the tracked checkout's `.uid` files. Its `test_*.gd` name follows the repository's automatic test discovery.

## Files and remaining gates

- Frozen baseline `root-output/timber_visual_details_baseline.gd`: SHA-256 `6b200f12db0e672624b044076457f71d0c67597cb1d69ba3a0cf73ff9ae4b945`.
- Frozen two-line candidate `root-output/timber_visual_details_grid_candidate.gd`: SHA-256 `877b6c87e58381febff96c137e164d64d40d9a242a3d8275eb47a867d9ed7db7`.
- Focused differential `physics-output/timber_grid_differential.gd`: SHA-256 `d36c5a8130b87524985462d22da8a4cdbdb35b7c7adc37fde2790fa9ab25dacb`.
- Standalone test `physics-output/test_timber_paint_grid.gd`: SHA-256 `7a90f382bb3699eb81466b13a3cbd416e857c07c5251289d8d22b149a5e3ec7a`; UID-file SHA-256 `19cd26b8cc1dab04b0a07899de809cee659abf23af6625aaa3018dd3374a3b3b`.

Changing `timber_visual_details.gd` changes the procedural Timber source identity. Existing distributed custom-paint kit identity and archives must remain accepted through an exact reviewed compatibility pair after geometry/material/UV parity; do not blindly update the kit base identity. The focused check does not replace imported-asset, cold/warm cache, package, release or actual renderer checks.
