#!/usr/bin/env python3
"""Build a deliberately isolated stage-local phase-reuse experiment.

Only writes physics-output/candidate. No repository source or existing fixture is modified.
Run the project's checked runner and existing full-session benchmark against a separately
assembled app copy after inspecting these generated diffs.
"""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
source = root.parent / "repository" / "app"
target = root / "candidate"
files = ["physics/wind_aircraft_flow.gd", "physics/wind_field.gd",
         "physics/wind_spatial_field.gd", "sim/environment.gd"]
for name in files:
    path = target / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((source / name).read_bytes())

def replace_one(contents, old, new):
    if contents.count(old) != 1:
        raise RuntimeError(f"expected exactly one occurrence: {old!r}; found {contents.count(old)}")
    return contents.replace(old, new)

def function(contents, start, following):
    a = contents.index(start)
    b = contents.index(following, a)
    return contents[a:b]

# Spatial field: clone two existing routines verbatim and alter only how the
# single time-only remainder is supplied. Keep existing public method untouched.
path = target / "physics/wind_spatial_field.gd"
contents = path.read_text()
sample = function(contents, "func sample_world(", "\n\nfunc _profile_wind(")
sample = replace_one(sample,
    "func sample_world(position_ned: PackedFloat64Array, simulation_time_s: float) -> Dictionary:",
    "func _sample_world_phase_stage(position_ned: PackedFloat64Array, simulation_time_s: float, scratch: Dictionary) -> Dictionary:")
sample = replace_one(sample,
    "_turbulence_wind(position_ned[0], position_ned[1], height_agl, epoch_time)",
    "_turbulence_wind_phase_stage(position_ned[0], position_ned[1], height_agl, epoch_time, scratch)")
contents = replace_one(contents, "\n\nfunc _profile_wind(", "\n\n" + sample + "\n\nfunc _profile_wind(")

turbulence = function(contents, "func _turbulence_wind(", "\n\nfunc _resolve_modes(")
turbulence = replace_one(turbulence,
    "func _turbulence_wind(north_m: float, east_m: float, height_agl: float, epoch_time: float) -> PackedFloat64Array:",
    "func _turbulence_wind_phase_stage(north_m: float, east_m: float, height_agl: float, epoch_time: float, scratch: Dictionary) -> PackedFloat64Array:")
turbulence = replace_one(turbulence,
    "\tfor mode_offset: int in range(0, _modes.size(), MODE_SCALAR_COUNT):",
    """\t# Do not store on the shared field. The caller owns this one-stage scratch.
\t# A changed epoch, layout, or live omega must take the original calculation.
\tvar mode_count: int = _modes.size() / MODE_SCALAR_COUNT
\tvar eligible: bool = _modes.size() % MODE_SCALAR_COUNT == 0 and mode_count <= 64 and epoch_time != 0.0 and is_finite(epoch_time)
\tvar saved_omegas: PackedFloat64Array = scratch.omegas
\tvar saved_phases: PackedFloat64Array = scratch.phases
\tvar ready: bool = bool(scratch.ready)
\tvar reuse: bool = eligible and ready and float(scratch.epoch) == epoch_time and saved_omegas.size() == mode_count and saved_phases.size() == mode_count
\tvar record: bool = eligible and not ready
\tif record:
\t\tsaved_omegas.resize(mode_count)
\t\tsaved_phases.resize(mode_count)
\tvar mode_index: int = 0
\tfor mode_offset: int in range(0, _modes.size(), MODE_SCALAR_COUNT):""")
turbulence = replace_one(turbulence,
    """\t\tvar temporal_phase := omega * epoch_time
\t\tvar phase := fposmod(fposmod(spatial_phase, TAU_F64) + fposmod(temporal_phase, TAU_F64), TAU_F64)""",
    """\t\tvar temporal_reduced: float
\t\tif reuse and omega != 0.0 and is_finite(omega) and omega == saved_omegas[mode_index]:
\t\t\ttemporal_reduced = saved_phases[mode_index]
\t\telse:
\t\t\tvar temporal_phase := omega * epoch_time
\t\t\ttemporal_reduced = fposmod(temporal_phase, TAU_F64)
\t\tif record:
\t\t\tsaved_omegas[mode_index] = omega
\t\t\tsaved_phases[mode_index] = temporal_reduced
\t\tvar phase := fposmod(fposmod(spatial_phase, TAU_F64) + temporal_reduced, TAU_F64)""")
turbulence = replace_one(turbulence,
    """\t\tresult_east -= axis_north * horizontal_derivative
\t\tresult_down += vertical_velocity
\treturn PackedFloat64Array([result_north, result_east, result_down])""",
    """\t\tresult_east -= axis_north * horizontal_derivative
\t\tresult_down += vertical_velocity
\t\tmode_index += 1
\tif record:
\t\tscratch.omegas = saved_omegas
\t\tscratch.phases = saved_phases
\t\tscratch.epoch = epoch_time
\t\tscratch.ready = true
\treturn PackedFloat64Array([result_north, result_east, result_down])""")
contents = replace_one(contents, "\n\nfunc _resolve_modes(", "\n\n" + turbulence + "\n\nfunc _resolve_modes(")
path.write_text(contents)

# WindField: retain the original public method and exact point validation.
path = target / "physics/wind_field.gd"
contents = path.read_text()
method = function(contents, "func sample_world(", "\n\nfunc _apply_config(")
method = replace_one(method,
    "func sample_world(position_ned: PackedFloat64Array, time_s: float) -> PackedFloat64Array:",
    "func _sample_world_phase_stage(position_ned: PackedFloat64Array, time_s: float, scratch: Dictionary) -> PackedFloat64Array:")
method = replace_one(method,
    """\t\tvar result: Dictionary = _spatial.sample_world(position_ned, time_s)""",
    """\t\tvar result: Dictionary
\t\tif _spatial == scratch.owner and _spatial.get_script() == SpatialField:
\t\t\tresult = _spatial._sample_world_phase_stage(position_ned, time_s, scratch)
\t\telse:
\t\t\tresult = _spatial.sample_world(position_ned, time_s)""")
contents = replace_one(contents, "\n\nfunc _apply_config(", "\n\n" + method + "\n\nfunc _apply_config(")
path.write_text(contents)

# Environment: retain the public method and its precise turbulence callback order.
path = target / "sim/environment.gd"
contents = path.read_text()
method = function(contents, "func wind_world(", "\n\n## Atmosphere at `down_m`")
method = replace_one(method,
    "func wind_world(position_ned: PackedFloat64Array, time_s: float) -> PackedFloat64Array:",
    "func _wind_world_phase_stage(position_ned: PackedFloat64Array, time_s: float, scratch: Dictionary) -> PackedFloat64Array:")
method = replace_one(method,
    "\tvar out: PackedFloat64Array = weather.sample_world(position_ned, time_s)",
    """\tvar out: PackedFloat64Array
\tif is_instance_valid(weather) and weather.get_script() == WeatherField:
\t\tout = weather._sample_world_phase_stage(position_ned, time_s, scratch)
\telse:
\t\tout = weather.sample_world(position_ned, time_s)""")
contents = replace_one(contents, "\n\n## Atmosphere at `down_m`", "\n\n" + method + "\n\n## Atmosphere at `down_m`")
path.write_text(contents)

# Fixed-wing point sampling: branch only for exact built-ins and a known-safe
# callback. Arbitrary environment/provider/callback overrides retain dispatch.
path = target / "physics/wind_aircraft_flow.gd"
contents = path.read_text()
contents = replace_one(contents, 'const Simulation := preload("res://sim/simulation.gd")',
    '''const Simulation := preload("res://sim/simulation.gd")
const PhaseEnvironment := preload("res://sim/environment.gd")
const PhaseWeather := preload("res://physics/wind_field.gd")
const PhaseSpatial := preload("res://physics/wind_spatial_field.gd")''')
helper = '''
## Experimental only: cache time terms for one synchronous built-in point sample.
## Public/derived environment and weather methods retain their normal dispatch.
static func _phase_stage_scratch(environment: Object) -> Variant:
\tif environment.get_script() != PhaseEnvironment:
\t\treturn null
\tvar weather: Variant = environment.get("weather")
\tif not is_instance_valid(weather) or weather.get_script() != PhaseWeather:
\t\treturn null
\tvar spatial: Variant = weather.get("_spatial")
\tif not is_instance_valid(spatial) or spatial.get_script() != PhaseSpatial or spatial.get("_thermal_field") != null:
\t\treturn null
\tvar noise: Callable = environment.get("turbulence")
\tif noise.is_valid():
\t\tvar session: Object = noise.get_object()
\t\tif not is_instance_valid(session) or session.get_script() != load("res://sim/flight_session.gd"):
\t\t\treturn null
\t\tif noise != Callable(session, "_turbulence_noise") or session.get("environment") != environment or weather.has_turbulence():
\t\t\treturn null
\treturn {owner = spatial, ready = false, epoch = NAN,
\t\tomegas = PackedFloat64Array(), phases = PackedFloat64Array()}


static func _phase_stage_query(environment: Object, position: PackedFloat64Array, time_s: float, scratch: Variant) -> Variant:
\tif scratch == null or environment.get_script() != PhaseEnvironment:
\t\treturn environment.call("wind_world", position, time_s)
\treturn environment.call("_wind_world_phase_stage", position, time_s, scratch)


'''
contents = replace_one(contents, "## One immutable stage's query context.", helper + "## One immutable stage's query context.")
contents = replace_one(contents,
    """\tvar reference_wind_value: Variant = environment.call("wind_world", position_ned.duplicate(), time_s)""",
    """\tvar phase_scratch: Variant = _phase_stage_scratch(environment)
\tvar reference_wind_value: Variant = _phase_stage_query(environment, position_ned.duplicate(), time_s, phase_scratch)""")
contents = replace_one(contents,
    """\t\tvar station_wind_value: Variant = environment.call("wind_world", station_position.duplicate(), time_s)""",
    """\t\tvar station_wind_value: Variant = _phase_stage_query(environment, station_position.duplicate(), time_s, phase_scratch)""")
path.write_text(contents)

for name in files:
    print(hashlib.sha256((target / name).read_bytes()).hexdigest(), name)
