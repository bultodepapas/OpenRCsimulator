# Fixed-datum station-flow bundle and ephemeral Air receipt for explicit spatial weather.
# The aircraft dynamics owns forces; this module samples ambient air and local kinematics only.
extends RefCounted

const M := preload("res://physics/math3d.gd")
const RB := preload("res://physics/rigid_body.gd")
const Aero := preload("res://physics/aero.gd")
const Air := preload("res://physics/air_data.gd")
const Simulation := preload("res://sim/simulation.gd")
const PhaseEnvironment := preload("res://sim/environment.gd")
const PhaseWeather := preload("res://physics/wind_field.gd")
const PhaseSpatial := preload("res://physics/wind_spatial_field.gd")

const LAW := "m5-w05c-r1-fixed-datum-station-relative-flow-v1"
const STAGE_AIR_LAW := "m5-w05c-r2-point-air-v1"



## Experimental only: cache time terms for one synchronous built-in point sample.
## Public/derived environment and weather methods retain their normal dispatch.
static func _phase_stage_scratch(environment: Object) -> Variant:
	if environment.get_script() != PhaseEnvironment:
		return null
	var weather: Variant = environment.get("weather")
	if not is_instance_valid(weather) or weather.get_script() != PhaseWeather:
		return null
	var spatial: Variant = weather.get("_spatial")
	if not is_instance_valid(spatial) or spatial.get_script() != PhaseSpatial or spatial.get("_thermal_field") != null:
		return null
	var noise: Callable = environment.get("turbulence")
	if noise.is_valid():
		var session: Object = noise.get_object()
		if not is_instance_valid(session) or session.get_script() != load("res://sim/flight_session.gd"):
			return null
		if noise != Callable(session, "_turbulence_noise") or session.get("environment") != environment or weather.has_turbulence():
			return null
	return {owner = spatial, ready = false, epoch = NAN,
		omegas = PackedFloat64Array(), phases = PackedFloat64Array()}


static func _phase_stage_query(environment: Object, position: PackedFloat64Array, time_s: float, scratch: Variant) -> Variant:
	if scratch == null or environment.get_script() != PhaseEnvironment:
		return environment.call("wind_world", position, time_s)
	return environment.call("_wind_world_phase_stage", position, time_s, scratch)


## One immutable stage's query context. Only the provider reference is shared; queries must be pure.
## Extra wash stations use their actual aerodynamic force arms, not the neutral coverage geometry.
class StagePointSampler:
	extends RefCounted
	var position_ned := PackedFloat64Array()
	var q_body_to_ned := PackedFloat64Array()
	var q_ned_to_body := PackedFloat64Array()
	var reference_wind := PackedFloat64Array()
	var environment: Object
	var time_s := 0.0

	func delta_at(arm: PackedFloat64Array) -> PackedFloat64Array:
		if not _finite3(arm) or not is_instance_valid(environment):
			return PackedFloat64Array([NAN, NAN, NAN])
		var position := M.add(position_ned, M.q_rotate(q_body_to_ned, arm))
		if not _finite3(position):
			return PackedFloat64Array([NAN, NAN, NAN])
		var wind: Variant = environment.call("wind_world", position, time_s)
		if not _finite3(wind):
			return PackedFloat64Array([NAN, NAN, NAN])
		if wind[0] == reference_wind[0] and wind[1] == reference_wind[1] and wind[2] == reference_wind[2]:
			return PackedFloat64Array([0.0, 0.0, 0.0])
		var delta := M.q_rotate(q_ned_to_body, M.sub(reference_wind, wind))
		return delta if _finite3(delta) else PackedFloat64Array([NAN, NAN, NAN])

	static func _finite3(value: Variant) -> bool:
		if not value is PackedFloat64Array or value.size() != 3:
			return false
		for component: float in value:
			if not is_finite(component):
				return false
		return true


## Stage-local Air contract, not a checkpoint. Always selects physical point inflow,
## including in uniform air; do not toggle the law when the instantaneous gradient happens to be zero.
## No caller may reuse this result for another body stage, density, model or time.
## Production consumers may omit the diagnostic flow bundle; all samples and validation still run.
static func stage_air(s: PackedFloat64Array, model: Dictionary, environment: Object, time_s: float,
		rho := Air.RHO_SEA_LEVEL, aero_law: String = "", include_flow := true) -> Dictionary:
	if aero_law not in ["", Aero.SPATIAL_CONTINUATION_LAW]:
		return {ok = false, errors = PackedStringArray(["unsupported spatial aerodynamic law"]), air = {}}
	if not is_finite(rho) or rho <= 0.0:
		return {ok = false, errors = PackedStringArray(["invalid stage density"]), air = {}}
	var flow := _sample(s, model, environment, time_s, include_flow)
	if not flow.ok:
		return {ok = false, errors = flow.errors, air = {}}
	if flow.propulsion_index < 0:
		return {ok = false, errors = PackedStringArray(["powered stage needs a supported hub or intake"]), air = {}}
	var air := Air.compute(s, flow.reference_wind_ned, rho)
	if not is_finite(air.V) or not is_finite(air.qbar):
		return {ok = false, errors = PackedStringArray(["nonfinite stage air data"]), air = {}}
	var point_sampler := StagePointSampler.new()
	# Detached pose for this stage only. Do not normalize an intermediate RK quaternion.
	point_sampler.position_ned = s.slice(RB.POS, RB.POS + 3)
	point_sampler.q_body_to_ned = s.slice(RB.ATT, RB.ATT + 4)
	point_sampler.q_ned_to_body = M.q_conj(point_sampler.q_body_to_ned)
	point_sampler.reference_wind = flow.reference_wind_ned.duplicate()
	point_sampler.environment = environment
	point_sampler.time_s = time_s
	air.spatial_air_law = STAGE_AIR_LAW
	if not aero_law.is_empty():
		air.spatial_aero_law = aero_law
	air.spatial_state = s.duplicate()
	air.spatial_time_s = time_s
	air.spatial_rho = rho
	air.aero_station_delta_body = flow.delta_body.slice(0, 3 * (flow.wing_count + 2))
	# A method Callable stores an object ID; retain the RefCounted target explicitly for the stage's lifetime.
	air.spatial_sampler = point_sampler
	air.ambient_delta_body_at = point_sampler.delta_at
	if flow.propulsion_index >= 0:
		var start: int = 3 * flow.propulsion_index
		air.propulsion_air_body = flow.relative_body.slice(start, start + 3) if include_flow else flow.propulsion_air_body
		# Preserve the wake closure's datum-flow convention; rotation belongs only to powered-device inflow.
		air.wake_source_delta_body = flow.delta_body.slice(start, start + 3)
	var result := {ok = true, errors = PackedStringArray(), air = air}
	if include_flow:
		result.flow = flow
	return result


## Receipt check for the load entrypoint. A stage context is ephemeral, never a checkpoint or cross-stage cache.
static func matches_stage(air: Dictionary, s: PackedFloat64Array, rho: float) -> bool:
	var state: Variant = air.get("spatial_state")
	var deltas: Variant = air.get("aero_station_delta_body")
	var sampler: Variant = air.get("ambient_delta_body_at")
	var time: Variant = air.get("spatial_time_s")
	var density: Variant = air.get("spatial_rho")
	return air.get("spatial_air_law", "") == STAGE_AIR_LAW \
		and air.get("spatial_aero_law", "") in ["", Aero.SPATIAL_CONTINUATION_LAW] \
		and state is PackedFloat64Array and state.to_byte_array() == s.to_byte_array() \
		and deltas is PackedFloat64Array and Aero._spatial_finite(deltas, 3 * (Aero.WING_STATIONS_PER_SIDE * 2 + 2)) \
		and sampler is Callable and sampler.is_valid() \
		and typeof(time) in [TYPE_FLOAT, TYPE_INT] and is_finite(float(time)) and float(time) >= 0.0 \
		and typeof(density) in [TYPE_FLOAT, TYPE_INT] and is_finite(float(density)) and float(density) == rho \
		and _finite3(air.get("propulsion_air_body")) and _finite3(air.get("wake_source_delta_body"))


## Build immutable station arms in body FRD from the authored datum O.
## Order: main-wing envelope stations, horizontal slot, vertical tail, then optional hub/intake.
## Explicit tailless models reserve the horizontal slot at O but never sample it or apply a load there.
static func geometry(model: Variant) -> Dictionary:
	var errors := PackedStringArray()
	if typeof(model) != TYPE_DICTIONARY:
		errors.append("model must be a Dictionary")
		return _geometry_failure(errors)
	var cg_value: Variant = model.get("cg_le", null)
	if not _finite3(cg_value):
		errors.append("model.cg_le must be three finite authored-datum LE coordinates")
		return _geometry_failure(errors)
	var cg: PackedFloat64Array = cg_value

	var reference_value: Variant = model.get("reference", null)
	if typeof(reference_value) != TYPE_DICTIONARY:
		errors.append("model.reference must be a Dictionary")
		return _geometry_failure(errors)
	var reference: Dictionary = reference_value
	var arp_value: Variant = reference.get("arp_le", null)
	if not _finite3(arp_value):
		errors.append("model.reference.arp_le must be three finite LE coordinates")
		return _geometry_failure(errors)
	var span_value: Variant = reference.get("b", null)
	if typeof(span_value) not in [TYPE_FLOAT, TYPE_INT] or not is_finite(float(span_value)) or float(span_value) <= 0.0:
		errors.append("model.reference.b must be a finite positive span")
		return _geometry_failure(errors)
	var half_span: float = 0.5 * float(span_value)

	var envelope_value: Variant = model.get("envelope", null)
	if typeof(envelope_value) != TYPE_DICTIONARY:
		errors.append("model.envelope must be a Dictionary")
		return _geometry_failure(errors)
	var envelope: Dictionary = envelope_value
	var station_value: Variant = envelope.get("station_ys", null)
	var wing_count: int = Aero.WING_STATIONS_PER_SIDE * 2
	if typeof(station_value) != TYPE_PACKED_FLOAT64_ARRAY or station_value.size() != wing_count:
		errors.append("model.envelope.station_ys must contain the validated left-to-right wing stations")
		return _geometry_failure(errors)
	var station_ys: PackedFloat64Array = station_value
	for i in station_ys.size():
		if not is_finite(station_ys[i]):
			errors.append("model.envelope.station_ys[%d] must be finite" % i)
		elif absf(station_ys[i]) >= half_span:
			errors.append("model.envelope.station_ys[%d] must lie inside the declared semi-span" % i)
		elif i > 0 and station_ys[i] <= station_ys[i - 1]:
			errors.append("model.envelope.station_ys must be strictly ordered left to right")
			break
	var right_side_start: int = wing_count >> 1
	if station_ys[right_side_start - 1] >= 0.0 or station_ys[right_side_start] <= 0.0:
		errors.append("model.envelope.station_ys must contain stations on both sides of the centreline")
	if not errors.is_empty():
		return _geometry_failure(errors)

	var surfaces_value: Variant = model.get("surfaces", null)
	if typeof(surfaces_value) != TYPE_DICTIONARY:
		errors.append("model.surfaces must be a Dictionary")
		return _geometry_failure(errors)
	var surfaces: Dictionary = surfaces_value
	var layout_error := Aero.spatial_layout_error(model, wing_count)
	if not layout_error.is_empty():
		errors.append(layout_error)
		return _geometry_failure(errors)
	var tailless := surfaces.has("tailless")
	var station_x: PackedFloat64Array = surfaces.get("tailless", {}).get("station_x", PackedFloat64Array())
	var horizontal_value: Variant = surfaces.get("horizontal", null)
	var vertical_value: Variant = surfaces.get("vertical", null)
	if (not tailless and typeof(horizontal_value) != TYPE_DICTIONARY) or typeof(vertical_value) != TYPE_DICTIONARY:
		errors.append("model.surfaces.horizontal and vertical must be Dictionaries")
		return _geometry_failure(errors)
	var vertical: Dictionary = vertical_value
	var horizontal_position: Variant = null if tailless else horizontal_value.get("position", null)
	var vertical_position: Variant = vertical.get("position", null)
	if not tailless and not _finite3(horizontal_position):
		errors.append("model.surfaces.horizontal.position must be three finite LE coordinates")
	if not _finite3(vertical_position):
		errors.append("model.surfaces.vertical.position must be three finite LE coordinates")
	if not errors.is_empty():
		return _geometry_failure(errors)

	var offsets := PackedFloat64Array()
	var wing_arm: PackedFloat64Array = Aero._arm(arp_value, cg)
	if not _finite3(wing_arm):
		errors.append("main-wing aerodynamic reference arm is nonfinite")
		return _geometry_failure(errors)
	for i in wing_count:
		# Match the derived, swept force/rotation arms in Aero._wing_flow/_local_loads.
		offsets.append(wing_arm[0] if not tailless else -(station_x[i] - cg[0]) + 0.0)
		offsets.append(wing_arm[1] + station_ys[i])
		offsets.append(wing_arm[2])

	var horizontal_index: int = -1 if tailless else wing_count
	var horizontal_arm: PackedFloat64Array = PackedFloat64Array([0.0, 0.0, 0.0]) if tailless else Aero._arm(horizontal_position, cg)
	var vertical_index: int = wing_count + 1
	var vertical_arm: PackedFloat64Array = Aero._arm(vertical_position, cg)
	if not _finite3(horizontal_arm):
		errors.append("horizontal-tail arm is nonfinite")
	if not _finite3(vertical_arm):
		errors.append("vertical-tail arm is nonfinite")
	if not errors.is_empty():
		return _geometry_failure(errors)
	offsets.append_array(horizontal_arm)
	offsets.append_array(vertical_arm)

	var propulsion_index: int = -1
	var propulsion_value: Variant = model.get("propulsion", null)
	if propulsion_value != null:
		if typeof(propulsion_value) != TYPE_DICTIONARY:
			errors.append("model.propulsion must be a Dictionary when present")
		else:
			var propulsion: Dictionary = propulsion_value
			var kind: String = str(propulsion.get("kind", "glow_prop"))
			var location_key: String = ""
			if kind == "turbine":
				location_key = "intake_offset"
			elif kind in ["glow_prop", "electric_prop"]:
				location_key = "offset"
			elif kind == "none":
				location_key = ""
			else:
				errors.append("model.propulsion.kind has no supported station definition")
			if not location_key.is_empty():
				var propulsion_location: Variant = propulsion.get(location_key, null)
				if not _finite3(propulsion_location):
					errors.append("model.propulsion.%s must be three finite authored-datum coordinates" % location_key)
				else:
					var point: PackedFloat64Array = propulsion_location
					# Propulsion offsets are already relative to authored O. Convert only [aft,right,up] axes to FRD;
					# subtracting cg_le again would move a finite-resource vehicle's fixed datum.
					offsets.append(-point[0])
					offsets.append(point[1])
					offsets.append(-point[2])
					propulsion_index = wing_count + 2
	if not errors.is_empty():
		return _geometry_failure(errors)
	for value: float in offsets:
		if not is_finite(value):
			errors.append("station offsets contain a nonfinite body-frame coordinate")
			return _geometry_failure(errors)
	return {
		"ok": true,
		"errors": PackedStringArray(),
		"offsets_body": offsets,
		"wing_count": wing_count,
		"horizontal_index": horizontal_index,
		"vertical_index": vertical_index,
		"propulsion_index": propulsion_index,
	}


## Sample the same position/time wind law at O and every station, returning diagnostic local relative flows.
## relative_body includes datum air-relative velocity, one omega×r term, and the spatial wind delta.
static func sample(s: Variant, model: Variant, environment: Variant, time_s: float) -> Dictionary:
	return _sample(s, model, environment, time_s, true)


## One sampling/validation law for diagnostic and lean receipts. Only retained output differs.
static func _sample(s: Variant, model: Variant, environment: Variant, time_s: float, include_flow: bool) -> Dictionary:
	var station_geometry: Dictionary = geometry(model)
	if not station_geometry.ok:
		return _sample_failure(station_geometry.errors, station_geometry, time_s)
	var errors := PackedStringArray()
	if typeof(s) != TYPE_PACKED_FLOAT64_ARRAY or not Simulation.state_is_valid(s):
		errors.append("state must be a finite full rigid-body state with a nondegenerate quaternion")
	if not is_finite(time_s) or time_s < 0.0:
		errors.append("time_s must be finite and nonnegative")
	if environment == null or typeof(environment) != TYPE_OBJECT or not environment.has_method("wind_world"):
		errors.append("environment must provide wind_world(position_ned, time_s)")
	if not errors.is_empty():
		return _sample_failure(errors, station_geometry, time_s)

	var state: PackedFloat64Array = s
	# RK stages use the supplied quaternion directly; normalization belongs to the integrator's accepted-step path.
	# Match Air.compute and the existing stage-point transform even when an intermediate stage is not exactly unit length.
	var q_body_to_ned: PackedFloat64Array = state.slice(RB.ATT, RB.ATT + 4)
	var q_ned_to_body: PackedFloat64Array = M.q_conj(q_body_to_ned)
	var position_ned: PackedFloat64Array = state.slice(RB.POS, RB.POS + 3)
	var phase_scratch: Variant = _phase_stage_scratch(environment)
	var reference_wind_value: Variant = _phase_stage_query(environment, position_ned.duplicate(), time_s, phase_scratch)
	if not _finite3(reference_wind_value):
		errors.append("environment rejected the datum wind sample")
		return _sample_failure(errors, station_geometry, time_s)
	var reference_wind: PackedFloat64Array = reference_wind_value.duplicate()
	var reference_air_body: PackedFloat64Array = Air.compute(state, reference_wind).v_air
	if not _finite3(reference_air_body):
		errors.append("datum air-relative body velocity is nonfinite")
		return _sample_failure(errors, station_geometry, time_s)

	var offsets: PackedFloat64Array = station_geometry.offsets_body
	var station_count: int = offsets.size() / 3
	var positions_ned := PackedFloat64Array()
	var wind_ned := PackedFloat64Array()
	var relative_body := PackedFloat64Array()
	var propulsion_air_body := PackedFloat64Array()
	var delta_body := PackedFloat64Array()
	var omega: PackedFloat64Array = state.slice(RB.RATE, RB.RATE + 3)
	var uniform := true
	for i in station_count:
		if i == int(station_geometry.wing_count) and int(station_geometry.horizontal_index) < 0:
			# Reserved ABI slot, not a physical surface. Do not create a weather probe,
			# angular-flow contribution or extra domain/refusal point for an absent tail.
			if include_flow:
				positions_ned.append_array(position_ned)
				wind_ned.append_array(reference_wind)
				relative_body.append_array(reference_air_body)
			delta_body.append_array(PackedFloat64Array([0.0, 0.0, 0.0]))
			continue
		var arm := offsets.slice(i * 3, i * 3 + 3)
		var station_position: PackedFloat64Array = M.add(position_ned, M.q_rotate(q_body_to_ned, arm))
		if not _finite3(station_position):
			errors.append("station %d world position is nonfinite" % i)
			return _sample_failure(errors, station_geometry, time_s)
		var station_wind_value: Variant = _phase_stage_query(environment, station_position.duplicate(), time_s, phase_scratch)
		if not _finite3(station_wind_value):
			errors.append("environment rejected wind at station %d" % i)
			return _sample_failure(errors, station_geometry, time_s)
		var station_wind: PackedFloat64Array = station_wind_value.duplicate()
		var station_uniform: bool = _same3(reference_wind, station_wind)
		uniform = uniform and station_uniform
		var delta: PackedFloat64Array
		if station_uniform:
			# Preserve the exact uniform-field limit rather than subtracting and rotating equal samples.
			delta = PackedFloat64Array([0.0, 0.0, 0.0])
		else:
			delta = M.q_rotate(q_ned_to_body, M.sub(reference_wind, station_wind))
		var rate_delta: PackedFloat64Array = M.cross(omega, arm)
		var local_air: PackedFloat64Array = reference_air_body.duplicate()
		for axis in 3:
			if rate_delta[axis] != 0.0:
				local_air[axis] += rate_delta[axis]
		if not station_uniform:
			for axis in 3:
				if delta[axis] != 0.0:
					local_air[axis] += delta[axis]
		if not _finite3(delta) or not _finite3(local_air):
			errors.append("station %d relative flow is nonfinite" % i)
			return _sample_failure(errors, station_geometry, time_s)
		if include_flow:
			positions_ned.append_array(station_position)
			wind_ned.append_array(station_wind)
			relative_body.append_array(local_air)
		elif i == int(station_geometry.propulsion_index):
			propulsion_air_body = local_air
		delta_body.append_array(delta)

	if not include_flow:
		return {ok = true, reference_wind_ned = reference_wind, delta_body = delta_body,
			wing_count = int(station_geometry.wing_count), propulsion_index = int(station_geometry.propulsion_index),
			propulsion_air_body = propulsion_air_body}
	return {
		"ok": true,
		"errors": PackedStringArray(),
		"law": LAW,
		"position_ned": position_ned,
		"time_s": time_s,
		"offsets_body": offsets.duplicate(),
		"positions_ned": positions_ned,
		"wind_ned": wind_ned,
		"relative_body": relative_body,
		"delta_body": delta_body,
		"reference_wind_ned": reference_wind,
		"reference_air_body": reference_air_body,
		"uniform": uniform,
		"wing_count": int(station_geometry.wing_count),
		"horizontal_index": int(station_geometry.horizontal_index),
		"vertical_index": int(station_geometry.vertical_index),
		"propulsion_index": int(station_geometry.propulsion_index),
		"indices": {
			"wing_count": int(station_geometry.wing_count),
			"horizontal_index": int(station_geometry.horizontal_index),
			"vertical_index": int(station_geometry.vertical_index),
			"propulsion_index": int(station_geometry.propulsion_index),
		},
	}


static func _geometry_failure(errors: PackedStringArray) -> Dictionary:
	return {
		"ok": false,
		"errors": errors.duplicate(),
		"offsets_body": PackedFloat64Array(),
		"wing_count": 0,
		"horizontal_index": -1,
		"vertical_index": -1,
		"propulsion_index": -1,
	}


static func _sample_failure(errors: PackedStringArray, station_geometry: Dictionary, time_s: float) -> Dictionary:
	return {
		"ok": false,
		"errors": errors.duplicate(),
		"law": LAW,
		"position_ned": PackedFloat64Array(),
		"time_s": time_s,
		"offsets_body": station_geometry.get("offsets_body", PackedFloat64Array()).duplicate(),
		"positions_ned": PackedFloat64Array(),
		"wind_ned": PackedFloat64Array(),
		"relative_body": PackedFloat64Array(),
		"delta_body": PackedFloat64Array(),
		"reference_wind_ned": PackedFloat64Array(),
		"reference_air_body": PackedFloat64Array(),
		"uniform": false,
		"wing_count": int(station_geometry.get("wing_count", 0)),
		"horizontal_index": int(station_geometry.get("horizontal_index", -1)),
		"vertical_index": int(station_geometry.get("vertical_index", -1)),
		"propulsion_index": int(station_geometry.get("propulsion_index", -1)),
		"indices": {
			"wing_count": int(station_geometry.get("wing_count", 0)),
			"horizontal_index": int(station_geometry.get("horizontal_index", -1)),
			"vertical_index": int(station_geometry.get("vertical_index", -1)),
			"propulsion_index": int(station_geometry.get("propulsion_index", -1)),
		},
	}


static func _finite3(value: Variant) -> bool:
	if typeof(value) != TYPE_PACKED_FLOAT64_ARRAY or value.size() != 3:
		return false
	for component: float in value:
		if not is_finite(component):
			return false
	return true


static func _same3(a: PackedFloat64Array, b: PackedFloat64Array) -> bool:
	return a[0] == b[0] and a[1] == b[1] and a[2] == b[2]
