extends SceneTree

# Run the baseline and candidate together against the same focused project:
# godot --headless --path <timber-focused-project> --script <this file> -- \
#   --baseline-source=<absolute path> --candidate-source=<absolute path>
#
# The final test deliberately mutates a native mesh from a node property getter.
# A difference is a real failed parity gate, not an expected-pass assertion.

class ObservedMesh extends ArrayMesh:
	var events: Array[String] = []
	var reads := 0
	var return_records := false
	var mutate_returned_records := false
	var records: Array = []

	func _get(property: StringName) -> Variant:
		events.append(String(property))
		if property == &"_surfaces":
			reads += 1
			if return_records:
				if mutate_returned_records:
					for value: Variant in records:
						var record: Dictionary = value
						var lods: Array = record.get("lods", [])
						if not lods.is_empty():
							lods[0] = 0.25 + float(reads) * 0.125
				return records
		return null # Let Godot's native property getter handle the request.


class MutatingInstance extends MeshInstance3D:
	var target: ArrayMesh
	var armed := false
	var transform_reads := 0

	func _get(property: StringName) -> Variant:
		if property == &"transform":
			transform_reads += 1
			if armed:
				armed = false
				var arrays: Array = target.surface_get_arrays(0)
				var material: Material = target.surface_get_material(0)
				var surface_name := target.surface_get_name(0)
				var primitive := target.surface_get_primitive_type(0)
				var flags := target.surface_get_format(0)
				target.clear_surfaces()
				target.add_surface_from_arrays(primitive, arrays, [], {0.9: PackedInt32Array([0, 1, 2])}, flags)
				target.surface_set_name(0, surface_name)
				target.surface_set_material(0, material)
		return null


var _checks := 0
var _failures := 0


func _check(condition: bool, label: String, detail: Variant = null) -> void:
	_checks += 1
	if not condition:
		_failures += 1
		printerr("FAIL: ", label, " ", str(detail))


func _load_source(path: String) -> Script:
	var script := GDScript.new()
	script.source_code = FileAccess.get_file_as_string(path)
	if script.source_code.is_empty() or script.reload() != OK:
		printerr("Cannot load Timber source: ", path)
		return null
	return script


func _arrays() -> Array:
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = PackedVector3Array([
		Vector3(0, 0, 0), Vector3(0.01, 0, 0), Vector3(0, 0.01, 0), Vector3(0.01, 0.01, 0),
	])
	arrays[Mesh.ARRAY_NORMAL] = PackedVector3Array([Vector3.BACK, Vector3.BACK, Vector3.BACK, Vector3.BACK])
	arrays[Mesh.ARRAY_TEX_UV] = PackedVector2Array([Vector2.ZERO, Vector2.RIGHT, Vector2.DOWN, Vector2.ONE])
	arrays[Mesh.ARRAY_INDEX] = PackedInt32Array([0, 1, 2, 1, 3, 2])
	return arrays


func _populate(mesh: ArrayMesh, surface_count: int, distance: float) -> void:
	mesh.resource_name = "snapshot-differential-source"
	for index in surface_count:
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _arrays(), [], {distance: PackedInt32Array([0, 1, 2])})
		mesh.surface_set_name(index, "surface_%d" % index)
		var material := StandardMaterial3D.new()
		material.resource_name = ["white", "red", "accent"][index % 3]
		mesh.surface_set_material(index, material)


func _observed(surface_count: int, override_records: bool, mutate_during_reads: bool) -> ObservedMesh:
	var mesh := ObservedMesh.new()
	_populate(mesh, surface_count, 0.25)
	# Capture valid native records before enabling the scripted getter override.
	mesh.records = mesh.get("_surfaces")
	mesh.return_records = override_records
	mesh.mutate_returned_records = mutate_during_reads
	mesh.events.clear()
	mesh.reads = 0
	return mesh


func _hash(details: Script, mesh: Mesh) -> String:
	return str(details.call("_mesh_content_sha256", mesh, "snapshot-differential-v1"))


func _comparable_records(records: Array) -> Array:
	# The independently built fixtures own different Material instances. Compare
	# their meaningful fixture properties while retaining every other field,
	# including all LOD distances and raw packed index bytes, without alteration.
	var normalized: Array = records.duplicate(true)
	for value: Variant in normalized:
		var surface: Dictionary = value
		if surface.has("material"):
			var material: Material = surface["material"]
			if material is StandardMaterial3D:
				var standard := material as StandardMaterial3D
				surface["material"] = {
					material_class = standard.get_class(),
					resource_name = standard.resource_name,
					albedo_color = standard.albedo_color,
					roughness = standard.roughness,
					metallic = standard.metallic,
					emission_enabled = standard.emission_enabled,
				}
			else:
				surface["material"] = {material_class = material.get_class(), resource_name = material.resource_name}
	return normalized


func _scripted_hash(details: Script, surface_count: int, override_records: bool, mutate_during_reads: bool) -> Dictionary:
	var mesh := _observed(surface_count, override_records, mutate_during_reads)
	var result := _hash(details, mesh)
	return {hash = result, reads = mesh.reads, events = mesh.events.duplicate(), records = _comparable_records(mesh.records)}


func _native_mutation_hashes(details: Script) -> Dictionary:
	var mesh := ArrayMesh.new()
	_populate(mesh, 1, 0.25)
	var instance_id := mesh.get_instance_id()
	var first := _hash(details, mesh)
	mesh.clear_surfaces()
	_populate(mesh, 1, 0.75)
	var second := _hash(details, mesh)
	return {first = first, second = second, same_object = mesh.get_instance_id() == instance_id}


func _override_mutation_hashes(details: Script) -> Dictionary:
	var mesh := _observed(2, true, false)
	var instance_id := mesh.get_instance_id()
	var first := _hash(details, mesh)
	var first_record: Dictionary = mesh.records[0]
	var lods: Array = first_record["lods"]
	lods[0] = 0.875
	var second := _hash(details, mesh)
	return {first = first, second = second, reads = mesh.reads, events = mesh.events.duplicate(), same_object = mesh.get_instance_id() == instance_id}


func _empty_repair(details: Script, scripted: bool) -> Dictionary:
	(details.get("_paint_repair_cache") as Dictionary).clear()
	(details.get("_paint_repair_cache_order") as Array).clear()
	var source: ArrayMesh = _observed(0, false, false) if scripted else ArrayMesh.new()
	source.resource_name = "empty-surface-source"
	if scripted:
		(source as ObservedMesh).events.clear()
		(source as ObservedMesh).reads = 0
	var root_node := Node3D.new()
	var instance := MeshInstance3D.new()
	instance.name = "wing_left_fixed"
	instance.mesh = source
	root_node.add_child(instance)
	details.call("_repair_painted_surface_poke_through", root_node)
	var cache: Dictionary = details.get("_paint_repair_cache")
	var result := {cache_keys = cache.keys(), same_mesh = instance.mesh == source}
	if scripted:
		result["reads"] = (source as ObservedMesh).reads
		result["events"] = (source as ObservedMesh).events.duplicate()
	root_node.free()
	return result


func _node_mutation_repair(details: Script) -> Dictionary:
	(details.get("_paint_repair_cache") as Dictionary).clear()
	(details.get("_paint_repair_cache_order") as Array).clear()
	var source := ArrayMesh.new()
	_populate(source, 1, 0.25)
	var root_node := Node3D.new()
	var instance := MutatingInstance.new()
	instance.name = "wing_left_fixed"
	instance.mesh = source
	instance.target = source
	root_node.add_child(instance)
	instance.transform_reads = 0
	instance.armed = true
	details.call("_repair_painted_surface_poke_through", root_node)
	var cache: Dictionary = details.get("_paint_repair_cache")
	var first_keys := cache.keys().duplicate()
	var triggered := not instance.armed
	var observed_transform_reads := instance.transform_reads
	details.call("_repair_painted_surface_poke_through", root_node)
	var result := {
		first_keys = first_keys,
		final_keys = cache.keys().duplicate(),
		triggered = triggered,
		transform_reads = observed_transform_reads,
		same_mesh = instance.mesh == source,
	}
	root_node.free()
	return result


func _initialize() -> void:
	var baseline_path := ""
	var candidate_path := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--baseline-source="):
			baseline_path = arg.trim_prefix("--baseline-source=")
		elif arg.begins_with("--candidate-source="):
			candidate_path = arg.trim_prefix("--candidate-source=")
	if baseline_path.is_empty() or candidate_path.is_empty():
		printerr("Both --baseline-source and --candidate-source are required.")
		quit(2)
		return
	var baseline := _load_source(baseline_path)
	var candidate := _load_source(candidate_path)
	if baseline == null or candidate == null:
		quit(2)
		return

	for options: Array in [[0, false, false], [3, false, false], [3, true, false], [3, true, true]]:
		var original := _scripted_hash(baseline, options[0], options[1], options[2])
		var proposed := _scripted_hash(candidate, options[0], options[1], options[2])
		_check(original.hash == proposed.hash, "scripted getter hash " + str(options), [original, proposed])
		_check(original.events == proposed.events and original.reads == proposed.reads, "scripted getter call order and count " + str(options), [original, proposed])
		_check(original.reads == options[0], "baseline read count equals surface count " + str(options), original)
		_check(original.records == proposed.records, "returned record state " + str(options), [original, proposed])

	var native_a := _native_mutation_hashes(baseline)
	var native_b := _native_mutation_hashes(candidate)
	_check(native_a == native_b and native_a.same_object and native_a.first != native_a.second, "same native object LOD mutation invalidates hash", [native_a, native_b])
	var override_a := _override_mutation_hashes(baseline)
	var override_b := _override_mutation_hashes(candidate)
	_check(override_a == override_b and override_a.same_object and override_a.first != override_a.second, "same scripted object and returned records mutation invalidate hash", [override_a, override_b])
	var unchanged_records: Array = _scripted_hash(baseline, 1, true, false).records
	var changed_records: Array = unchanged_records.duplicate(true)
	var changed_lods: Array = (changed_records[0] as Dictionary)["lods"]
	var changed_bytes: PackedByteArray = changed_lods[1]
	changed_bytes[0] = changed_bytes[0] ^ 1
	changed_lods[1] = changed_bytes
	_check(unchanged_records != changed_records, "record comparison retains and detects changed raw LOD bytes")
	# A generated BoxMesh is unsupported by both baseline and candidate hash
	# functions because it does not expose surface_get_primitive_type(). The
	# valid non-ArrayMesh control instead has zero surfaces, with a nonempty name.
	var placeholder: Mesh = PlaceholderMesh.new()
	placeholder.resource_name = "non-array-empty-control"
	var empty_non_array := not placeholder is ArrayMesh and placeholder.get_surface_count() == 0
	_check(empty_non_array, "non-ArrayMesh control has zero surfaces")
	if empty_non_array:
		var baseline_hash := _hash(baseline, placeholder)
		var candidate_hash := _hash(candidate, placeholder)
		_check(not baseline_hash.is_empty() and baseline_hash == candidate_hash, "zero-surface non-ArrayMesh direct hash")
	for scripted: bool in [false, true]:
		var empty_a := _empty_repair(baseline, scripted)
		var empty_b := _empty_repair(candidate, scripted)
		_check(empty_a == empty_b and empty_a.same_mesh, "empty mesh repair parity scripted=" + str(scripted), [empty_a, empty_b])
		if scripted:
			_check(empty_a.reads == 0, "empty scripted mesh never requests _surfaces", empty_a)

	var node_a := _node_mutation_repair(baseline)
	var node_b := _node_mutation_repair(candidate)
	_check(node_a.triggered and node_b.triggered, "scripted transform getter actually mutates the source mesh", [node_a, node_b])
	_check(node_a == node_b, "scripted node mutation preserves cache keys and behavior", [node_a, node_b])
	print("Timber adversarial snapshot differential: %d checks, %d failures" % [_checks, _failures])
	quit(1 if _failures else 0)
