extends SceneTree

# Regression oracle for paint-face grid buckets and the resulting material.
# This test accepts the historical string and current Vector3i key types.
const Details := preload("res://aircraft/timber_visual_details.gd")

var checks := 0
var failures := 0


func _check(condition: bool, label: String, detail: Variant = null) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ", label, " ", str(detail))


func _face(id: String, material: String, a: Vector3, b: Vector3, c: Vector3, bounds: AABB) -> Dictionary:
	return {id = id, material = material, normal = Vector3(0, 0, 1), bounds = bounds,
		vertices = PackedVector3Array([a, b, c])}


func _normalize(index: Dictionary) -> Dictionary:
	var normalized := {}
	for key: Variant in index:
		var label: String
		if key is Vector3i:
			var cell: Vector3i = key
			label = "%d:%d:%d" % [cell.x, cell.y, cell.z]
		elif key is String:
			label = key
		else:
			_check(false, "unsupported grid key", typeof(key))
			continue
		var face_ids: Array[String] = []
		for face: Dictionary in index[key]: face_ids.append(str(face.id))
		_check(not normalized.has(label), "one bucket per cell", label)
		normalized[label] = face_ids
	return normalized


func _bucket_oracle() -> void:
	var v := Vector3.ZERO
	var faces: Array[Dictionary] = [
		_face("a", "red", v, v, v, AABB(Vector3(-0.009, -0.009, -0.001), Vector3(0.018, 0.018, 0.002))),
		_face("b", "blue", v, v, v, AABB(Vector3(0.005, 0.005, -0.001), Vector3(0.001, 0.001, 0.002))),
		_face("zero", "black", v, v, v, AABB(Vector3(0.0101, -0.0101, -0.009), Vector3.ZERO)),
		_face("reversed", "black", v, v, v, AABB(Vector3(0.019, 0, 0), Vector3(-0.01, 0, 0))),
	]
	var expected := {
		"-1:-1:-1": ["a"], "-1:-1:0": ["a"], "-1:0:-1": ["a"], "-1:0:0": ["a"],
		"0:-1:-1": ["a"], "0:-1:0": ["a"], "0:0:-1": ["a", "b"], "0:0:0": ["a", "b"],
		"1:-2:-1": ["zero"],
	}
	var actual := _normalize(Details._build_paint_face_index(faces))
	_check(actual == expected, "signed cells and bucket insertion match explicit oracle", actual)
	var none: Array[Dictionary] = []
	_check(Details._build_paint_face_index(none).is_empty(), "no faces gives empty index")


func _covering_oracle() -> void:
	var a := Vector3(-0.03, -0.03, 0)
	var b := Vector3(0.03, -0.03, 0)
	var c := Vector3(0, 0.03, 0)
	var bounds := AABB(a, Vector3.ZERO).expand(b).expand(c).grow(0.012)
	var faces: Array[Dictionary] = [
		_face("red", "red", a, b, c, bounds),
		_face("blue", "blue", a, b, c, bounds),
		_face("red-repeat", "red", a, b, c, bounds),
	]
	var index := Details._build_paint_face_index(faces)
	var normal := Vector3(0, 0, 1)
	for coordinate: float in [-0.0101, -0.01, -0.0099, 0.0, 0.0099, 0.01, 0.0101]:
		for point: Vector3 in [Vector3(coordinate, 0, 0), Vector3(0, coordinate, 0), Vector3(0, 0, coordinate)]:
			var indexed := Details._covering_paint_at(point, normal, faces, 0.02, 0.7, index)
			var fallback := Details._covering_paint_at(point, normal, faces, 0.02, 0.7, {})
			_check(indexed.keys() == ["red", "blue"], "both materials keep insertion order at " + str(point), indexed)
			_check(indexed == fallback and indexed.keys() == fallback.keys(), "indexed lookup matches empty-index scan at " + str(point), [indexed, fallback])
	_check(Details._fully_covered_paint(a, b, c, normal, faces, 0.02, 0.7, index) == "red", "first coincident material wins")
	var reversed: Array[Dictionary] = [faces[1], faces[0], faces[2]]
	_check(Details._fully_covered_paint(a, b, c, normal, reversed, 0.02, 0.7, Details._build_paint_face_index(reversed)) == "blue", "reversing faces reverses a material tie")
	_check(Details._covering_paint_at(Vector3.ZERO, -normal, faces, 0.02, 0.7, index).is_empty(), "opposite normal is refused")
	_check(Details._covering_paint_at(Vector3(0, 0, 0.005), normal, faces, 0.001, 0.7, index).is_empty(), "distance threshold is enforced")
	var remote: Array[Dictionary] = [_face("remote", "remote", a, b, c, AABB(Vector3(5, 5, 5), Vector3.ZERO))]
	_check(Details._covering_paint_at(Vector3.ZERO, normal, faces, 0.02, 0.7, Details._build_paint_face_index(remote)).is_empty(), "nonempty index with missing cell does not use full scan")
	var degenerate: Array[Dictionary] = [_face("degenerate", "none", Vector3.ZERO, Vector3.ZERO, Vector3.ZERO, AABB(Vector3.ZERO, Vector3.ZERO))]
	_check(Details._covering_paint_at(Vector3.ZERO, normal, degenerate, 0.02, 0.7, Details._build_paint_face_index(degenerate)).is_empty(), "zero-sized bounds do not cover a point")


func _initialize() -> void:
	_bucket_oracle()
	_covering_oracle()
	print("Timber paint grid: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
