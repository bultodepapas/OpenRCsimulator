## Isolated exact-result and ownership controls for the phase-reuse experiment.
## The production repository is never modified by this fixture.
extends SceneTree

const AD := preload("res://physics/aircraft_data.gd")
const Flow := preload("res://physics/wind_aircraft_flow.gd")
const Weather := preload("res://physics/wind_field.gd")
const WeatherConfig := preload("res://physics/wind_config.gd")
const SpatialConfig := preload("res://physics/wind_spatial_config.gd")
const SimEnvironment := preload("res://sim/environment.gd")
const Session := preload("res://sim/flight_session.gd")

class ForwardEnvironment extends "res://sim/environment.gd":
    var calls := 0
    func wind_world(position: PackedFloat64Array, time_s: float) -> PackedFloat64Array:
        calls += 1
        return super.wind_world(position, time_s)

class ForwardWeather extends "res://physics/wind_field.gd":
    var calls := 0
    func sample_world(position: PackedFloat64Array, time_s: float) -> PackedFloat64Array:
        calls += 1
        return super.sample_world(position, time_s)

var checks := 0
var failures := 0
var callback_count := 0
var callback_spatial: Variant

func _check(label: String, condition: bool) -> void:
    checks += 1
    if not condition:
        failures += 1
        printerr("FAIL ", label)

func _same(a: PackedFloat64Array, b: PackedFloat64Array) -> bool:
    return a.to_byte_array() == b.to_byte_array()

func _mutating_noise(_time_s: float) -> PackedFloat64Array:
    callback_count += 1
    var modes: PackedFloat64Array = callback_spatial.get("_modes")
    modes[8] += 0.125
    callback_spatial.set("_modes", modes)
    return PackedFloat64Array()

func _make_weather(mode_count: int, epoch: float, thermal := false) -> Variant:
    var config: Dictionary = WeatherConfig.spatial_defaults()
    config.spatial_wind.turbulence.rms_mps = 0.3
    config.spatial_wind.turbulence.mode_count = mode_count
    config.spatial_wind.identity.epoch_offset_s = epoch
    config.spatial_wind.profile.reference_speed_mps = 3.0
    if thermal:
        var upgrade: Dictionary = SpatialConfig.thermal_defaults(config.spatial_wind)
        if not upgrade.ok: return null
        config.spatial_wind = upgrade.config
    var built: Dictionary = Weather.build(config)
    return built.field if built.ok else null

func _same_environment_point(env: Object, point: PackedFloat64Array, time_s: float, scratch: Dictionary, label: String) -> void:
    var reference: PackedFloat64Array = env.wind_world(point, time_s)
    var candidate: PackedFloat64Array = env._wind_world_phase_stage(point, time_s, scratch)
    _check(label, _same(reference, candidate))

func _initialize() -> void:
    _run.call_deferred()

func _run() -> void:
    var point := PackedFloat64Array([2.5, -1.75, -30.0])
    var origin := PackedFloat64Array([0.0, 0.0, -30.0])
    var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/aircraft/jensen_ugly_stik_60.json"))
    var model_result: Dictionary = AD.validate_and_derive(raw)
    _check("stock aircraft model validates", model_result.get("ok", false))
    if not model_result.get("ok", false):
        quit(1)
        return
    var model: Dictionary = model_result.model
    var state := PackedFloat64Array([0.0, 0.0, -30.0, 20.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

    for modes: int in [8, 24, 64]:
        var weather: Variant = _make_weather(modes, 1.25)
        _check("built field for %d modes" % modes, weather != null)
        if weather == null: continue
        var env := SimEnvironment.new()
        env.weather = weather
        var scratch: Variant = Flow._phase_stage_scratch(env)
        _check("plain built-ins admitted %d" % modes, scratch is Dictionary)
        if not scratch is Dictionary: continue
        _same_environment_point(env, point, 2.0, scratch, "initial exact sample %d" % modes)
        _check("scratch populated %d" % modes, scratch.ready and scratch.omegas.size() == modes and scratch.phases.size() == modes)
        for i: int in 30:
            var candidate := PackedFloat64Array([2.5 + i * 0.17, -1.75 - i * 0.09, -30.0 - i * 0.01])
            _same_environment_point(env, candidate, 2.0, scratch, "same-stage point %d / %d" % [modes, i])
        for case in [
            {"p": PackedFloat64Array([0.0, 0.0, 0.0]), "t": 2.0},
            {"p": PackedFloat64Array([0.0, 0.0, 0.1]), "t": 2.0},
            {"p": PackedFloat64Array([10001.0, 0.0, -1.0]), "t": 2.0},
            {"p": PackedFloat64Array([NAN, 0.0, -1.0]), "t": 2.0},
            {"p": PackedFloat64Array([0.0, INF, -1.0]), "t": 2.0},
            {"p": point, "t": -1.0}, {"p": point, "t": INF},
            {"p": point, "t": 2.25}, {"p": point, "t": 2.0},
        ]:
            _same_environment_point(env, case.p, case.t, scratch, "domain/time fallback %d" % modes)

        # Deliberately poison scratch to prove the reuse branch actually reads it.
        var normal: PackedFloat64Array = env.wind_world(point, 2.0)
        var phases: PackedFloat64Array = scratch.phases
        var original_phase: float = phases[0]
        phases[0] = original_phase + 0.5
        scratch.phases = phases
        var poisoned: PackedFloat64Array = env._wind_world_phase_stage(point, 2.0, scratch)
        _check("poisoned scratch negative control %d" % modes, not _same(normal, poisoned))
        phases[0] = original_phase
        scratch.phases = phases
        _same_environment_point(env, point, 2.0, scratch, "scratch restored %d" % modes)

        # Same instance and same timestamp: an altered live omega must not use stale phase.
        var spatial: Variant = weather.get("_spatial")
        var mode_values: PackedFloat64Array = spatial.get("_modes")
        mode_values[8] += 0.375
        spatial.set("_modes", mode_values)
        _same_environment_point(env, point, 2.0, scratch, "same-object omega mutation %d" % modes)
        var config: Dictionary = spatial.get("_config")
        config.identity.epoch_offset_s += 0.5
        spatial.set("_config", config)
        _same_environment_point(env, point, 2.0, scratch, "same-object epoch mutation %d" % modes)
        mode_values = spatial.get("_modes")
        spatial.set("_modes", mode_values.slice(0, mode_values.size() - 9))
        _same_environment_point(env, point, 2.0, scratch, "same-object layout mutation %d" % modes)

    var actual_session: Node = Session.new()
    var standard_weather: Variant = _make_weather(24, 1.25)
    actual_session.environment.weather = standard_weather
    var actual_scratch: Variant = Flow._phase_stage_scratch(actual_session.environment)
    _check("real FlightSession bound callback admitted", actual_scratch is Dictionary)
    if actual_scratch is Dictionary:
        _same_environment_point(actual_session.environment, point, 2.0, actual_scratch, "FlightSession callback exact")
        _check("real FlightSession populated phase cache", actual_scratch.ready and actual_scratch.phases.size() == 24)

    var active_env := SimEnvironment.new()
    active_env.weather = _make_weather(24, 1.25)
    var fallback_env := ForwardEnvironment.new()
    fallback_env.weather = _make_weather(24, 1.25)
    var active_result: Dictionary = Flow.sample(state, model, active_env, 2.0)
    var fallback_result: Dictionary = Flow.sample(state, model, fallback_env, 2.0)
    _check("real 10-point flow matches override fallback exactly", active_result.ok and fallback_result.ok
        and var_to_bytes(active_result) == var_to_bytes(fallback_result) and fallback_env.calls == 10)
    var active_air: Dictionary = Flow.stage_air(state, model, active_env, 2.0)
    var fallback_air: Dictionary = Flow.stage_air(state, model, fallback_env, 2.0)
    _check("both air receipts succeed", active_air.ok and fallback_air.ok)
    if active_air.ok and fallback_air.ok:
        var a: Dictionary = active_air.air.duplicate()
        var b: Dictionary = fallback_air.air.duplicate()
        a.erase("spatial_sampler"); a.erase("ambient_delta_body_at")
        b.erase("spatial_sampler"); b.erase("ambient_delta_body_at")
        _check("all serializable air and diagnostic flow match", var_to_bytes(a) == var_to_bytes(b)
            and var_to_bytes(active_air.flow) == var_to_bytes(fallback_air.flow))
        var arm := PackedFloat64Array([0.2, 0.1, -0.05])
        _check("retained point sampler stays live and exact", _same(active_air.air.ambient_delta_body_at.call(arm),
            fallback_air.air.ambient_delta_body_at.call(arm)))

    # User-supplied callback is invoked once per query, after weather, and may mutate it.
    var custom_env := SimEnvironment.new()
    custom_env.weather = _make_weather(24, 1.25)
    callback_spatial = custom_env.weather.get("_spatial")
    custom_env.turbulence = _mutating_noise
    _check("arbitrary callback forces unprepared route", Flow._phase_stage_scratch(custom_env) == null)
    for i in 3:
        var expected: PackedFloat64Array = custom_env.weather.sample_world(origin, 2.0)
        var actual: PackedFloat64Array = Flow._phase_stage_query(custom_env, origin, 2.0, null)
        _check("mutating callback preserves result and call count %d" % i,
            _same(expected, actual) and callback_count == i + 1)

    var overridden_weather := ForwardWeather.new()
    var built_config: Dictionary = WeatherConfig.spatial_defaults()
    built_config.spatial_wind.turbulence.rms_mps = 0.3
    built_config.spatial_wind.identity.epoch_offset_s = 1.25
    var resolved: Dictionary = WeatherConfig.validate(built_config)
    _check("override weather configured", resolved.ok and overridden_weather._apply_config(resolved.config))
    var custom_weather_env := SimEnvironment.new()
    custom_weather_env.weather = overridden_weather
    _check("derived weather preserves public override", Flow._phase_stage_scratch(custom_weather_env) == null)
    var custom_flow: Dictionary = Flow.sample(state, model, custom_weather_env, 2.0)
    _check("derived weather gets all point queries", custom_flow.ok and overridden_weather.calls == 10)
    _check("derived environment uses generic dispatch", Flow._phase_stage_scratch(fallback_env) == null)
    var thermal_env := SimEnvironment.new()
    thermal_env.weather = _make_weather(24, 1.25, true)
    _check("thermal field uses generic path", Flow._phase_stage_scratch(thermal_env) == null)
    var zero_epoch_env := SimEnvironment.new()
    zero_epoch_env.weather = _make_weather(24, 0.0)
    var zero_scratch: Variant = Flow._phase_stage_scratch(zero_epoch_env)
    if zero_scratch is Dictionary:
        _same_environment_point(zero_epoch_env, point, 0.0, zero_scratch, "zero epoch original path")
        _check("zero epoch does not populate cache", not zero_scratch.ready)
    else:
        _check("zero epoch scratch exists", false)
    actual_session.free()
    print("phase stage differential: %d checks, %d failed" % [checks, failures])
    quit(1 if failures else 0)
