#!/usr/bin/env python3
"""Compare checked, completed baseline/candidate pilot qualification outputs."""
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parent / "pilot-full"
CHECKS = ROOT / "checks"
issues = []


def require(condition: bool, detail: str) -> None:
    if not condition:
        issues.append(detail)


def checked(label: str) -> tuple[dict, str]:
    matches = sorted(CHECKS.glob(label + "-*"))
    if len(matches) != 1:
        raise ValueError(f"expected one {label} check directory; found {matches}")
    report = json.loads((matches[0] / "report.json").read_text())
    require(report.get("ok") is True and report.get("complete") is True, f"{label}: checked run failed")
    return report, (matches[0] / "engine.log").read_text()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


try:
    receipt = json.loads((ROOT / "fixture-receipt.json").read_text())
    _, base_log = checked("matrix-baseline")
    _, cand_log = checked("matrix-candidate")
    require("PILOT SOURCE res://ai/companions/pilot.gd SHA256 " + receipt["baseline_pilot_sha256"] in base_log,
            "baseline pilot hash missing from matrix log")
    require("PILOT SOURCE res://ai/companions/pilot_candidate_audit.gd SHA256 " + receipt["candidate_pilot_sha256"] in cand_log,
            "candidate pilot hash missing from matrix log")
    pattern = re.compile(r"^PILOT_MATRIX_AUDIT (\S+) (\d+) (true|false) (\d+) ([0-9a-f]{64})$", re.MULTILINE)
    base_rows = pattern.findall(base_log)
    cand_rows = pattern.findall(cand_log)
    require(len(base_rows) == 8 and len(cand_rows) == 8, "matrix did not complete eight audit streams per variant")
    require(base_rows == cand_rows, "matrix state/packet/latch streams differ")
    expected_plans = [7200, 14400, 21600, 7200, 14400, 21600, 21600, 21600]
    require([int(row[3]) for row in base_rows] == expected_plans, "matrix plan count differs from complete 120 s cases")
    matrix_files = {}
    for name in ("scenario_metrics.csv", "flight_samples_1hz.csv"):
        left, right = ROOT / "matrix-baseline" / name, ROOT / "matrix-candidate" / name
        left_hash, right_hash = digest(left), digest(right)
        require(left_hash == right_hash, f"matrix {name} bytes differ")
        matrix_files[name] = {"baseline_sha256": left_hash, "candidate_sha256": right_hash}

    _, _ = checked("encounter-baseline-catalog")
    _, _ = checked("encounter-candidate")
    a = json.loads((ROOT / "encounter-baseline-complete/report.json").read_text())
    b = json.loads((ROOT / "encounter-candidate/report.json").read_text())
    require(a.get("pilot_source_sha256") == receipt["baseline_pilot_sha256"], "encounter baseline pilot hash differs")
    require(b.get("pilot_source_sha256") == receipt["candidate_pilot_sha256"], "encounter candidate pilot hash differs")
    require(a.get("probe_source_sha256") == receipt["encounter_probe_instrumented_sha256"] == b.get("probe_source_sha256"),
            "encounter probe source hash differs")
    require(a.get("process_success") is True and b.get("process_success") is True, "encounter process incomplete")
    require(a.get("seconds") == 12 == b.get("seconds"), "encounter not full 12 s survey")
    left_cases, right_cases = a.get("cases", []), b.get("cases", [])
    require(len(left_cases) == 7 == len(right_cases), "encounter case count differs from seven")
    compared = []
    for left, right in zip(left_cases, right_cases):
        key = f"{left.get('case_id')}/{left.get('seed')}"
        require(left.get("case_id") == right.get("case_id") and left.get("seed") == right.get("seed"),
                key + " case identities differ")
        for side, item in (("baseline", left), ("candidate", right)):
            require(item.get("valid_run") is True and item.get("complete") is True and item.get("ticks") == 2880
                    and item.get("planner_samples") == 720, f"{key} {side} incomplete")
        for field in ("state_command_sha256", "decision_packet_sha256"):
            require(bool(re.fullmatch(r"[0-9a-f]{64}", str(left.get(field, "")))) and left.get(field) == right.get(field),
                    f"{key} {field} differs or is missing")
        compared.append({"case_id": left.get("case_id"), "seed": left.get("seed"),
                         "state_command_sha256": left.get("state_command_sha256"),
                         "decision_packet_sha256": left.get("decision_packet_sha256"),
                         "separation_gate_passed": left.get("separation_gate_passed")})
    ar, br = a["deterministic_repeat"]["repeat_run"], b["deterministic_repeat"]["repeat_run"]
    for side, item in (("baseline", ar), ("candidate", br)):
        require(item.get("valid_run") is True and item.get("ticks") == 2880 and item.get("planner_samples") == 720,
                f"{side} repeat incomplete")
    for field in ("state_command_sha256", "decision_packet_sha256"):
        require(ar.get(field) == br.get(field) and bool(ar.get(field)), f"repeat {field} differs")
    left_csv, right_csv = ROOT / "encounter-baseline-complete/trajectory.csv", ROOT / "encounter-candidate/trajectory.csv"
    require(digest(left_csv) == digest(right_csv), "encounter trajectory CSV differs")
    result = {"fixture": receipt, "matrix_streams": base_rows, "matrix_csvs": matrix_files,
              "encounter_cases": compared, "encounter_repeat": {field: ar.get(field) for field in
                   ("state_command_sha256", "decision_packet_sha256")},
              "encounter_trajectory_sha256": digest(left_csv), "issues": issues,
              "limits": "Same-build selected-headless fixture and tested cases only; encounter survey is not separation qualification or physical validation."}
    (ROOT / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"ok": not issues, "matrix_streams": len(base_rows), "encounter_cases": len(compared),
                      "issues": issues}, indent=2))
    sys.exit(1 if issues else 0)
except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
    print(f"qualification comparison could not complete: {error}", file=sys.stderr)
    sys.exit(2)
