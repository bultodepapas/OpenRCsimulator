extends SceneTree

const Loader := preload("res://ai/companions/profile_loader.gd")
const Field := preload("res://data/field_loader.gd")
const Aircraft := preload("res://physics/aircraft_data.gd")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var expected := "refused" if OS.get_cmdline_user_args().has("--expect=refused") else "admitted"
	var aircraft: Dictionary = Aircraft.load_file("res://data/aircraft/jensen_ugly_stik_60.json")
	var field: Dictionary = Field.load_from()
	if not aircraft.get("ok", false) or not field.get("ok", false):
		printerr("ADMISSION FIXTURE ERROR %s %s" % [str(aircraft.get("errors", [])), str(field.get("errors", []))])
		quit(1)
		return
	var result: Dictionary = Loader.load_profile("jensen-das-ugly-stik-60", aircraft.input_identity, field.field)
	var errors: PackedStringArray = result.get("errors", PackedStringArray())
	var mismatch := errors.size() == 1 and str(errors[0]) == "controller.sha256: current pilot source does not match this profile"
	var success: bool = mismatch if expected == "refused" else bool(result.get("ok", false)) and errors.is_empty()
	print("PILOT PROFILE ADMISSION expected=%s observed_ok=%s errors=%s pilot_sha256=%s" % [expected, str(result.get("ok", false)), str(errors), FileAccess.get_sha256("res://ai/companions/pilot.gd")])
	print("PILOT PROFILE ADMISSION CHECK %s" % ("PASS" if success else "FAIL"))
	quit(0 if success else 1)
