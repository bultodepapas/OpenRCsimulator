extends SceneTree
const Pilot := preload("res://ai/companions/pilot_baseline.gd")

func _initialize() -> void:
	var pilot := Pilot.new()
	var state := PackedFloat64Array([0.0, 0.0, -35.0, 15.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var velocity := PackedFloat64Array([15.0, 0.0, 0.0])
	var pos := PackedFloat64Array()
	for sample in 33:
		pos.append_array(PackedFloat64Array([100.0, 10.0, -35.0]))
	var threats: Array[Dictionary] = [{id = "target", is_player = true, required_separation_m = 30.0, positions = pos}]
	var result: Dictionary = pilot._score_bank(state, velocity, 15.0, 0.0, 0.0, 0.35, 35.0, threats, true)
	var trace: PackedFloat64Array = result.distance_traces_m[0]
	for i in [0, 1, 4, 7, 8, 16, 32]:
		print("GOLDEN %d %.12f" % [i, trace[i]])
	quit()
