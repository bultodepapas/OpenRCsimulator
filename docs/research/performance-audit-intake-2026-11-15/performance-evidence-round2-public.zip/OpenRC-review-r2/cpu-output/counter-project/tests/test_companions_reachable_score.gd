## Reachable-pilot distance minima and predicted turn regression witnesses.
extends SceneTree

const Pilot := preload("res://ai/companions/pilot.gd")

var _checks := 0
var _failures := 0


func _check(label: String, passed: bool) -> void:
	_checks += 1
	if not passed:
		_failures += 1
		printerr("FAIL ", label)


func _initialize() -> void:
	_run.call_deferred()


func _positions(distance: float, moving: bool) -> PackedFloat64Array:
	var positions := PackedFloat64Array()
	for sample in 33:
		positions.append_array(PackedFloat64Array([distance + (3.75 * sample if moving else 0.0), 0.0, -35.0]))
	return positions


func _adjacent_positive(value: float, direction: int) -> float:
	var bytes := PackedByteArray()
	bytes.resize(8)
	bytes.encode_double(0, value)
	bytes.encode_u64(0, bytes.decode_u64(0) + direction)
	return bytes.decode_double(0)


func _score_pair(pilot: RefCounted, state: PackedFloat64Array, velocity: PackedFloat64Array,
		speed: float, bank: float, threats: Array[Dictionary], label: String) -> Dictionary:
	var inputs_before := var_to_bytes([state, velocity, threats])
	var plain: Dictionary = pilot._score_bank(state, velocity, speed, 0.0, 0.0, bank, 35.0, threats)
	var traced: Dictionary = pilot._score_bank(state, velocity, speed, 0.0, 0.0, bank, 35.0, threats, true)
	var reduced := traced.duplicate(true)
	reduced.erase("distance_traces_m")
	_check(label + ": trace and non-trace score fields are byte-identical", var_to_bytes(plain) == var_to_bytes(reduced))
	_check(label + ": input arrays remain unchanged", inputs_before == var_to_bytes([state, velocity, threats]))
	return traced


func _run() -> void:
	var pilot := Pilot.new()
	var state := PackedFloat64Array([0.0, 0.0, -35.0, 15.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var velocity := PackedFloat64Array([15.0, 0.0, 0.0])
	var none: Array[Dictionary] = []
	var empty := _score_pair(pilot, state, velocity, 15.0, 0.0, none, "no threats")
	_check("no threats retain infinite traffic margin and empty trace", is_inf(float(empty.traffic_margin_m)) and empty.distance_traces_m.is_empty())

	# Straight flight and co-moving traffic hold every sampled separation exactly
	# constant, giving an explicit 33-way minimum tie and an exact zero margin.
	var tied: Array[Dictionary] = [
		{id = "player", is_player = true, required_separation_m = 30.0, positions = _positions(30.0, true)},
		{id = "peer", is_player = false, required_separation_m = 15.0, positions = _positions(15.0, true)},
		{id = "far", is_player = false, required_separation_m = 15.0, positions = _positions(50.0, true)},
	]
	var tie := _score_pair(pilot, state, velocity, 15.0, 0.0, tied, "three tied threats")
	var player_trace: PackedFloat64Array = tie.distance_traces_m[0]
	var all_tied := player_trace.size() == 33
	for distance: float in player_trace:
		all_tied = all_tied and distance == 30.0
	_check("all 33 player samples share the exact 30 m minimum", all_tied)
	_check("player and peer tie at the exact separation boundary", float(tie.minimum_player_distance_m) == 30.0 \
		and float(tie.minimum_peer_distance_m) == 15.0 and float(tie.traffic_margin_m) == 0.0)

	# Values on the two sides of the boundary differ by one binary64 ULP. A
	# stationary direct-scorer fixture keeps these distances exactly representable.
	var stationary := PackedFloat64Array([0.0, 0.0, 0.0])
	for direction: int in [-1, 0, 1]:
		var distance: float = 30.0 if direction == 0 else _adjacent_positive(30.0, direction)
		var traffic: Array[Dictionary] = [{id = "boundary", is_player = true,
			required_separation_m = 30.0, positions = _positions(distance, false)}]
		var boundary := _score_pair(pilot, state, stationary, 0.0, 0.0, traffic, "boundary %d" % direction)
		var margin: float = float(boundary.traffic_margin_m)
		_check("one-ULP boundary retains margin sign %d" % direction,
			(margin < 0.0 if direction < 0 else margin > 0.0 if direction > 0 else margin == 0.0))

	# Independent checkpoints from the previously qualified pilot's turn trace,
	# including before and after the bank-response ramp reaches its endpoint.
	var target := PackedFloat64Array()
	for sample in 33:
		target.append_array(PackedFloat64Array([100.0, 10.0, -35.0]))
	var turn_threats: Array[Dictionary] = [{id = "target", is_player = true,
		required_separation_m = 30.0, positions = target}]
	var turn := _score_pair(pilot, state, velocity, 15.0, 0.35, turn_threats, "bank response")
	var trace: PackedFloat64Array = turn.distance_traces_m[0]
	var checkpoints := {0: 100.498756211209, 1: 96.768086164810, 4: 85.586213843118,
		7: 74.365090065489, 8: 70.619201976024, 16: 43.373426646457, 32: 60.207925095225}
	_check("bank-response trace has the full 33 samples", trace.size() == 33)
	if trace.size() == 33:
		for index: int in checkpoints:
			_check("bank-response reference sample %d" % index,
				absf(trace[index] - float(checkpoints[index])) <= 1e-7)

	print("companion reachable score: %d checks, %d failed" % [_checks, _failures])
	quit(1 if _failures else 0)
