extends SceneTree

const Base := preload("res://ai/companions/pilot_baseline.gd")
const Both := preload("res://ai/companions/pilot_both.gd")
const M := preload("res://physics/math3d.gd")

var checks := 0
var failures := 0

func check(label: String, ok: bool) -> void:
	checks += 1
	if not ok:
		failures += 1
		printerr("FAIL " + label)

func adjacent(value: float, direction: int) -> float:
	var raw := PackedByteArray()
	raw.resize(8)
	raw.encode_double(0, value)
	raw.encode_u64(0, raw.decode_u64(0) + direction)
	return raw.decode_double(0)

func fixed_threats(count: int, distance: float, required: float) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for index in count:
		var positions := PackedFloat64Array()
		positions.resize(99)
		for sample in 33:
			positions[3 * sample] = distance if sample % 2 == 0 else -distance
			positions[3 * sample + 2] = -35.0
		result.append({id = "tie-%d" % index, is_player = index == 0,
			required_separation_m = required, positions = positions})
	return result

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var base := Base.new()
	var candidate := Both.new()
	var state := PackedFloat64Array([0.0, 0.0, -35.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var velocity := PackedFloat64Array([0.0, 0.0, 0.0])
	var values: Array[float] = [0.0, 15.0, adjacent(30.0, -1), 30.0, adjacent(30.0, 1), pow(2.0, -600.0), pow(2.0, 600.0)]
	for count in 4:
		for trace: bool in [false, true]:
			for distance: float in values:
				var threats := fixed_threats(count, distance, 30.0)
				var before := var_to_bytes([state, velocity, threats])
				M.audit_sqrt_calls = 0
				var expected: Dictionary = base._score_bank(state, velocity, 0.0, 0.3, 0.0, -0.4, 35.0, threats, trace)
				var base_roots: int = M.audit_sqrt_calls
				M.audit_sqrt_calls = 0
				var actual: Dictionary = candidate._score_bank(state, velocity, 0.0, 0.3, 0.0, -0.4, 35.0, threats, trace)
				var candidate_roots: int = M.audit_sqrt_calls
				var label := "count=%d trace=%s d=%s" % [count, str(trace), str(distance)]
				check(label + " bytes", var_to_bytes(expected) == var_to_bytes(actual))
				check(label + " inputs", before == var_to_bytes([state, velocity, threats]))
				check(label + " baseline root calls", base_roots == 33 * count)
				check(label + " candidate root calls", candidate_roots == (33 * count if trace else count))
				if trace and count > 0 and distance == 30.0:
					var samples: PackedFloat64Array = expected.distance_traces_m[0]
					var all_tied := samples.size() == 33
					for sample: float in samples:
						all_tied = all_tied and sample == 30.0
					check(label + " 33-way exact distance tie", all_tied)
	print("PREDICTOR COUNTER COMPLETE: %d checks, %d failures; direct scorer only, 33 samples, trace preserved" % [checks, failures])
	quit(1 if failures else 0)
