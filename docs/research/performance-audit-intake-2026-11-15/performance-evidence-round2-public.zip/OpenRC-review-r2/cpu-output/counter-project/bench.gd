extends SceneTree

const Base := preload("res://ai/companions/pilot_baseline.gd")
const Roots := preload("res://ai/companions/pilot_roots.gd")
const Turn := preload("res://ai/companions/pilot_turn.gd")
const Both := preload("res://ai/companions/pilot_both.gd")
const FieldLoader := preload("res://data/field_loader.gd")
const M := preload("res://physics/math3d.gd")
const Body := preload("res://physics/rigid_body.gd")
const TRIM := {V = 15.0, throttle = 0.45}
const ROUNDS := 5
const SCORE_ITERATIONS := 120
const COMMAND_ITERATIONS := 35
var sink := 0.0
var failed := false

func setup(pilot: RefCounted, field: Dictionary, near: bool, count: int) -> Dictionary:
	if not pilot.configure(0, 1, 20261020, TRIM, field):
		return {ok = false}
	pilot.diagnostics_enabled = false
	var pose: Dictionary = pilot.initial_pose()
	var heading: float = float(pose.heading_rad)
	var own: PackedFloat64Array = Body.make_state(
		PackedFloat64Array([pose.north, pose.east, -pose.height_m]),
		PackedFloat64Array([15.0, 0.0, 0.0]), M.q_from_euler(heading, 0.0, 0.0),
		PackedFloat64Array([0.0, 0.0, 0.0]))
	var wind := PackedFloat64Array([0.1, -0.1, 0.0])
	var snapshot := {state = own, airspeed_m_s = 15.0, wind_ned = wind,
		ground_clearance_m = 35.0, trim = TRIM}
	var traffic: Array = []
	var forward := PackedFloat64Array([cos(heading), sin(heading)])
	for index in count:
		var distance: float = 45.0 + float(index) * 12.0 if near else 1000.0 + float(index) * 200.0
		var offset: float = float(index - 1) * 5.0
		var other := Body.make_state(PackedFloat64Array([
			own[0] + distance * forward[0] - offset * forward[1],
			own[1] + distance * forward[1] + offset * forward[0], own[2]]),
			PackedFloat64Array([15.0, 0.0, 0.0]), M.q_from_euler(heading + PI, 0.0, 0.0),
			PackedFloat64Array([0.0, 0.0, 0.0]))
		traffic.append({id = "other-%d" % index, is_player = index == 0,
			wingspan_m = 1.7, state = other, wind_ned = wind})
	var result: Dictionary = pilot.command(snapshot, 0, traffic)
	var actual_active: bool = bool(result.get("avoidance_active", false))
	if not bool(result.get("ok", false)) or actual_active != near:
		return {ok = false, packet = result, expected_active = near}
	var velocity: PackedFloat64Array = M.q_rotate(own.slice(6, 10), own.slice(3, 6))
	var threats: Array[Dictionary] = pilot._prepare_threats(traffic, velocity)
	return {ok = true, state = own, velocity = velocity, wind = wind, snapshot = snapshot,
		traffic = traffic, threats = threats, initial = result, held = pilot.snapshot_state()}

func measure(pilot: RefCounted, field: Dictionary, kind: String, near: bool, count: int) -> Dictionary:
	var fixture := setup(pilot, field, near, count)
	if not fixture.ok:
		return fixture
	var iterations: int = SCORE_ITERATIONS if kind == "score" else COMMAND_ITERATIONS
	var own: PackedFloat64Array = fixture.state
	var velocity: PackedFloat64Array = fixture.velocity
	var threats: Array[Dictionary] = fixture.threats
	var snapshot: Dictionary = fixture.snapshot
	var traffic: Array = fixture.traffic
	var started := Time.get_ticks_usec()
	var local_sink := 0.0
	for i in iterations:
		if kind == "score":
			var result: Dictionary = pilot._score_bank(own, velocity, 15.0, 0.2, 0.1, -0.2, 35.0, threats)
			local_sink += float(result.score)
		else:
			var result: Dictionary = pilot.command(snapshot, (i + 1) * 4, traffic)
			local_sink += float(result.roll)
	var elapsed := Time.get_ticks_usec() - started
	sink += local_sink
	return {ok = true, elapsed_usec = elapsed, iterations = iterations, sink = local_sink,
		initial_packet = fixture.initial, initial_latch = fixture.held, final_latch = pilot.snapshot_state()}

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var out_path := ""
	var smoke := false
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="): out_path = argument.trim_prefix("--out=")
		elif argument == "--smoke": smoke = true
	if out_path.is_empty() or FileAccess.file_exists(out_path):
		printerr("Require a new --out path")
		quit(1)
		return
	var loaded: Dictionary = FieldLoader.load_from()
	if not loaded.get("ok", false):
		printerr("Could not load field")
		quit(1)
		return
	var field: Dictionary = loaded.field
	var variants: Array[Script] = [Roots, Turn, Both]
	var names := ["roots", "turn", "both"]
	var cases: Array[Dictionary] = [
		{name = "score_1", kind = "score", near = false, count = 1},
		{name = "score_3", kind = "score", near = false, count = 3},
		{name = "clear_command_1", kind = "command", near = false, count = 1},
		{name = "clear_command_3", kind = "command", near = false, count = 3},
		{name = "held_conflict_1", kind = "command", near = true, count = 1},
		{name = "held_conflict_3", kind = "command", near = true, count = 3},
	]
	var trials: Array[Dictionary] = []
	var rounds: int = 1 if smoke else ROUNDS
	for entry: Dictionary in cases:
		for v in variants.size():
			var pilots: Array = [Base.new(), variants[v].new()]
			var baseline_fixture: Dictionary = setup(pilots[0], field, entry.near, entry.count)
			var candidate_fixture: Dictionary = setup(pilots[1], field, entry.near, entry.count)
			if not baseline_fixture.ok or not candidate_fixture.ok \
					or var_to_bytes(baseline_fixture.initial) != var_to_bytes(candidate_fixture.initial) \
					or var_to_bytes(baseline_fixture.held) != var_to_bytes(candidate_fixture.held):
				printerr("Invalid/mismatched benchmark fixture " + str(entry.name) + " " + names[v])
				quit(1)
				return
			# One untimed call warms bytecode, table, and object paths.
			measure(pilots[0], field, entry.kind, entry.near, entry.count)
			measure(pilots[1], field, entry.kind, entry.near, entry.count)
			for round_index in rounds:
				var order: Array = [0, 1, 1, 0] if round_index % 2 == 0 else [1, 0, 0, 1]
				for position in order.size():
					var role: int = order[position]
					var result := measure(pilots[role], field, entry.kind, entry.near, entry.count)
					if not result.ok:
						printerr("Invalid measurement fixture")
						quit(1)
						return
					result.round = round_index
					result.position = position
					result.role = "baseline" if role == 0 else "candidate"
					result.candidate = names[v]
					result.case = entry.name
					trials.append(result)
	var report := {format = "openrc-predictor-comparison-v1", godot = Engine.get_version_info(),
		field_sha256 = FileAccess.get_sha256("res://data/fields/default.json"),
		baseline_sha256 = FileAccess.get_sha256("res://ai/companions/pilot_baseline.gd"),
		roots_sha256 = FileAccess.get_sha256("res://ai/companions/pilot_roots.gd"),
		turn_sha256 = FileAccess.get_sha256("res://ai/companions/pilot_turn.gd"),
		both_sha256 = FileAccess.get_sha256("res://ai/companions/pilot_both.gd"),
		warmup = "one untimed complete block per role and case", rounds = rounds, smoke = smoke,
		scope = "isolated score and command methods on synthetic fixed snapshots; no simulation, whole-manager, physical validation or rendered FPS", trials = trials}
	var file := FileAccess.open(out_path, FileAccess.WRITE)
	if file == null:
		printerr("Cannot write output")
		quit(1)
		return
	file.store_string(JSON.stringify(report, "  ") + "\n")
	file.close()
	print("PREDICTOR BENCH COMPLETE: %d trials" % trials.size())
	quit(0)
