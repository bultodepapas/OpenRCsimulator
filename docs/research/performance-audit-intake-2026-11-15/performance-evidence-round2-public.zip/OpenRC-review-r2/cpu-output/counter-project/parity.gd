extends SceneTree

const Base := preload("res://ai/companions/pilot_baseline.gd")
const Roots := preload("res://ai/companions/pilot_roots.gd")
const Turn := preload("res://ai/companions/pilot_turn.gd")
const Both := preload("res://ai/companions/pilot_both.gd")
const FieldLoader := preload("res://data/field_loader.gd")
const M := preload("res://physics/math3d.gd")
const Body := preload("res://physics/rigid_body.gd")
const TRIM := {V = 15.0, throttle = 0.45}
var checks := 0
var failures := 0
var command_pairs := 0
var score_pairs := 0
var total_command_cases := 0
var total_score_cases := 0
var trace_cases := 0
var held_cases := 0
var active_cases := 0
var clear_cases := 0
var empty_cases := 0
var _shown := 0

func check(label: String, condition: bool) -> void:
	checks += 1
	if not condition:
		failures += 1
		if _shown < 12:
			printerr("FAIL " + label)
			_shown += 1

func pilot_set(field: Dictionary, slot: int, count: int, seed: int) -> Array:
	var pilots: Array = [Base.new(), Roots.new(), Turn.new(), Both.new()]
	for pilot: RefCounted in pilots:
		check("configuration " + pilot.get_script().resource_path, pilot.configure(slot, count, seed, TRIM, field))
		pilot._plan_diagnostic_count = pilot.MAX_PLAN_DIAGNOSTICS
	return pilots

func compare_command(pilots: Array, snapshot: Dictionary, tick: int, traffic: Array, label: String) -> void:
	var before := var_to_bytes([snapshot, traffic])
	var baseline: Dictionary = pilots[0].command(snapshot, tick, traffic)
	var base_state: PackedByteArray = var_to_bytes(pilots[0].snapshot_state())
	var base_diagnostic: PackedByteArray = var_to_bytes(pilots[0]._last_decision)
	if traffic.is_empty(): empty_cases += 1
	elif bool(baseline.get("avoidance_active", false)): active_cases += 1
	else: clear_cases += 1
	if bool(pilots[0].snapshot_state().has_held_maneuver): held_cases += 1
	for i in range(1, pilots.size()):
		var actual: Dictionary = pilots[i].command(snapshot, tick, traffic)
		var ok: bool = var_to_bytes(baseline) == var_to_bytes(actual) \
			and base_state == var_to_bytes(pilots[i].snapshot_state()) \
			and base_diagnostic == var_to_bytes(pilots[i]._last_decision)
		check("command %s variant %d" % [label, i], ok)
		command_pairs += 1
	check("command preserves inputs " + label, before == var_to_bytes([snapshot, traffic]))
	total_command_cases += 1

func snapshot_for(pose: Dictionary, rng: RandomNumberGenerator, phase: int) -> Dictionary:
	var heading: float = float(pose.heading_rad)
	var roll: float = rng.randf_range(-0.4, 0.4) if phase > 0 else 0.0
	var wind := PackedFloat64Array([rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0), 0.0])
	var state: PackedFloat64Array = Body.make_state(
		PackedFloat64Array([pose.north, pose.east, -pose.height_m]),
		PackedFloat64Array([15.0, 0.0, 0.0]), M.q_from_euler(heading, 0.0, roll),
		PackedFloat64Array([rng.randf_range(-0.1, 0.1), 0.0, 0.0]))
	return {state = state, airspeed_m_s = 15.0, wind_ned = wind,
		ground_clearance_m = 35.0, trim = TRIM}

func traffic_for(snapshot: Dictionary, rng: RandomNumberGenerator, phase: int) -> Array:
	if phase == 4 or phase == 5: return []
	var own: PackedFloat64Array = snapshot.state
	var heading: float = M.q_to_euler(own.slice(Body.ATT, Body.ATT + 4))[0]
	var result: Array = []
	var near: bool = phase in [1, 2, 6, 7]
	for index in (3 if phase == 2 or phase == 7 else 1):
		var distance := rng.randf_range(35.0, 90.0) if near else 1000.0
		var offset := rng.randf_range(-0.8, 0.8) if near else 0.0
		result.append({id = "other-%d" % index, is_player = index == 0, wingspan_m = 1.7,
			state = Body.make_state(PackedFloat64Array([
				own[0] + distance * cos(heading + offset), own[1] + distance * sin(heading + offset), own[2]]),
				PackedFloat64Array([15.0, 0.0, 0.0]), M.q_from_euler(heading + PI, 0.0, 0.0),
				PackedFloat64Array([0.0, 0.0, 0.0])), wind_ned = snapshot.wind_ned})
	return result

func run_commands(field: Dictionary, rng: RandomNumberGenerator) -> void:
	for sequence in 96:
		var pilots := pilot_set(field, 0, 1, sequence)
		for pilot: RefCounted in pilots:
			pilot.diagnostics_enabled = sequence % 2 == 0
		var pose: Dictionary = pilots[0].initial_pose()
		for phase in 10:
			var snapshot := snapshot_for(pose, rng, phase)
			var traffic := traffic_for(snapshot, rng, phase)
			compare_command(pilots, snapshot, phase * 244, traffic, "%d/%d" % [sequence, phase])
	# Boundary and refusal controls pass through the public command entry point.
	var pilots := pilot_set(field, 0, 1, 100)
	var pose: Dictionary = pilots[0].initial_pose()
	var valid := snapshot_for(pose, rng, 0)
	var malformed := valid.duplicate(true)
	malformed.state = PackedFloat64Array([NAN, 0.0])
	compare_command(pilots, malformed, 0, [], "bad state")
	var high_wind := valid.duplicate(true)
	high_wind.wind_ned = PackedFloat64Array([6.0, 0.0, 0.0])
	compare_command(pilots, high_wind, 4, [], "rejected wind")
	var low_speed := valid.duplicate(true)
	low_speed.state[3] = 1.0
	compare_command(pilots, low_speed, 8, traffic_for(low_speed, rng, 1), "low speed fallback")

func make_threats(count: int, rng: RandomNumberGenerator, extreme: Variant = null) -> Array[Dictionary]:
	var threats: Array[Dictionary] = []
	for index in count:
		var positions := PackedFloat64Array()
		positions.resize(33 * 3)
		for sample in 33:
			positions[sample * 3] = rng.randf_range(-500.0, 500.0)
			positions[sample * 3 + 1] = rng.randf_range(-500.0, 500.0)
			positions[sample * 3 + 2] = rng.randf_range(-100.0, 0.0)
		if extreme != null:
			positions[0] = float(extreme)
			positions[3 * 17 + 1] = float(extreme)
		threats.append({id = "sample-%d" % index, is_player = index == 0,
			required_separation_m = 30.0 if index == 0 else 15.0, positions = positions})
	return threats

func compare_score(pilots: Array, state: PackedFloat64Array, velocity: PackedFloat64Array,
		wind: PackedFloat64Array, speed: float, bank: float, nominal: float, selected: float,
		clearance: float, threats: Array[Dictionary], trace: bool, label: String) -> void:
	for pilot: RefCounted in pilots:
		pilot._planning_wind = wind.duplicate()
	var before := var_to_bytes([state, velocity, wind, threats])
	var expected: Dictionary = pilots[0]._score_bank(state, velocity, speed, bank, nominal, selected, clearance, threats, trace)
	for i in range(1, pilots.size()):
		var actual: Dictionary = pilots[i]._score_bank(state, velocity, speed, bank, nominal, selected, clearance, threats, trace)
		check("score %s variant %d" % [label, i], var_to_bytes(expected) == var_to_bytes(actual))
		score_pairs += 1
	check("score preserves inputs " + label, before == var_to_bytes([state, velocity, wind, threats]))
	if trace: trace_cases += 1
	total_score_cases += 1

func run_scores(field: Dictionary, rng: RandomNumberGenerator) -> void:
	var pilots := pilot_set(field, 0, 1, 101)
	for case_index in 500:
		var state := PackedFloat64Array([rng.randf_range(-500.0, 500.0), rng.randf_range(-500.0, 500.0),
			rng.randf_range(-100.0, -20.0), 15.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
		var velocity := PackedFloat64Array([rng.randf_range(-25.0, 25.0), rng.randf_range(-25.0, 25.0), rng.randf_range(-3.0, 3.0)])
		var wind := PackedFloat64Array([rng.randf_range(-2.0, 2.0), rng.randf_range(-2.0, 2.0), 0.0])
		var speed: float = rng.randf_range(3.0, 25.0)
		var bank: float = rng.randf_range(-0.4363323129985824, 0.4363323129985824)
		var selected: float = rng.randf_range(-0.4363323129985824, 0.4363323129985824)
		var threats := make_threats(case_index % 4, rng)
		compare_score(pilots, state, velocity, wind, speed, bank, 0.1, selected,
			rng.randf_range(15.0, 100.0), threats, case_index % 5 == 0, str(case_index))
	# Extreme positions force underflow, overflow, infinities, NaNs and signed zeros
	# through the actual scorer without pretending they are qualified flight states.
	var state := PackedFloat64Array([0.0, 0.0, -35.0, 15.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
	var velocity := PackedFloat64Array([15.0, 0.0, 0.0])
	var wind := PackedFloat64Array([0.0, 0.0, 0.0])
	for extreme: float in [0.0, -0.0, pow(2.0, -600.0), -pow(2.0, -600.0), pow(2.0, 600.0), -pow(2.0, 600.0), INF, -INF, NAN]:
		for trace: bool in [false, true]:
			compare_score(pilots, state, velocity, wind, 15.0, -0.4, 0.1, 0.4, 35.0,
				make_threats(3, rng, extreme), trace, "extreme %s trace=%s" % [str(extreme), str(trace)])

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var loaded: Dictionary = FieldLoader.load_from()
	check("actual field validates", bool(loaded.get("ok", false)))
	if not loaded.get("ok", false):
		quit(1)
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261109
	run_commands(loaded.field, rng)
	run_scores(loaded.field, rng)
	print("PREDICTOR PARITY COMPLETE: %d checks, %d failures; %d command pairs (%d cases), %d score pairs (%d cases), %d traces; active=%d held=%d clear=%d empty=%d" % [checks, failures, command_pairs, total_command_cases, score_pairs, total_score_cases, trace_cases, active_cases, held_cases, clear_cases, empty_cases])
	quit(1 if failures else 0)
