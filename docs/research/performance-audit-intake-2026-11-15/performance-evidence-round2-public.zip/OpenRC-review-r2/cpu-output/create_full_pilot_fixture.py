#!/usr/bin/env python3
"""Copy the already-imported exact-current physics fixture to a private pilot workspace."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "repository"
PREPARED = HERE.parent / "physics-output" / "baseline-app"
OUT = HERE / "pilot-full"
APP = OUT / "app"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if OUT.exists():
    raise SystemExit("refusing to overwrite pilot-full")
if not PREPARED.is_dir() or not (PREPARED / ".godot").is_dir():
    raise SystemExit("prepared, imported baseline fixture is unavailable")
OUT.mkdir()
shutil.copytree(PREPARED, APP)
candidate_from = HERE / "predictor-project/ai/companions/pilot_both.gd"
candidate_to = APP / "ai/companions/pilot_candidate_audit.gd"
shutil.copy2(candidate_from, candidate_to)
tools = APP / "audit_tools"
tools.mkdir()
for name in ("pilot_probe_audit.gd", "encounter_probe_audit.gd"):
    shutil.copy2(HERE / "prepared-probes" / name, tools / name)

# Compare all source and data files that exist in the selected checkout; the
# fixture's project.godot delta and independently recovered assets are recorded separately.
checked = 0
mismatches = []
for source in (ROOT / "app").rglob("*"):
    if not source.is_file() or source.suffix not in (".gd", ".json", ".tscn", ".tres", ".gdshader"):
        continue
    relative = source.relative_to(ROOT / "app")
    target = APP / relative
    checked += 1
    if not target.is_file() or sha(source) != sha(target):
        mismatches.append(str(relative))
if mismatches:
    raise SystemExit("fixture source/data mismatches: " + ", ".join(mismatches[:30]))
shutil.copy2(HERE.parent / "physics-output/reference-project.diff", OUT / "reference-project.diff")
shutil.copy2(HERE.parent / "physics-output/fixture-assets.json", OUT / "fixture-assets.json")
receipt = {
    "source_commit": "ca529cb88476a22fbb1c8edf957d6917ab9b6042",
    "checked_source_and_data_files": checked,
    "source_data_mismatches": mismatches,
    "baseline_pilot_sha256": sha(APP / "ai/companions/pilot.gd"),
    "candidate_pilot_sha256": sha(candidate_to),
    "matrix_probe_original_sha256": sha(ROOT / "research/ai-companions/pilot_probe.gd"),
    "matrix_probe_instrumented_sha256": sha(tools / "pilot_probe_audit.gd"),
    "encounter_probe_original_sha256": sha(ROOT / "research/ai-companions/encounter_probe.gd"),
    "encounter_probe_instrumented_sha256": sha(tools / "encounter_probe_audit.gd"),
    "project_sha256": sha(APP / "project.godot"),
    "project_delta": "reference-project.diff",
    "recovered_exact_assets": "fixture-assets.json",
    "purpose": "headless source-selected fixed-step qualification; no profile pin or production source modified",
}
(OUT / "fixture-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
