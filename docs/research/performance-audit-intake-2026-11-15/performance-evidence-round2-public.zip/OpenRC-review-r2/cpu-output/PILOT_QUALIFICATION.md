# Reachable-pilot optimization: qualification and scope

## Result and production files

The combined candidate was qualified on the pinned Godot
`4.8.beta2.official.cafc17a19` build. The source change and a focused regression
test are installed in the review worktree on base commit
`300dc4e82cc6975b6f4e808cb4b2b845a0240ded`, without a commit or push:

- `app/ai/companions/pilot.gd`: SHA-256
  `c8435800538963c3313f3e2c7b769c716ffa33d3eb2ca611f669c5170d1fa41d`.
- `app/data/ai/companions/aircraft/jensen-das-ugly-stik-60.json`: only the
  controller source pin changes; file SHA-256
  `8e4eaae9325559313554e250dba135c82bbf86db71ee7235d93f115fd3086e12`.
- `app/tests/test_companions_reachable_score.gd`: SHA-256
  `bf5bcf4f6da32d307f04494fbb140aaad3292e8cc1da7273780f94b3027b8aa9`.
- The test's Godot-generated sidecar is `uid://nadycuiumhgt`.

The source baseline was pilot SHA-256
`6c9eb4c53f4f80c284249fc143f976b2e5becc555a50ee415afe92bb8129b151`.
`profile_loader.gd` enforces the exact pilot source and inherited circuit
controller hash. In a private production-path fixture the stale profile
rejected the candidate for exactly that mismatch; changing only its pilot pin
admitted it without errors. The current-head source-overlay profile test also
passed its strict solver/source gate.

## Change and component measurement

When trace output is off, `_score_bank` reduces the same squared distances to
one minimum per threat and applies `sqrt_` after the reduction. With trace on,
each original distance and trace sample is still computed. It also computes
the original full-ramp `lerpf`/`tan`/division once and reuses the result for
the remaining full-ramp samples of that score, with no shared or cross-call
cache. The implemented ramp changes 32 turn-rate calculations to 8. The
instrumented direct scorer measured 33 to 1 square-root calls per threat
without a trace, and 33 to 33 with a trace; 227 checks including exact ties
passed. The instrumentation exists only in the separate counter fixture.

The five-round alternating component comparison used real `pilot.command`
methods on synthetic fixed snapshots. For the combined candidate, the median
batch means in the held-conflict cases were 544.3 to 473.5 microseconds per
command with one threat and 740.4 to 657.1 microseconds with three threats.
Those are about 70.8 and 83.3 microseconds saved in those tested cases. The
clear-traffic results were mixed, and individual paired ratios were noisy.
These are not whole-flight, frame-rate, or platform-wide performance results.
The complete timings and individual trials are in `predictor-timing.json`.

## Closed-loop evidence

`pilot-full/fixture-receipt.json` records 1,898 app source/data files matched
against commit `ca529cb88476a22fbb1c8edf957d6917ab9b6042`; the `project.godot`
delta removes the main scene, font autoload, translations and editor plugins.
The app is an isolated headless source-and-selected-assets fixture. Exact
recovered Git blob and generated-import receipts are retained alongside it.

Both the original and candidate completed the full existing circuit matrix:
148 checks each, zero failures, six 120-second calm/gentle cases across one,
two and three aircraft plus two 120-second seeded repeats. The audit-probe
copy hashed every 60 Hz returned packet and controller latch, plus selected
physical state arrays at every 240 Hz tick. All eight 120-second streams match,
including all 129,600 planning calls per version. Both emitted circuit CSVs
are also byte-identical. The instrumented probe differs from the original only
by this observational digest; source hashes are in the fixture receipt.

Both pilots then completed the seven existing 12-second real-session encounter
cases plus the deterministic repeat, each with 2,880 physical ticks and 720
plans. The existing per-tick physical-state/control digests, added per-plan
packet/latch/diagnostic-decision digests, and trajectory CSVs match. The
seven cases include 3,106 active-avoidance samples out of 5,040 plans.
The deliberately constructed parallel-two-threats case misses its separation
gate for both versions, so this is a survey comparison, not an expansion of
the existing pilot qualification. Both successful checked encounter runs had
zero errors and six UID-to-text-path resource fallback warnings; they did not
use flight-log replay as a surrogate for executing the pilot.

`pilot-full/comparison.json` contains the detailed digests and verifies the
case/plan/tick counts. Earlier incomplete setup attempts remain retained: one
lacked scenery assets and parked metadata; a later attempt lacked the
vegetation catalog and emitted 359 errors. They are failed runs, not included
in the passing comparison.

Separately, the minimal exact-source component fixture passed 6,317 checks:
2,889 baseline/candidate command pairs and 1,554 score pairs, including 109
trace cases and direct synthetic signed-zero, underflow, overflow, infinity and
NaN inputs. This is differential evidence for the tested inputs, not a claim
that arbitrary malformed private calls are a supported flight envelope.

## Focused production-path checks

With the tested pilot installed at its actual resource path and the matching
profile pin in the private fixture, the checked suites passed: pilot 24/24,
linear fallback encounters 191/191, clearance 20/20, strict profiles 44/44,
manager 53/53 and session 65/65. The first manager check printed 53 successful
assertions but produced 29 errors from absent Stik/Timber visual assets and was
rejected; the successful rerun used the exact recovered assets and had zero
errors and engine warnings.

The new focused score test passes 26/26 on both the old and candidate source.
It covers a 33-way distance tie, the one-ULP sides of the separation threshold,
unchanged inputs, equality of trace and non-trace score fields, and seven
baseline turn-trace checkpoints spanning the ramp and its endpoint. The
unit-test roster discovers `app/tests/test_*.gd` automatically.

Run the focused check in a complete imported checkout with:

```sh
python3 tools/godot/run_checked.py --label companion-reachable-score --timeout 60 \
  --require-text "companion reachable score: 26 checks, 0 failed" -- \
  "$GODOT" --headless --audio-driver Dummy --path app \
  --script res://tests/test_companions_reachable_score.gd
```

## Current-head closure and limits

The full flights ran on the frozen `ca529` fixture, not the later head. The
`ca529` to `300dc` diff has no changes in app physics, simulation, failures,
companion AI/profile/data, project settings, or the two flight probes. It does
change controller actions and audio render code, render/UI code, scenery source
and tractor visual assets. The controller change affects automatic gamepad
binding, while these external-driver fixtures use no live gamepad. The changed
scenery setup adds render metadata; `CollisionSetup.build` uses the unchanged
options/layout methods and collision boxes from prefab dimensions rather than
the new tractor mesh. These are source assessments, not claims about every
product route. `head-300-integration/overlay-receipt.json` records a private
overlay of 21 available changed app files; the unused tractor visual resource
and shadow test source were absent from the selective checkout. On that overlay,
the manager suite passed 53/53 and strict profiles 44/44 with no engine errors
or warnings, and the new score test passed 26/26.

This evidence covers the recorded headless source builds, input scenarios and
physics backend only. It does not establish native GPU/FPS results, physical
aircraft validity, wider encounter separation, or an unrestricted new roster,
weather, aircraft or activity envelope. The stage-time wind-cache experiment
is a separate unpromoted proposal.
