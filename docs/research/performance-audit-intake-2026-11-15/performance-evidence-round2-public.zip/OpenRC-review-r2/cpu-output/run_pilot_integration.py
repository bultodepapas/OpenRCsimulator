#!/usr/bin/env python3
"""Run checked existing production-path companion suites in the private candidate fixture."""
from pathlib import Path
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "repository"
OUT = HERE / "pilot-full"
GODOT = HERE.parent.parent / "audit-review/repository/.tools/Godot_v4.8-beta2_linux.x86_64"
CASES = [
    ("test_companions_pilot.gd", "companion pilot:"),
    ("test_companions_encounters.gd", "companion encounters:"),
    ("test_companions_clearance.gd", "companion clearance:"),
    ("test_companions_profiles.gd", "AFC-02 companion profile validation:"),
    ("test_companions_manager.gd", "companions manager:"),
    ("test_companions_session.gd", "checks, 0 failed"),
]
results = []
for test, marker in CASES:
    label = "integration-" + test.removesuffix(".gd")
    cmd = [sys.executable, str(REPO / "tools/godot/run_checked.py"), "--out-dir", str(OUT / "checks"),
           "--label", label, "--timeout", "240", "--require-text", marker, "--",
           "env", f"XDG_CONFIG_HOME={HERE / 'xdg/config'}", f"XDG_DATA_HOME={HERE / 'xdg/data'}",
           f"XDG_CACHE_HOME={HERE / 'xdg/cache'}", str(GODOT), "--headless", "--audio-driver", "Dummy",
           "--path", str(OUT / "app"), "--script", f"res://tests/{test}"]
    run = subprocess.run(cmd, cwd=REPO, text=True, capture_output=True)
    directories = sorted((OUT / "checks").glob(label + "-*"))
    if len(directories) != 1:
        result = {"test": test, "ok": False, "runner_exit": run.returncode, "error": "checked report missing or ambiguous"}
    else:
        report = json.loads((directories[0] / "report.json").read_text())
        lines = (directories[0] / "engine.log").read_text(errors="replace").splitlines()
        summary = [line for line in lines if marker in line]
        result = {"test": test, "ok": report.get("ok", False), "runner_exit": run.returncode,
                  "summary": summary[-1] if summary else "", "counts": report.get("counts", {}),
                  "reason": report.get("reason", ""), "report": str(directories[0] / "report.json")}
    results.append(result)
    print(json.dumps(result), flush=True)
(OUT / "integration-summary.json").write_text(json.dumps(results, indent=2) + "\n")
sys.exit(0 if all(result["ok"] for result in results) else 1)
