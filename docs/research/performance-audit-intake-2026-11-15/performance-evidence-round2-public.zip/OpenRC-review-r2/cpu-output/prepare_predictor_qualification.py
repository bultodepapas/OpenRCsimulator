#!/usr/bin/env python3
"""Prepare scratch-only controller qualification tools; never edits repository sources."""
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "repository"
PREDICTOR = HERE / "predictor-project"
COUNTER = HERE / "counter-project"
PROBES = HERE / "prepared-probes"


def once(source: str, old: str, new: str) -> str:
    if source.count(old) != 1:
        raise RuntimeError(f"expected one source anchor, found {source.count(old)}: {old!r}")
    return source.replace(old, new)


if COUNTER.exists() or PROBES.exists():
    raise SystemExit("refusing to overwrite an existing scratch preparation")
shutil.copytree(PREDICTOR, COUNTER, ignore=shutil.ignore_patterns(".godot"))
math_path = COUNTER / "physics" / "math3d.gd"
math = math_path.read_text()
math = once(math, "static func sqrt_(a: float) -> float:\n\treturn sqrt(a)",
            "static var audit_sqrt_calls: int = 0\n\n\nstatic func sqrt_(a: float) -> float:\n\taudit_sqrt_calls += 1\n\treturn sqrt(a)")
math_path.write_text(math)
PROBES.mkdir()
matrix = (ROOT / "research/ai-companions/pilot_probe.gd").read_text()
matrix = once(matrix, "\tfor tick in _flight_ticks:\n", "\tvar audit_digest := HashingContext.new()\n\taudit_digest.start(HashingContext.HASH_SHA256)\n\tvar audit_plans := 0\n\tfor initial_session: Node in sessions:\n\t\taudit_digest.update(var_to_bytes([initial_session.sim.state, initial_session.sim.previous, initial_session.sim.aux, initial_session.sim.continuous, initial_session.sim.modes, initial_session.sim.inputs]))\n\tfor tick in _flight_ticks:\n")
matrix = once(matrix, "\t\t\t\tvar packet: Dictionary = pilot.command(snapshot, tick, traffic)\n", "\t\t\t\tvar packet: Dictionary = pilot.command(snapshot, tick, traffic)\n\t\t\t\taudit_digest.update(var_to_bytes([tick, slot, packet, pilot.snapshot_state()]))\n\t\t\t\taudit_plans += 1\n")
matrix = once(matrix, "\t\t\tvar state: PackedFloat64Array = session.sim.state\n\t\t\tvar altitude:", "\t\t\tvar state: PackedFloat64Array = session.sim.state\n\t\t\taudit_digest.update(var_to_bytes([tick, slot, state, session.sim.previous, session.sim.aux, session.sim.continuous, session.sim.modes, session.sim.inputs]))\n\t\t\tvar altitude:")
matrix = once(matrix, "\tvar completed_ticks: int = int(sessions[0].sim.tick) if not sessions.is_empty() else 0\n", "\tprint(\"PILOT_MATRIX_AUDIT %s %d %s %d %s\" % [weather_id, count, str(record_trace), audit_plans, audit_digest.finish().hex_encode()])\n\tvar completed_ticks: int = int(sessions[0].sim.tick) if not sessions.is_empty() else 0\n")
(PROBES / "pilot_probe_audit.gd").write_text(matrix)
encounter = (ROOT / "research/ai-companions/encounter_probe.gd").read_text()
encounter = once(encounter, "\tvar pose_value: Variant = pilot.call(\"initial_pose\")\n", "\tpilot.diagnostics_enabled = true\n\tpilot._plan_diagnostic_count = pilot.MAX_PLAN_DIAGNOSTICS\n\tvar pose_value: Variant = pilot.call(\"initial_pose\")\n")
encounter = once(encounter, "\tvar digest := HashingContext.new()\n\tdigest.start(HashingContext.HASH_SHA256)\n\tdigest.update(\"openrc-companion-encounter-state-command-v1\".to_utf8_buffer())\n", "\tvar decision_digest := HashingContext.new()\n\tdecision_digest.start(HashingContext.HASH_SHA256)\n\tvar digest := HashingContext.new()\n\tdigest.start(HashingContext.HASH_SHA256)\n\tdigest.update(\"openrc-companion-encounter-state-command-v1\".to_utf8_buffer())\n")
encounter = once(encounter, "\t\t\tvar packet_value: Variant = pilot.call(\"command\", ai_snapshot, tick, traffic)\n", "\t\t\tvar packet_value: Variant = pilot.call(\"command\", ai_snapshot, tick, traffic)\n\t\t\tdecision_digest.update(var_to_bytes([tick, packet_value, pilot.snapshot_state(), pilot._last_decision]))\n")
encounter = once(encounter, "\t\t\"state_command_sha256\": digest_hex,\n", "\t\t\"state_command_sha256\": digest_hex,\n\t\t\"decision_packet_sha256\": decision_digest.finish().hex_encode(),\n")
(PROBES / "encounter_probe_audit.gd").write_text(encounter)
print("Prepared isolated counter project and two instrumented probe copies.")
