#!/usr/bin/env python3
"""Create private 300dc overlay of qualified fixture for bounded admission check."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "repository"
SRC = HERE / "pilot-full/app"
OUT = HERE / "head-300-integration"
APP = OUT / "app"
OLD = "ca529cb88476a22fbb1c8edf957d6917ab9b6042"
HEAD = "300dc4e82cc6975b6f4e808cb4b2b845a0240ded"
actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
if actual != HEAD or OUT.exists():
    raise SystemExit("head changed or overlay already exists")
shutil.copytree(SRC, APP)
names = subprocess.check_output(["git", "diff", "--name-only", OLD, HEAD, "--", "app"], cwd=REPO, text=True).splitlines()
names += ["app/render/worn_ground_material.gd.uid", "app/tests/test_farm_tractor.gd.uid"]
applied, absent = [], []
for name in names:
    source = REPO / name
    target = APP / Path(name).relative_to("app")
    if not source.is_file():
        absent.append(name)
        continue
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    applied.append({"path": name, "sha256": hashlib.sha256(source.read_bytes()).hexdigest()})
pilot = APP / "ai/companions/pilot.gd"
profile = APP / "data/ai/companions/aircraft/jensen-das-ugly-stik-60.json"
candidate_sha = hashlib.sha256(pilot.read_bytes()).hexdigest()
if candidate_sha != "c8435800538963c3313f3e2c7b769c716ffa33d3eb2ca611f669c5170d1fa41d":
    raise SystemExit("candidate source changed")
receipt = {"head": HEAD, "qualified_fixture_base": OLD, "applied": applied, "absent": absent,
           "pilot_sha256": candidate_sha, "profile_sha256": hashlib.sha256(profile.read_bytes()).hexdigest(),
           "limitations": "Source overlay of source-only, headless ca529 fixture; missing tractor visual resource remains unexercised."}
(OUT / "overlay-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"head": HEAD, "applied": len(applied), "absent": absent, "pilot_sha256": candidate_sha}, indent=2))
