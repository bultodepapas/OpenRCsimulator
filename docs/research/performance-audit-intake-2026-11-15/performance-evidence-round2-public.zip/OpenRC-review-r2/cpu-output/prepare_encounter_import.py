#!/usr/bin/env python3
"""Stage exact recovered assets at matching res:// paths for isolated Godot import."""
from pathlib import Path
import json
import shutil

HERE = Path(__file__).resolve().parent
APP = HERE / "pilot-full/app"
TARGET = HERE / "encounter-import-project"
if TARGET.exists():
    raise SystemExit("refusing to overwrite encounter import project")
TARGET.mkdir()
shutil.copy2(APP / "project.godot", TARGET / "project.godot")
receipt = json.loads((HERE / "pilot-full/encounter-assets-receipt.json").read_text())
for item in receipt["files"]:
    relative = item["path"]
    source, dest = APP / relative, TARGET / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    sidecar = Path(str(source) + ".import")
    if sidecar.is_file():
        shutil.copy2(sidecar, Path(str(dest) + ".import"))
print(f"Staged {len(receipt['files'])} exact files at identical project-relative paths")
