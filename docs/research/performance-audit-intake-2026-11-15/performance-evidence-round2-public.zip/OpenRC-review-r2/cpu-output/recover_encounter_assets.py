#!/usr/bin/env python3
"""Recover explicitly required ca529 Git blobs into the private encounter fixture."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "repository"
APP = HERE / "pilot-full/app"
REV = "ca529cb88476a22fbb1c8edf957d6917ab9b6042"
names = [
    "assets/landscape/building-roofs/roof_slates_03_diff_1k.jpg",
    "assets/landscape/building-roofs/roof_slates_03_nor_gl_1k.png",
    "assets/landscape/building-roofs/roof_slates_03_arm_1k.jpg",
    "assets/landscape/building-roofs/clay_roof_tiles_diff_1k.jpg",
    "assets/landscape/building-roofs/clay_roof_tiles_nor_gl_1k.png",
    "assets/landscape/building-roofs/clay_roof_tiles_arm_1k.jpg",
    "assets/landscape/pit-shelter/corrugated_iron_02_diff_2k.jpg",
    "assets/landscape/pit-shelter/corrugated_iron_02_nor_gl_2k.png",
    "assets/landscape/pit-shelter/corrugated_iron_02_arm_2k.jpg",
]
names += [f"assets/scenery/aircraft/{name}.json" for name in
          ("avanti_assembled", "extra_assembled", "p51_assembled", "stik_assembled", "stik_service", "timber_assembled")]
names += [f"assets/landscape/airfield_detail/quaternius_rocks/Rock_Medium_{i}.{ext}" for i in (1, 2, 3)
          for ext in ("gltf", "bin")]
names += ["assets/landscape/airfield_detail/quaternius_rocks/Rocks_Diffuse.png",
          "assets/landscape/airfield_detail/flower_empodium/flower_empodium_1k.gltf",
          "assets/landscape/airfield_detail/flower_empodium/flower_empodium.bin"]
names += [f"assets/landscape/airfield_detail/flower_empodium/textures/flower_empodium_{kind}_1k.jpg"
          for kind in ("alpha", "arm", "diff", "nor_gl")]
items = []
for name in names:
    target = APP / name
    if target.exists():
        raise SystemExit(f"refusing to overwrite fixture asset: {name}")
    oid = subprocess.check_output(["git", "rev-parse", f"{REV}:app/{name}"], cwd=ROOT, text=True).strip()
    content = subprocess.check_output(["git", "cat-file", "blob", oid], cwd=ROOT)
    actual_oid = hashlib.sha1(f"blob {len(content)}\0".encode() + content).hexdigest()
    if actual_oid != oid:
        raise SystemExit(f"Git blob verification failed for {name}")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    items.append({"path": name, "git_blob": oid, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()})
    print(f"Recovered {name} ({len(content)} bytes)", flush=True)
receipt = {"revision": REV, "files": items, "total_bytes": sum(item["bytes"] for item in items)}
(HERE / "pilot-full/encounter-assets-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Recovered {len(items)} exact blobs ({receipt['total_bytes']} bytes)")
