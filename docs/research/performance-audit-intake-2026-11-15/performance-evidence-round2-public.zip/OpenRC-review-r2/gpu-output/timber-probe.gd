## Disposable comparison for the actual imported Timber GLB. The two scripts are
## supplied as source paths and loaded independently, like test_timber_visual_lods.
## Scope: imported hierarchy + paint-seam repair, not full Airplane.build/flight.
extends SceneTree

const ASSET := "res://assets/aircraft/turbo-lumber-evolution/timber.glb"
const VisualData := preload("res://assets/aircraft/turbo-lumber-evolution/visual-upgrade/visual_detail_data.gd")
const TARGETS := ["cowl", "fin_fixed", "fuselage_core", "wing_left_fixed", "wing_right_fixed"]

var checks := 0
var failures: Array[String] = []
var scene: PackedScene
var baseline: Script
var candidate: Script
var output_path := ""
var groups := 1


func _check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures.append(label)
		printerr("FAIL: ", label)


func _load_script(path: String) -> Script:
	var source := FileAccess.get_file_as_string(path)
	if source.is_empty():
		printerr("Cannot read details source: ", path)
		return null
	var script := GDScript.new()
	script.source_code = source
	if script.reload() != OK:
		printerr("Cannot compile details source: ", path)
		return null
	return script


func _initialize() -> void:
	var baseline_path := ""
	var candidate_path := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--baseline-source="):
			baseline_path = arg.trim_prefix("--baseline-source=")
		elif arg.begins_with("--candidate-source="):
			candidate_path = arg.trim_prefix("--candidate-source=")
		elif arg.begins_with("--report="):
			output_path = arg.trim_prefix("--report=")
		elif arg.begins_with("--groups="):
			groups = clampi(int(arg.trim_prefix("--groups=")), 1, 5)
	if baseline_path.is_empty() or candidate_path.is_empty() or output_path.is_empty():
		printerr("Pass --baseline-source=<absolute> --candidate-source=<absolute> --report=<absolute>")
		quit(2)
		return
	baseline = _load_script(baseline_path)
	candidate = _load_script(candidate_path)
	scene = load(ASSET) as PackedScene
	if baseline == null or candidate == null or scene == null:
		printerr("Missing script or imported Timber scene")
		quit(2)
		return
	var seed := _instance()
	if seed == null:
		quit(2)
		return
	var inventory := _inventory(seed)
	_check(inventory.size() == TARGETS.size(), "all five named source meshes are present")
	var original_refs := _source_refs(seed)
	_compare_hashes_and_keys(seed)
	_compare_lod_mutation(seed)

	# Independent script objects must own independent cache dictionaries.
	_clear_cache(baseline)
	_clear_cache(candidate)
	baseline.call("_repair_painted_surface_poke_through", seed)
	var baseline_cold := _root_snapshot(seed)
	var baseline_keys := _cache_keys(baseline)
	_check(not baseline_keys.is_empty(), "baseline cold repair builds cache entries")
	_check(_cache_keys(candidate).is_empty(), "candidate cache is separate")
	_check(_sources_unchanged(original_refs), "baseline repair preserves imported source meshes")

	var candidate_cold_root := _instance()
	var candidate_refs := _source_refs(candidate_cold_root)
	candidate.call("_repair_painted_surface_poke_through", candidate_cold_root)
	var candidate_cold := _root_snapshot(candidate_cold_root)
	var candidate_keys := _cache_keys(candidate)
	_check(baseline_keys == candidate_keys, "cold cache keys match")
	_check(baseline_cold == candidate_cold, "cold repair arrays, flags, LOD bytes, materials and node state match")
	_check(_sources_unchanged(candidate_refs), "candidate repair preserves imported source meshes")

	var baseline_warm_root := _instance()
	var candidate_warm_root := _instance()
	baseline.call("_repair_painted_surface_poke_through", baseline_warm_root)
	candidate.call("_repair_painted_surface_poke_through", candidate_warm_root)
	_check(_cache_keys(baseline) == baseline_keys and _cache_keys(candidate) == candidate_keys,
		"warm repair retains the same cache entries")
	_check(_root_snapshot(baseline_warm_root) == baseline_cold, "baseline cold and warm representations match")
	_check(_root_snapshot(candidate_warm_root) == candidate_cold, "candidate cold and warm representations match")
	_check(_root_snapshot(candidate_warm_root) == _root_snapshot(baseline_warm_root), "warm repair representations match")

	seed.free()
	candidate_cold_root.free()
	baseline_warm_root.free()
	candidate_warm_root.free()
	original_refs.clear()
	candidate_refs.clear()

	var control := _instance()
	# Source is now process-warm. A cold sample means the paint-repair cache was
	# cleared, not a fresh import or process. Model instantiation is not timed.
	var timings := {hash_sweep = [], repair_cold = [], repair_warm = []}
	for role: Script in [baseline, candidate]:
		_hash_sample(role, control)
		_repair_sample(role, true)
		_clear_cache(role)
		_repair_sample(role, false)
		_repair_sample(role, false)
	for kind in ["hash_sweep", "repair_cold", "repair_warm"]:
		if kind == "repair_warm":
			for role: Script in [baseline, candidate]:
				_clear_cache(role)
				_repair_sample(role, false)
		for group in groups:
			var order := [baseline, candidate, candidate, baseline] if group % 2 == 0 \
				else [candidate, baseline, baseline, candidate]
			for role: Script in order:
				var elapsed := _hash_sample(role, control) if kind == "hash_sweep" else _repair_sample(role, kind == "repair_cold", kind == "repair_warm")
				timings[kind].append({role = "baseline" if role == baseline else "candidate", usec = elapsed})
	control.free()
	var report := {format = "openrc-timber-snapshot-probe v1", baseline_revision = "ca529cb88476a22fbb1c8edf957d6917ab9b6042",
		asset_sha256 = FileAccess.get_sha256(ASSET), baseline_source_sha256 = FileAccess.get_sha256(baseline_path),
		candidate_source_sha256 = FileAccess.get_sha256(candidate_path), engine = Engine.get_version_info(),
		scope = "Imported Timber hierarchy and paint-seam repair only; cache-cold means process-warm; no flight or GPU claim",
		inventory = inventory, cache_keys = baseline_keys, checks = checks, failures = failures, groups = groups, timings = timings}
	var output := FileAccess.open(output_path, FileAccess.WRITE)
	if output == null:
		printerr("Cannot open report: ", output_path)
		quit(2)
		return
	output.store_string(JSON.stringify(report, "  "))
	output.close()
	print("Timber imported-source probe: ", checks, " checks, ", failures.size(), " failed")
	quit(1 if not failures.is_empty() else 0)


func _instance() -> Node3D:
	var node := scene.instantiate() as Node3D
	if node == null:
		printerr("Imported Timber root is not Node3D")
	return node


func _target_nodes(root: Node3D) -> Array[MeshInstance3D]:
	var nodes: Array[MeshInstance3D] = []
	if root == null:
		return nodes
	for node: Node in root.find_children("*", "MeshInstance3D", true, false):
		if str(node.name) in TARGETS and (node as MeshInstance3D).mesh is ArrayMesh:
			nodes.append(node as MeshInstance3D)
	nodes.sort_custom(func(a: MeshInstance3D, b: MeshInstance3D) -> bool: return str(root.get_path_to(a)) < str(root.get_path_to(b)))
	return nodes


func _inventory(root: Node3D) -> Array:
	var result := []
	for node: MeshInstance3D in _target_nodes(root):
		var surfaces: Array = node.mesh.get("_surfaces")
		var buffer_bytes := 0
		var lod_bytes := 0
		for surface: Dictionary in surfaces:
			for key in ["vertex_data", "attribute_data", "skin_data", "index_data", "blend_shapes"]:
				var data: Variant = surface.get(key)
				if data is PackedByteArray:
					buffer_bytes += data.size()
			var lods: Array = surface.get("lods", [])
			for index in range(1, lods.size(), 2):
				var indices: PackedByteArray = lods[index]
				lod_bytes += indices.size()
		result.append({name = str(node.name), path = str(root.get_path_to(node)), surfaces = node.mesh.get_surface_count(),
			logical_buffer_bytes_per_snapshot = buffer_bytes + lod_bytes, logical_lod_bytes = lod_bytes})
	return result


func _material_snapshot(material: Material) -> Dictionary:
	if material == null:
		return {}
	var properties := {}
	for info: Dictionary in material.get_property_list():
		if (int(info.get("usage", 0)) & PROPERTY_USAGE_STORAGE) == 0:
			continue
		var key := str(info.name)
		var value: Variant = material.get(key)
		if value is Resource:
			var resource := value as Resource
			properties[key] = {"class": resource.get_class(), "name": resource.resource_name, "path": resource.resource_path}
		elif value is Object:
			properties[key] = {"class": value.get_class()}
		elif typeof(value) not in [TYPE_RID, TYPE_CALLABLE, TYPE_SIGNAL]:
			properties[key] = value
	return {"class": material.get_class(), "name": material.resource_name, "properties": properties}


func _mesh_snapshot(mesh: ArrayMesh) -> PackedByteArray:
	var serialized: Array = mesh.get("_surfaces")
	var surfaces: Array = []
	for index in mesh.get_surface_count():
		var surface: Dictionary = serialized[index]
		surfaces.append({name = mesh.surface_get_name(index), format = mesh.surface_get_format(index),
			primitive = mesh.surface_get_primitive_type(index), arrays = mesh.surface_get_arrays(index),
			lods = surface.get("lods", []), material = _material_snapshot(mesh.surface_get_material(index))})
	return var_to_bytes({name = mesh.resource_name, surfaces = surfaces})


func _root_snapshot(root: Node3D) -> PackedByteArray:
	var nodes: Array = []
	for node: MeshInstance3D in _target_nodes(root):
		var active: Array = []
		var overrides: Array = []
		for index in node.mesh.get_surface_count():
			active.append(_material_snapshot(node.get_active_material(index)))
			overrides.append(_material_snapshot(node.get_surface_override_material(index)))
		nodes.append({name = str(node.name), path = str(root.get_path_to(node)), transform = node.transform,
			visible = node.visible, cast_shadow = node.cast_shadow, layers = node.layers,
			seam_faces = node.get_meta("timber_paint_seam_faces", -1),
			mesh = _mesh_snapshot(node.mesh as ArrayMesh), active_materials = active, surface_overrides = overrides,
			material_override = _material_snapshot(node.material_override)})
	return var_to_bytes(nodes)


func _source_refs(root: Node3D) -> Array:
	var result: Array = []
	for node: MeshInstance3D in _target_nodes(root):
		result.append({mesh = node.mesh, before = _mesh_snapshot(node.mesh as ArrayMesh)})
	return result


func _sources_unchanged(refs: Array) -> bool:
	for record: Dictionary in refs:
		if _mesh_snapshot(record.mesh as ArrayMesh) != record.before:
			return false
	return true


func _clear_cache(script: Script) -> void:
	(script.get("_paint_repair_cache") as Dictionary).clear()
	(script.get("_paint_repair_cache_order") as Array).clear()


func _cache_keys(script: Script) -> Array:
	var result: Array = (script.get("_paint_repair_cache") as Dictionary).keys()
	result.sort()
	return result


func _material_names(node: MeshInstance3D) -> Array[String]:
	var names: Array[String] = []
	for index in node.mesh.get_surface_count():
		var material := node.get_active_material(index)
		names.append(String(material.resource_name) if material != null else "")
	return names


func _compare_hashes_and_keys(root: Node3D) -> void:
	for node: MeshInstance3D in _target_nodes(root):
		var names := _material_names(node)
		var base_hash: String = baseline.call("_mesh_content_sha256", node.mesh, "probe")
		var candidate_hash: String = candidate.call("_mesh_content_sha256", node.mesh, "probe")
		_check(not base_hash.is_empty() and base_hash == candidate_hash, str(node.name) + " content hash matches")
		var config: Dictionary = VisualData.DATA.paint_seam_repair
		var key_a: String = baseline.call("_paint_repair_cache_key", root, node, node.mesh, config, names)
		var key_b: String = candidate.call("_paint_repair_cache_key", root, node, node.mesh, config, names)
		_check(key_a == key_b and not key_a.is_empty(), str(node.name) + " cache key matches")
		var original := node.transform
		node.position.x += 0.125
		var moved_a: String = baseline.call("_paint_repair_cache_key", root, node, node.mesh, config, names)
		var moved_b: String = candidate.call("_paint_repair_cache_key", root, node, node.mesh, config, names)
		node.transform = original
		_check(moved_a == moved_b and moved_a != key_a, str(node.name) + " transform invalidates key identically")
		if not names.is_empty():
			var renamed: Array[String] = names.duplicate()
			renamed[0] += "_changed"
			var renamed_a: String = baseline.call("_paint_repair_cache_key", root, node, node.mesh, config, renamed)
			var renamed_b: String = candidate.call("_paint_repair_cache_key", root, node, node.mesh, config, renamed)
			_check(renamed_a == renamed_b and renamed_a != key_a, str(node.name) + " material name invalidates key identically")


func _compare_lod_mutation(root: Node3D) -> void:
	# Reconstruct one actual imported source mesh, changing only one valid LOD
	# index. Base arrays, flags, names and materials remain separately checked.
	for node: MeshInstance3D in _target_nodes(root):
		var source := node.mesh as ArrayMesh
		if source.get_blend_shape_count() != 0:
			continue
		var serialized: Array = (source.get("_surfaces") as Array).duplicate(true)
		var changed := false
		for surface in source.get_surface_count():
			var record: Dictionary = serialized[surface]
			var items: Array = record.get("lods", [])
			var width := 2 if int(record.vertex_count) <= 65536 else 4
			for i in range(0, items.size(), 2):
				var raw: PackedByteArray = (items[i + 1] as PackedByteArray).duplicate()
				if not changed and raw.size() >= width and int(record.vertex_count) > 1:
					var first := raw.decode_u16(0) if width == 2 else raw.decode_u32(0)
					var next := (first + 1) % int(record.vertex_count)
					if width == 2: raw.encode_u16(0, next)
					else: raw.encode_u32(0, next)
					items[i + 1] = raw
					changed = true
			record["lods"] = items
			serialized[surface] = record
		if not changed:
			continue
		var clone := ArrayMesh.new()
		clone.resource_name = source.resource_name
		clone.set("_surfaces", serialized)
		var same_base := clone.get_surface_count() == source.get_surface_count()
		for surface in source.get_surface_count():
			same_base = same_base and var_to_bytes(clone.surface_get_arrays(surface)) == var_to_bytes(source.surface_get_arrays(surface)) \
				and clone.surface_get_format(surface) == source.surface_get_format(surface) \
				and clone.surface_get_name(surface) == source.surface_get_name(surface)
		_check(same_base, "LOD mutation preserves base arrays, flags and names")
		var before_a: String = baseline.call("_mesh_content_sha256", source, "mutation")
		var after_a: String = baseline.call("_mesh_content_sha256", clone, "mutation")
		var after_b: String = candidate.call("_mesh_content_sha256", clone, "mutation")
		_check(after_a == after_b and before_a != after_a, "LOD index mutation invalidates content hash identically")
		return
	_check(false, "found a mutable imported LOD for invalidation control")


func _hash_sample(script: Script, root: Node3D) -> int:
	var started := Time.get_ticks_usec()
	for node: MeshInstance3D in _target_nodes(root):
		var result: String = script.call("_mesh_content_sha256", node.mesh, "timing")
		if result.is_empty():
			failures.append("empty timed hash")
	return Time.get_ticks_usec() - started


func _repair_sample(script: Script, cold: bool, expect_hit: bool = false) -> int:
	if cold:
		_clear_cache(script)
	var root := _instance()
	var keys_before := _cache_keys(script)
	var started := Time.get_ticks_usec()
	script.call("_repair_painted_surface_poke_through", root)
	var elapsed := Time.get_ticks_usec() - started
	if expect_hit and (keys_before.is_empty() or _cache_keys(script) != keys_before):
		failures.append("timed warm repair missed or replaced cache entries")
	root.free()
	return elapsed
