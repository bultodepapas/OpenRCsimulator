# Rendering and loading review — `ca529cb`

Source review identity: `bultodepapas/OpenRCsimulator` commit
`ca529cb88476a22fbb1c8edf957d6917ab9b6042`. The production tree is read-only in
this investigation. The pinned engine is Godot `4.8.beta2.official.cafc17a19`.
This host has neither an exposed GPU nor an X server; native drawing, pass timing,
Metal and pilot readability are not established here. Prior experiments at
`8fb825a96dbc39fbbf99c1056ba643c9cde49b5d` keep their own baseline identity.

## Changes since the previous review

- `f7b58bd`: the TT-21 repair now preserves imported LOD dictionaries and flags on
  unchanged Lumber surfaces, including reconstruction on cache hits; changed or
  smoothed surfaces deliberately retain full-detail fallback. A narrowly reviewed
  legacy paint identity remains admitted. Its native fixed-50 m Windows RTX 3090
  Compatibility inspector reports 29,465 to 24,827 submitted primitives, with
  143 draw calls unchanged. This is a counter in an isolated fixture, not FPS or
  proof that retaining buffers reduces resident memory. The same commit adds the
  graphics/physics invariance instruction. Existing scenery-tier collision
  filtering can still change the world at its next build; the new triangle audit
  owns that separately.
- `975ef9ca3ce60e39f72a0b8dd7368349161d75a7`: adds the proxy implementation and
  updates farmland surfaces and compressed/mipmapped river-rock import. The
  class alone is not evidence of runtime admission; integration follows below.
- `eadf89edd350d26eca6470253ce9fe61fa1f706b`: adds the external geometry and LOD
  dossier. Its source audit identifies itself as `f47d1dc6` and reports no new
  hardware benchmark; distinguish its recommendations from later runtime changes.
- `ca529cb`: wires the Corsair proxy into production, adds the baked tractor and
  its placement logic, and adds the native proxy trial and its receipts. The
  tractor replaces one eligible bundled-field placement: metadata records 2,954
  triangles, five material surfaces and 1K mipmapped PBR textures, with no dynamic
  shadow casting. Scenery-off, Low, ineligible/custom layouts and explicit off
  retain their guarded paths. No runtime GPU or memory result is implied.

## 1. Timber: repeated full-mesh readback for each LOD surface

The TT-21 fix introduces a concrete source-level scaling issue. In
[`timber_visual_details.gd`](https://github.com/bultodepapas/OpenRCsimulator/blob/ca529cb88476a22fbb1c8edf957d6917ab9b6042/app/aircraft/timber_visual_details.gd#L279-L328),
`_mesh_content_sha256` calls `_surface_lods(mesh, index)` for every surface.
The helper fetches `mesh.get("_surfaces")` each time. The exact engine's
[`ArrayMesh::_get_surfaces`](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/scene/resources/mesh.cpp#L1541-L1604)
iterates over **all** S surfaces and retrieves each surface data. Its
[Compatibility storage](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/drivers/gles3/storage/mesh_storage.cpp#L617-L656)
reads vertex, attribute, base-index and LOD buffers, as applicable; the
[RenderingDevice path](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/servers/rendering/renderer_rd/storage_rd/mesh_storage.cpp#L671-L706)
also calls `buffer_get_data`. A single fingerprint thus makes S² surface-data
retrievals for the LOD snapshots, in addition to `surface_get_arrays` work. Cold
repair later asks for per-surface LODs again. Readback cost and synchronization
depend on actual renderer and must be measured; no target GPU timing was performed.

The original Timber GLB was SHA-256 verified as
`d75ae605aa3afdf3f417a0ec535c3bd3126c2a5a4eb7827393727152245c6722`. Its glTF
JSON lists 4, 3, 4, 5 and 5 authored primitives on the five named repair meshes,
and 49 across 21 meshes in total. If those per-mesh counts survive import, a
fingerprint of the five targets makes 91 versus 21 LOD-snapshot surface retrievals
after a per-mesh snapshot, 70 fewer. The total 49/21 matches the published imported
inventory, but the individual runtime counts still need verification. The
fuselage-marking fingerprint is additional.

The lead's isolated candidate takes one short-lived `_surfaces` snapshot per
native `ArrayMesh` fingerprint and discards it after hashing; cold repair's later
unchanged-surface reconstruction is deliberately unchanged. For an S-surface
mesh with U subsequent unchanged-surface reconstructions, the total whole-mesh
getter calls change from S+U to 1+U. The adjacent `procedural_skin.gd:119–129`
already follows a per-mesh snapshot pattern. Preserve byte-for-byte fingerprint
order and cache key, 16/32-bit decoding, current content/format/transform identity,
material ownership and mutation behavior. Do not retain a process-wide RID cache.
Changing this helper's source also changes Lumber's procedural paint identity,
which needs a reviewed compatibility update even if the rendered bytes match.
Compare cold and warm repairs, changed mesh/LOD/format/transform, legacy custom
paint, cache eviction and rendered output, then measure actual GPU transfers,
peak memory and Home-to-flight phases. The lead owns this separate candidate.

## 2. Corsair proxy: geometry reduction and new synchronous cost

[`aircraft_shadow_proxy.gd`](https://github.com/bultodepapas/OpenRCsimulator/blob/ca529cb88476a22fbb1c8edf957d6917ab9b6042/app/render/aircraft_shadow_proxy.gd#L20-L86)
now admits only the explicitly qualified stock Corsair session, exact model
manifest, asset and default livery, pinned engine and non-headless Compatibility.
Home, custom paint, Workshop, other models, diagnostic routes and Mobile/Metal
retain the full collector. Stock runtime admission is real, not just tooling.

The author's [native receipt](https://github.com/bultodepapas/OpenRCsimulator/blob/ca529cb88476a22fbb1c8edf957d6917ab9b6042/docs/research/visual-quality-implementation/VQ-04a/aircraft-proxy-20261109/README.md)
reports 321,191 to 178,455 triangles in an isolated mask (44.44% fewer) and a
production-route smoke with 321,287 to 178,551. Eleven poses report small but
nonzero pixel changes; static review and sampled 0.24° controls are not a global
silhouette-error bound. Four short native GPU pairs are mixed, and the fixture
does not establish full-flight FPS. It reports a median of 19.956 ms full versus
166.197 ms proxy collection across eleven poses on the author's Windows host.
Each trial calls full immediately before proxy, so it is not a cold-launch A/B.
All eleven reported source hashes match ca529 content: six directly and five
after applying the Windows CRLF line endings recorded by the receipt. Its actual
run still identifies the then-dirty `eadf89` worktree, not a clean ca529 run.

The Home route awaits a “Preparing flight model” checkpoint, then executes this
whole collector on the main-thread continuation with no internal yield
([main.gd](https://github.com/bultodepapas/OpenRCsimulator/blob/ca529cb88476a22fbb1c8edf957d6917ab9b6042/app/main.gd#L881-L892),
[loader](https://github.com/bultodepapas/OpenRCsimulator/blob/ca529cb88476a22fbb1c8edf957d6917ab9b6042/app/app_root.gd#L1261-L1281)).
Animation/input/cancellation cannot be serviced during the call; actual
user-visible delay on a complete cold or warm launch has not been measured. This
is a specific new cause within the existing UI-34c loading owner.

The successful 178,455-triangle proxy contains 535,365 position records. Its
final finite-and-bounds guard visits every one in GDScript; each serialized LOD
is also validated and materialized, including nonwinning levels. An isolated
copied-source candidate under `proxy-fixture/` selects the best record using
metadata first, validates **all** indices as before, and materializes only the
winner. The original 20,026,424-byte Corsair GLB was retrieved and verified
against `9fa3b86a9b33cdc16eefde328b347bb8af2c4191684f4c7db922acf7ba2c0851`.

The pinned headless engine imported that GLB into a disposable project. To model
the collector's propeller exclusion, the fixture renames only the imported
`propeller_spin` subtree to `propeller`; it does not build the production rig.
The direct source/proxy triangle counts then match the isolated native report:
321,191 / 178,455. Across 55 eligible surfaces, all 913,938 indices in 255
16-bit LOD records remain checked; 390,930 indices in 39 winning records are
materialized. The candidate avoids 523,008 index writes, 216 nonwinning arrays,
and 2,092,032 logical bytes of temporary 32-bit index materialization per sweep.
These are allocation-volume calculations, not retained-memory measurements.

The exact-output harness completed 3,023 synthetic comparisons, including
nonwinning malformed records, duplicate thresholds, no winner, and 16/32-bit
boundaries. All seven full-collection A/B pairs on the imported model had
byte-identical expanded proxy positions and identical bounds/metadata. The
checked runs found no warnings or errors. These tests do not prove all possible
models, renderer outcomes or out-of-memory behavior.

Seven alternating warm pairs on the Linux x86-64 shared host yielded a
decoder-only median of 63.367 ms before and 56.539 ms after, with two paired
regressions and substantial variation. Complete `collect()` medians were
126.608 and 126.382 ms; the candidate was slower in five of seven pairs, and
the median paired difference was 0.878 ms slower. Separately instrumented
phase samples were similarly variable. **There is no demonstrated complete
collection improvement, so this candidate is not promoted.** These are
headless component timings with a dummy renderer, not loading responsiveness,
GPU, or FPS results. The raw clean samples and checked logs are retained;
an earlier probe overlapped a source download and its timing is excluded.

A potential subsequent change can combine the full and proxy traversals while
reusing each `get_faces()` result. The engine caches its TriangleMesh/BVH, but
[`TriangleMesh::get_faces`](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/core/math/triangle_mesh.cpp#L503-L522)
still allocates and expands a fresh ordered face stream per call. The reported
full fixture has 963,573 position records, or 11,562,876 logical float32 position
bytes in the second full expansion. This is data volume, not peak memory or time.
An optimized aircraft-only collector must preserve visibility and propeller
exclusion, full fallback, face order, transformations, selected LOD raw vertices,
full-face 0.0001 snapping, the original bounds, and the field collector's separate
deindexed-vertex consumer. Avoid keeping all streams alive merely to reuse them.

Do **not** replace the final point guard with a finite aggregate mesh AABB without
a separate proof: the engine's AABB aggregation is not an all-point NaN test,
size padding and finite arithmetic can change boundary behavior, and creating a
mesh before validation changes the failure/resource boundary. An exact decoder
change is narrower.

## 3. Disabled cue still builds the shadow representation

`Shadow.bind_model` collects a full or proxy shape and `Projected.setup` creates
its 256², 4×-MSAA viewport and resources even when the effective shadow technique
is Native/Off or the aircraft cue starts Off. Existing policy correctly disables
viewport updates and visibility; it does not skip construction or guarantee
unallocated backing storage. In the admitted Corsair case the isolated 166.197 ms
proxy component demonstrates the scale of the potentially unnecessary operation,
not an off-mode target launch measurement.

This is a conditional UI-34c/VQ-04b refinement. A lazy design must preserve the
old bind-time geometry snapshot before night-light nodes and later articulation,
support live Settings changes and the V-key override that enables a saved-Off cue,
and avoid moving a long preparation stall into active flight. Source ownership,
detachment, settings preview/revert, cancellation and cue immediacy require
explicit tests. Measure actual retained/peak resources and enable latency; do not
claim a GPU-memory byte saving from the existence of a viewport node alone.

## 4. Visual shader follow-up, not a measured regression

LU-28-R1's `countryside_surface.gdshader:92–118` evaluates the stubble/windrow
expression even for ordinary wheat and maize where the computed harvested weight
is zero. The source layout contains 13 wheat and nine maize parcels among 54;
parcel counts do not establish on-screen coverage. The expression includes one
filtered `periodic_band` (two `band_integral` calls) and stubble-color arithmetic.
Whether a driver already removes the work or whether a branch wins is unknown.
A candidate must preserve the filtered derivatives and boundary behavior, compare
every crop/harvest/headland/zoom view, and measure Compatibility and Mobile/Metal.
The native LU-28 postcard captures do not qualify full-flight GPU time.

The previous afterimage witness remains a refinement of existing A26 §2E, not a
new finding: the three relevant source files are byte-identical to 8fb. Eight
ideal Gaussian contributions at a minimum distance of three radii total at most
`8 * exp(-40.5) ≈ 2.06e-17` alpha, assuming each input alpha is in [0,1]. This is
an error budget, not exact GPU or final quantization parity; output range, blending,
screen-copy dependencies and actual supported renderer math require testing. The
41.5°/2.786-radius witness remains a useful control but can be culled under a
sufficiently permissive validated budget. Water has a separate spatial
screen-texture consumer; only a GPU pass trace can establish copy savings.

## Verification status

The retained prior Stik indexing probe remains a negative preparation-cost
result, not the new Corsair LOD proxy. This pass has independently inspected
source, engine code, receipts and exact file hashes, and run the isolated
headless decoder/collection comparisons above. No production edit or
target-renderer capture was made. Headless results cannot certify GPU,
rendering or whole-flight performance.
