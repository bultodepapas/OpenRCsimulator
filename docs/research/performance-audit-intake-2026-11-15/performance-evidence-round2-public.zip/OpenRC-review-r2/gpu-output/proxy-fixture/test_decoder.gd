extends SceneTree

const Original := preload("res://render/aircraft_shadow_proxy.gd")
const Candidate := preload("res://decoder_candidate.gd")
var checks := 0
var failures := 0


func _raw(values: Array, width: int) -> PackedByteArray:
	var bytes := PackedByteArray()
	bytes.resize(values.size() * width)
	for i in values.size():
		if width == 2:
			bytes.encode_u16(i * width, int(values[i]))
		else:
			bytes.encode_u32(i * width, int(values[i]))
	return bytes


func _compare(surface: Dictionary, vertices: int, base: int, distance: float, label: String) -> void:
	var before := var_to_bytes(surface)
	var baseline: Dictionary = Original._select_lod(surface, vertices, base, distance)
	var candidate: Dictionary = Candidate.select_lod(surface, vertices, base, distance)
	checks += 1
	if var_to_bytes(baseline) != var_to_bytes(candidate) or before != var_to_bytes(surface):
		failures += 1
		if failures <= 20:
			printerr("Mismatch ", label, " baseline=", baseline, " candidate=", candidate)


func _initialize() -> void:
	var three := _raw([0, 1, 2], 2)
	var six := _raw([0, 1, 2, 2, 3, 4], 2)
	var valid := {vertex_count = 5, lods = [0.8, three, 0.2, six]}
	for distance: float in [0.1, 0.2, 0.5, 0.8, 1.0, NAN, INF, 0.0, -1.0]:
		_compare(valid, 5, 9, distance, "distance " + str(distance))
	_compare({vertex_count = 5, lods = []}, 5, 9, 1.0, "no LOD")
	_compare({vertex_count = 5, lods = [0.2]}, 5, 9, 1.0, "odd entries")
	_compare({vertex_count = 5, lods = [0.2, "bad"]}, 5, 9, 1.0, "wrong bytes type")
	_compare({vertex_count = 5, lods = [0.2, PackedByteArray()]}, 5, 9, 1.0, "empty bytes")
	_compare({vertex_count = 5, lods = [0.2, PackedByteArray([0, 0, 1])]}, 5, 9, 1.0, "bad bytes length")
	_compare({vertex_count = 5, lods = [0.2, three, 0.2, six]}, 5, 9, 1.0, "duplicate threshold")
	_compare({vertex_count = 5, lods = [NAN, three]}, 5, 9, 1.0, "nonfinite threshold")
	_compare({vertex_count = 5, lods = [0.2, three, 100.0, _raw([0, 1, 5], 2)]}, 5, 9, 1.0, "invalid nonwinner")
	_compare({vertex_count = 5, lods = [0.2, _raw([0, 1, 5], 2), 0.4, three]}, 5, 9, 1.0, "invalid earlier")
	_compare({vertex_count = 65536, lods = [0.2, _raw([0, 1, 65535], 2)]}, 65536, 6, 1.0, "u16 limit")
	_compare({vertex_count = 65537, lods = [0.2, _raw([0, 1, 65536], 4)]}, 65537, 6, 1.0, "u32 limit")
	_compare({vertex_count = 65537, lods = [0.2, _raw([0, 1, 2147483648], 4)]}, 65537, 6, 1.0, "u32 high bit invalid")
	_compare(valid, 0, 9, 1.0, "bad vertex count")
	_compare(valid, 5, 8, 1.0, "bad base count")
	var rng := RandomNumberGenerator.new()
	rng.seed = 0x41b2a76
	for case_index in 3000:
		var width := 2 if case_index % 2 == 0 else 4
		var vertex_count := 7 if width == 2 else 65537
		var entries: Array = []
		var record_count := rng.randi_range(0, 5)
		for record in record_count:
			var values: Array = []
			for index in 3 * rng.randi_range(1, 6):
				values.append(rng.randi_range(0, mini(vertex_count - 1, 31)))
			var threshold := float(record + 1) * 0.1
			entries.append(threshold)
			entries.append(_raw(values, width))
		if not entries.is_empty():
			match case_index % 10:
				0: entries[0] = -1.0
				1: entries[entries.size() - 1] = _raw([0, 1, vertex_count], width) if width == 4 else _raw([0, 1, 7], width)
				2: entries[entries.size() - 1] = PackedByteArray([0, 1, 2])
				3: entries[entries.size() - 1] = "bad"
				4:
					if entries.size() >= 4: entries[2] = entries[0]
				5: entries.append(0.9)
		_compare({vertex_count = vertex_count, lods = entries}, vertex_count, 3 * rng.randi_range(1, 7), 0.1 * rng.randi_range(1, 6), "random " + str(case_index))
	print("Decoder comparison: ", checks, " checked, ", failures, " failed")
	quit(1 if failures else 0)
