## Disposable experiment based on ca529 aircraft_shadow_proxy.gd::_select_lod.
## Every record and every index is still validated; only the winning index array
## is materialized. Production source is not changed by this fixture.
extends RefCounted


static func select_lod(surface: Dictionary, vertex_count: int, base_count: int, max_distance: float) -> Dictionary:
	var failure := {ok = false, indices = PackedInt32Array(), distance = 0.0}
	if vertex_count < 1 or int(surface.get("vertex_count", -1)) != vertex_count \
			or base_count < 3 or base_count % 3 != 0 or not is_finite(max_distance) or max_distance <= 0.0:
		return failure
	var entries: Variant = surface.get("lods", [])
	if not entries is Array or entries.size() % 2 != 0:
		return failure
	var index_bytes := 2 if vertex_count <= 65536 else 4
	var result := {ok = true, indices = PackedInt32Array(), distance = 0.0}
	var seen := {}
	var selected_entry := -1
	# Match the original metadata rejection and winner rules before allocating.
	for entry in range(0, entries.size(), 2):
		if typeof(entries[entry]) not in [TYPE_FLOAT, TYPE_INT] or not entries[entry + 1] is PackedByteArray:
			return failure
		var distance := float(entries[entry])
		var raw: PackedByteArray = entries[entry + 1]
		if not is_finite(distance) or distance <= 0.0 or seen.has(distance) \
				or raw.is_empty() or raw.size() % (3 * index_bytes) != 0:
			return failure
		seen[distance] = true
		if distance <= max_distance and distance > float(result.distance) and raw.size() / index_bytes < base_count:
			selected_entry = entry
			result.distance = distance
	# Do not skip out-of-range indices in nonwinning or out-of-range LODs: the
	# existing implementation treats malformed unused records as a hard failure.
	for entry in range(0, entries.size(), 2):
		var raw: PackedByteArray = entries[entry + 1]
		var count := raw.size() / index_bytes
		if entry == selected_entry:
			var indices := PackedInt32Array()
			indices.resize(count)
			for index in count:
				var value := raw.decode_u16(index * 2) if index_bytes == 2 else raw.decode_u32(index * 4)
				if value >= vertex_count:
					return failure
				indices[index] = value
			result.indices = indices
		else:
			for index in count:
				var value := raw.decode_u16(index * 2) if index_bytes == 2 else raw.decode_u32(index * 4)
				if value >= vertex_count:
					return failure
	return result
