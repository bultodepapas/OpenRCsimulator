## Imported source scene only, not the assembled production aircraft. Measures
## existing and experimental decoder on the same retained imported LOD bytes.
extends SceneTree

const Original := preload("res://render/aircraft_shadow_proxy.gd")
const Candidate := preload("res://decoder_candidate.gd")
const CandidateProxy := preload("res://render/aircraft_shadow_proxy_candidate.gd")
const DiagnosticBaseline := preload("res://render/diag_baseline.gd")
const DiagnosticCandidate := preload("res://render/diag_candidate.gd")
const ASSET := "res://assets/aircraft/f4u-corsair-250/f4u_corsair.glb"
const DISTANCE := 0.0005
var failures: Array[String] = []
var records: Array = []


func _initialize() -> void:
	var scene := load(ASSET) as PackedScene
	if scene == null:
		printerr("Missing or unimported original Corsair GLB")
		quit(2)
		return
	var model := scene.instantiate() as Node3D
	if model == null:
		printerr("Imported scene is not Node3D")
		quit(2)
		return
	# Production ImportedModel wraps the propeller_spin subtree in a Node3D
	# named "propeller", which Projected.collect excludes. Reproduce only
	# that exclusion; do not claim to have constructed its full aircraft rig.
	var spin := model.find_child("propeller_spin", true, false) as Node3D
	if spin == null:
		printerr("Missing authored propeller_spin subtree")
		model.free()
		quit(2)
		return
	spin.name = "propeller"
	var full := Original.collect(model, DISTANCE)
	var candidate := CandidateProxy.collect(model, DISTANCE)
	if full.is_empty() or candidate.is_empty():
		failures.append("missing full/proxy shape")
	var same_shape := _same_shape(full, candidate)
	if not same_shape:
		failures.append("candidate output shape mismatch")
	var totals := {meshes_seen = 0, meshes_validated = 0, surfaces_checked = 0, lod_records = 0,
		indices_scanned_16 = 0, indices_scanned_32 = 0, indices_winning_16 = 0, indices_winning_32 = 0,
		surfaces_with_winner = 0}
	var meshes: Array[Node] = model.find_children("*", "MeshInstance3D", true, false)
	if model is MeshInstance3D:
		meshes.push_front(model)
	for item in meshes:
		var instance := item as MeshInstance3D
		if instance.mesh == null or not _included(model, instance):
			continue
		totals.meshes_seen += 1
		var mesh := instance.mesh
		if not mesh is ArrayMesh or mesh.get_blend_shape_count() != 0:
			continue
		var serialized: Variant = mesh.get("_surfaces")
		if not serialized is Array or serialized.size() != mesh.get_surface_count():
			continue
		var face_count := mesh.get_faces().size()
		var offset := 0
		var valid_mesh := true
		var local_records: Array = []
		for surface_index in mesh.get_surface_count():
			if mesh.surface_get_primitive_type(surface_index) != Mesh.PRIMITIVE_TRIANGLES:
				valid_mesh = false
				break
			var arrays := mesh.surface_get_arrays(surface_index)
			if not arrays[Mesh.ARRAY_VERTEX] is PackedVector3Array or not serialized[surface_index] is Dictionary:
				valid_mesh = false
				break
			var vertex_count: int = (arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array).size()
			var base_count: int = (mesh as ArrayMesh).surface_get_array_index_len(surface_index)
			if base_count == 0:
				base_count = vertex_count
			if base_count % 3 != 0 or offset + base_count > face_count:
				valid_mesh = false
				break
			var surface: Dictionary = serialized[surface_index]
			var original: Dictionary = Original._select_lod(surface, vertex_count, base_count, DISTANCE)
			var changed: Dictionary = Candidate.select_lod(surface, vertex_count, base_count, DISTANCE)
			if var_to_bytes(original) != var_to_bytes(changed):
				failures.append("real LOD decoder output mismatch")
			if not original.ok:
				valid_mesh = false
				break
			local_records.append({surface = surface, vertex_count = vertex_count, base_count = base_count})
			offset += base_count
		if not valid_mesh or offset != face_count:
			continue
		totals.meshes_validated += 1
		for record: Dictionary in local_records:
			records.append(record)
			totals.surfaces_checked += 1
			var width := 2 if record.vertex_count <= 65536 else 4
			var lods: Array = record.surface.get("lods", [])
			totals.lod_records += lods.size() / 2
			for i in range(1, lods.size(), 2):
				var raw: PackedByteArray = lods[i]
				if width == 2: totals.indices_scanned_16 += raw.size() / width
				else: totals.indices_scanned_32 += raw.size() / width
			var selected: Dictionary = Original._select_lod(record.surface, record.vertex_count, record.base_count, DISTANCE)
			var length: int = (selected.indices as PackedInt32Array).size()
			if length > 0:
				totals.surfaces_with_winner += 1
				if width == 2: totals.indices_winning_16 += length
				else: totals.indices_winning_32 += length
	if records.is_empty():
		failures.append("no eligible source surface records")
	for warm in 2:
		_sample(false)
		_sample(true)
	var samples: Array = []
	for batch in 7:
		var first: Dictionary = _sample(batch % 2 != 0)
		var second: Dictionary = _sample(batch % 2 == 0)
		if first.signature != second.signature:
			failures.append("sweep signatures differ at pair " + str(batch))
		samples.append({batch = batch, first = first, second = second})
	# Time the complete collection including the unchanged full-geometry oracle,
	# selected-face expansion, bound scan, and ArrayMesh finalization. The model
	# has already been collected and import/get_faces caches are warm.
	for warm in 2:
		_sample_collect(model, false)
		_sample_collect(model, true)
	var collection_samples: Array = []
	for batch in 7:
		var first: Dictionary = _sample_collect(model, batch % 2 != 0)
		var second: Dictionary = _sample_collect(model, batch % 2 == 0)
		var same: bool = _same_shape(first.shape, second.shape)
		if not same:
			failures.append("complete collection mismatch at pair " + str(batch))
		first.erase("shape")
		second.erase("shape")
		collection_samples.append({batch = batch, first = first, second = second, same_shape = same})
	# Instrumented runs are separately reported; their per-surface timer overhead
	# means they are attribution only and not the clean collection timing.
	var diagnostics: Array = []
	for batch in 3:
		var a: Dictionary
		var b: Dictionary
		if batch % 2 == 0:
			a = DiagnosticBaseline.collect(model, DISTANCE)
			b = DiagnosticCandidate.collect(model, DISTANCE)
		else:
			b = DiagnosticCandidate.collect(model, DISTANCE)
			a = DiagnosticBaseline.collect(model, DISTANCE)
		if not _same_shape(a, b) or not _same_shape(a, full):
			failures.append("diagnostic shape mismatch at pair " + str(batch))
		diagnostics.append({batch = batch, baseline = DiagnosticBaseline.diagnostic_last.duplicate(true),
			candidate = DiagnosticCandidate.diagnostic_last.duplicate(true)})
	var report := {format = "openrc-proxy-decoder-fixture v1", baseline = "ca529cb88476a22fbb1c8edf957d6917ab9b6042",
		asset_sha256 = FileAccess.get_sha256(ASSET), engine = Engine.get_version_info(),
		scope = "Linux headless imported GLB hierarchy with propeller-spin subtree excluded; not assembled flight, renderer, or FPS",
		same_shape = same_shape, full_source_triangles = full.get("source_triangles", -1),
		proxy_triangles = full.get("triangles", -1), selected_surfaces = full.get("lod_surfaces", -1),
		representation = full.get("representation", "missing"), totals = totals, samples = samples,
		collection_samples = collection_samples, diagnostic_phases = diagnostics, failures = failures}
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var output := FileAccess.open(arg.trim_prefix("--report="), FileAccess.WRITE)
			if output != null:
				output.store_string(JSON.stringify(report, "  "))
	print(JSON.stringify(report))
	model.free()
	quit(1 if not failures.is_empty() else 0)


func _included(model: Node3D, instance: MeshInstance3D) -> bool:
	var node: Node = instance
	while node != model and node != null:
		if node is Node3D and (not node.visible or node.name == &"propeller"):
			return false
		node = node.get_parent()
	return true


func _same_shape(a: Dictionary, b: Dictionary) -> bool:
	for key in ["bounds", "triangles", "source_triangles", "representation", "lod_surfaces", "max_lod_distance", "fallback_reason"]:
		if a.get(key) != b.get(key):
			return false
	if not a.has("mesh") or not b.has("mesh"):
		return a.is_empty() and b.is_empty()
	var av: PackedVector3Array = a.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
	var bv: PackedVector3Array = b.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
	return av.to_byte_array() == bv.to_byte_array()


func _sample(candidate: bool) -> Dictionary:
	var start := Time.get_ticks_usec()
	var signature := 0
	for record: Dictionary in records:
		var result: Dictionary = Candidate.select_lod(record.surface, record.vertex_count, record.base_count, DISTANCE) \
			if candidate else Original._select_lod(record.surface, record.vertex_count, record.base_count, DISTANCE)
		signature += (result.indices as PackedInt32Array).size() if result.ok else -1
	return {candidate = candidate, usec = Time.get_ticks_usec() - start, signature = signature}


func _sample_collect(model: Node3D, candidate: bool) -> Dictionary:
	var start := Time.get_ticks_usec()
	var shape: Dictionary = CandidateProxy.collect(model, DISTANCE) if candidate else Original.collect(model, DISTANCE)
	return {candidate = candidate, usec = Time.get_ticks_usec() - start, shape = shape}
