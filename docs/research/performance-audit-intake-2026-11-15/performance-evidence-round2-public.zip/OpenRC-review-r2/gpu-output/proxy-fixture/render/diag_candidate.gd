## Optional aircraft-mask geometry from existing imported LODs. Never changes the visible model.
extends RefCounted

const Projected := preload("res://render/projected_shadow.gd")
const AIRCRAFT_ID := "f4u-corsair-250"
const ASSET_SHA256 := "9fa3b86a9b33cdc16eefde328b347bb8af2c4191684f4c7db922acf7ba2c0851"
const ENGINE_HASH := "cafc17a192acf67903910a68aeb3c076c0907a4b"
const MANIFEST_SHA256 := "37456deee3c57870fed47ea623701e35aebc4ee0f38ac6fe6cc03519429c3fa0"
# This is the imported LOD selection criterion, not a certified geometric-error bound.
const MAX_LOD_DISTANCE := 0.0005


static func source_supported(model: Node3D) -> bool:
	return is_instance_valid(model) and str(model.get_meta("aircraft_id", "")) == AIRCRAFT_ID \
		and str(model.get_meta("asset_sha256", "")) == ASSET_SHA256 \
		and str(model.get_meta("livery", "")) == "midnight" \
		and not model.has_meta("skin_base_sha256")


static func context_supported(context: Dictionary) -> bool:
	return typeof(context.get("stock_session")) == TYPE_BOOL and context.stock_session \
		and str(context.get("model_manifest_sha256", "")) == MANIFEST_SHA256


static func qualified(model: Node3D, context: Dictionary = {}) -> bool:
	return context_supported(context) and requested() == "auto" \
		and DisplayServer.get_name() != "headless" and source_supported(model) \
		and str(Engine.get_version_info().get("hash", "")) == ENGINE_HASH \
		and RenderingServer.get_current_rendering_method() == "gl_compatibility"


## Developer comparison switch; it never changes saved graphics preferences.
static func requested() -> String:
	var value := OS.get_environment("OPENRC_AIRCRAFT_SHADOW_PROXY").strip_edges().to_lower()
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--aircraft-shadow-proxy="):
			value = argument.trim_prefix("--aircraft-shadow-proxy=").strip_edges().to_lower()
	return "auto" if value in ["", "auto"] else "full"


## Full collection remains the bounds oracle and fallback. Unsupported surfaces are never discarded.
static var diagnostic_decode_usec := 0
static var diagnostic_last: Dictionary = {}


static func collect(model: Node3D, max_lod_distance: float) -> Dictionary:
	var diagnostic_start := Time.get_ticks_usec()
	diagnostic_decode_usec = 0
	if not is_instance_valid(model):
		return {}
	var full := Projected.collect(model)
	var diagnostic_full := Time.get_ticks_usec()
	if full.is_empty():
		return full
	if not is_finite(max_lod_distance) or max_lod_distance <= 0.0:
		return _full(full, "invalid LOD criterion")
	var vertices := PackedVector3Array()
	var lod_surfaces := 0
	var meshes: Array[Node] = model.find_children("*", "MeshInstance3D", true, false)
	if model is MeshInstance3D:
		meshes.push_front(model)
	for item in meshes:
		var instance := item as MeshInstance3D
		if instance.mesh == null:
			continue
		var transform := Transform3D.IDENTITY
		var node: Node = instance
		var include := true
		while node != model and node != null:
			if node is Node3D:
				include = include and node.visible and node.name != &"propeller"
				transform = node.transform * transform
			node = node.get_parent()
		if not include:
			continue
		var faces: PackedVector3Array = instance.mesh.get_faces()
		var selected := _mesh_faces(instance.mesh, faces, max_lod_distance)
		vertices.append_array(transform * (selected.faces as PackedVector3Array))
		lod_surfaces += int(selected.lod_surfaces)
	var diagnostic_traversal := Time.get_ticks_usec()
	if lod_surfaces == 0 or vertices.size() >= int(full.triangles) * 3:
		return _full(full, "no smaller usable imported LOD")
	var guarded_bounds: AABB = full.bounds.grow(0.0001)
	for point: Vector3 in vertices:
		if not point.is_finite() or not guarded_bounds.has_point(point):
			return _full(full, "LOD extends outside the original silhouette bounds")
	var diagnostic_guard := Time.get_ticks_usec()
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var diagnostic_end := Time.get_ticks_usec()
	diagnostic_last = {full_usec = diagnostic_full - diagnostic_start, traversal_usec = diagnostic_traversal - diagnostic_full, decoder_usec = diagnostic_decode_usec, guard_usec = diagnostic_guard - diagnostic_traversal, finalize_usec = diagnostic_end - diagnostic_guard}
	return {mesh = mesh, bounds = full.bounds, triangles = vertices.size() / 3,
		source_triangles = full.triangles, representation = "imported-lod-proxy",
		lod_surfaces = lod_surfaces, max_lod_distance = max_lod_distance}


static func _full(shape: Dictionary, reason: String) -> Dictionary:
	var result := shape.duplicate()
	result.representation = "full"
	result.source_triangles = shape.triangles
	result.lod_surfaces = 0
	result.fallback_reason = reason
	return result


static func _mesh_faces(mesh: Mesh, full_faces: PackedVector3Array, max_distance: float) -> Dictionary:
	var fallback := {faces = full_faces, lod_surfaces = 0}
	if not mesh is ArrayMesh or mesh.get_blend_shape_count() != 0:
		return fallback
	var serialized: Variant = mesh.get("_surfaces")
	if not serialized is Array or serialized.size() != mesh.get_surface_count():
		return fallback
	var faces := PackedVector3Array()
	var offset := 0
	var selected_count := 0
	for surface in mesh.get_surface_count():
		if mesh.surface_get_primitive_type(surface) != Mesh.PRIMITIVE_TRIANGLES:
			return fallback
		var arrays := mesh.surface_get_arrays(surface)
		if not arrays[Mesh.ARRAY_VERTEX] is PackedVector3Array or not serialized[surface] is Dictionary:
			return fallback
		var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var base_count: int = (mesh as ArrayMesh).surface_get_array_index_len(surface)
		if base_count == 0:
			base_count = vertices.size()
		if base_count % 3 != 0 or offset + base_count > full_faces.size():
			return fallback
		var diagnostic_decode_start := Time.get_ticks_usec()
		var selected := _select_lod(serialized[surface], vertices.size(), base_count, max_distance)
		diagnostic_decode_usec += Time.get_ticks_usec() - diagnostic_decode_start
		if not selected.ok:
			return fallback
		var indices: PackedInt32Array = selected.indices
		if indices.is_empty():
			faces.append_array(full_faces.slice(offset, offset + base_count))
		else:
			var reduced := PackedVector3Array()
			reduced.resize(indices.size())
			for index in indices.size():
				reduced[index] = vertices[indices[index]]
			faces.append_array(reduced)
			selected_count += 1
		offset += base_count
	if offset != full_faces.size():
		return fallback
	return {faces = faces, lod_surfaces = selected_count}


## Pure decoder: malformed records fail closed before touching any renderer resource.
static func _select_lod(surface: Dictionary, vertex_count: int, base_count: int, max_distance: float) -> Dictionary:
	return preload("res://decoder_candidate.gd").select_lod(surface, vertex_count, base_count, max_distance)
