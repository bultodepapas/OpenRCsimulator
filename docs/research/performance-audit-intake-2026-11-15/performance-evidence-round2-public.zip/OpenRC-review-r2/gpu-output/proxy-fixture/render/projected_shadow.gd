## VQ-04a: one neutral-geometry silhouette draw in an isolated 256² viewport.
## No light/physics writes. The root's actual model transform supplies the datum.
extends Node

const MaskShader = preload("res://render/projected_shadow_mask.gdshader")
const ReceiverShader = preload("res://render/projected_shadow_receiver.gdshader")
const RESOLUTION := 256
const Spec = preload("res://spec.gd")
const HEIGHT: float = Spec.SHADOW.height
## PT1h-R12: a flying aircraft changes attitude every frame, so an exact-match cache redrew the full-detail
## silhouette (165,398 triangles for the Ugly Stik, MSAA 4x) every frame: about 0.9 ms of GPU on an RTX 3090,
## a third of the frame's GPU time. Below these tolerances the blurred shadow cannot show the difference:
## 0.25° moves a 1.5 m span's tips by 6.5 mm, under the 18 mm minimum blur; 2 mm of blur stays inside the frame's
## fixed 4 cm margin (see framing()).
const REUSE_ANGLE_DEG := 0.25
const REUSE_COS: float = 0.99999048 # cos(0.25°)
const REUSE_BLUR_M := 0.002

var source: Node3D
var viewport: SubViewport
var receiver: MeshInstance3D
var mask_material: ShaderMaterial
var bounds: AABB
var triangle_count := 0
var _last_signature: Array = []
var _last_request: Array = []
var _desired_shown := false
# The remaining frame inputs; basis/direction/frame already live in _last_signature.
var _frame_bounds := AABB()
var _frame_blur := 0.0
## Masks drawn since setup (diagnostics: compare with frames elapsed to see how often the cache is reused).
var redraw_count := 0


## The shape is captured at bind time. Propellers are omitted: a neutral blade
## would cast a visibly frozen streak while the rendered prop rotates.
static func collect(model: Node3D, min_height: float = -INF) -> Dictionary:
	var vertices := PackedVector3Array()
	var meshes: Array[Node] = model.find_children("*", "MeshInstance3D", true, false)
	if model is MeshInstance3D:
		meshes.push_front(model)
	for item in meshes:
		var mi := item as MeshInstance3D
		if mi.mesh == null:
			continue
		var transform := Transform3D.IDENTITY
		var node: Node = mi
		var include := true
		while node != model and node != null:
			if node is Node3D:
				include = include and node.visible and node.name != &"propeller"
				transform = node.transform * transform
			node = node.get_parent()
		if not include:
			continue
		var faces: PackedVector3Array = transform * mi.mesh.get_faces()
		if min_height == -INF:
			vertices.append_array(faces)
		else:
			append_above(vertices, faces, min_height)
	if vertices.is_empty():
		return {}
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	var merged := ArrayMesh.new()
	merged.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	# The engine computes nondegenerate bounds in native code, but pads flat
	# surfaces to 1e-5 m. Preserve exact collection bounds for those fixtures.
	var box := merged.get_aabb()
	if not box.is_finite() or minf(box.size.x, minf(box.size.y, box.size.z)) <= 0.00001:
		box = AABB(vertices[0], Vector3.ZERO)
		for point in vertices:
			box = box.expand(point)
	return {mesh = merged, bounds = box, triangles = vertices.size() / 3}


## Append ordered runs of accepted triangles to an independent destination.
## Keep the scalar cutoff exactly; only the copies run in native code.
static func append_above(vertices: PackedVector3Array, faces: PackedVector3Array,
		min_height: float) -> int:
	var before := vertices.size()
	var run_start := 0
	for first in range(0, faces.size(), 3):
		var a := faces[first]
		var b := faces[first + 1]
		var c := faces[first + 2]
		if maxf(a.y, maxf(b.y, c.y)) <= min_height:
			if first > run_start:
				vertices.append_array(faces.slice(run_start, first))
			run_start = first + 3
	if run_start == 0:
		vertices.append_array(faces)
	elif run_start < faces.size():
		vertices.append_array(faces.slice(run_start))
	return (vertices.size() - before) / 3


## Every axis within the angle (cos_limit) and its length unchanged: a scaled model is never "close".
static func same_within(a: Basis, b: Basis, cos_limit: float) -> bool:
	for axis in 3:
		var u: Vector3 = a[axis]
		var v: Vector3 = b[axis]
		var lu := u.length()
		var lv := v.length()
		if absf(lu - lv) > 1.0e-5 * maxf(1.0, lu):
			return false
		if lu > 0.0 and u.dot(v) < cos_limit * lu * lv:
			return false
	return true


static func _direction_within(a: Vector3, b: Vector3, cos_limit: float) -> bool:
	var la := a.length()
	var lb := b.length()
	return la > 0.0 and lb > 0.0 and a.dot(b) >= cos_limit * la * lb


static func project(point: Vector3, direction: Vector3) -> Vector2:
	var slope := direction / maxf(direction.y, 0.05)
	return Vector2(point.x - slope.x * point.y, point.z - slope.z * point.y)


## Conservative bounds of projected model, with room for every blur tap.
static func framing(box: AABB, basis: Basis, direction: Vector3, blur_m: float) -> Rect2:
	var slope := direction / maxf(direction.y, 0.05)
	var point := basis * box.get_endpoint(0)
	var rect := Rect2(Vector2(point.x - slope.x * point.y, point.z - slope.z * point.y), Vector2.ZERO)
	for i in range(1, 8):
		point = basis * box.get_endpoint(i)
		rect = rect.expand(Vector2(point.x - slope.x * point.y, point.z - slope.z * point.y))
	var side := maxf(rect.size.x, rect.size.y) + 2.0 * (blur_m + 0.04)
	side = maxf(side, 0.1)
	return Rect2(rect.get_center() - Vector2.ONE * side * 0.5, Vector2.ONE * side)


func setup(model: Node3D, shape: Dictionary, resolution: int = RESOLUTION, antialias: int = Viewport.MSAA_4X) -> void:
	source = model
	bounds = shape.bounds
	triangle_count = shape.triangles
	viewport = SubViewport.new()
	viewport.name = "Silhouette256"
	viewport.size = Vector2i(resolution, resolution)
	viewport.own_world_3d = true
	viewport.transparent_bg = true
	viewport.msaa_3d = antialias as Viewport.MSAA
	viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(viewport)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color.BLACK
	viewport.add_child(environment)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 100.0
	camera.position = Vector3(0, 10, 0)
	camera.rotation_degrees.x = -90.0
	viewport.add_child(camera)
	camera.current = true
	var proxy := MeshInstance3D.new()
	proxy.mesh = shape.mesh
	# POSITION bypasses the camera; imported/model vertices may be far off origin.
	proxy.custom_aabb = AABB(Vector3(-1, -1, -1), Vector3(2, 2, 2))
	proxy.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mask_material = ShaderMaterial.new()
	mask_material.shader = MaskShader
	proxy.material_override = mask_material
	viewport.add_child(proxy)
	receiver = MeshInstance3D.new()
	receiver.name = "SoftAircraftShadow"
	receiver.top_level = true
	var plane := PlaneMesh.new()
	plane.size = Vector2.ONE
	receiver.mesh = plane
	receiver.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var material := ShaderMaterial.new()
	material.shader = ReceiverShader
	material.set_shader_parameter("mask", viewport.get_texture())
	receiver.material_override = material
	add_child(receiver)
	source.visibility_changed.connect(_source_visibility_changed)
	source.tree_exiting.connect(_source_exiting)
	source.tree_entered.connect(_source_entered)


func _source_visibility_changed() -> void:
	if not _last_request.is_empty():
		refresh(_last_request[0], _last_request[1], _last_request[2], _desired_shown)


func _source_exiting() -> void:
	receiver.visible = false
	viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	_last_signature.clear()
	if not _last_request.is_empty():
		_last_request[3] = false # stop animated projectors while their source is absent


func _source_entered() -> void:
	if not _last_request.is_empty():
		refresh(_last_request[0], _last_request[1], _last_request[2], _desired_shown)


func refresh(height: float, direction: Vector3, opacity: float, shown: bool) -> void:
	_desired_shown = shown
	_last_request = [height, direction, opacity, shown]
	# Both nodes may be detached during construction. A live projector must not
	# draw a still-valid source that has left its scene.
	if not is_instance_valid(source) or (is_inside_tree() and not source.is_inside_tree()):
		_last_request[3] = false
		receiver.visible = false
		viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		_last_signature.clear()
		return
	shown = shown and (source.is_visible_in_tree() if source.is_inside_tree() else source.visible)
	receiver.visible = shown
	if not shown:
		viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		_last_signature.clear()
		return
	# Artistic area-light approximation, bounded to keep the RC height cue readable.
	var blur := clampf(0.018 + maxf(height, 0.0) * 0.0093, 0.018, 0.45)
	var pose := source.global_transform if source.is_inside_tree() else source.transform
	var frame: Rect2
	# Reuse the drawn mask while the attitude, light and blur stay within what the blurred shadow cannot show.
	# Tolerances compare against the last DRAWN mask, so the error never accumulates past them.
	var reuse := _last_signature.size() == 3 and bounds == _frame_bounds \
			and absf(blur - _frame_blur) <= REUSE_BLUR_M \
			and same_within(pose.basis, _last_signature[0], REUSE_COS) \
			and _direction_within(direction, _last_signature[1], REUSE_COS)
	if reuse:
		frame = _last_signature[2]
	else:
		frame = framing(bounds, pose.basis, direction, blur)
		_frame_bounds = bounds
		_frame_blur = blur
	var center := frame.get_center()
	var ground_origin := project(pose.origin - Vector3(0, HEIGHT, 0), direction) + center
	receiver.transform = Transform3D(Basis.from_scale(Vector3(frame.size.x, 1, frame.size.y)),
		Vector3(ground_origin.x, HEIGHT, ground_origin.y))
	var material := receiver.material_override as ShaderMaterial
	material.set_shader_parameter("opacity", opacity)
	material.set_shader_parameter("blur_uv", blur / frame.size.x)
	if reuse:
		return # the receiver moved with the aircraft; the mask on it is still the right shape
	var signature := [pose.basis, direction, frame]
	if signature != _last_signature:
		mask_material.set_shader_parameter("aircraft_basis", pose.basis)
		mask_material.set_shader_parameter("light_direction", direction)
		mask_material.set_shader_parameter("frame_center", center)
		mask_material.set_shader_parameter("frame_size", frame.size.x)
		viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
		redraw_count += 1
		_last_signature = signature
