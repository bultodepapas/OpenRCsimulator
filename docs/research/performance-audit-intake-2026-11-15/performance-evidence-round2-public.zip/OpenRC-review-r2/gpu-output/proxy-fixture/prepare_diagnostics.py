"""Generate disposable, phase-instrumented copies of the two proxy scripts."""

from pathlib import Path

root = Path(__file__).parent
for source, destination in (
    ("render/aircraft_shadow_proxy.gd", "render/diag_baseline.gd"),
    ("render/aircraft_shadow_proxy_candidate.gd", "render/diag_candidate.gd"),
):
    text = (root / source).read_text()
    edits = [
        ("static func collect(model: Node3D, max_lod_distance: float) -> Dictionary:\n",
         "static var diagnostic_decode_usec := 0\nstatic var diagnostic_last: Dictionary = {}\n\n\n"
         "static func collect(model: Node3D, max_lod_distance: float) -> Dictionary:\n"
         "\tvar diagnostic_start := Time.get_ticks_usec()\n\tdiagnostic_decode_usec = 0\n"),
        ("\tvar full := Projected.collect(model)\n",
         "\tvar full := Projected.collect(model)\n\tvar diagnostic_full := Time.get_ticks_usec()\n"),
        ("\tif lod_surfaces == 0 or vertices.size() >= int(full.triangles) * 3:\n",
         "\tvar diagnostic_traversal := Time.get_ticks_usec()\n"
         "\tif lod_surfaces == 0 or vertices.size() >= int(full.triangles) * 3:\n"),
        ("\tvar arrays := []\n\tarrays.resize(Mesh.ARRAY_MAX)\n",
         "\tvar diagnostic_guard := Time.get_ticks_usec()\n\tvar arrays := []\n\tarrays.resize(Mesh.ARRAY_MAX)\n"),
        ("\tmesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)\n",
         "\tmesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)\n"
         "\tvar diagnostic_end := Time.get_ticks_usec()\n"
         "\tdiagnostic_last = {full_usec = diagnostic_full - diagnostic_start, "
         "traversal_usec = diagnostic_traversal - diagnostic_full, "
         "decoder_usec = diagnostic_decode_usec, guard_usec = diagnostic_guard - diagnostic_traversal, "
         "finalize_usec = diagnostic_end - diagnostic_guard}\n"),
        ("\t\tvar selected := _select_lod(serialized[surface], vertices.size(), base_count, max_distance)\n",
         "\t\tvar diagnostic_decode_start := Time.get_ticks_usec()\n"
         "\t\tvar selected := _select_lod(serialized[surface], vertices.size(), base_count, max_distance)\n"
         "\t\tdiagnostic_decode_usec += Time.get_ticks_usec() - diagnostic_decode_start\n"),
    ]
    for old, new in edits:
        assert text.count(old) == 1, (source, old)
        text = text.replace(old, new, 1)
    (root / destination).write_text(text)
