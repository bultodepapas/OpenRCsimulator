# Successor reconciliation and Timber follow-up

This note supplements, rather than changes, `FINDINGS.md`, which remains pinned
to `ca529cb88476a22fbb1c8edf957d6917ab9b6042`. The successor source reviewed
here is `300dc4e82cc6975b6f4e808cb4b2b845a0240ded`, two commits ahead of that
baseline. No production files were edited for this review.

## Initially disabled aircraft shadows

The successor implements part of the former disabled-cue finding. At
[`shadow.gd:100–164`](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/render/shadow.gd#L100-L164),
an initially disabled cue defers the `ProjectedShadow` child, 256² mask viewport,
receiver and shader materials, and skips the generic fallback-texture upload.
The carrier's mesh and material, policy node, and already-collected shape remain.
An enabled projector is reused, rather than freed, if the cue is later disabled.

Geometry collection remains synchronous before the disabled-cue test at
[`shadow.gd:134–155`](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/render/shadow.gd#L134-L155).
On the staged non-glow flight path, the collector runs after the
[`Preparing flight model` checkpoint](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/main.gd#L881-L893);
the checkpoint yields a frame, but collection does not itself yield. The saved
shape is a deliberate bind-time snapshot, and collecting only on later activation
could change geometry after mesh or articulation changes. Pending geometry is
released after a freed source is observed on a policy process frame; a detached
but still-live source retains it.

The author's [native deferred-startup receipt](https://github.com/bultodepapas/OpenRCsimulator/tree/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/docs/research/visual-quality-implementation/VQ-04a/deferred-startup-20261109)
uses Windows, an RTX 3090, NVIDIA OpenGL 617.42, pinned Godot 4.8-beta2 in
Compatibility, native 1920×1080 and MSAA 4×. Four initially disabled routes
were compared with the enabled eager path using a **precomputed full**
321,191-triangle Corsair shape:

| Initially disabled route | Eager setup | Deferred setup | First enable |
|---|---:|---:|---:|
| Master Off | 4.868 ms | 0.099 ms | 6.530 ms |
| Native | 6.286 ms | 0.100 ms | 7.002 ms |
| Saved cue Off | 13.138 ms | 0.116 ms | 6.136 ms |
| Explicit local Off | 6.944 ms | 0.116 ms | 6.215 ms |

Each value is a single component observation. The fixture excludes geometry
collection, complete world loading and the first visible draw; resource work
moves to first enable. It reports a 611,668-byte increase in the renderer's
texture-memory estimate for the eager control and zero before enable for each
deferred route. These figures are not total or peak VRAM. The report records
matching hashes for four post-enable 256² mask PNGs and 1080p receiver PNGs;
the PNG files are not committed. Nine focused suites report 490 checks.

The latest receipt's separate eleven-pose collection observations have medians
of **18.259 ms full** and **115.080 ms proxy**; the median within-pose difference
is 96.080 ms. Each pose contributes one full and one proxy observation; this is
not a randomized repeated cold-launch comparison. The newer receipt has no
per-frame profile samples. The earlier proxy receipt's four short isolated
GPU/wall pairs are mixed and pertain to its earlier source snapshot. Neither
establishes a Home-to-flight hitch, whole-flight FPS or a GPU win.

The author's live Home route held an admitted 178,551-triangle proxy while Off;
the direct Off route held 178,455. Assuming three float32 positions per triangle,
their logical position payloads are 6,427,836 and 6,424,380 bytes, respectively,
or about 6.13 MiB each. The full shape in the precomputed fixture has a logical
11,562,876-byte position payload. These are arithmetic data volumes, not measured
CPU allocation or GPU residency. `triangles = 0` in deferred metadata counts no
instantiated projector; it does not indicate an empty retained shape.

The [verification receipt](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/docs/research/visual-quality-implementation/VQ-04a/deferred-startup-20261109/verification.json)
records a dirty shared worktree based on `a188a1d`, with per-file source hashes.
Independently hashing the ten corresponding files fetched from `300dc` showed
seven raw-byte matches; the other three (`main.gd`, `shadow.gd`, and
`projected_shadow_mask.gdshader`) match after converting the repository's LF
line endings to the receipt's CRLF representation. Thus the recorded source
content matches the successor for these ten files, with that qualification.

## Afterimage correction

The earlier `FINDINGS.md` calls the tails Gaussian. The actual
[`sun_afterimage.gdshader:20–31`](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/render/sun/sun_afterimage.gdshader#L20-L31)
uses the **quartic** weight `p.w * exp(-0.5 * x^4)`. Its numerical bound in that
note remains correct: if every patch weight is in [0, 1] and every evaluated
pixel is at least three radii from every patch, the sum of eight ideal weights
is at most `8 * exp(-40.5)`, approximately `2.06e-17`. The blur LOD taper reaches
zero at two radii. This supports an error-budget experiment, not a proof of exact
floating-point, screen-texture, blending or final-pixel equivalence.

## Imported Timber: updated measurement and focused cold-path candidate

The lead's isolated imported-Timber probe used the original asset with SHA-256
`d75ae605aa3afdf3f417a0ec535c3bd3126c2a5a4eb7827393727152245c6722`, and passed
33 comparisons of source isolation, cache keys and cold/warm repaired output.
The five actual imported targets had 4, 3, 4, 5 and 5 surfaces, confirming 91
versus 21 full-surface retrievals for the hash portion of the proposed per-mesh
snapshot. Ten paired samples on the shared Linux headless host gave hash-sweep
medians of 8.1425 ms baseline and 7.3325 ms candidate; warm complete-repair
medians of 8.634 and 8.3915 ms; and cache-cold, process-warm complete-repair
medians of 392.9675 and 387.266 ms. The candidate was faster in only five of ten
cold pairs; there is no convincing complete-repair gain. Timings do not represent
GPU readback, first process launch, Home-to-flight, or target hardware. The
checked outputs are `root-output/timber-probe-timing.json` and
`root-output/timber-timing-summary.json`.

One focused, unmeasured cold-path opportunity remains. On every uncovered white
triangle, [`timber_visual_details.gd:183–200`](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/aircraft/timber_visual_details.gd#L183-L200)
calls `_authored_paint_region`. Before checking the region's mesh name, that
helper traverses the hierarchy for a relative transform, transforms the center,
inverts/transposes the basis, and transforms and normalizes the normal
([lines 421–448](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/aircraft/timber_visual_details.gd#L421-L448)).
Current [configuration](https://github.com/bultodepapas/OpenRCsimulator/blob/300dc4e82cc6975b6f4e808cb4b2b845a0240ded/app/assets/aircraft/turbo-lumber-evolution/visual-upgrade/visual_detail_data.gd#L199-L246)
contains exactly one authored region, for `fuselage_core`. The other four
repair targets cannot match it. Filter regions once per mesh in original order,
skip the helper if there are none, and, for a matching mesh, consider computing
its unchanged relative transform and inverse-transpose once for that evaluation.
Do not retain a persistent cache. Preserve each triangle's operations, order,
region precedence, source mesh and material ownership, and output/cache key.
Skipping the original unused basis inverse can remove a debug diagnostic for a
singular transform: the pinned engine's
[`Basis::invert`](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/core/math/basis.cpp#L39-L49)
has a zero-determinant check under `MATH_CHECKS`. Preserve a fallback for such
inputs if diagnostic parity is required. The measured imported inventory reports
local-identity transforms for the five target meshes.

The asset's measured imported geometry lists 2,310 cowl, 2,314 fin, 5,197 left
wing and 5,125 right wing faces: 14,946 total faces across the four no-region
meshes. All four list both white and paint materials. Actual avoided helper calls
are the unknown subset of white faces for which the first coverage test fails;
14,946 is an upper bound, not a measured call count. The fuselage has 4,542
faces in total. Instrument counts and phase times, then use paired complete
cache-cold and warm repair tests and byte-level comparisons, including multiple
ordered regions, transformed and nonuniformly scaled roots, singular transforms,
negative scales, missing regions, LODs, cache eviction and source isolation.
Any script change also changes the procedural-paint identity and requires the
existing reviewed compatibility path. No such optimization is implemented or
timed in this source-only review.
