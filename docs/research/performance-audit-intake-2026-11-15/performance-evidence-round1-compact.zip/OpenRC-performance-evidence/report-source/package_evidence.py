from pathlib import Path
import json, os, platform, hashlib, zipfile, collections

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'deliverables/OpenRC-performance-evidence.zip'
entries={}
def add(path, name=None):
    path=Path(path)
    if path.is_file(): entries[name or str(path.relative_to(ROOT))]=path.read_bytes()
def scan(folder, excluded=()):
    for p in sorted((ROOT/folder).rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT/folder)
        if any(x in rel.parts for x in ('.godot','__pycache__','.git',*excluded)): continue
        if p.suffix.lower() in {'.pyc','.glb','.jpg','.jpeg','.png','.wav','.ogg','.so','.dll','.exe','.pck'}: continue
        if p.name=='compare': continue
        add(p)

for name in ['repository-state.json','patch-manifest.json','inventory-summary.json','git-tree.txt']:
    add(ROOT/name)
add(ROOT/'deliverables/OpenRC-performance-review.html','OpenRC-performance-review.html')
add(ROOT/'deliverables/OpenRC-performance.patch','OpenRC-performance.patch')
add(ROOT/'report-work/README-evidence.txt','README.txt')
scan('input-experiment')
scan('cpu-output',excluded=('audio-integration-app',))
scan('physics-output',excluded=('reference-app',))
scan('gpu-output')
for name in ['project.godot','render/engine_voice.gd','render/engine_audio.gd','render/engine_sound.gd',
             'tests/test_engine_voice.gd','tests/test_engine_audio.gd','tests/test_engine_sound.gd','aircraft/aircraft_catalog.gd']:
    add(ROOT/'cpu-output/audio-integration-app'/name,'cpu-output/integration-sources/'+name)
for name in ['app/input/controller_actions.gd','app/render/engine_voice.gd','app/tests/test_engine_voice.gd',
             'app/tests/test_controller_button_index.gd','app/tests/test_controller_button_index.gd.uid']:
    add(ROOT/'repository'/name,'implemented/'+name)
for name in ['report.md','build_report.py','package_evidence.py']:
    add(ROOT/'report-work'/name,'report-source/'+name)

receipts=[]
commands=[]
for name,data in entries.items():
    if name.endswith('/report.json'):
        try: obj=json.loads(data)
        except (ValueError,UnicodeDecodeError): continue
        if obj.get('format')!='openrc-godot-check v1': continue
        receipts.append({'receipt':name,'label':obj.get('label'),'ok':obj.get('ok'),
                         'reason':obj.get('reason'),'process_exit':obj.get('process_exit'),
                         'checked_exit':obj.get('exit_code'),'counts':obj.get('counts'),
                         'detail':obj.get('detail'),'log_sha256':obj.get('log_sha256')})
        commands.append({'receipt':name,'cwd':obj.get('cwd'),'command':obj.get('command')})
entries['evidence-index.json']=(json.dumps({'scope':'Raw checked receipts include deliberate errors and unsuccessful setup/harness attempts. Consult README and report before classifying a failure.','receipts':receipts},indent=2)+'\n').encode()
entries['commands.json']=(json.dumps(commands,indent=2)+'\n').encode()

cpu=''
for line in Path('/proc/cpuinfo').read_text().splitlines():
    if line.startswith('model name'):
        cpu=line.split(':',1)[1].strip();break
env={'cpu_model':cpu,'os':platform.system(),'kernel':platform.release(),'machine':platform.machine(),
     'visible_cpu_count':os.cpu_count(),'affinity_cpu_count':len(os.sched_getaffinity(0)),
     'cgroup_cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
     'cgroup_memory_max':Path('/sys/fs/cgroup/memory.max').read_text().strip(),
     'gpu_device_present':Path('/dev/dri').exists(),'engine':json.loads((ROOT/'input-experiment/benchmark-results.json').read_text())['godot'],
     'build':'official editor/debug','rendering':'headless/Dummy','qualification':'shared container; not target graphics, physical input, display latency or sustained release performance'}
entries['environment.json']=(json.dumps(env,indent=2)+'\n').encode()
notes='''FINAL REVIEW NOTES

The main HTML report incorporates these final corrections to specialist-stage prose:
* Controller 36–68% reductions describe the tested 2–5-candidate gamepad cases;
  explicit/radio controls do not establish a gain.
* No universal patched-flight trajectory equivalence is claimed. Audio fixtures
  retain simulation checkpoints; a full patched-flight comparison is still needed.
* The native cache fills after initial domain/layout checks when an above-ground
  query reaches active turbulence; later finite-wind or thermal checks can refuse.
* Native overwritten libm calculations have no explicit evaluator mutation, but
  errno/FP exception effects and optimized-build elimination must be considered.
* The 2.786-radius afterimage case is a boundary control, not inherently visible;
  a validated output-error budget decides culling. Include positive controls.
* Shadow geometry equality is not a measurement of fragment invocations or GPU
  cost. Redraw-only payback is one accounting model, not the sole possible benefit.
* Audio prototype source was subsequently implemented unchanged. The 868 total
  includes PCM/state, reset and adapter checks, not only PCM comparisons.
'''
entries['FINAL-REVIEW-NOTES.txt']=notes.encode()
manifest={'format':'openrc-performance-evidence-v1','reviewed_base':'8fb825a96dbc39fbbf99c1056ba643c9cde49b5d',
          'successor_reviewed':'f7b58bd830d4a5eb78901d00514ce1fc18286477',
          'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())]}
entries['archive-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in sorted(entries.items()):
        z.writestr('OpenRC-performance-evidence/'+name,data)
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(entries)
    for name,data in entries.items(): assert z.read('OpenRC-performance-evidence/'+name)==data
summary={'archive':str(DEST),'bytes':DEST.stat().st_size,'entries':len(entries),'checked_receipts':len(receipts),
         'receipt_verdicts':dict(collections.Counter(str(x['ok']) for x in receipts)),
         'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest()}
(ROOT/'deliverables/package-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
