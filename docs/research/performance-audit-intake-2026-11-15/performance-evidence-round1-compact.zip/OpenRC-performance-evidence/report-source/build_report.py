"""Render this review's restricted Markdown into a self-contained, script-free HTML report."""
from pathlib import Path
from html import escape
from html.parser import HTMLParser
import re

ROOT = Path(__file__).resolve().parents[1]
text = (ROOT / 'report-work/report.md').read_text()
tokens = []

def inline(s):
    held = []
    def hold(value):
        held.append(value)
        return f'@@HELD{len(held)-1}@@'
    s = re.sub(r'`([^`]+)`', lambda m: hold('<code>' + escape(m[1]) + '</code>'), s)
    s = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', lambda m: hold('<a href="' + escape(m[2], quote=True) + '">' + escape(m[1]) + '</a>'), s)
    s = escape(s)
    s = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', s)
    for i, v in enumerate(held):
        s = s.replace(f'@@HELD{i}@@', v)
    return s

lines = text.splitlines()
out = []
toc = []
i = 0
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    if line.startswith('```'):
        block = []
        i += 1
        while i < len(lines) and not lines[i].startswith('```'):
            block.append(lines[i]); i += 1
        out.append('<pre><code>' + escape('\n'.join(block)) + '</code></pre>')
        i += 1
        continue
    match = re.match(r'^(#{1,3}) (.+)$', line)
    if match:
        level = len(match[1]); title = match[2]
        slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
        out.append(f'<h{level} id="{slug}">{inline(title)}</h{level}>')
        if level == 2:
            toc.append((slug, title))
        i += 1
        continue
    if line.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            row = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?', c.replace(' ', '')) for c in row):
                rows.append(row)
            i += 1
        out.append('<div class="table-wrap"><table><thead><tr>' + ''.join('<th scope="col">'+inline(c)+'</th>' for c in rows[0]) + '</tr></thead><tbody>')
        for row in rows[1:]:
            out.append('<tr>' + ''.join('<td>'+inline(c)+'</td>' for c in row) + '</tr>')
        out.append('</tbody></table></div>')
        continue
    if line.startswith('- '):
        out.append('<ul>')
        while i < len(lines) and lines[i].startswith('- '):
            out.append('<li>' + inline(lines[i][2:]) + '</li>'); i += 1
        out.append('</ul>')
        continue
    para = [line]
    i += 1
    while i < len(lines) and lines[i].strip() and not lines[i].startswith(('#', '|', '```', '- ')):
        para.append(lines[i]); i += 1
    out.append('<p>' + inline(' '.join(para)) + '</p>')

style = '''
:root{color-scheme:light;--ink:#162c3d;--muted:#536777;--blue:#145d85;--line:#d5e1e9;--pale:#f3f7fa}
*{box-sizing:border-box}body{margin:0;background:#eaf0f4;color:var(--ink);font:16px/1.62 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.page{max-width:1160px;margin:32px auto;background:white;border-top:7px solid var(--blue);padding:42px 58px 70px;box-shadow:0 8px 28px #223f5510}
.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:12px;color:var(--blue);font-weight:750}
h1{font-size:34px;line-height:1.2;letter-spacing:-.035em;margin:14px 0 24px;max-width:900px}h2{font-size:25px;line-height:1.28;border-top:1px solid var(--line);padding-top:28px;margin-top:40px;letter-spacing:-.02em}h3{font-size:19px;line-height:1.35;margin:27px 0 9px}
p{margin:12px 0}a{color:#075b91;text-decoration-thickness:1px;text-underline-offset:3px;overflow-wrap:anywhere}strong{font-weight:700}code{font: .88em/1.45 ui-monospace,SFMono-Regular,Consolas,monospace;background:#eff4f7;border-radius:3px;padding:1px 4px;overflow-wrap:anywhere}
pre{border:1px solid var(--line);background:#f6f9fb;padding:18px;overflow:auto;border-radius:6px;line-height:1.45}pre code{background:none;padding:0;overflow-wrap:normal;white-space:pre}
.table-wrap{overflow-x:auto;margin:22px 0;border:1px solid var(--line);border-radius:5px}table{width:100%;border-collapse:collapse;font-size:14px;line-height:1.45}th{background:#e8f0f5;text-align:left;font-weight:700}th,td{padding:11px 13px;border-bottom:1px solid var(--line);vertical-align:top}tbody tr:nth-child(even){background:#f8fafc}tbody tr:last-child td{border-bottom:0}
ul{padding-left:23px}li{margin:9px 0}.toc{background:var(--pale);border-left:4px solid var(--blue);padding:16px 22px;margin:26px 0}.toc strong{display:block;margin-bottom:8px}.toc ol{columns:2;column-gap:36px;margin:0;padding-left:22px;font-size:14px}.toc li{break-inside:avoid;margin:6px 0}.scope{font-size:13px;color:var(--muted);margin-bottom:25px}footer{margin-top:45px;border-top:1px solid var(--line);padding-top:16px;font-size:13px;color:var(--muted)}
@media(max-width:760px){.page{margin:0;padding:24px 19px}.toc ol{columns:1}h1{font-size:28px}h2{font-size:22px}table{min-width:580px}}
@media print{body{background:white;font-size:10pt}.page{max-width:none;box-shadow:none;margin:0;border:0;padding:0}.toc{break-after:page}.toc ol{columns:1}h2,h3{break-after:avoid}table{font-size:8.5pt}tr{break-inside:avoid}pre{white-space:pre-wrap}pre code{white-space:pre-wrap}a{color:#174e70}h2{margin-top:24px}footer{font-size:8pt}}
'''
toc_html = '<nav class="toc" aria-label="Report contents"><strong>Contents</strong><ol>' + ''.join('<li><a href="#'+slug+'">'+escape(title)+'</a></li>' for slug,title in toc) + '</ol></nav>'
body = '\n'.join(out)
first_h2 = body.index('<h2')
body = body[:first_h2] + toc_html + body[first_h2:]
document = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>OpenRC Simulator — Mathematical Performance Review</title><style>'+style+'</style></head><body><main class="page"><div class="eyebrow">Engineering review · measurements and source-bound proposals</div>'+body+'<footer>Prepared 9 November 2026. Component timings, source estimates, historical evidence and target qualification are distinguished throughout. The accompanying evidence bundle retains the raw measurements and reproduction material.</footer></main></body></html>'
target = ROOT / 'deliverables/OpenRC-performance-review.html'
target.write_text(document, encoding='utf-8')

class Check(HTMLParser):
    def __init__(self):
        super().__init__(); self.stack=[]; self.ids=set(); self.anchors=[]; self.scripts=0
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag not in {'meta','br','hr','img','link','input'}: self.stack.append(tag)
        if 'id' in a:
            assert a['id'] not in self.ids; self.ids.add(a['id'])
        if tag=='a' and a.get('href','').startswith('#'): self.anchors.append(a['href'][1:])
        if tag=='script': self.scripts += 1
    def handle_endtag(self,tag):
        assert self.stack and self.stack.pop()==tag,tag
c=Check();c.feed(document);assert not c.stack and not c.scripts and all(x in c.ids for x in c.anchors)
assert '@@HELD' not in document
print(target, target.stat().st_size, 'bytes; HTML structure and contents links valid')
