# OpenRC Simulator: mathematical and algorithmic performance review

**Review date:** 9 November 2026. **Repository:** [bultodepapas/OpenRCsimulator](https://github.com/bultodepapas/OpenRCsimulator). **Target branch:** `main`.

## Outcome

Two bounded CPU optimizations are implemented in the local branch `perf/math-audit-20261109`: a controller-button occupancy index and guarded engine-voice interpolation inlining. The passing controller, voice, and audio checks and the component measurements support these changes. The existing engine-sound suite retains the same stale catalog failure on baseline and candidate. They have not been pushed or merged. An apply-ready patch accompanies this report.

The controller resolver is the stronger implemented result: across the tested two-to-five-candidate gamepad fixtures, its measured median cost falls by 36–68%; the five-action airplane capability case falls from 356.339 to 114.228 microseconds per resolution. The audio component falls from 6.435 to 4.937 milliseconds per generated audio second, a much smaller absolute saving of about 1.5 ms/s per active voice.

The real GDScript flight-session benchmark also ran. Its 24-mode spatial-wind workload had a median batch cost of 4.556 ms/tick on this host, compared with a 4.167 ms period at 240 Hz. This identifies a demanding CPU workload and supports prioritizing spatial-wind work; it does not measure the benefit of the proposed phase cache. No GPU, displayed-frame, full-game FPS, physical-controller latency, target-Mac, or sustained release-build performance result was obtained.

The report separates implemented changes, measured unchanged baselines, component prototypes, source-derived operation estimates, existing audit work, and remaining qualification. The patch changes no simulation tick rate, flight law, aircraft data, or native source identity. Exercised audio integration fixtures retained identical simulation checkpoints; patched whole-flight trajectory equivalence remains to be qualified.

## 1. Revision, repository state, and investigation scope

All local benchmarks and the main source investigation use **`8fb825a96dbc39fbbf99c1056ba643c9cde49b5d`**, committed at 15:29:45 UTC / 10:29:45 America/Bogota. Its tree is `464a14200216ec3d64eaaff2a26ca71b1d1c4625`. The review began by reading [CONSOLIDATED-AUDITS.md](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/external%20Audits/CONSOLIDATED-AUDITS.md) and the completed-work ledger, then checking the live sources rather than treating audit suggestions as unimplemented defects.

During the investigation, `main` advanced to **`f7b58bd830d4a5eb78901d00514ce1fc18286477`**, committed at 15:48:44 UTC / 10:48:44 America/Bogota. Its entire 27-file change list was reviewed. Despite its evidence-oriented title, it also changes Timber LOD preservation, paint identity compatibility, and project instructions. The controller, oscillator, physics, companion predictor, afterimage, and Stik shadow paths discussed here are unchanged by that successor. The experiments remain bound to the original revision; they are not presented as clean successor-commit executions. A patch applicability check covers both revisions.

The complete tracked path/object inventory contains 47,923 entries, including historical evidence, generated data, archived prototypes, and skill bundles. A selected source/configuration/documentation checkout was used instead of downloading every large binary. Parallel investigations traced production `app/` entry points, input/UI routing, fixed-wing and helicopter simulation, native evaluator boundaries, wind and atmosphere, companion control and audio, rendering/shaders, meshes/materials, settings, loading, caching, and recording. This is broad repository coverage, not a claim to have manually read every tracked file or visually inspected every asset. The frozen three.js prototype is not a production hot path.

### Recent changes and open proposals

The latest pre-review changes include visual-quality integration (`a831fa35`), exact zero-fuel derivative handling (`979819ec`), observer datum-wind reuse (`c8d5cfbe`), source-bound scenario caching (`b788965e`), and solver/profile requalification (`7556c3af`). Those matter when separating new work from already implemented changes.

Open draft [PR #11](https://github.com/bultodepapas/OpenRCsimulator/pull/11) remains unmerged, but its bounded circuit-mesh-cache and parked-ORM-read changes are already ported into `main`. Their open PR status does not make them absent from production. Open draft [PR #10](https://github.com/bultodepapas/OpenRCsimulator/pull/10) likewise overlaps previously integrated tooling repairs. This review does not report either as a fresh optimization.

### Current CI is not green

The pinned revision's [CI run 42645261283](https://github.com/bultodepapas/OpenRCsimulator/actions/runs/42645261283) fails in preflight. The successor's [CI run 42648597425](https://github.com/bultodepapas/OpenRCsimulator/actions/runs/42648597425) fails at the same orchestration test. The retrieved job logs show 125 tests and one failure: `test_every_original_ci_generator_runs_once_and_failure_stops`, at `tools/ci/test_phases.py:374`. The actual generator sequence contains two additional commands relative to the expected roster; the first difference is the Stik 6S aircraft generator. Downstream application, native, visual, and export jobs are skipped. The required-artifact job then fails. These are observed CI failures, not evidence that the reviewed game crashes or that this patch caused them.

### Actual engine and platform constraints

The repository getter supplied the SHA-512-verified official **Godot 4.8 beta 2**, `4.8.beta2.official.cafc17a19`; full engine revision `cafc17a192acf67903910a68aeb3c076c0907a4b`. The application uses a custom float64, 240 Hz RK4 flight kernel. It does not delegate flight to Godot's rigid-body solver. Its state uses scalar and packed double precision deliberately: default Godot vectors have different precision. Replacing that math with float32 vectors is not an equivalent optimization.

The configured baseline renderer is Compatibility; the native arm64 override selects Mobile. High graphics features are conditional on the effective renderer. Default 4x MSAA, effective reconstruction, actual drawable dimensions, and hardware selection must be recorded rather than inferred from a preset name. The product's primary measurement target is 1920x1080; larger outputs are secondary and 720p is fallback. The custom NK-3 flight evaluator's current build scope is Linux x86-64. The presence of separate Windows RC native builds does not make the flight evaluator portable to Windows or Apple Silicon.

Sources: [project configuration](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/project.godot), [stack contract](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/docs/STACK.md), [native toolchain](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/research/native-kernel/toolchain-lock.json), [Godot precision reference](https://docs.godotengine.org/en/stable/tutorials/physics/large_world_coordinates.html).

## 2. Priorities and evidence levels

| Priority | Opportunity | Classification | Evidence and current disposition |
| --- | --- | --- | --- |
| P1 implemented | Index occupied gamepad buttons once per resolution | New algorithmic improvement | Exact output corpus; focused tests; 36–68% lower component medians for 2–5 candidates; local patch |
| P1 next experiment | Reuse exact spatial-wind temporal phase within each stage | New; distinct from WOPT-01/02 and geometry preparation | Real expensive reference workload; 38,853 native component checks; unintegrated and untimed candidate |
| P1 target profiling | Suppress provably negligible offscreen afterimage passes | Refinement of existing A26 section 2E | Source-derived engine witness; no target GPU timing; error-budget and renderer gate required |
| P1 known stutter work | Asynchronous bounded F10 bundle identity admission/finalization | Existing A24 section 2, reinforced by A26 | Current synchronous path retained; actual packaged target boundary measurement remains necessary |
| P2 implemented | Inline valid-domain engine-voice interpolation | New small CPU improvement | Exact tested PCM/state; voice/audio suites pass; 23.3% component reduction but about 1.5 ms/s/voice absolute |
| P2 next experiment | Reduce companion roots and reuse endpoint turn rates | New scoped math proposals | Source-derived counts; source-bound guidance/replay qualification required |
| P2 next experiment | Avoid overwritten legacy air calculation in native spatial stages | New source candidate | Pure source path; compiler/DCE and native parity/timing still required |
| P2 preparation experiment | Indexed aircraft-only shadow masks | Refinement within existing shadow ownership | 49.64% lower logical geometry payload in tested Stik component; naive preparation adds about 100 ms; not promoted |

Priority is based on likely player-facing impact and readiness, not the largest percentage printed by a microbenchmark. Known native circuit/companion admission, hull preparation, loading/upload attribution, texture compression, and cloud readback can outrank a small arithmetic change once the actual target bottleneck is measured.

## 3. Implemented: one occupancy index for controller defaults

### Executed path and cost

`app/input/controller_actions.gd::effective_bindings` constructs the effective action map, applies explicit overrides and AUX ownership, then calls `_add_automatic_buttons`. The original helper scans every current binding for each eligible automatic candidate. The built-in map has 37 actions. An ordinary capability configuration can enable between one and five candidates; all nine declared airplane/helicopter candidates can participate in mixed test configurations.

The cost matters beyond a single call. In Home-launched flight, `app_root.gd::_input` resolves maps for restart, rates, generic action identities, selected flight/UI observers, dispatch, and throttle cut. A stable selected gamepad can pass through seven resolutions during one event. Flight capabilities are aircraft-dependent; the UI resolver uses the full default airplane capability set. A direct technical/main-scene input benchmark can bypass this shell. Delivered event rate, actual capability sets, profile overrides, and reentrant callbacks must be measured before attributing a total event cost.

Sources: [resolver and automatic defaults](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/input/controller_actions.gd#L154-L216), [binding ownership](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/app_root.gd#L1746-L1759), [event routing](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/app_root.gd#L2116-L2187), [actual flight capabilities](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/main.gd#L1737-L1743).

### Original and proposed algorithms

```text
Original, for each eligible candidate c:
    inspect AUX reservations
    for every binding b:
        validate b, check action/context, compare b with c
    insert c if unreserved

Implemented:
    lazily scan bindings once when the first eligible candidate is reached
    occupied = valid button IDs belonging to known flight/both actions
    for each eligible candidate in original declaration order:
        inspect the unchanged AUX reservations
        test candidate.button membership in occupied
        if free: insert candidate and immediately occupy its button
```

With A bindings, C eligible candidates and U AUX entries, the inner work changes from `O(C*A + C*U)` to `O(A + C + C*U)`. Five candidates produce 185 binding inspections before versus 37 after: 148 removed. Two candidates produce 74 versus 37. The earlier outer effective-binding/AUX work still exists. Memory adds one short-lived dictionary of valid occupied buttons, bounded by the known action set; allocator bytes were not measured. There is no persistent cache and no invalidation protocol.

### Equivalence conditions

For a valid button candidate, the old comparison reduces to equality of integer button IDs when the other binding is also a valid button. Unknown definitions, malformed types, out-of-range values, and menu-only actions must not reserve flight buttons. Explicit Clear, explicit overrides, all AUX switch members, same-channel ownership, and deep-copy ownership of returned bindings remain unchanged. Immediate insertion preserves declaration priority when airplane and helicopter defaults share a button.

The private helper is additive under its sole production caller: automatic candidates start unbound unless explicitly overridden, and explicit ones are skipped. This invariant is documented in the patch. A future arbitrary caller that replaces a nonexplicit existing binding would need occupancy removal or reference counts; the new helper must not silently become a general replacement API.

### Measured complete-resolver results

Both experiments use the same official headless editor executable: 500 warmup calls per role/case, nine alternating baseline/candidate batches, and 4,000 complete `effective_bindings` calls per batch. The capability follow-up is a separate run; its absolute times should not be combined with the earlier run as a single paired event measurement.

| Configuration | Baseline median, microseconds | Candidate median, microseconds | Cost reduction |
| --- | --- | --- | --- |
| Rates plus restart, two candidates | 202.897 | 129.232 | 36.3% |
| Smoke, rates, restart, three candidates | 253.006 | 128.678 | 49.1% |
| Gear, flaps, rates, restart, four candidates | 334.325 | 129.778 | 61.2% |
| Full airplane capabilities, five candidates | 356.339 | 114.228 | 67.9% |
| Helicopter capabilities, five candidates | 341.561 | 116.242 | 66.0% |
| AUX-conflict fixture | 400.241 | 183.270 | 54.2% |
| All actions explicitly overridden | 88.045 | 91.772 | -4.2% |
| No equipment capabilities, restart still eligible | 121.535 | 118.585 | 2.4% |
| Radio control path | 75.616 | 77.216 | -2.1% |

Controls with explicit bindings and radio routing show no useful improvement; their timing ranges overlap and small regressions are retained rather than hidden. The unchanged raw-radio early return occurs before index construction. These measurements establish an actual net benefit on the tested Godot VM for relevant gamepad profiles, not only a source-operation estimate. They do not measure full event propagation, USB sampling, accepted-tick input, rendering, FPS, or display latency.

There are 31,244 deterministic exact serialized-output/input-ownership comparisons, zero failures, covering action/button boundaries, mixed/malformed/StringName profiles, capabilities and AUX. The new permanent regression has 38 checks. Existing controller actions, extended actions (104), binding audit (14), profile (74), and conditioning (57) checks pass in the exact dependency fixture. An independent source review found no public-path counterexample.

The next larger input opportunity is event-scoped reuse of repeated effective maps. It is not implemented: restart, device changes, profile edits, capability changes, and callbacks can invalidate assumptions within an event. First count calls and profile copies on the Home route, then introduce an explicit event snapshot/generation contract if timing justifies it. `Input.use_accumulated_input = false` is already set at `main.gd:694`; recommending that switch again would duplicate existing work.

## 4. Measured flight baseline and new spatial-wind proposal

### What was executed

The unchanged `app/tests/bench_spatial_wind.gd --full-session` runs real `FlightSession` and `Simulation.step` paths. It was first run with `--verify-only`, then with its shortest permitted measured configuration: three batches of 480 accepted ticks, with 240 warmup ticks before each batch and exact fixture restoration. Rendering and ordinary UI/observer work are outside this measurement. Fifteen exact pinned visual blobs were restored solely to satisfy transitive script preloads. The isolated project removes startup/main-scene, font autoload, locale, and editor-plugin settings; its full configuration diff is retained. No simulation law, collision implementation, or aircraft data was stubbed.

| Workload | Three batch means, microseconds/tick | Median, ms/tick | Diagnostic query count |
| --- | --- | --- | --- |
| Stik, legacy steady wind 3 m/s from 270 degrees | 679.610; 618.081; 581.206 | 0.618081 | First tick 5; 2,400 over 480 ticks |
| Stik, spatial 24 modes, 3 m/s reference wind, RMS 0.3 m/s | 4,555.629; 5,408.696; 4,075.217 | 4.555629 | First tick 50; 24,000 over 480 ticks |

Each case completed 720 warmup and 1,440 measured ticks, passed nine of nine restore checks, and produced identical final hashes across its three batches and the separate verification run. The accepted solver identity is `b98411b3c131e0a91bd7e2793799bf2f4d69264e1f29b058084e623ab20a1581`. The two weather scenarios differ physically; their ratio is not an optimization speedup. Three batch means are not individual-tick p95/p99 data. One spatial batch was below the 240 Hz period, and the shared host was not a sustained target run.

### Reuse the time factor, preserve every spatial sample

Both [GDScript spatial wind](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/physics/wind_spatial_field.gd#L316-L353) and [native spatial wind](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/research/native-kernel/src/nk_spatial_weather.hpp#L212-L253) evaluate the following expression for each mode and each queried point:

```text
epoch = stage_time + immutable_epoch_offset
spatial_i = kN_i * north + kE_i * east + phase_offset_i
time_i = fposmod(omega_i * epoch, TAU)
phase_i = fposmod(fposmod(spatial_i, TAU) + time_i, TAU)
```

Only `time_i` is identical across the datum and station queries at that stage. Compute that exact binary64 value once, then reuse it without reassociation. Keep the spatial remainder, final remainder, four point-dependent trigonometric evaluations, wall taper/derivative, and vector accumulation in their original order. Do not interpolate full winds or reuse between RK trial states.

For M modes, Q qualifying point queries and S independently owned groups per tick, this removes `M*(Q-1)*S` temporal products and remainders per tick. A Stik-like group has datum plus nine stations. With 24 modes, ten points, four ordinary RK stages and 240 accepted ticks/s, the source-level saving is **207,360 products and 207,360 remainders per simulated second**. The 8/64-mode equivalents are 69,120/552,960 of each. Adding the separate pre-step group could raise the 24-mode count to 259,200, but only after implementing that owner's separate context. Extra event trials and invalid/ground/zero-RMS paths change the count.

This is a targeted reduction: for ten queries it removes 90% of the repeated temporal term, but only 30% of the original three-remainder-per-mode work, and none of the four trigonometric calls per point. It cannot honestly be described as a 90% wind or physics speedup. The effect on the measured 4.556 ms reference cost is unknown.

### Ownership, prototype, and acceptance

The separate C++ prototype uses at most 64 doubles: 512 bytes of value storage plus identity/metadata. A fresh stage context fills lazily on the first above-ground query reaching turbulence after the initial domain/layout checks; different provider, epoch, or oversized layout takes the original path. It retains strict floating-point compiler flags. The final component comparison reports 38,853 checks and zero unexpected differences, including modes 8/24/64, synthetic 65-mode fallback, gusts, thermals, zero activity, invalid domain, nonfinite/signed-zero inputs, changed time, and provider identity.

An intentional same-pointer mutation is a negative control: a pointer and time alone do not detect modified coefficients. The provider must remain immutable for the context lifetime. New stage, reset, rebind, changed configuration, retry, and replay require new scratch. Preview/retained-sampler ownership must remain detached correctly. The production stage oracles and trajectories have not run on this unintegrated candidate; the native prototype was not timed.

A reference-GDScript implementation needs a separate opt-in stage sampler through WindFlow, Environment, WindField, and SpatialField. It must preserve custom `wind_world`/`sample_world` overrides and the existing call/refusal order; `test_wind_aircraft_flow.gd` exercises these contracts. This reference implementation is particularly relevant to the measured workload and to platforms without the native evaluator. Inspect optimized native assembly/profiles and VM call costs before assigning time savings; compiler removal and scratch/dispatch overhead remain unmeasured.

Required gates are exact stage/load arrays, refusal and rollback behavior, source mutation, preview/wake/gear sampler lifetime, zero RMS, all mode counts, ground boundary, substeps/events, checkpoints/restores, actual-aircraft trajectories, native/reference oracles, then matched session timing. This new opportunity is separate from completed WOPT-01 thermal reuse, WOPT-02 observer datum reuse, A6 O4 pre-step air reuse, and pending A6 O5 geometry preparation.

## 5. Other CPU and numerical opportunities

### Implemented: guarded audio interpolation

The path is companion render -> EngineSound.update -> EngineAudio.refill -> [EngineVoice.render](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/render/engine_voice.gd#L59-L74). The normal player reaches this oscillator only on legacy soundscape routing. An active voice generates 22,050 stereo frames per second when refill demand exists.

The original loop calls `sample(table, phase)` per frame. The implemented valid-domain path evaluates the identical interpolation inline:

```text
index = phase * 4096
lo = int(index)
interpolated = table[lo] + (table[lo+1] - table[lo]) * (index-lo)
value = amplitude * interpolated
```

It preserves update order and the original `fposmod` phase operation. A block-level guard requires finite phase in [0,1), finite nonnegative frequency, and at least 4,097 table entries; otherwise the original helper remains responsible for behavior. No table, PCM allocation, float precision, or smoothing law changes. Extra memory is constant scalar state. Unconditional inlining was rejected because invalid mutable phase could move an error from the helper to the caller and abort rendering instead of preserving original continuation.

Five alternating ABBA/BAAB rounds, 20 total trials, each 300 blocks x 368 frames, produced baseline/candidate medians 32,220/24,718.5 microseconds. Each round's pair mean favored the candidate. The normalized 6.435 -> 4.937 ms per generated second is a 23.3% component reduction and about 0.15% of one CPU-second per continuously active voice. Three voices would imply about 4.5 ms/s saved only under linear continuously refilled assumptions; this fleet cost was not measured. Maintenance cost includes duplicated interpolation and guard logic, so the benefit is deliberately classified below input and spatial wind.

The exact implementation passed 868 checks, including exact PCM/state comparisons over 422 blocks and 122,633 frames plus pause/resume adapter checks. The permanent voice suite passes 86/86; engine-audio integration passes 147/147, including pause, queueing, accepted-state observation, restore, restart, and simulation noninterference. A separate invalid-phase witness intentionally logs the same original errors in both variants and is classified as an expected-error run, not a passing checked test. The engine-sound suite has one stale catalog expectation out of 27 checks on both variants; after exact required WAV import, its complete baseline/candidate logs are byte-identical. Listening and physical audio-driver tests remain unperformed.

### Companion forecast: reduce first, take roots last

[pilot.gd::_score_bank](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/ai/companions/pilot.gd) computes 33 forecast distances for each threat and keeps the minimum. For finite, nonnegative identically computed squared distances `d_j2`, monotonicity gives `min_j sqrt(d_j2) = sqrt(min_j d_j2)`. A no-trace path can therefore take one root per threat after reducing instead of 33. Preserve the original distance result and all subsequent meter-based margins; comparing squared scores directly would change the algorithm.

At 60 Hz planning, N healthy companions each considering the player and N-1 peers produce source-derived clear-path counts of `1980*N*N` roots per simulated second. N=1/2/3 gives 1,980/7,920/17,820, versus 60/240/540 after reduction. The existing clear-baseline shortcut already avoids eleven extra bank candidates; those candidates must not be charged on every plan. Conflicts and held maneuvers increase work separately. Trace mode still needs every sampled distance. Preserve NaN/overflow/tie/signed-zero behavior with domain checks or fallback; the cost of those guards must be measured.

The same 32-step predictor repeats bank-to-turn-rate evaluation at clamped interpolation endpoints: iterations 1–4 use weight zero, 5–7 are transitional, and 8–32 use weight one. Lazy reuse of the exact endpoint `lerpf -> tan -> multiply/divide` results reduces 32 such evaluations to five without changing heading accumulation. Do not replace `lerpf(a,b,1)` with `b` merely on real-number intuition; preserving the actual endpoint operation avoids a different floating-point rounding path. Two callers also need only roll from a full quaternion-to-Euler conversion; reuse the original roll expression and coordinate convention, leaving base guidance's full Euler requirement intact.

These changes are unimplemented and untimed. They require exact score/result-field comparisons, thresholds and ties, zero threats, avoidance/held/clear scenarios, all commands and decision state, trajectories, replay and a genuine source-identity rebind. Updating a profile hash alone is not qualification. No approximation or reduced planning frequency is proposed.

### Native spatial stage: remove discarded legacy air work

In [nk_stage.hpp:273–296](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/research/native-kernel/src/nk_stage.hpp#L273-L296), legacy wind and `air_compute` initialize an Air value before the spatial branch replaces it on both success and refusal. Their returned values are overwritten and the examined evaluator has no explicit state mutation. Libm calls can still affect errno or floating-point exception flags; preserve the supported environment and check malformed inputs before removal. Moving that initialization into the nonspatial branch could remove a legacy query plus two square roots and two atan2 calls per qualifying native stage: nominally 960 discarded Air evaluations/s for four stages at 240 Hz.

First inspect the actual optimized build to determine whether dead-store/call elimination already removes this work. Then compare complete native stage arrays, malformed and invalid spatial cases, preview/fuel/wake/gear behavior, rollback, and accepted trajectories. No candidate timing or stage-level parity was obtained, and this native-only proposal does not improve the measured reference path by itself.

## 6. GPU and memory opportunities

### Afterimage support can be outside the viewport while the pass remains active

[sun_glare.gd::_show_afterimage](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/render/landscape_upgrade/sun_glare.gd#L261-L286) enables the layer based on patch alpha rather than projected support. The dose model can remain active outside the visible camera rectangle. A source-derived, checked-engine 1920x1080 fixture at 50-degree vertical FOV produced a 50-degree horizontal patch with alpha 0.941845, center x=2,340.09 pixels, radius=23.164 pixels, and nearest viewport distance=18.136 radii. The layer was shown. A 41.5-degree control lies 2.786 radii from the edge and provides a useful boundary case; whether it remains drawn depends on the chosen validated error budget. Its ideal mask factor is also very small. Add a clearly contributing positive control within one to two radii.

The [afterimage shader](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/render/sun/sun_afterimage.gdshader#L9-L36) loops over up to eight patches and requests a mipmapped screen texture. Its radial contribution is `m_i = alpha_i * exp(-0.5*x_i^4)`. It has no finite mathematical support. At the distant witness, its ideal maximum tail is below 10^-23490; at three radii the factor is about 2.577e-18. Neither statement proves an algebraically exact cutoff across GPU formats and compilers.

Proposed experiment: preserve patch state, exposure, decay and time semantics, but hide the rendering item when every packed contribution is outside a validated error envelope. For finite 0<=m_i<=1, the combined alpha satisfies `1-product(1-m_i) <= sum(m_i)`. This gives a conservative way to allocate a total alpha error budget across at most eight patches, then bound color error using the actual output range. It must include low-alpha patches that render while another patch keeps the layer enabled. Use the exact viewport, aspect, height scaling, FOV and radius clamp; uncertain or nonfinite input stays on the old path. Validate a displayed-channel error budget and pilot-readability policy in each supported format/backend before promotion.

A full-screen item nominally covers 2,073,600 pixels at 1080p or 8,294,400 at 4K. These are work envelopes, not GPU invocation counters or measured bandwidth. Hiding the item may also remove a screen-copy/mipmap dependency if no other consumer requires it. A fragment branch alone does not necessarily remove that material dependency. The exact pinned engine's RD and GLES3 canvas paths were inspected, and Godot's screen-reading documentation describes the copy/mipmap mechanism. GPU capture must establish the actual pass graph and savings.

Test sun/moon, skyline/cloud occlusion, resize/aspect/zoom, overlapping patches, barely visible edges, pause/seek, eyewear, and offscreen transitions on Compatibility and Mobile/Metal. This refines A26 section 2E; it is not a separately counted new GPU defect or an implemented FPS improvement.

### Index shadow geometry only after accounting for preparation and consumers

[Projected.collect](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/render/projected_shadow.gd#L35-L75) expands model faces into an unindexed position-only shadow mesh. In the exact Stik builder component, the result contains 165,296 triangles and 495,888 positions. Indexing produces 84,428 positions and 495,888 indices. Deindexing the candidate reproduces original position bytes before any second `get_faces()` conversion; bounds and face streams also match.

Logical position/index payload, assuming 12-byte float32 positions and 4-byte indices, changes from `495888*12 = 5,950,656` bytes to `84428*12 + 495888*4 = 2,996,688` bytes: **49.64%**, or 2.817 MiB per such mask. This is not observed RSS, VRAM, drawn-vertex count, or GPU time. The triangle count and tested triangle positions/order are unchanged. Actual fragment-shader invocations were not measured; post-transform cache reuse depends on draw order and hardware.

Seven alternating warm pairs after two warmups measured median collection at **8.950 ms**, versus **108.193 ms** for collection plus indexing/finalization. Incremental indexing/finalization median was **99.917 ms**. A naive synchronous patch would introduce a substantial preparation pause; it was rejected. An offline or bounded prepared-cache artifact can be evaluated later, with source/material/visibility/version identity and dynamic-model fallback. For a redraw-time-only payback screen on a comparable critical-path basis, compare `redraw_count * measured_redraw_saving` with the incremental preparation cost, while also enforcing the first-interactive-frame budget. Offline preparation, memory residency and upload savings require their own accounting.

There is a concrete consumer trap: [field_projected_shadows.gd](https://github.com/bultodepapas/OpenRCsimulator/blob/8fb825a96dbc39fbbf99c1056ba643c9cde49b5d/app/render/field_projected_shadows.gd#L154-L165) treats the vertex array as a deindexed triangle stream. Globally indexing `Projected.collect` would break that interpretation. Use an aircraft-only finalizer or update every relevant consumer deliberately.

The pinned Godot engine also snaps positions to 0.0001 and builds a cached triangle mesh/BVH inside `get_faces`; a direct source-index shortcut must preserve snapping, strip winding, transforms and invalid-input behavior. Avoid claiming cache-residency savings without measuring who owns and shares those structures. Historical Windows active-roll shadow measurements are context only, not this review's current GPU baseline.

## 7. Reconciliation with earlier work and the successor commit

Already present and not rediscovered here: thermal sine/zero-result reuse (WOPT-01), overlay datum reuse (WOPT-02), pre-step air reuse (A6 O4), accepted-iterate trim RPM reuse, conditional audio humidity fallback, deferred unused legacy PCM preparation, bounded telemetry chunks/export, two-entry circuit mesh LRU, shared parked ORM retrieval, source-bound scenario cache, existing native evaluator, typed paths, batched stars, field-tree spatial cells, guarded ground-shader work, cloud texture cache, incremental sky updates, staged world construction, and threaded preview acquisition.

Known remaining work retains its original owner: native circuit terrain and companion admission, conservative hull reach and station geometry, stage mass properties, rotor-stage reuse, retract validation, angle-only flap presentation, cloud readback, texture compression and loading/pipeline readiness. The source still synchronously hashes eligible packaged reference-recording bundles at F10 start and stop. Its approximately 2B-byte traversal per pair is the existing A24 issue; old synthetic timing numbers are not current target measurements. Any asynchronous version must retain both exact byte checks, frozen stop state, main-thread checkpoint boundaries, bounded worker ownership and stale-job isolation.

The successor `f7b58bd` preserves imported LODs on unchanged Timber repair/cache surfaces and admits one exact reviewed paint-identity pair. Its TT-21 report describes 29,465 -> 24,827 submitted primitives at a fixed 50 m pose, with 143 draw calls unchanged. That is reported component evidence, not this review's measurement or an FPS result; do not propose this now-implemented LOD fix again.

The new L8a-R4 JSONs report 30 zero-error synthetic material comparisons and 43 native 1080p lighting captures on Windows/RTX 3090/Compatibility. The reports were retrieved and hashed, but underlying images/logs were unavailable for independent inspection. Their recorded HEAD is the original revision while two recorded script hashes match the successor, so describe them as mixed-worktree evidence, not a clean original-revision run. They do not qualify whole-tree appearance, moving flight, Mobile/Metal, or frame time. The a831 change intentionally lowers Auto’s unknown/unreported-GPU fallback from High to Medium; Apple M was already classified Medium. Medium selects Balanced scenery and can therefore change ornament collisions on the next world build. No confirmed sustained GPU regression was established for the latest visual changes.

The successor also instructs that graphics settings must not change simulation physics. The inherited quality path currently filters scenery collision placements when a world is built, and existing tests explicitly expect different collision inventories by quality. Future quality optimization must reconcile that contract: keep a stable physical world with scalable presentation or deliberately version migration and checkpoints. Lowering collision content is not a behavior-preserving graphics speedup.

## 8. Hardware, methodology, and limits

All new elapsed measurements used a Linux x86-64 container on an AMD EPYC 9V74 80-Core Processor host, with nine visible/affinity CPUs, an eight-core cgroup quota, and an 8 GiB memory limit. The host is shared; frequency, contention and thermal isolation are not controlled. The official Godot editor/debug binary reports a headless display and Dummy rendering/audio. No GPU device or physical display/controller was exposed. These are warm software/component screens and short accepted-session baselines, not native consumer-hardware qualification.

Independent agents' CPU tests, imports, compilation and timing runs were serialized so they did not compete with the reported benchmark batches. Raw samples, candidate hashes, fixtures, configuration diffs, checked-runner logs, failed setup attempts, and expected-error controls are retained. The checked runner scans engine logs: an exit-zero script with engine errors is not accepted as a pass. Failure evidence is kept with its classification.

For a component speedup s occupying fraction f of the relevant serial work, Amdahl's law gives `S_total = 1 / ((1-f) + f/s)`. For s=3.1195, f=0.10 gives about 1.073x; f=0.25 gives about 1.205x. The actual f is unmeasured, and a GPU bottleneck or presentation wait can hide CPU savings in displayed FPS. Input-path work can still affect responsiveness when the frame rate does not change. Apply this to measured frame/handler shares, not an invented workload fraction.

## 9. Practical target-validation campaign

### Reproducible identity and baseline

Record commit, patch/source hashes, Godot/editor/export-template hashes, build type, native library/ABI and selected/fallback solver, hardware/OS/driver, process architecture, power/thermal state, renderer, output and internal pixel sizes, MSAA/reconstruction, effective quality settings, world/aircraft/paint/cache identity, weather seed/epoch and tape, simulation tick policy, companion count, camera/FOV, and audio configuration. Start with 1920x1080 on native Apple Silicon Mobile/Metal and representative Compatibility hardware; check larger outputs only after that. Do not substitute configured window size for measured drawable size.

Use the same accepted-state reset, input tape, weather, world, camera and readiness condition for each pair. First screen five alternating independent baseline/candidate pairs with 30 seconds warmup and 120 seconds capture. Collect five fresh-process and five warm loads separately. Only finalists warrant three independent 30-minute active runs per role, retaining early/final behavior and power/thermal context. Keep a clean timing launch separate from profiler/diagnostic launches.

### Workloads

| Scenario | What it resolves |
| --- | --- |
| Home-launched selected gamepad, rates-only and equipment-rich fixed wing; helicopter; separate UI/flight devices | Full input-routing cost, actual resolver calls/event, press/release correctness, frame pacing and latency |
| Real radio and explicit-binding controls | No-regression routes where the index is not expected to help |
| Stik steady wind; spatial 8/24/64 modes; gusts/thermals; low-altitude boundaries | Simulation cost, refusal order, stage-cache correctness and actual query workloads |
| Zero/one/three companions, clear and crossing/held-conflict cases | Fleet simulation, predictor scaling, native admission and audio contribution |
| Active roll versus hands-off, aircraft changes and Home previews | Shadow redraw cost, preparation, eviction and retained memory |
| Pilot sun/moon on-screen, far-offscreen and near-edge transitions | Screen-copy/mipmap/pass attribution and bounded afterimage visual differences |
| Dense field, near-ground view, night, cloud change, high-memory aircraft | Geometry, alpha fill, passes, texture/readback and memory pressure |
| Cold launch, Home-to-flight, return/restart, F10 start/stop and long telemetry | Loading, pipeline/upload readiness, filesystem synchronization and stalls |

### Metrics and attribution

Record CPU frame and main-thread work, GPU frame/pass times, physics ticks and cost, actual presented/interarrival frame intervals, average FPS from total frames/time, p50/p95/p99/p99.9 intervals, maximum interval, stall counts and bursts above the selected target's budgets, and simulation-time/wall-time ratio. Retain distributions rather than converting a median component time into FPS. The existing three physics batch means cannot supply these percentiles.

Track GPU/pass state with Godot visual profiling and the platform's native GPU tools, and CPU call stacks/self versus inclusive time with separate diagnostic runs. For copies/readbacks, correlate CPU stalls with GPU events. Record load phases separately: acquisition/decode, construction/publication, upload/pipeline preparation, first drawn and first interactive frame. Capture process peak/retained memory and actual texture/buffer formats; logical array arithmetic is not residency.

Measure input from physical actuation or timestamped device ingress through event handler, accepted simulation tick and displayed response. A software timestamp alone does not measure USB/display scanout. Keep VSync/presentation modes fixed for comparisons and test reconnect, calibration, Pause, restart, held controls, rebinds and role changes. Audio qualification adds listening/underrun checks on the real driver while preserving checkpoint parity.

### Acceptance order

First fix the pre-existing CI roster mismatch without reducing coverage. Merge or apply the small local patch only after its normal integration gates. Next integrate the spatial phase candidate one backend at a time, with actual source-bound oracles before timing. Profile afterimage and recording-boundary candidates on the real target to choose between GPU-pass elimination and I/O scheduling. Pursue companion math only through the required replay/rebind workflow. Evaluate shadow indexing as a prepared representation, not as an unconditional synchronous load step.

Require correctness, refusal/rollback, replay, visual and input/audio behavior together with whole-session performance. A candidate should improve the relevant cost distribution without worsening first interaction, tail stalls, memory pressure or pilot readability beyond an explicitly accepted budget. Keep 240 Hz, float64 state, coordinate conventions, physical collision contracts, and deterministic reductions intact.

## 10. Deliverables and reproduction

The accompanying patch changes only `app/input/controller_actions.gd`, `app/render/engine_voice.gd`, the existing `app/tests/test_engine_voice.gd`, and a new controller-index test plus its Godot UID. Prototypes and reports remain outside the production application. The evidence bundle includes the patch, raw controller/audio/session timings, exact comparison harnesses, focused checked receipts, negative controls, stage-cache prototype, GPU witnesses, manifests, and a reproduction guide. Large original assets, the Godot executable, imported caches and the repository clone are not duplicated in the bundle; source identities and retrieval paths are retained.

Apply to a clean reviewed checkout with `git apply --check OpenRC-performance.patch`, inspect it, then `git apply OpenRC-performance.patch`. Use the repository's pinned Godot getter and checked runner for the listed tests. The independent evidence guide explains fixture-only settings and unavailable target-hardware gates; it must not be confused with a full release qualification.

## Primary technical references

- [Godot CPU optimization](https://docs.godotengine.org/en/latest/tutorials/performance/cpu_optimization.html): repeated timing, caches and actual bottlenecks. Generic tick-rate advice is not applied to this simulator's fixed kernel contract.
- [Godot profiler](https://docs.godotengine.org/en/latest/tutorials/scripting/debug/the_profiler.html): self/inclusive attribution and instrumentation overhead.
- [Pinned GDScript implementation notes](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/modules/gdscript/README.md): VM, typed operations and constant folding. Actual component timing establishes whether the tested source change still helps.
- [Godot input accumulation](https://docs.godotengine.org/en/latest/classes/class_input.html#class-input-property-use-accumulated-input): event behavior; the application already disables accumulation.
- [Screen-reading shaders](https://docs.godotengine.org/en/latest/tutorials/shaders/screen-reading_shaders.html) and [pinned RD canvas implementation](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/servers/rendering/renderer_rd/renderer_canvas_render_rd.cpp#L773-L785): screen copies, mipmaps and shared dependencies.
- [Pinned GLES3 canvas implementation](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/drivers/gles3/rasterizer_canvas_gles3.cpp#L429-L435): Compatibility-path screen-copy decisions.
- [Pinned mesh implementation](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/scene/resources/mesh.cpp#L290-L407) and [triangle-mesh construction](https://github.com/godotengine/godot/blob/cafc17a192acf67903910a68aeb3c076c0907a4b/core/math/triangle_mesh.cpp#L108-L184): indexed/strip expansion, snapping and cached acceleration.
- [Godot precision](https://docs.godotengine.org/en/stable/tutorials/physics/large_world_coordinates.html): scalar/vector precision distinctions and native ABI implications.

The complete audit and source links in the specialist appendices remain in the evidence bundle. Historical author-reported observations are explicitly separate from this review's measurements.
