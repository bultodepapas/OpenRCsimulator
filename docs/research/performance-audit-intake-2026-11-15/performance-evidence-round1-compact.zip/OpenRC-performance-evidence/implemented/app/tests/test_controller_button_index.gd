extends SceneTree

const Actions := preload("res://input/controller_actions.gd")
var checks := 0
var failures := 0

func _initialize() -> void:
	var all_caps := {"gear": true, "smoke": true, "flaps": true, "rates": true, "helicopter": true}
	var base := {"kind": "gamepad", "actions": {}, "aux": {}}
	var mixed := Actions.effective_bindings(base, all_caps)
	for pair: Array in [["gear_toggle", JOY_BUTTON_B], ["smoke_toggle", JOY_BUTTON_RIGHT_SHOULDER],
		["flaps_cycle", JOY_BUTTON_A], ["rates_toggle", JOY_BUTTON_LEFT_STICK], ["restart_flight", JOY_BUTTON_BACK]]:
		_check("declaration priority %s" % pair[0], mixed[pair[0]] == {"type": "button", "button": pair[1]})
	for action: String in ["helicopter_arm", "helicopter_hold", "helicopter_mode", "helicopter_trainer"]:
		_check("earlier default reserves %s" % action, mixed[action] == {"type": "unbound"})
	_check("menu-only accept and back do not reserve flight buttons", mixed.accept.button == mixed.flaps_cycle.button
		and mixed.back.button == mixed.gear_toggle.button)
	var heli := Actions.effective_bindings(base, Actions.HELICOPTER_CAPABILITIES)
	_check("helicopter-only A is admitted", heli.helicopter_arm == {"type": "button", "button": JOY_BUTTON_A})
	_check("helicopter-only B is admitted", heli.helicopter_hold == {"type": "button", "button": JOY_BUTTON_B})
	var profile: Dictionary = base.duplicate(true)
	profile.actions.pause = {"type": "button", "button": JOY_BUTTON_A}
	_check("both-context recovery reserves A", Actions.effective_bindings(profile, all_caps).flaps_cycle == {"type": "unbound"})
	profile.actions = {"camera_cycle": {"type": "button", "button": JOY_BUTTON_A}}
	_check("valid flight binding reserves A", Actions.effective_bindings(profile, all_caps).flaps_cycle == {"type": "unbound"})
	for invalid: Variant in [{"type": "button", "button": float(JOY_BUTTON_A)},
		{"type": StringName("button"), "button": JOY_BUTTON_A}, {"type": "button", "button": -1},
		{"type": "button", "button": JOY_BUTTON_MAX}, {"type": "button"}, null, 4]:
		profile.actions = {"camera_cycle": invalid}
		var result := Actions.effective_bindings(profile, all_caps)
		_check("malformed override does not reserve", result.flaps_cycle == {"type": "button", "button": JOY_BUTTON_A})
		_check("malformed override remains visible for validation", var_to_bytes(result.camera_cycle) == var_to_bytes(invalid))
	profile.actions = {"unknown_action": {"type": "button", "button": JOY_BUTTON_A}}
	_check("unknown definition cannot reserve", Actions.effective_bindings(profile, all_caps).flaps_cycle.button == JOY_BUTTON_A)
	profile.actions = {"camera_cycle": {StringName("type"): "button", StringName("button"): JOY_BUTTON_A}}
	_check("StringName binding keys retain reservation", Actions.effective_bindings(profile, all_caps).flaps_cycle.type == "unbound")
	profile.actions = {StringName("flaps_cycle"): {"type": "unbound"}}
	var explicitly_cleared := Actions.effective_bindings(profile, all_caps)
	_check("explicit Clear is retained", explicitly_cleared.flaps_cycle.type == "unbound")
	_check("cleared airplane action releases A for helicopter", explicitly_cleared.helicopter_arm.button == JOY_BUTTON_A)
	profile.actions = {}
	profile.aux = {"gear": {"type": "switch", "buttons": [JOY_BUTTON_A, JOY_BUTTON_RIGHT_SHOULDER], "invert": false}}
	var reserved := Actions.effective_bindings(profile, all_caps)
	_check("same AUX channel reserves gear independently of button", reserved.gear_toggle.type == "unbound")
	_check("every AUX switch member reserves", reserved.flaps_cycle.type == "unbound" and reserved.smoke_toggle.type == "unbound")
	profile.aux = {}
	profile.actions = Actions.default_bindings()
	_check("all explicit bindings stay exact", var_to_bytes(Actions.effective_bindings(profile, all_caps)) == var_to_bytes(profile.actions))
	profile.actions = {"camera_cycle": {"type": "button", "button": JOY_BUTTON_X}}
	var snapshot := var_to_bytes(profile)
	var detached := Actions.effective_bindings(profile, all_caps)
	detached.camera_cycle.button = JOY_BUTTON_A
	_check("nested returned bindings remain detached", var_to_bytes(profile) == snapshot)
	profile.kind = "radio"
	_check("radio path does not gain automatic buttons", Actions.effective_bindings(profile, all_caps).flaps_cycle.type == "unbound")
	profile.kind = "joystick"
	_check("joystick path does not gain automatic buttons", Actions.effective_bindings(profile, all_caps).helicopter_arm.type == "unbound")
	print("Controller button index: %d checks, %d failed" % [checks, failures])
	quit(1 if failures else 0)

func _check(label: String, condition: bool) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL ", label)
