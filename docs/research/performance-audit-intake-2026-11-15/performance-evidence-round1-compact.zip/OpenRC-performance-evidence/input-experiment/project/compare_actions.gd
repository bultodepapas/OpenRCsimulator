extends SceneTree

const Baseline := preload("res://baseline_actions.gd")
const Candidate := preload("res://input/controller_actions.gd")
const Profile := preload("res://input/controller_profile.gd")
var checks := 0
var failures := 0

func _initialize() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 82520261109
	var base: Dictionary = Profile.defaults()
	var capabilities: Array[Dictionary] = [Candidate.AIRPLANE_CAPABILITIES,
		Candidate.HELICOPTER_CAPABILITIES, {},
		{"gear": true, "smoke": true, "flaps": true, "rates": true, "helicopter": true}]
	for caps: Dictionary in capabilities:
		_compare(base, caps, "stock")
	# Every action/button, including boundaries, in every supported capability set.
	for action: Dictionary in Candidate.ACTIONS:
		for button: int in range(-1, JOY_BUTTON_MAX + 1):
			var profile: Dictionary = base.duplicate(true)
			profile.actions[action.id] = {"type": "button", "button": button}
			for caps: Dictionary in capabilities:
				_compare(profile, caps, "button sweep")
	# Seeded mixed inputs exercise malformed/unknown/string-name overrides and AUX ownership.
	var values: Array = [{"type": "unbound"}, {"type": "unbound", "button": 1},
		{"type": "button", "button": 0.0}, {"type": StringName("button"), "button": 1},
		{"type": "axis", "axis": 4, "sign": 1, "threshold": 0.65},
		{"type": "axis", "axis": 5, "sign": -1, "threshold": NAN},
		{"type": "key", "physical_keycode": KEY_ESCAPE}, {}, null, 7,
		{"type": "button", "button": JOY_BUTTON_MAX}, {"type": "button", "button": JOY_BUTTON_MAX - 1}]
	for sample: int in 3000:
		var profile: Dictionary = base.duplicate(true)
		if sample % 17 == 0: profile.kind = "radio"
		if sample % 19 == 0: profile.kind = "joystick"
		for index: int in rng.randi_range(0, 12):
			var id: Variant = Candidate.ACTIONS[rng.randi_range(0, Candidate.ACTIONS.size() - 1)].id
			if index % 3 == 0: id = StringName(id)
			var value: Variant = values[rng.randi_range(0, values.size() - 1)]
			if index % 2 == 0: value = {"type": "button", "button": rng.randi_range(0, JOY_BUTTON_MAX - 1)}
			profile.actions[id] = value
		if sample % 11 == 0: profile.actions.unknown_action = {"type": "button", "button": JOY_BUTTON_A}
		match sample % 5:
			0: profile.aux = {"smoke": {"type": "button", "button": rng.randi_range(0, 12), "mode": "level"}}
			1: profile.aux = {"gear": {"type": "switch", "buttons": [0, 1, 10], "invert": false}}
			2: profile.aux = {"flaps": {"type": "axis", "axis": 4, "off": -1.0, "on": 1.0, "invert": false}}
			3: profile.aux = {"smoke": {"type": "button", "button": JOY_BUTTON_RIGHT_SHOULDER, "mode": "toggle_edge"},
				"gear": {"type": "switch", "buttons": [JOY_BUTTON_A, JOY_BUTTON_B], "invert": false}}
		for caps: Dictionary in capabilities:
			_compare(profile, caps, "seeded %d" % sample)
	print("ACTION_PARITY ", JSON.stringify({checks=checks, failures=failures,
		godot=Engine.get_version_info().string, seed=82520261109,
		baseline_sha="8fb825a96dbc39fbbf99c1056ba643c9cde49b5d"}))
	quit(1 if failures else 0)

func _compare(profile: Dictionary, caps: Dictionary, label: String) -> void:
	var before: PackedByteArray = var_to_bytes(profile)
	var old: Dictionary = Baseline.effective_bindings(profile, caps)
	var new: Dictionary = Candidate.effective_bindings(profile, caps)
	checks += 1
	if var_to_bytes(old) != var_to_bytes(new) or var_to_bytes(profile) != before:
		failures += 1
		printerr("FAIL ", label, " ", str(profile), " ", str(caps))
	# A consumer must still own every returned nested binding independently.
	new.pause = {"type": "unbound"}
	if var_to_bytes(profile) != before:
		failures += 1
		printerr("FAIL output ownership ", label)
