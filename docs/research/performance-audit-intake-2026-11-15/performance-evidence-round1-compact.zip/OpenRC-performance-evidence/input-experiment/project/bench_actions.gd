extends SceneTree

const Baseline := preload("res://baseline_actions.gd")
const Candidate := preload("res://input/controller_actions.gd")
const Profile := preload("res://input/controller_profile.gd")
const CALLS := 4000
const ROUNDS := 9
var _sink := 0

func _initialize() -> void:
	var gamepad: Dictionary = Profile.defaults()
	var overridden: Dictionary = gamepad.duplicate(true)
	overridden.actions = Baseline.default_bindings()
	var aux: Dictionary = gamepad.duplicate(true)
	aux.aux = {"smoke": {"type": "switch", "buttons": [JOY_BUTTON_A, JOY_BUTTON_B], "invert": false},
		"gear": {"type": "button", "button": JOY_BUTTON_RIGHT_SHOULDER, "mode": "level"}}
	var radio: Dictionary = Profile.defaults("radio", "radio_custom")
	var cases: Array[Dictionary] = [
		{"name": "airplane_gamepad", "profile": gamepad, "caps": Candidate.AIRPLANE_CAPABILITIES},
		{"name": "helicopter_gamepad", "profile": gamepad, "caps": Candidate.HELICOPTER_CAPABILITIES},
		{"name": "aux_conflicts", "profile": aux, "caps": Candidate.AIRPLANE_CAPABILITIES},
		{"name": "explicit_all", "profile": overridden, "caps": Candidate.AIRPLANE_CAPABILITIES},
		{"name": "no_capabilities", "profile": gamepad, "caps": {}},
		{"name": "radio_control", "profile": radio, "caps": Candidate.AIRPLANE_CAPABILITIES},
	]
	var results: Array[Dictionary] = []
	for item: Dictionary in cases:
		_measure(Baseline, item.profile, item.caps, 500)
		_measure(Candidate, item.profile, item.caps, 500)
		var before: Array[float] = []
		var after: Array[float] = []
		for round_index: int in ROUNDS:
			if round_index % 2 == 0:
				before.append(_measure(Baseline, item.profile, item.caps, CALLS))
				after.append(_measure(Candidate, item.profile, item.caps, CALLS))
			else:
				after.append(_measure(Candidate, item.profile, item.caps, CALLS))
				before.append(_measure(Baseline, item.profile, item.caps, CALLS))
		results.append({name=item.name, baseline_us_per_call=before, candidate_us_per_call=after})
	print("ACTION_BENCH ", JSON.stringify({format="openrc-action-index-bench-v1",
		godot=Engine.get_version_info(), cpu=OS.get_processor_name(), os=OS.get_name(),
		debug_build=OS.is_debug_build(), display=DisplayServer.get_name(),
		calls_per_batch=CALLS, rounds=ROUNDS, warmup_per_role=500, alternating_order=true,
		cases=results, sink=_sink, scope="effective_bindings only; no event dispatch, USB, rendering, physics, or FPS"}))
	quit()

func _measure(implementation: Script, profile: Dictionary, capabilities: Dictionary, count: int) -> float:
	var start := Time.get_ticks_usec()
	for index: int in count:
		var result: Dictionary = implementation.effective_bindings(profile, capabilities)
		_sink += result.size()
	return float(Time.get_ticks_usec() - start) / float(count)
