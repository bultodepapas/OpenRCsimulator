from pathlib import Path
import hashlib, json, re, shutil, subprocess

ROOT = Path('/workspace/scratch/b5b7ad11b056/audit-review')
REPO = ROOT / 'repository'
FIXTURE = ROOT / 'input-experiment' / 'project'
TESTS = ['test_controller_actions.gd', 'test_controller_extended_actions.gd',
         'test_controller_binding_audit.gd', 'test_controller_profile.gd',
         'test_controller_conditioning.gd']
pending = ['tests/' + name for name in TESTS]
seen = set()
manifest = {}
while pending:
    relative = pending.pop()
    if relative in seen:
        continue
    seen.add(relative)
    source = REPO / 'app' / relative
    if not source.is_file():
        raise FileNotFoundError(source)
    data = source.read_bytes()
    target = FIXTURE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    manifest[relative] = hashlib.sha256(data).hexdigest()
    text = data.decode('utf-8')
    pending.extend(re.findall(r'(?:preload|load)\("res://([^"\n]+\.gd)"\)', text))

translation = subprocess.check_output(['git', 'show', 'HEAD:app/i18n/es.po'], cwd=REPO)
(FIXTURE / 'i18n').mkdir(exist_ok=True)
(FIXTURE / 'i18n/es.po').write_bytes(translation)
(FIXTURE / 'project.godot').write_text('''config_version=5
[application]
config/name="OpenRC controller optimization fixture 8fb825a"
[rendering]
renderer/rendering_method="gl_compatibility"
[internationalization]
locale/translations=PackedStringArray("res://i18n/es.po")
''')
original = (FIXTURE / 'input/controller_actions.gd').read_text()
(FIXTURE / 'baseline_actions.gd').write_text(original)
manifest['baseline_commit'] = '8fb825a96dbc39fbbf99c1056ba643c9cde49b5d'
(ROOT / 'input-experiment/source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'fixture': str(FIXTURE), 'files': len(seen), 'tests': TESTS}))
