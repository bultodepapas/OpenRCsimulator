extends SceneTree
const Stik := preload("res://aircraft/ugly_stik_model.gd")
const Projected := preload("res://render/projected_shadow.gd")

func _initialize() -> void:
	var airplane: Dictionary = Stik.build()
	var model: Node3D = airplane.root
	var unique: Dictionary = {}
	var unique_triangle_count := 0
	for item: Node in model.find_children("*", "MeshInstance3D", true, false):
		var mi := item as MeshInstance3D
		if mi.mesh == null:
			continue
		var cursor: Node = mi
		var include := true
		while cursor != model and cursor != null:
			if cursor is Node3D:
				include = include and cursor.visible and cursor.name != &"propeller"
			cursor = cursor.get_parent()
		if not include or unique.has(mi.mesh.get_instance_id()):
			continue
		unique[mi.mesh.get_instance_id()] = true
		for surface in mi.mesh.get_surface_count():
			var count: int = mi.mesh.surface_get_array_index_len(surface) if mi.mesh.surface_get_format(surface) & Mesh.ARRAY_FORMAT_INDEX else mi.mesh.surface_get_array_len(surface)
			match mi.mesh.surface_get_primitive_type(surface):
				Mesh.PRIMITIVE_TRIANGLES:
					if count % 3 == 0:
						unique_triangle_count += count / 3
				Mesh.PRIMITIVE_TRIANGLE_STRIP:
					unique_triangle_count += maxi(count - 2, 0)
	var before: int = OS.get_static_memory_usage()
	var shape: Dictionary = Projected.collect(model)
	var after_collect: int = OS.get_static_memory_usage()
	var triangles: int = shape.triangles
	shape.clear()
	var after_shape_release: int = OS.get_static_memory_usage()
	var second: Dictionary = Projected.collect(model)
	var after_second: int = OS.get_static_memory_usage()
	second.clear()
	var after_second_release: int = OS.get_static_memory_usage()
	print("unique_source_meshes=", unique.size(), " unique_source_triangles=", unique_triangle_count,
		" projected_triangles=", triangles)
	print("static_before=", before, " static_after_first=", after_collect,
		" static_after_shape_release=", after_shape_release,
		" static_after_second=", after_second, " static_after_second_release=", after_second_release)
	model.free()
	print("Shadow memory witness complete")
	quit()
