extends SceneTree

const Optics := preload("res://render/sun/sun_optics.gd")
const GlareFragment := preload("res://show_afterimage.gd")

func _initialize() -> void:
	call_deferred("run")


func run() -> void:
	root.size = Vector2i(1920, 1080)
	var glare := GlareFragment.new()
	root.add_child(glare)
	var shader := Shader.new()
	shader.code = "shader_type canvas_item; uniform vec4 patches[8]; uniform float lit[8]; void fragment() { COLOR = vec4(1.0); }"
	glare._after_material = ShaderMaterial.new()
	glare._after_material.shader = shader
	var camera := Camera3D.new()
	camera.fov = 50.0
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	root.add_child(camera)
	var size := root.get_visible_rect().size
	var failures := 0
	if size != Vector2(1920, 1080):
		print("Unexpected root size ", size)
		failures += 1
	for angle_deg in [0.0, 41.5, 50.0]:
		var angle: float = deg_to_rad(angle_deg)
		var direction := Vector3(sin(angle), 0.0, -cos(angle))
		var weight: float = Optics.field_weight(angle)
		glare._afterimage = Optics.afterimage_step(Optics.afterimage_rest(), 0.3, weight, direction)
		var shown: bool = glare._show_afterimage(camera, direction, weight)
		var alpha: float = Optics.afterimage_alphas(glare._afterimage)[0]
		var half_height: float = Optics.view_tan_half_height(camera.fov, false, size.x / size.y)
		var uv_x: float = 0.5 + direction.x / -direction.z / half_height * 0.5 * size.y / size.x
		var radius: float = tan(Optics.AFTER_BASE_RADIUS) / half_height * 0.5
		var outside_px: float = maxf((uv_x - 1.0) * size.x, 0.0)
		var radii_from_edge: float = outside_px / (radius * size.y)
		print("angle_deg=", angle_deg, " weight=", weight, " shown=", shown, " alpha=", alpha,
			" center_x=", uv_x * size.x, " radius_px=", radius * size.y,
			" edge_distance_radii=", radii_from_edge)
		if not shown or alpha <= 0.002:
			failures += 1
		if angle_deg == 50.0 and radii_from_edge < 3.0:
			failures += 1
		if angle_deg == 41.5 and (radii_from_edge <= 0.0 or radii_from_edge >= 3.0):
			failures += 1
	glare._afterimage = Optics.afterimage_rest()
	if glare._show_afterimage(camera, Vector3(0.0, 0.0, -1.0), 0.0):
		failures += 1
	print("Afterimage source witness: ", failures, " failures")
	quit(1 if failures else 0)
