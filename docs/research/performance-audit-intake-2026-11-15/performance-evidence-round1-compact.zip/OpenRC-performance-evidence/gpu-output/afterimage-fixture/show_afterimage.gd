extends Node
const SunOptics := preload("res://render/sun/sun_optics.gd")
var _afterimage: Dictionary
var _after_material: ShaderMaterial
var intensity := 1.0

func _show_afterimage(camera: Camera3D, sun_view: Vector3, dose: float) -> bool:
	var size := get_viewport().get_visible_rect().size
	if size.x <= 0.0 or size.y <= 0.0:
		return false
	var alphas := SunOptics.afterimage_alphas(_afterimage)
	var patches: Array = _afterimage.patches
	var tan_half_height := SunOptics.view_tan_half_height(camera.fov, camera.keep_aspect == Camera3D.KEEP_WIDTH, size.x / size.y)
	var packed := PackedVector4Array()
	var lit := PackedFloat32Array()
	var any := false
	for i in SunOptics.AFTER_PATCHES:
		var patch: Dictionary = patches[i] if i < patches.size() else {}
		var d: Vector3 = patch.get("dir", Vector3(0.0, 0.0, -1.0))
		var radius := float(patch.get("radius", SunOptics.AFTER_BASE_RADIUS))
		# The strength control scales the masking too (bleaching itself saturates within a glance).
		var alpha := alphas[i] * clampf(intensity, 0.0, 1.0) if d.z < -0.05 else 0.0
		# View space to screen uv (top-left origin, as SCREEN_UV): x right, y up in view space.
		var uv := Vector2(0.5 + d.x / -d.z / tan_half_height * 0.5 * size.y / size.x, 0.5 - d.y / -d.z / tan_half_height * 0.5) \
			if d.z < -0.05 else Vector2(-10.0, -10.0)
		packed.append(Vector4(uv.x, uv.y, tan(radius) / tan_half_height * 0.5, alpha))
		lit.append(SunOptics.afterimage_lit(d, radius, sun_view, dose))
		any = any or alpha > 0.002
	_after_material.set_shader_parameter("patches", packed)
	_after_material.set_shader_parameter("lit", lit)
	return any

