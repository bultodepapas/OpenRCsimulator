extends SceneTree
const Stik := preload("res://aircraft/ugly_stik_model.gd")
const Projected := preload("res://render/projected_shadow.gd")

func _initialize() -> void:
	var airplane: Dictionary = Stik.build()
	var model: Node3D = airplane.root
	for warm in 2:
		sample(model, false, -1)
		sample(model, true, -1)
	for i in 7:
		if i % 2 == 0:
			sample(model, false, i)
			sample(model, true, i)
		else:
			sample(model, true, i)
			sample(model, false, i)
	model.free()
	print("Shadow construction sampling complete")
	quit()


func sample(model: Node3D, index_it: bool, iteration: int) -> void:
	var start := Time.get_ticks_usec()
	var shape: Dictionary = Projected.collect(model)
	var collected := Time.get_ticks_usec()
	if index_it:
		var arrays: Array = shape.mesh.surface_get_arrays(0)
		var surface := SurfaceTool.new()
		surface.create_from_arrays(arrays, Mesh.PRIMITIVE_TRIANGLES)
		surface.index()
		var indexed_arrays: Array = surface.commit_to_arrays()
		var mesh := ArrayMesh.new()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, indexed_arrays)
	var finished := Time.get_ticks_usec()
	if iteration >= 0:
		print("iteration=", iteration, " indexed=", index_it, " collect_us=", collected - start,
			" index_finalize_us=", finished - collected, " total_us=", finished - start)
