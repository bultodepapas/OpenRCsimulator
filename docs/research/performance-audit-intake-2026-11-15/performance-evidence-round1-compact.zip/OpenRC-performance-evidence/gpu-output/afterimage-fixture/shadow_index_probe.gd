extends SceneTree
const Projected := preload("res://render/projected_shadow.gd")

func _initialize() -> void:
	var model := Node3D.new()
	for i in 4:
		var part := MeshInstance3D.new()
		var cube := BoxMesh.new()
		cube.size = Vector3(1.5, 0.25, 0.7)
		part.mesh = cube
		part.position = Vector3(float(i) * 0.5, 0.4 * float(i), -0.2 * float(i))
		part.rotation = Vector3(0.0, 0.1 * float(i), 0.05 * float(i))
		model.add_child(part)
	var baseline: Dictionary = Projected.collect(model)
	var source_arrays: Array = baseline.mesh.surface_get_arrays(0)
	var before: PackedVector3Array = baseline.mesh.get_faces()
	var surface := SurfaceTool.new()
	surface.create_from_arrays(source_arrays, Mesh.PRIMITIVE_TRIANGLES)
	surface.index()
	var indexed_arrays: Array = surface.commit_to_arrays()
	var indexed := ArrayMesh.new()
	indexed.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, indexed_arrays)
	var after: PackedVector3Array = indexed.get_faces()
	var vertex: PackedVector3Array = indexed_arrays[Mesh.ARRAY_VERTEX]
	var indices: PackedInt32Array = indexed_arrays[Mesh.ARRAY_INDEX]
	var failures := 0
	if before != after or before.size() != indices.size():
		failures += 1
	if vertex.size() >= before.size():
		failures += 1
	print("source_face_positions=", before.size(), " indexed_positions=", vertex.size(),
		" indices=", indices.size(), " same_faces=", before == after,
		" before_logical_bytes=", before.size() * 12,
		" after_logical_bytes_32bit_index=", vertex.size() * 12 + indices.size() * 4)
	model.free()
	print("Synthetic shadow-index witness: ", failures, " failures")
	quit(1 if failures else 0)
