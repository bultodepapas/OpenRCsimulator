extends SceneTree
const Stik := preload("res://aircraft/ugly_stik_model.gd")
const Projected := preload("res://render/projected_shadow.gd")

func _initialize() -> void:
	var airplane: Dictionary = Stik.build()
	var model: Node3D = airplane.root
	var baseline: Dictionary = Projected.collect(model)
	var source_arrays: Array = baseline.mesh.surface_get_arrays(0)
	var before: PackedVector3Array = baseline.mesh.get_faces()
	var surface := SurfaceTool.new()
	surface.create_from_arrays(source_arrays, Mesh.PRIMITIVE_TRIANGLES)
	surface.index()
	var indexed_arrays: Array = surface.commit_to_arrays()
	var expanded_tool := SurfaceTool.new()
	expanded_tool.create_from_arrays(indexed_arrays, Mesh.PRIMITIVE_TRIANGLES)
	expanded_tool.deindex()
	var expanded_arrays: Array = expanded_tool.commit_to_arrays()
	var raw_source: PackedVector3Array = source_arrays[Mesh.ARRAY_VERTEX]
	var expanded_source: PackedVector3Array = expanded_arrays[Mesh.ARRAY_VERTEX]
	var indexed := ArrayMesh.new()
	indexed.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, indexed_arrays)
	var after: PackedVector3Array = indexed.get_faces()
	var vertex: PackedVector3Array = indexed_arrays[Mesh.ARRAY_VERTEX]
	var indices: PackedInt32Array = indexed_arrays[Mesh.ARRAY_INDEX]
	var failures := 0
	if before.to_byte_array() != after.to_byte_array() or raw_source.to_byte_array() != expanded_source.to_byte_array() \
			or before.size() != indices.size() or before.size() / 3 != int(baseline.triangles):
		failures += 1
	if vertex.size() >= before.size():
		failures += 1
	print("source_triangles=", baseline.triangles, " source_face_positions=", before.size(),
		" indexed_positions=", vertex.size(), " indices=", indices.size(),
		" same_faces=", before == after, " same_face_bytes=", before.to_byte_array() == after.to_byte_array(),
		" same_pre_get_faces_bytes=", raw_source.to_byte_array() == expanded_source.to_byte_array(),
		" source_aabb=", baseline.bounds, " indexed_aabb=", indexed.get_aabb(),
		" before_logical_bytes=", before.size() * 12,
		" after_logical_bytes_32bit_index=", vertex.size() * 12 + indices.size() * 4)
	model.free()
	print("Stik shadow-index witness: ", failures, " failures")
	quit(1 if failures else 0)
