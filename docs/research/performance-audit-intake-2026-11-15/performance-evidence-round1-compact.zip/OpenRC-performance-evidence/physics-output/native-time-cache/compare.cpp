// Isolated comparison of the actual committed native weather header with a
// stage-time-scratch candidate. No Godot extension or production source edits.
#include "baseline/nk_spatial_weather.hpp"
#include "candidate/nk_spatial_weather.hpp"

#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>

static std::uint64_t rng = 0x1b77952a3674d129ULL;
static std::uint64_t next_u64() {
    rng ^= rng >> 12; rng ^= rng << 25; rng ^= rng >> 27;
    return rng * 2685821657736338717ULL;
}
static double unit() { return static_cast<double>(next_u64() >> 11) * 0x1.0p-53; }
static double within(double a, double b) { return a + (b - a) * unit(); }
static std::uint64_t bits(double x) {
    std::uint64_t result; std::memcpy(&result, &x, sizeof(result)); return result;
}

template <typename Model> static void setup(Model &m, int count, bool thermal, bool active) {
    m.half_extent_north_m = 10000.; m.half_extent_east_m = 10000.;
    m.max_height_agl_m = 1000.; m.ground_extension_m = 5.;
    m.time_horizon_s = 100000.; m.epoch_offset_s = 5.75;
    m.reference_speed = 3.; m.roughness_length = 0.1; m.displacement_height = 0.;
    m.wall_height = 0.5; m.surface_top = 80.; m.free_air_join_height = 20.;
    m.direction_cosine = 0.6; m.direction_sine = 0.8;
    m.log_denominator = std::log(100.);
    m.wall_scale = std::log(5.) / std::log(100.);
    m.wall_scale_slope = 1. / (0.5 * std::log(100.));
    m.free_air_ned = {1.5, -2.2, 0.};
    m.gust_transition_height = 8.; m.gust_max_duration = 17.;
    m.gust_values = {0., 5., 1.2, -0.7, 10., 17., -2.1, 1.5, 10., 3., .1, .4};
    m.turbulence_rms = active ? 0.3 : 0.0;
    for (int i = 0; i < count; ++i) {
        // Deterministic, finite synthetic modes: nine native coefficients each.
        double d = static_cast<double>(i + 1);
        m.modes.insert(m.modes.end(), {0.002 * d, -0.003 / d, 0.04 + 0.001*d,
            0.6, 0.8, 0.05 + 0.0003*d, 0.02 / (1.+d), 0.11*d, -0.17 + 0.009*d});
    }
    m.has_thermal = thermal;
    auto &t = m.thermal;
    t.half_extent_north_m = 10000.; t.half_extent_east_m = 10000.;
    t.max_height_agl_m = 1000.; t.time_horizon_s = 100000.; t.epoch_offset_s = 5.75;
    typename decltype(t.cells)::value_type cell;
    cell.birth_s = 0.; cell.duration_s = 200.; cell.center_north_m = 0.;
    cell.center_east_m = 0.; cell.drift_north_mps = 0.1; cell.drift_east_mps = -0.2;
    cell.radius_m = 120.; cell.top_agl_m = 500.; cell.peak_updraft_mps = 1.2;
    t.cells.push_back(cell);
}

struct Counts { int checks = 0; int failures = 0; int ok = 0; int rejected = 0; } counts;

static bool match(const nk::SpatialWeather &reference, const nk_candidate::SpatialWeather &candidate,
                  const std::array<double, 3> &position, double time,
                  nk_candidate::StageTimeScratch *scratch, const char *label, bool expect_match = true) {
    nk::R original_position[3] = {position[0], position[1], position[2]};
    nk_candidate::R modified_position[3] = {position[0], position[1], position[2]};
    const auto original = nk::spatial_weather_sample(reference, original_position, time);
    const auto modified = nk_candidate::spatial_weather_sample(candidate, modified_position, time, scratch);
    bool same = original.ok == modified.ok;
    for (int i = 0; i < 3; ++i) same = same && bits(original.wind_ned[i].v) == bits(modified.wind_ned[i].v);
    ++counts.checks;
    if (original.ok) ++counts.ok; else ++counts.rejected;
    if (same != expect_match) {
        ++counts.failures;
        std::fprintf(stderr, "FAIL %s t=%.17g position=(%.17g, %.17g, %.17g) baseline_ok=%d candidate_ok=%d\n",
                     label, time, position[0], position[1], position[2], original.ok, modified.ok);
    }
    return same;
}

int main() {
    const double inf = std::numeric_limits<double>::infinity();
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const double tiny = std::numeric_limits<double>::denorm_min();
    for (int n : {8, 24, 64, 65}) {
        for (bool thermal : {false, true}) for (bool active : {false, true}) {
            nk::SpatialWeather a; nk_candidate::SpatialWeather b;
            setup(a, n, thermal, active); setup(b, n, thermal, active);
            for (int stage = 0; stage < 160; ++stage) {
                const double t = stage % 8 == 0 ? 0. : (stage % 8 == 1 ? 194.25 : within(0., 180.));
                const std::array<double, 3> datum{within(-70.,70.), within(-70.,70.), -within(.01,150.)};
                nk_candidate::StageTimeScratch scratch;
                // Rejection or below-ground first must not prepare from an invalid point.
                match(a,b,{10001.,0.,-1.},t,&scratch,"north-domain-first");
                match(a,b,{0.,0.,0.},t,&scratch,"ground-first");
                for (int station = 0; station < 11; ++station) {
                    std::array<double,3> p{datum[0]+within(-2.,2.), datum[1]+within(-2.,2.),
                                           datum[2]+within(-0.2,0.2)};
                    match(a,b,p,t,&scratch,"valid-stations");
                }
                // Time mismatches and return to the original time use the slow path safely.
                match(a,b,datum,std::nextafter(t, inf),&scratch,"different-time");
                match(a,b,datum,t,&scratch,"return-to-stage-time");
            }
            nk_candidate::StageTimeScratch scratch;
            for (const auto &p : std::array<std::array<double,3>, 16>{{
                {0.,0.,-0.0}, {0.,0.,tiny}, {0.,0.,-tiny}, {0.,0.,5.},
                {0.,0.,std::nextafter(5.,inf)}, {0.,0.,-1000.},
                {0.,0.,std::nextafter(-1000.,-inf)}, {10000.,0.,-1.},
                {std::nextafter(10000.,inf),0.,-1.}, {0.,-10000.,-1.},
                {0.,std::nextafter(-10000.,-inf),-1.}, {nan,0.,-1.},
                {inf,0.,-1.}, {0.,nan,-1.}, {0.,0.,nan}, {0.,0.,-inf}
            }}) match(a,b,p,0.,&scratch,"position-edges");
            for (double t : {0., -0., tiny, -tiny, 99994.25, std::nextafter(99994.25,inf),
                             100000., std::nextafter(100000.,inf), inf, -inf, nan})
                match(a,b,{1.,2.,-3.},t,&scratch,"time-edges");
            // A malformed mode array must retain the source's rejection behavior.
            a.modes.pop_back(); b.modes.pop_back();
            nk_candidate::StageTimeScratch malformed_scratch;
            match(a,b,{0.,0.,-1.},1.,&malformed_scratch,"malformed-modes");
        }
    }
    {
        nk::SpatialWeather a; nk_candidate::SpatialWeather b;
        setup(a,24,true,true); setup(b,24,true,true);
        nk_candidate::StageTimeScratch scratch;
        match(a,b,{1.,2.,-3.},23.,&scratch,"mutation-baseline");
        a.modes[8] = a.modes[8].v + 0.375; b.modes[8] = b.modes[8].v + 0.375;
        match(a,b,{1.,2.,-3.},23.,&scratch,"intentional-stale-scratch-negative-control",false);
        nk_candidate::StageTimeScratch fresh;
        match(a,b,{1.,2.,-3.},23.,&fresh,"reset-after-mutation");
        nk_candidate::SpatialWeather different; setup(different,24,true,true);
        different.modes[8] = different.modes[8].v + 0.375;
        match(a,different,{1.,2.,-3.},23.,&fresh,"different-model-identity-falls-back");
        match(a,b,{1.,2.,-3.},23.,&fresh,"repeat-fresh");
    }
    std::printf("checks=%d failures=%d valid=%d rejected=%d\n", counts.checks, counts.failures, counts.ok, counts.rejected);
    return counts.failures ? 1 : 0;
}
