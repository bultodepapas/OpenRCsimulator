#!/usr/bin/env python3
"""Create an isolated candidate from the pinned, unmodified NK-3 headers."""
from pathlib import Path
import hashlib
import shutil

here = Path(__file__).resolve().parent
source = here.parents[1] / "repository" / "research" / "native-kernel" / "src"
names = ("nk_math.hpp", "nk_weather.hpp", "nk_spatial_weather.hpp")
for directory in (here / "baseline", here / "candidate"):
    directory.mkdir(exist_ok=True)
    for name in names:
        shutil.copy2(source / name, directory / name)

for name in names:
    path = here / "candidate" / name
    contents = path.read_text()
    assert contents.count("namespace nk {") == 1
    path.write_text(contents.replace("namespace nk {", "namespace nk_candidate {"))

path = here / "candidate" / "nk_spatial_weather.hpp"
contents = path.read_text()

def replace_once(old, new):
    global contents
    assert contents.count(old) == 1, old
    contents = contents.replace(old, new)

replace_once("struct SpatialWeatherSample {", """// Scratch proof only. Construct a fresh instance for each stage.
// A pointer is an identity guard, not a content-mutation detector.
struct StageTimeScratch {
    const SpatialWeather *owner = nullptr;
    std::uint64_t epoch_bits = 0;
    std::size_t modes_size = 0;
    bool ready = false;
    std::array<R, 64> reduced_temporal{};
};

struct SpatialWeatherSample {""")
replace_once("""inline std::array<R, 3> spatial_turbulence_wind(const SpatialWeather &model, R north_m, R east_m,
		R height_agl, R epoch_time) {""", """inline std::array<R, 3> spatial_turbulence_wind(const SpatialWeather &model, R north_m, R east_m,
		R height_agl, R epoch_time, StageTimeScratch *scratch = nullptr) {""")
replace_once("""\tfor (std::size_t offset = 0; offset < model.modes.size(); offset += kSpatialWeatherModeSize) {
\t\tconst R k_north = model.modes[offset];""", """\tstd::uint64_t epoch_bits;
\tstd::memcpy(&epoch_bits, &epoch_time.v, sizeof(epoch_bits));
\tconst bool eligible = scratch != nullptr && model.modes.size() % kSpatialWeatherModeSize == 0 &&
\t\t\tmodel.modes.size() / kSpatialWeatherModeSize <= scratch->reduced_temporal.size();
\tconst bool reuse = eligible && scratch->ready && scratch->owner == &model &&
\t\t\tscratch->epoch_bits == epoch_bits && scratch->modes_size == model.modes.size();
\tconst bool record = eligible && !scratch->ready;
\tfor (std::size_t offset = 0; offset < model.modes.size(); offset += kSpatialWeatherModeSize) {
\t\tconst R k_north = model.modes[offset];""")
replace_once("""\t\tconst R temporal_phase = omega * epoch_time;
\t\tconst R phase = weather_fposmod(weather_fposmod(spatial_phase, kSpatialWeatherTau) +
\t\t\t\tweather_fposmod(temporal_phase, kSpatialWeatherTau), kSpatialWeatherTau);""", """\t\tR reduced_time;
\t\tif (reuse) {
\t\t\treduced_time = scratch->reduced_temporal[offset / kSpatialWeatherModeSize];
\t\t} else {
\t\t\tconst R temporal_phase = omega * epoch_time;
\t\t\treduced_time = weather_fposmod(temporal_phase, kSpatialWeatherTau);
\t\t\tif (record) scratch->reduced_temporal[offset / kSpatialWeatherModeSize] = reduced_time;
\t\t}
\t\tconst R phase = weather_fposmod(weather_fposmod(spatial_phase, kSpatialWeatherTau) +
\t\t\t\treduced_time, kSpatialWeatherTau);""")
replace_once("""\treturn {result_north, result_east, result_down};
}

// wind_thermal_field.gd""", """\tif (record) {
\t\tscratch->owner = &model;
\t\tscratch->epoch_bits = epoch_bits;
\t\tscratch->modes_size = model.modes.size();
\t\tscratch->ready = true;
\t}
\treturn {result_north, result_east, result_down};
}

// wind_thermal_field.gd""")
replace_once("""inline SpatialWeatherSample spatial_weather_sample(const SpatialWeather &model, const R *position_ned, R stage_time) {""", """inline SpatialWeatherSample spatial_weather_sample(const SpatialWeather &model, const R *position_ned, R stage_time,
\t\tStageTimeScratch *scratch = nullptr) {""")
replace_once("""const std::array<R, 3> turbulent = spatial_turbulence_wind(model, position_ned[0], position_ned[1], height_agl, epoch_time);""", """const std::array<R, 3> turbulent = spatial_turbulence_wind(model, position_ned[0], position_ned[1], height_agl, epoch_time, scratch);""")
path.write_text(contents)

for name in names:
    digest = hashlib.sha256((source / name).read_bytes()).hexdigest()
    print(f"{digest}  {name}")
