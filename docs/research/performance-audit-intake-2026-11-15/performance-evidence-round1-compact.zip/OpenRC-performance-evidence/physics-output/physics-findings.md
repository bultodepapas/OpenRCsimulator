# Physics performance review: source-bound candidates

Baseline: `bultodepapas/OpenRCsimulator` commit `8fb825a96dbc39fbbf99c1056ba643c9cde49b5d`. No production files modified. These are candidates, not measured speedups.

## Same-stage temporal phase preparation

The source's spatial wind mode computes, for each mode `i` and query point `(N,E,z)` at stage time `t`:

```
epoch = t + epoch_offset
spatial_i = kN_i * N + kE_i * E + phase_i
temporal_i = omega_i * epoch
phase_i = fposmod(fposmod(spatial_i, TAU) + fposmod(temporal_i, TAU), TAU)
```

The spatial and final phase, four trigonometric calls, height-dependent wall terms, and ordered vector reductions still depend on the query point. Only the binary64 value `fposmod(omega_i * epoch, TAU)` may be produced once and shared by subsequent queries for the same immutable provider and exactly matching stage epoch. Do not use angle-addition identities, reorder products/reductions, approximate sin/cos, cache full winds, interpolate between stages, or reuse state-dependent values.

The repetition occurs in `app/physics/wind_spatial_field.gd:316-353` and its native counterpart `research/native-kernel/src/nk_spatial_weather.hpp:212-253`. `FlightSession.air_data` calls `WindFlow.stage_air` at the real stage time (`app/sim/flight_session.gd:662-671`); `_sample` queries the datum then physical stations sequentially (`app/physics/wind_aircraft_flow.gd:284-325`). The equivalent native calls are `nk_stage.hpp:283-288` and `nk_wake_spatial_flow.hpp:94,105-123`; optional wake and gear points can add queries. A conventional, fully sampled Stik-like stage has one datum plus six wing stations, two tail stations, and a powered-device station: ten queries; a tailless model omits the horizontal tail. This is conditional on all requested points being valid and above the flat ground, nonzero mode RMS, and the route actually being selected.

For M modes, Q qualifying queries per independently owned group and S groups per tick, the baseline performs `S*Q*M` temporal products and remainders; a lazy scratch value for each group performs `S*M` each, saving `M*(Q-1)*S` each per tick. With Q=10 and S=4, 8/24/64 modes give 69,120/207,360/552,960 fewer products and the same number of remainders per simulated second at 240 accepted ticks/s. With 24 modes, a fifth 10-query group would give 259,200 of each per simulated second **only if** that separate caller receives its own correct context. The checked reference workload's diagnostic counts five groups' worth of calls, including pre-step work; that count does not automatically authorize sharing or establish that all five groups use the candidate. Preserve separate pre-step and RK ownership. Event trials, substeps, refusals, ground extension, other callers and unselected weather change the count. These are source-level operation counts, not CPU timings or FPS; the other phase remainders and all trig calls remain. No profiling has shown how much, if any, of this work the target compiler or VM already removes, or how scratch allocation and dispatch would offset it.

The candidate in `native-time-cache/` copies the three pinned native headers and modifies the copied spatial header only. It uses a 64-entry `std::array` (512 bytes of element storage, plus identity and metadata) in a fresh per-stage context, fills entries lazily on the first valid, above-ground query, preserves the original multiplication and `weather_fposmod`, and falls back to the original calculation for a different provider, epoch or oversized layout. Native decode admits 8–64 modes (`nk_weather_binding.hpp:244-247`). The live `StageWindContext` is stack-local in each `stage_evaluate`; never let its provider pointer escape. Preview handoff currently explicitly clears that pointer (`nk_stage.hpp:424-427,453-457`) and the retained `OpenRCNativePointSampler` rebinds to its own weather owner; preserve that behavior.

The scratch identity check is not a mutation detector: the owner must be immutable for the entire context. The supplied negative control deliberately mutates an existing model in place at the same time and detects changed output. Construct new scratch at every stage, reset, accepted configuration change, retry, replay, or rebind; never make this a session/global cache. Test in-place model mutation through the production configuration guard. For GDScript, a similar ephemeral sampler must preserve `Environment.wind_world` and custom weather/provider override dispatch. `app/tests/test_wind_aircraft_flow.gd` contains overridden synthetic providers and checks call order/count. Using an explicit opt-in capability with the current generic path as fallback is safer than invoking private provider methods unconditionally. Avoid assuming that a detached sampler is a cross-stage cache.

### Isolated component comparison

`native-time-cache/build_fixture.py` constructs untouched baseline and candidate copies. `compare.cpp` runs both source-level implementations side by side; compile with `g++ -std=c++17 -O2 -fno-fast-math -ffp-contract=off -Wall -Wextra -pedantic compare.cpp -o compare`, then `./compare`. On Linux x86-64, the final run produced `checks=38853 failures=0 valid=36029 rejected=2824`. This includes synthetic 8/24/64 modes, a 65-mode fallback beyond production admission, active/inactive turbulence, gusts and thermal cells, valid and invalid domains, nonfinite values, signed zero, stage-time changes, a different-provider fallback, and an expected stale-mutation mismatch. The numbers include the negative control; the fixture exercises copied component headers, not installed native ownership, complete stage outputs, complete sessions, or physical validation. Do not treat it as the required production oracle.

Before promotion, use the existing NK-3 component/stage/trajectory oracles and full spatial-weather tests with exact component bytes, refusal order, rollback, checkpoint and restore, mutation and stale-source controls, preview and wake sampler lifetime, all mode counts and point counts, zero RMS, thermal/gust combinations, substeps/events and selected actual-aircraft trajectories. Then run the existing full-session benchmark with isolated, matched sources on a quiet target host. NK-3's current build and `nk_math.hpp` are explicitly Linux x86-64, so this native prototype does not qualify Apple Silicon; its reference-GDScript equivalent would require separate implementation and tests.

Audit classification: new stage-local time-factor reuse found by source inspection; distinct from completed A22 WOPT-01 (thermal sine) and WOPT-02 (overlay datum), completed A6 O4 (pre-step Air reuse), pending A6 O5 (geometry preparation), and pending M09 (duplicate wing-flow passes). A25/A29 concern validation and statistics, not this runtime time factor.

### Actual reference-session baseline

The repository's `app/tests/bench_spatial_wind.gd --full-session` was run without changes to the simulation or aircraft data, first with `--verify-only`, then in its shortest allowed timed configuration. The isolated project copy retains the pinned 240 Hz setting; its recorded `reference-project.diff` removes only startup/main scene, fonts autoload, locale list, and editor plugins because the sparse checkout lacked those presentation resources. The original checked import failure is retained. Fifteen individually retrieved pinned visual blobs were required to parse transitive scenery scripts; no law or collision script was substituted. This source-copy fixture is not a packaged-app run.

Linux x86-64, AMD EPYC 9V74, pinned Godot `4.8.beta2.official.cafc17a19`, GDScript reference backend, headless, aircraft `jensen-das-ugly-stik-60`, solver SHA-256 `b98411b3c131e0a91bd7e2793799bf2f4d69264e1f29b058084e623ab20a1581`:

| Case | Weather | Batch means in µs per tick | Median | Untimed first-tick queries; 480-tick total |
| --- | --- | --- | ---: | ---: |
| `legacy-v4-steady` | 3 m/s from 270° | 679.610, 618.081, 581.206 | 618.081 | 5; 2,400 |
| `spatial-v5-modes-24` | 3 m/s reference, 0.3 m/s turbulence RMS | 4,555.629, 5,408.696, 4,075.217 | 4,555.629 | 50; 24,000 |

Every case completed three batches of 480 measured ticks, 240 warmup ticks per batch and nine out of nine reset checks. Final hashes were identical across all three batches and matched the independent verification-only run. The separate untimed counting replay gives the first tick's count and the total over 480 ticks; the latter averages 5/50, but the fixture does not record each tick's query count. Values are three batch averages on a shared host, not per-tick percentiles. The scenarios have different weather laws and are not an A/B optimization test. The 4,555.629 µs median happens to exceed a 240 Hz period of about 4,166.667 µs, but one batch was below and the headless, observer-free measurement does not establish sustained real-time performance, frame rate, Apple Silicon behavior, or timing for the unintegrated candidate. Its effect on that measured cost is unmeasured. Complete results and configuration are in `wind-timing.json`, with `wind-verify.json` and checked-runner receipts under `checks/`.

## Native spatial stage: overwritten air calculation

`research/native-kernel/src/nk_stage.hpp:273-296` first samples **legacy** `weather_wind` and calls `air_compute`. When `m.spatial_weather` is true, this `Air` object is always replaced: `spatial_flow_sample` success uses `spatial_flow.air`, failure uses a newly calculated `air_compute` with three NaNs. Move the initial legacy weather/air work inside the `!m.spatial_weather` branch; leave the spatial branch, invalid datum, stage order visible to callers, and `weather_air` calculation intact. Both removed functions are pure in the examined native implementation. Current `air_compute` (`nk_aero.hpp:115-138`) uses two square roots and two `atan2` calls per call. This would avoid one discarded legacy weather query and one discarded Air calculation per qualifying native spatial stage, not an actual spatial query. With four ordinary stages the source-level count is 960 discarded Air calculations per simulated second. No timing or output-parity experiment has yet been performed on this independent candidate.

Sketch only:

```
rho = existing weather_air result
if spatial:
    flow = spatial_flow_sample(...)
    air = flow.air if flow.ok else air_compute(state, [NaN, NaN, NaN], rho)
else:
    wind = existing legacy/no-weather branch
    air = air_compute(state, wind, rho)
```

Check reference/native stage arrays including signed zero and malformed inputs, invalid spatial datum/station, fallback, finite-fuel preview and retained sampler, wake, gear, reset/rollback, and full accepted trajectories. Preserve normal error behavior; no source mutation or qualified runtime gain is claimed. This is distinct from M09's repeated wing-flow computation and WOPT-02's accepted overlay query. Again it is restricted to the existing Linux x86-64 native route until other backends are separately qualified.

## External method references

- NASA's Runge–Kutta appendix describes the four evaluations and distinct midpoint/end trial states: https://ntrs.nasa.gov/api/citations/20150014965/downloads/20150014965.pdf
- Godot's precision reference distinguishes 64-bit GDScript scalars from default single-precision vector components: https://docs.godotengine.org/en/stable/tutorials/physics/large_world_coordinates.html
- Godot's optimization guide advises profiling and verifying actual bottlenecks; component work is not a frame-rate claim: https://docs.godotengine.org/en/stable/tutorials/performance/cpu_optimization.html
