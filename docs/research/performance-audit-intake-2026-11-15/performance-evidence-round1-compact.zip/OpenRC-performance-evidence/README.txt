OPENRC SIMULATOR — PERFORMANCE REVIEW EVIDENCE
9 November 2026

START HERE

Open OpenRC-performance-review.html for the complete report. The patch is
OpenRC-performance.patch. patch-manifest.json identifies its five files, tested
source hashes, baseline, and successful applicability checks against both
8fb825a96dbc39fbbf99c1056ba643c9cde49b5d and
f7b58bd830d4a5eb78901d00514ce1fc18286477.

The local implementation changes controller-button resolution and EngineVoice
interpolation only. The native wind cache and GPU probes are unpromoted experiments.
No remote branch or pull request was created, and nothing was merged.

EVIDENCE MAP

input-experiment/benchmark-results.json
  Complete resolver timing: airplane/helicopter capabilities, AUX conflicts,
  explicit/no-equipment/radio controls. Nine alternating pairs per case.
input-experiment/capability-benchmark-results.json
  Separate follow-up timing with two, three, and four automatic candidates.
  Same source, methodology and engine; do not combine separate runs into one
  measured event-handler latency.
input-experiment/project/
  Runnable minimal fixture, unchanged pinned baseline, tested candidate,
  differential comparison, benchmarks and focused tests.
input-experiment/source-manifest.json
  Original dependency identity; final candidate identities are in patch-manifest.

cpu-output/voice-abba-measured.json
  Twenty warm synthesis trials in five ABBA/BAAB rounds. Absolute saving is about
  1.5 milliseconds per generated audio second per active voice on this host.
cpu-output/voice-project/
  Exact baseline/candidate, comparison harness and timing scripts.
cpu-output/integration-sources/
  Tested application voice/audio/sound source and test snapshots with fixture
  project configuration; supporting full-app sources come from the pinned repo.
cpu-output/checks/
  Includes 868-check guarded comparison, 86-check permanent voice suite and
  147-check audio integration. Also retains expected-error, setup/harness failures,
  and baseline/candidate identical stale engine-sound catalog failures.

physics-output/wind-timing.json and wind-verify.json
  Real unchanged GDScript FlightSession/Simulation.step benchmark. Three 480-tick
  batches and 240 warmup ticks per batch for each of two different wind scenarios.
  Batch statistics are not per-tick or frame-time percentiles. This does not time
  the native prototype or the patched input/audio whole flight.
physics-output/reference-project.diff
  Exact fixture-only removal of startup/font/locale/editor-plugin settings.
physics-output/retrieved-assets.sha256
  Fifteen pinned presentation dependencies restored for transitive parsing.
physics-output/native-time-cache/
  Copied pinned headers and unintegrated candidate; compare.cpp is a component
  experiment. component-recheck.json retains compiler flags, source hashes and
  stdout (38,853 checks, zero unexpected failures). A same-owner mutation is an
  intentional negative control, not permission to cache mutable providers.

gpu-output/afterimage-fixture/
  Copied production source and witness scripts. Large original binary model and
  import caches are omitted; recover those from the pinned repository before
  model-builder checks. No GPU ran in this review. The source-level visibility
  witness does not measure a screen-copy or frame-time saving.
gpu-output/checks/
  Raw afterimage, exact raw-position/deindex and shadow-construction receipts.
  Logical geometry bytes are not RSS/VRAM. Synchronous indexing was rejected for
  its measured approximately 100 ms extra preparation cost.

The specialist reports retain detailed source anchors and experimental context.
The main HTML report incorporates their final independent corrections and is the
authoritative current disposition. The raw checked receipts remain unchanged.

REPRODUCE THE PATCH'S FOCUSED APPLICATION TESTS

Use an existing full checkout at the pinned revision, with original data/assets.
From the repository root:

  git apply --check /absolute/path/OpenRC-performance.patch
  git apply /absolute/path/OpenRC-performance.patch
  godot_exe="$(app/get-godot.sh)"

First import through the checked runner using the full original project. Then run
each of these scripts through tools/godot/run_checked.py with --headless,
--path app, --audio-driver Dummy, and --script res://tests/<name>:

  test_controller_actions.gd
  test_controller_extended_actions.gd
  test_controller_binding_audit.gd
  test_controller_profile.gd
  test_controller_conditioning.gd
  test_controller_button_index.gd
  test_engine_voice.gd
  test_engine_audio.gd
  test_engine_sound.gd

Example (test script timeout and outputs are explicit):

  python3 tools/godot/run_checked.py --label controller-button-index \
    --timeout 90 --out-dir tmp/performance-review-checks \
    --require-text '0 failed' -- "$godot_exe" --headless --path app \
    --audio-driver Dummy --script res://tests/test_controller_button_index.gd

At the reviewed base, engine_sound has a known expected-catalog-list mismatch:
stik-electric-6s is present in the catalog but absent from the test's expectation.
The same 27-check/one-failure result occurs before and after the voice change.
Do not alter the expectation merely to label this review's results green. The
separate GitHub CI generator-roster failure is documented in repository-state.

MINIMAL CONTROLLER AND VOICE FIXTURES

The input-experiment/project and cpu-output/voice-project directories contain
their required text dependencies. Import a fixture with the same pinned binary
before running it. Use the checked runner for both import and scripts; an exit-zero
engine process with parse/runtime errors is a failure.

  ... --path /absolute/path/input-experiment/project --import
  ... --path /absolute/path/input-experiment/project --script res://compare_actions.gd
  ... --path /absolute/path/input-experiment/project --script res://bench_actions.gd
  ... --path /absolute/path/input-experiment/project --script res://bench_action_capabilities.gd

  ... --path /absolute/path/cpu-output/voice-project --import
  ... --path /absolute/path/cpu-output/voice-project --script res://test_parity.gd
  ... --path /absolute/path/cpu-output/voice-project --script res://bench_abba.gd

Use each recorded checked report's complete command for extra user arguments;
commands.json indexes them. Change only local path prefixes when relocating.
The invalid_phase_witness.gd fixture intentionally emits script errors and must
be run as an expected-failure diagnostic, separately from positive checks.

NATIVE COMPONENT EXPERIMENT

Within physics-output/native-time-cache:

  g++ -std=c++17 -O2 -fno-fast-math -ffp-contract=off \
    -Wall -Wextra -pedantic compare.cpp -o compare
  ./compare

This compiles the copied components, not a Godot extension. A native production
candidate still requires the repository's source-bound component/stage/trajectory
oracles, mutation/refusal tests and full-session comparison. Do not install this
header prototype as if those gates had passed.

REFERENCE PHYSICS BASELINE

Use app/tests/bench_spatial_wind.gd from the exact source revision, first with
--full-session --verify-only, then with --full-session and the same recorded
configuration. The full argument lists and fixture paths are in the checked
reports and commands.json. Use legacy-v4-steady and spatial-v5-modes-24 for the
reported Stik comparison, three samples, 480 workload ticks, 240 warmup ticks.
These are different weather laws and must not be labeled baseline/candidate
optimization variants. Preserve exact initial state, source identity, resets,
accepted-tick counters and the separate query-count replay.

MEASUREMENT DISCIPLINE

Run one import/compiler/test/benchmark workload at a time. Preserve warmups and
alternating order. Record exact engine, build, source, host, backend and fixture
configuration. Raw batch means cannot supply individual-tick or frame percentiles.
The included Linux container data do not establish GPU, physical-controller,
display latency, target-Mac, packaged-release, audible-quality or sustained FPS
results. Follow the HTML report's 1080p-first target campaign for those questions.

CONTENTS AND INTEGRITY

evidence-index.json lists every retained checked verdict, including failures.
commands.json contains their original exact commands and working directories.
archive-manifest.json hashes the bundled files. Files omitted for size or runtime
specificity include the git checkout, Godot executable, compiled native comparator,
import caches, and large original assets. Source paths/object IDs and fixture
asset records allow them to be restored. No secret or authentication material is
required to reproduce these public-repository experiments.
