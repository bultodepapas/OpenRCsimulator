extends SceneTree

const Baseline := preload("res://baseline.gd")
const Candidate := preload("res://candidate.gd")
const BLOCKS := 300
const FRAMES := 368
const ROUNDS := 5
const MAX_RPM := 11149.0
const TARGETS := [2800.0, 5100.0, 8000.0, 11149.0, 8400.0, 4200.0, 0.0, 5100.0]

func measure(voice: Object, blocks: int) -> Dictionary:
	voice.reset(5100.0, MAX_RPM)
	var before := Time.get_ticks_usec()
	var frames_ok := true
	for i in blocks:
		var target: float = TARGETS[(i / 38) % TARGETS.size()]
		var out: PackedVector2Array = voice.render(target, MAX_RPM, FRAMES)
		frames_ok = frames_ok and out.size() == FRAMES
	var elapsed := Time.get_ticks_usec() - before
	return {elapsed_usec = elapsed, valid = frames_ok, final_state = [voice.phase, voice.frequency, voice.amplitude]}

func _initialize() -> void:
	var voices: Array = [Baseline.new(), Candidate.new()]
	for voice: Object in voices:
		voice.reset(5100.0, MAX_RPM)
		voice.render(5100.0, MAX_RPM, 2048)
	var smoke: bool = "--smoke" in OS.get_cmdline_user_args()
	var blocks: int = 2 if smoke else BLOCKS
	var rounds: int = 1 if smoke else ROUNDS
	var trials: Array[Dictionary] = []
	for round_index in rounds:
		var order: Array = [0, 1, 1, 0] if round_index % 2 == 0 else [1, 0, 0, 1]
		for position in order.size():
			var variant: int = order[position]
			var trial: Dictionary = measure(voices[variant], blocks)
			trial.round = round_index
			trial.position = position
			trial.variant = "baseline" if variant == 0 else "candidate"
			trials.append(trial)
	var report := {format = "openrc-voice-abba-v1", engine = Engine.get_version_info().string,
		operating_system = OS.get_name(), blocks_per_trial = blocks, frames_per_block = FRAMES,
		rate_hz = 22050, rounds = rounds, smoke = smoke, targets_rpm = TARGETS, max_rpm = MAX_RPM,
		note = "Warm render component only; trials alternate ABBA/BAAB. Includes output allocation and GDScript dispatch. Not playback, frame, or device latency.",
		trials = trials}
	var target_path := ""
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			target_path = argument.trim_prefix("--out=")
	if target_path.is_empty():
		printerr("Missing --out= argument")
		quit(1)
		return
	var out := FileAccess.open(target_path, FileAccess.WRITE)
	if out == null:
		printerr("Could not open benchmark receipt")
		quit(1)
		return
	out.store_string(JSON.stringify(report, "  ") + "\n")
	out.close()
	for trial: Dictionary in trials:
		if not trial.valid:
			printerr("Invalid output length")
			quit(1)
			return
	print("VOICE ABBA COMPLETE: %d trials" % trials.size())
	quit(0)
