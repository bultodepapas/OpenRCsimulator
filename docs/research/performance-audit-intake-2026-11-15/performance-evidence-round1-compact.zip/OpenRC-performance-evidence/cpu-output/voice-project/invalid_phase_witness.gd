extends SceneTree

const Baseline := preload("res://baseline.gd")
const Candidate := preload("res://candidate.gd")

func _initialize() -> void:
	var left := Baseline.new()
	var right := Candidate.new()
	left.reset(1200.0, 12000.0)
	right.reset(1200.0, 12000.0)
	left.phase = 1.0
	right.phase = 1.0
	# Both calls deliberately exercise an invalid mutable state. Each original
	# helper logs one out-of-range script error, then the outer render continues.
	var a: PackedVector2Array = left.render(1200.0, 12000.0, 4)
	var b: PackedVector2Array = right.render(1200.0, 12000.0, 4)
	var state_a := PackedFloat64Array([left.phase, left.frequency, left.amplitude]).to_byte_array()
	var state_b := PackedFloat64Array([right.phase, right.frequency, right.amplitude]).to_byte_array()
	var matched := a.to_byte_array() == b.to_byte_array() and state_a == state_b
	print("EXPECTED INVALID-PHASE WITNESS: matched=%s baseline_frames=%d candidate_frames=%d" % [str(matched), a.size(), b.size()])
	quit(0 if matched else 1)
