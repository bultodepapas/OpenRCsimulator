extends SceneTree

const Baseline := preload("res://baseline.gd")
const Candidate := preload("res://candidate.gd")
const BaselineAdapter := preload("res://baseline_adapter.gd")
const CandidateAdapter := preload("res://candidate_adapter.gd")
const RATE := 22050.0

var checks := 0
var failures := 0
var frames_compared := 0
var blocks_compared := 0

class SimStub extends Node:
	signal stepped(tick: int, time_s: float, state: PackedFloat64Array, loads: PackedFloat64Array, inputs: PackedFloat64Array, aux: PackedFloat64Array)
	signal paused_changed(paused: bool)
	var paused := false
	var aux := PackedFloat64Array([5400.0])
	var tick := 25
	func time() -> float:
		return float(tick) / 240.0

func check(label: String, condition: bool) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: " + label)

func state_bytes(voice: Object) -> PackedByteArray:
	return PackedFloat64Array([voice.phase, voice.frequency, voice.amplitude]).to_byte_array()

func compare_block(label: String, left: Object, right: Object, rpm: float, max_rpm: float, frames: int) -> void:
	var a: PackedVector2Array = left.render(rpm, max_rpm, frames)
	var b: PackedVector2Array = right.render(rpm, max_rpm, frames)
	blocks_compared += 1
	frames_compared += a.size()
	check(label + " PCM", a.to_byte_array() == b.to_byte_array())
	check(label + " state", state_bytes(left) == state_bytes(right))

func compare_scenario(label: String, initial_rpm: float, initial_max: float, operations: Array[Dictionary]) -> void:
	var left := Baseline.new()
	var right := Candidate.new()
	left.reset(initial_rpm, initial_max)
	right.reset(initial_rpm, initial_max)
	check(label + " reset state", state_bytes(left) == state_bytes(right))
	for i in operations.size():
		var item: Dictionary = operations[i]
		match str(item.op):
			"render":
				compare_block("%s block %d" % [label, i], left, right, float(item.rpm), float(item.max_rpm), int(item.frames))
			"reset":
				left.reset(float(item.rpm), float(item.max_rpm))
				right.reset(float(item.rpm), float(item.max_rpm))
				check("%s reset %d" % [label, i], state_bytes(left) == state_bytes(right))
			"phase":
				left.phase = float(item.value)
				right.phase = float(item.value)
				check("%s phase %d" % [label, i], state_bytes(left) == state_bytes(right))
			"frequency":
				left.frequency = float(item.value)
				right.frequency = float(item.value)
				check("%s frequency %d" % [label, i], state_bytes(left) == state_bytes(right))
			"pause":
				var before: PackedByteArray = state_bytes(left)
				# The adapter renders no samples while paused. State must remain identical
				# and the first resumed block is compared by the next render operation.
				check("%s simulated pause %d" % [label, i], before == state_bytes(right))

func direct_checks() -> void:
	compare_scenario("partition and transition", 2800.0, 11149.0, [
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = 1},
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = 512},
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = 37},
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = 1000},
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = 243},
		{op = "render", rpm = 2000.0, max_rpm = 11149.0, frames = 2048},
		{op = "pause"},
		{op = "render", rpm = 0.0, max_rpm = 11149.0, frames = 22050},
		{op = "reset", rpm = 5400.0, max_rpm = 11149.0},
		{op = "render", rpm = 5400.0, max_rpm = 11149.0, frames = 1025},
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = 0},
		{op = "render", rpm = 8000.0, max_rpm = 11149.0, frames = -1},
	])
	compare_scenario("silence malformed and high finite rpm", 0.0, 12000.0, [
		{op = "render", rpm = 0.0, max_rpm = 12000.0, frames = 2048},
		{op = "render", rpm = NAN, max_rpm = 12000.0, frames = 32},
		{op = "render", rpm = INF, max_rpm = 12000.0, frames = 32},
		{op = "render", rpm = -INF, max_rpm = 12000.0, frames = 32},
		{op = "render", rpm = -100.0, max_rpm = 12000.0, frames = 100},
		{op = "render", rpm = 2800.0, max_rpm = NAN, frames = 128},
		{op = "render", rpm = 2800.0, max_rpm = INF, frames = 128},
		{op = "render", rpm = 1000000000.0, max_rpm = 1000000000.0, frames = 4096},
		{op = "reset", rpm = 12000.0, max_rpm = 12000.0},
		{op = "phase", value = 1.0 - pow(2.0, -40.0)},
		{op = "render", rpm = 12000.0, max_rpm = 12000.0, frames = 10},
		{op = "phase", value = -0.5},
		{op = "render", rpm = 12000.0, max_rpm = 12000.0, frames = 2},
		{op = "frequency", value = -1000.0},
		{op = "render", rpm = 0.0, max_rpm = 12000.0, frames = 20},
		{op = "phase", value = 0.5},
		{op = "render", rpm = 12000.0, max_rpm = 12000.0, frames = 2},
	])
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261109
	var cases: Array[Dictionary] = []
	var block_sizes := [0, 1, 2, 7, 37, 128, 255, 512, 997]
	for i in 400:
		var rpm: float = rng.randf_range(0.0, 18000.0)
		if i % 19 == 0:
			rpm = 60.0 * (RATE * 0.5 / float(1 + i % 6))
		if i % 51 == 0:
			cases.append({op = "reset", rpm = rpm, max_rpm = 18000.0})
		cases.append({op = "render", rpm = rpm, max_rpm = 18000.0, frames = block_sizes[rng.randi_range(0, block_sizes.size() - 1)]})
	compare_scenario("seeded changes and band boundaries", 0.0, 18000.0, cases)

func adapter_checks() -> void:
	for adapter_script: Script in [BaselineAdapter, CandidateAdapter]:
		var sim := SimStub.new()
		root.add_child(sim)
		var adapter: AudioStreamPlayer3D = adapter_script.new()
		var generator := AudioStreamGenerator.new()
		generator.mix_rate = RATE
		generator.buffer_length = 0.15
		adapter.stream = generator
		adapter.observe(sim, 11149.0)
		root.add_child(adapter)
		adapter.begin_voice()
		adapter.voice.reset(8000.0, 11149.0)
		adapter.voice.render(8000.0, 11149.0, 61)
		var before: PackedByteArray = state_bytes(adapter.voice)
		sim.paused = true
		adapter.stream_paused = true
		sim.paused_changed.emit(true)
		adapter.refill(9999.0, 11149.0)
		check("adapter pauses without advancing voice " + adapter_script.resource_path, state_bytes(adapter.voice) == before)
		# Emulate a checkpoint restore while paused; this intentionally does not
		# emit stepped, so the resume path must use the new accepted RPM and tick.
		sim.aux[0] = 3500.0
		sim.tick = 7
		sim.paused = false
		adapter.stream_paused = false
		var pushed_before: int = adapter.pushed_frames
		adapter.refill(-1.0, 11149.0)
		var pushed_now: int = adapter.pushed_frames - pushed_before
		var expected := Baseline.new()
		expected.reset(3500.0, 11149.0)
		expected.render(3500.0, 11149.0, pushed_now)
		check("adapter resumed and refilled " + adapter_script.resource_path, pushed_now > 0)
		check("adapter resumes from restored accepted state " + adapter_script.resource_path,
			adapter.snapshot_rpm == 3500.0 and adapter.snapshot_tick == 7 and adapter.snapshot_time == sim.time()
			and state_bytes(adapter.voice) == state_bytes(expected))
		adapter.stop()
		adapter.free()
		sim.free()

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	direct_checks()
	adapter_checks()
	print("VOICE PARITY COMPLETE: %d checks, %d failures, %d blocks, %d stereo frames" % [checks, failures, blocks_compared, frames_compared])
	quit(1 if failures else 0)
