#!/usr/bin/env bash
# Headless checks (no display needed). Fails if any script fails to parse or any test fails.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
GODOT="$("$HERE/get-godot.sh")"
run() { timeout 60 "$GODOT" --headless --path "$HERE" --audio-driver Dummy "$@"; }


LOG="$(mktemp)"; trap 'rm -f "$LOG"' EXIT
echo "== app: an unknown aircraft is refused on the direct route (exit 1, never another airplane)"
for id in no-such-aircraft; do
  if run -- --aircraft="$id" --trace=/dev/null --t=1 > /dev/null 2>&1; then echo "--aircraft=$id was not refused"; exit 1; fi
done
echo "refused"

echo "== frame-time logger writes its report (LANDSCAPE-PLAN L0e; headless numbers are plumbing, not performance)"
FT="$(mktemp --suffix=.json)"
run -- --frametimes="$FT" --t=1.5 > /dev/null 2>&1
python3 - "$FT" <<'PY'
import json, sys
r = json.load(open(sys.argv[1]))
ms = r["frame_ms"]
assert r["frames"] > 10 and r["seconds"] >= 1.5, r
assert r["format"] == "openrc-frametimes v2" and r["complete"] is True
assert r["route"] == "live-input" and r["input_enabled"] is True
assert len(r["frame_deltas_s"]) == r["frames"]
assert abs(sum(r["frame_deltas_s"]) - r["seconds"]) < 1e-8
assert all(len(values) == r["frames"] for values in r["raw_metrics"].values())
assert r["simulation"]["ticks"] > 0 and r["actual_warmup_s"] >= 1.0
assert 0 < ms["p50"] <= ms["p95"] <= ms["p99"] <= ms["max"], ms
assert all(k in r for k in ("adapter", "api", "godot", "os", "vsync", "physics_us_per_tick")), sorted(r)
print(f"frame-time report: {r['frames']} frames, p50 {ms['p50']:.2f} <= p95 {ms['p95']:.2f} <= p99 {ms['p99']:.2f} ms")
PY
rm -f "$FT"

echo "== VQ-01b: scripted logger disables input and identifies its route"
FT="$(mktemp --suffix=.json)"
run -- --frametimes="$FT" --warmup=0 --t=0.1 --scripted --case=logger-smoke > "$LOG" 2>&1
if grep -qE "^(SCRIPT )?ERROR:" "$LOG"; then cat "$LOG"; exit 1; fi
python3 - "$FT" <<'PYLOGGER'
import json, sys
r = json.load(open(sys.argv[1]))
assert r["route"] == "scripted-fixed" and r["case_id"] == "logger-smoke"
assert r["input_enabled"] is False and r["simulation"]["ticks"] == 0
assert r["complete"] is True and r["seconds"] >= 0.1
assert r["seconds"] - r["frame_deltas_s"][-1] < 0.100001
assert r["warmup_s"] == 0 and r["backend"] and r["preset"]
print("scripted route, raw samples and disabled input verified")
PYLOGGER
rm -f "$FT"
echo "== VQ-01b: invalid logger options and output write failures fail the process"
for bad in --t=0 --t=nan --warmup=-1 --capture --trace=/dev/null; do
  if run -- --frametimes=/dev/null "$bad" > "$LOG" 2>&1; then
    echo "logger accepted invalid option $bad"; exit 1
  fi
done
if run -- --frametimes="$HERE" --warmup=0 --t=0.01 > "$LOG" 2>&1; then
  echo "logger hid an output write failure"; exit 1
fi

echo "== fixed step: the real app with injected keys reaches the same state at 30, 60 and 144 fps rendering"
HASHES=""
for fps in 30 60 144; do
  out="$(run --fixed-fps "$fps" --script res://tests/run_fixed_step.gd 2>&1)"
  echo "$out" | grep -E "ticks=|ERROR"
  if echo "$out" | grep -qE "^(SCRIPT )?ERROR:"; then echo "engine error at $fps fps"; exit 1; fi
  HASHES="$HASHES $(echo "$out" | sed -n 's/.*state_sha256=\([0-9a-f]*\).*/\1/p')"
done
if [ "$(echo $HASHES | tr ' ' '\n' | sort -u | wc -l)" -ne 1 ] || [ -z "$(echo $HASHES | tr -d ' ')" ]; then
  echo "final state depends on the rendering frame rate:$HASHES"; exit 1
fi
echo "identical"

echo "== E0b5: experimental wash transport at 30/60/144 fps"
python3 "$HERE/../research/propwash/e0b5/check_frames.py" --godot "$GODOT"

echo "== E0b6p: distributed swirl at 30/60/144 fps"
python3 "$HERE/../research/propwash/e0b6p/check_frames.py" --godot "$GODOT"

echo "== E5a: generated Extra taildragger contacts, P-51 review and session refinement"
E5A_WORK="$(mktemp -d)"
python3 "$HERE/../research/ground-contact/e5a/verify.py" --godot "$GODOT" --out "$E5A_WORK/results"
rm -rf "$E5A_WORK"

echo "== E5b: tail-up pitch threshold, rigid tail lift and synthetic resistance patches"
E5B_WORK="$(mktemp -d)"
python3 "$HERE/../research/ground-contact/e5b/verify.py" --godot "$GODOT" --out "$E5B_WORK/results"
rm -rf "$E5B_WORK"
