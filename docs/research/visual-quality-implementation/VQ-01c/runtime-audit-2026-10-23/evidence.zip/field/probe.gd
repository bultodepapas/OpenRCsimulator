extends SceneTree
func _initialize() -> void:
    _run.call_deferred()
func _run() -> void:
    load("res://render/shader_clock.gd").register()
    var field: Dictionary = load("res://data/field_loader.gd").load_from()
    assert(field.ok)
    var builder: Script = load("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/field/profiled_field.gd")
    for i in 2:
        var begin := Time.get_ticks_usec()
        var built: Node3D = builder.build(field.field)
        print("FIELD_TOTAL ", i, " ", Time.get_ticks_usec() - begin)
        print("SCENERY_TIMES ", JSON.stringify(built.get_node("Scenery").get_meta("stats")))
        root.add_child(built)
        await process_frame
        built.queue_free()
        await process_frame
    quit()
