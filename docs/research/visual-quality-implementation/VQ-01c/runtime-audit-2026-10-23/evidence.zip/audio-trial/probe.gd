extends SceneTree

const Baseline = preload("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/baseline.gd")
const Candidate = preload("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/candidate.gd")
const Session = preload("res://sim/flight_session.gd")
const FieldLoader = preload("res://data/field_loader.gd")
const LakeLoader = preload("res://data/lake_loader.gd")
const AircraftData = preload("res://physics/aircraft_data.gd")
const Terrain = preload("res://physics/ground_terrain.gd")
const RB = preload("res://physics/rigid_body.gd")

const DEFAULT_AIRCRAFT := [
	"res://data/aircraft/jensen_ugly_stik_60.json",
	"res://data/aircraft/p51d_mustang_120.json",
	"res://data/aircraft/sebart_avanti_s_a200.json",
]
const DEFAULT_OUT := "C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/result-coverage.json"
const LAKE_PATH := "res://data/fields/lake.json"

var cases: Array[Dictionary] = []
var mismatches := 0
var fallback_cases := 0
var diagnostic_cases := 0
var setup_errors: Array[String] = []


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var aircraft_arg := _option("aircraft", "")
	var aircraft_paths: Array = DEFAULT_AIRCRAFT.duplicate()
	if not aircraft_arg.is_empty():
		aircraft_paths = [aircraft_arg]
	var out_path := _option("out", DEFAULT_OUT)
	var field_result: Dictionary = FieldLoader.load_from()
	var lake_result: Dictionary = LakeLoader.load_from(LAKE_PATH)
	if not field_result.get("ok", false):
		setup_errors.append("field load: %s" % str(field_result.get("errors", [])))
	if not lake_result.get("ok", false):
		setup_errors.append("lake load: %s" % str(lake_result.get("errors", [])))

	for aircraft_path: String in aircraft_paths:
		var source_specs: Array[Dictionary] = [
			{name = "file_profiled", frozen = {}},
			{name = "in_memory_fallback", frozen = _legacy_aircraft(aircraft_path)},
		]
		for source_spec: Dictionary in source_specs:
			var session := Session.new()
			session.input_enabled = false
			session.physics_enabled = false
			session.setup(aircraft_path, "", source_spec.frozen)
			root.add_child(session)
			if not session.aircraft.get("ok", false):
				setup_errors.append("aircraft load %s (%s): %s" % [aircraft_path, source_spec.name, str(session.aircraft.get("errors", []))])
				root.remove_child(session)
				session.free()
				continue
			var retractable := session.gear_is_retractable()
			var extensions: Array = [1.0]
			if retractable:
				extensions = [0.0, 0.5, 1.0]
			for environment: Dictionary in _environments(field_result, lake_result):
				_apply_environment(session, environment)
				session.reset()
				for extension: float in extensions:
					_run_case(session, aircraft_path, source_spec.name, environment, extension, 0.65 if retractable else 0.0)
			root.remove_child(session)
			session.free()

	var default_run := aircraft_arg.is_empty()
	var branches_ok := not default_run or (fallback_cases > 0 and diagnostic_cases > 0)
	var report := {
		"passed": mismatches == 0 and setup_errors.is_empty() and branches_ok,
		"mismatches": mismatches,
		"setup_errors": setup_errors,
		"branch_coverage": {"fallback": fallback_cases, "diagnostic": diagnostic_cases},
		"aircraft_paths": aircraft_paths,
		"cases": cases,
		"engine": Engine.get_version_info(),
	}
	var file := FileAccess.open(out_path, FileAccess.WRITE)
	if file == null:
		printerr("Could not write probe report: ", out_path, " error=", FileAccess.get_open_error())
		quit(1)
		return
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	print("Audio snapshot parity mismatches: ", mismatches,
		"; fallback cases: ", fallback_cases,
		"; diagnostic cases: ", diagnostic_cases,
		"; report: ", out_path)
	quit(0 if report.passed else 1)


func _environments(field_result: Dictionary, lake_result: Dictionary) -> Array[Dictionary]:
	var out: Array[Dictionary] = [
		{name = "flat", field = {}, lake = {}, north = 0.0, east = 0.0},
	]
	if field_result.get("ok", false):
		out.append({name = "terrain", field = field_result.field, lake = {}, north = 0.0, east = 0.0})
		if lake_result.get("ok", false):
			out.append({name = "lake", field = field_result.field, lake = lake_result.lake, north = 110.0, east = 125.0})
	return out


func _apply_environment(session: Node, environment: Dictionary) -> void:
	if environment.field.is_empty():
		session.ground_surfaces = PackedFloat64Array()
		session.ground_field_id = ""
	else:
		if not session.set_field(environment.field):
			setup_errors.append("set_field %s: %s" % [environment.name, session.surface_error])
	if not session.set_lake_context(environment.lake):
		setup_errors.append("set_lake_context %s refused" % str(environment.name))


func _run_case(session: Node, aircraft_path: String, source_mode: String, environment: Dictionary, extension: float, brake: float) -> void:
	var gear_index := int(session.gear_aux_index()) if session.gear_is_retractable() else -1
	if gear_index >= 0 and session.sim.aux.size() > gear_index + 1:
		session.sim.aux[gear_index] = extension
		session.sim.aux[gear_index + 1] = 1.0 if extension > 0.0 else 0.0
	if session.gear_is_retractable() and session.sim.inputs.size() > 5:
		session.sim.inputs[5] = brake
	var gear: Dictionary = session.current_landing_gear()
	if gear.is_empty() or gear.get("contacts", []).is_empty():
		setup_errors.append("no accepted contacts for %s at extension %.2f" % [aircraft_path, extension])
		return
	var state: PackedFloat64Array = session.sim.state.duplicate()
	state[RB.POS] = float(environment.north)
	state[RB.POS + 1] = float(environment.east)
	state[RB.VEL] = 7.0
	state[RB.VEL + 1] = 0.4
	state[RB.VEL + 2] = 0.0
	var contact: Dictionary = gear.contacts[0]
	var terrain := PackedFloat64Array([0.0, 0.0, 0.0])
	if not session.ground_surfaces.is_empty():
		terrain = Terrain.sample_validated(state[RB.POS], state[RB.POS + 1], session.ground_surfaces, session._lake)
	if terrain.size() != 3 or not is_finite(terrain[0]):
		setup_errors.append("invalid terrain sample for %s %s" % [aircraft_path, str(environment.name)])
		return
	state[RB.POS + 2] = -float(contact.position[2]) - terrain[0] + 0.025
	session.sim.state = state
	var branch := "diagnostic" if session.wheel_count() > 0 else "fallback"
	if branch == "diagnostic":
		diagnostic_cases += 1
	else:
		fallback_cases += 1
	var audio_field := {surfaces = environment.field.get("surfaces", [])}
	var before := _identity(session)
	var baseline_contacts: Array = Baseline.snapshot_contacts(session, audio_field)
	var baseline_unchanged := before == _identity(session)
	var candidate_contacts: Array = Candidate.snapshot_contacts(session, audio_field)
	var candidate_unchanged := before == _identity(session)
	var output_equal := var_to_bytes(baseline_contacts) == var_to_bytes(candidate_contacts)
	var equal := baseline_unchanged and candidate_unchanged and output_equal
	if not equal:
		mismatches += 1
	cases.append({
		"aircraft": aircraft_path,
		"source_mode": source_mode,
		"environment": environment.name,
		"gear_extension": extension if session.gear_is_retractable() else null,
		"brake": brake if session.gear_is_retractable() else null,
		"branch": branch,
		"contact_count": gear.contacts.size(),
		"baseline_contacts": baseline_contacts.size(),
		"candidate_contacts": candidate_contacts.size(),
		"outputs_equal": output_equal,
		"baseline_read_only": baseline_unchanged,
		"candidate_read_only": candidate_unchanged,
		"equal": equal,
	})


func _identity(session: Node) -> PackedByteArray:
	var current_gear: Dictionary = session.current_landing_gear()
	var model_gear: Dictionary = session.aircraft.model.get("landing_gear", {})
	return var_to_bytes([
		session.sim.state,
		session.sim.aux,
		session.sim.continuous,
		session.sim.inputs,
		model_gear,
		current_gear,
	])


func _legacy_aircraft(path: String) -> Dictionary:
	var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if typeof(raw) != TYPE_DICTIONARY:
		setup_errors.append("aircraft JSON parse failed for fallback: %s" % path)
		return {}
	var legacy: Dictionary = AircraftData.validate_and_derive(raw)
	if not legacy.get("ok", false):
		setup_errors.append("in-memory fallback validation failed for %s: %s" % [path, str(legacy.get("errors", []))])
	return legacy


func _option(name: String, fallback: String) -> String:
	var args := OS.get_cmdline_user_args()
	var prefix := "--%s=" % name
	for index in args.size():
		var arg: String = str(args[index])
		if arg.begins_with(prefix):
			return arg.substr(prefix.length())
		if arg == "--%s" % name and index + 1 < args.size():
			return str(args[index + 1])
	return fallback
