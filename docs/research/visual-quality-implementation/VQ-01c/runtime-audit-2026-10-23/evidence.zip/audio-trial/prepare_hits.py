from pathlib import Path
root=Path(__file__).resolve().parents[3]
here=Path(__file__).resolve().parent
source=(root/'app/audio/ground_audio_model.gd').read_text()
source=source.replace('extends RefCounted','extends RefCounted\nstatic var snapshot_hits := 0\nstatic var fallback_hits := 0',1)
source=source.replace('\tvar contacts_out: Array[Dictionary] = []','\tsnapshot_hits += 1\n\tvar contacts_out: Array[Dictionary] = []',1)
source=source.replace('\t\t\tvar single_gear: Dictionary = gear.duplicate()','\t\t\tfallback_hits += 1\n\t\t\tvar single_gear: Dictionary = gear.duplicate()',1)
(here/'hit_model.gd').write_text(source)
bootstrap=(root/'docs/research/visual-quality-implementation/VQ-07/planar-lake-2026-10-22/native-keyboard/keyboard_flight.gd').read_text()
bootstrap=bootstrap.replace('extends SceneTree','extends SceneTree\nvar counted_model: GDScript',1)
bootstrap=bootstrap.replace('\tvar service: Node','''\tcounted_model = load("res://audio/ground_audio_model.gd")
\tcounted_model.source_code = FileAccess.get_file_as_string("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/hit_model.gd")
\tif counted_model.reload() != OK:
\t\tquit(1)
\t\treturn
\tvar audio_script: GDScript = load("res://audio/flight_audio.gd")
\tif audio_script.get_script_constant_map().get("GroundAudioModel") != counted_model:
\t\tprinterr("Audio model cache binding mismatch")
\t\tquit(1)
\t\treturn
\troot.tree_exiting.connect(_save_hits)
\tvar service: Node''',1)
bootstrap+='''
func _save_hits() -> void:
\tvar result := {snapshot_hits=counted_model.snapshot_hits, fallback_hits=counted_model.fallback_hits,
\t\tpurpose="Untimed native path verification only; counters perturb execution", same_cached_script=true}
\tprint("AUDIO_PATH_HITS ",JSON.stringify(result))
\tFileAccess.open("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/hits.json",FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
'''
(here/'hit_bootstrap.gd').write_text(bootstrap)
