from pathlib import Path
import subprocess, sys, os, json, statistics, hashlib
root=Path(__file__).resolve().parents[3]
here=Path(__file__).resolve().parent
out=here/sys.argv[1]
out.mkdir(exist_ok=False)
aircraft=sys.argv[2] if len(sys.argv)>2 else 'jensen-das-ugly-stik-60'
landscape='green_paradise' if aircraft=='sebart-avanti-s-a200-p100rx' else 'club_field'
rows=[]
for i, arm in enumerate(os.environ.get('OPENRC_AUDIO_ORDER','baseline,candidate,candidate,baseline').split(',')):
    dest=out/f'{i}-{arm}'
    dest.mkdir()
    src=here/f'{arm}.gd'
    frame=dest/'frames.json'
    audio=dest/'audio.json'
    env=dict(os.environ,OPENRC_AUDIO_SOURCE=str(src),OPENRC_AUDIO_METRICS=str(audio))
    cmd=[sys.executable,str(root/'tools/godot/run_checked.py'),'--out-dir',str(dest/'checks'),'--timeout','120','--require-text','AUDIO_OVERRIDE_READY','--',str(root/'.tools/Godot_v4.7.2-stable_win64_console.exe'),'--path',str(root/'app'),'--audio-driver','Dummy','--resolution','1920x1080','--fullscreen','--screen','0','--max-fps','0','--script',str(here/'keyboard_audio_trial.gd'),'--',f'--aircraft={aircraft}',f'--landscape={landscape}','--start=airborne_half_power','--view=pilot','--look_az=49','--look_el=-1',f'--frametimes={frame}','--warmup=10','--t=60','--frame-diagnostics','--frametimes-max-frames=60000']
    (dest/'command.json').write_text(json.dumps({'command':cmd,'audio_source':str(src),'audio_sha256':hashlib.sha256(src.read_bytes()).hexdigest()},indent=2))
    print('RUN',i,arm,flush=True)
    r=subprocess.run(cmd,env=env,cwd=root)
    if r.returncode: sys.exit(r.returncode)
    d=json.loads(frame.read_text()); a=json.loads(audio.read_text())['samples_usec']
    assert d['complete'] and d['route']=='live-input' and d['simulation']['ticks']>14000 and not d['simulation']['paused'] and not d['simulation']['fault'] and not d['session_at_report']['crashed'] and not d['session_at_report']['holds'] and d['session_at_report']['window_focused'], d.get('session_at_report')
    row={'arm':arm,'frame_ms':d['frame_ms'],'audio_median_us':statistics.median(a),'audio_p95_us':sorted(a)[int(len(a)*.95)],'audio_samples':len(a),'measured_simulation':d['measured_simulation']}
    rows.append(row)
    print(row,flush=True)
    (out/'summary.json').write_text(json.dumps(rows,indent=2))
