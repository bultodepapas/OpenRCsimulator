## Native VQ-07 diagnostic: ordinary Main + ControllerService, keyboard selected once.
## No pose, input callback, pause, physics tick or frame collector override.
extends SceneTree
var counted_model: GDScript

func _initialize() -> void:
	_start.call_deferred()

func _start() -> void:
	if DisplayServer.get_name() == "headless":
		printerr("Native renderer required")
		quit(1)
		return
	counted_model = load("res://audio/ground_audio_model.gd")
	counted_model.source_code = FileAccess.get_file_as_string("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/hit_model.gd")
	if counted_model.reload() != OK:
		quit(1)
		return
	var audio_script: GDScript = load("res://audio/flight_audio.gd")
	if audio_script.get_script_constant_map().get("GroundAudioModel") != counted_model:
		printerr("Audio model cache binding mismatch")
		quit(1)
		return
	root.tree_exiting.connect(_save_hits)
	var service: Node = load("res://input/controller_service.gd").new()
	root.add_child(service)
	if not service.select_devices(-1, -1):
		printerr("Keyboard selection failed")
		quit(1)
		return
	var flight: Node = load("res://main.tscn").instantiate()
	flight.external_controller_selection = true
	root.add_child(flight)
	if not flight.startup_error.is_empty() or flight.session == null:
		printerr("Flight setup failed: ", flight.startup_error)
		quit(1)
		return
	service.attach_session(flight.session)
	if flight.session.radio.connected or not flight.session.input_enabled or not flight.session.physics_enabled:
		printerr("Expected live keyboard input and physical flight")
		quit(1)
		return
	print("Keyboard flight diagnostic: ", JSON.stringify({
		keyboard_selected=service.registry.selected_device_id("flight") == -1,
		radio_connected=flight.session.radio.connected, input_enabled=flight.session.input_enabled,
		physics_enabled=flight.session.physics_enabled, initial_paused=flight.session.sim.paused,
		initial_throttle=flight.session.commands.throttle, startup_error=flight.startup_error,
		focus=root.has_focus(), custom_bootstrap=true, prescribed_pose=false,
		pilot_acceptance=false}))

func _save_hits() -> void:
	var result := {snapshot_hits=counted_model.snapshot_hits, fallback_hits=counted_model.fallback_hits,
		purpose="Untimed native path verification only; counters perturb execution", same_cached_script=true}
	print("AUDIO_PATH_HITS ",JSON.stringify(result))
	FileAccess.open("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/hits.json",FileAccess.WRITE).store_string(JSON.stringify(result,"	"))
