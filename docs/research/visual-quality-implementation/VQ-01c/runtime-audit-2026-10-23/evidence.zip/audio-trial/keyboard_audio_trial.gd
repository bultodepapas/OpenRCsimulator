## Native VQ-07 diagnostic: ordinary Main + ControllerService, keyboard selected once.
## No pose, input callback, pause, physics tick or frame collector override.
extends SceneTree
var audio_model: GDScript
var observed_flight: Node
var audio_samples := PackedInt64Array()
var sample_start_usec: int
var state_events: Array[Dictionary] = []
var last_status := ""


func _initialize() -> void:
	_start.call_deferred()

func _start() -> void:
	if DisplayServer.get_name() == "headless":
		printerr("Native renderer required")
		quit(1)
		return
	audio_model = load("res://audio/ground_audio_model.gd")
	audio_model.source_code = FileAccess.get_file_as_string(OS.get_environment("OPENRC_AUDIO_SOURCE"))
	if audio_model.reload() != OK:
		quit(1)
		return
	print("AUDIO_OVERRIDE_READY ", OS.get_environment("OPENRC_AUDIO_SOURCE"))
	var service: Node = load("res://input/controller_service.gd").new()
	root.add_child(service)
	if not service.select_devices(-1, -1):
		printerr("Keyboard selection failed")
		quit(1)
		return
	var flight: Node = load("res://main.tscn").instantiate()
	flight.external_controller_selection = true
	root.add_child(flight)
	if not flight.startup_error.is_empty() or flight.session == null:
		printerr("Flight setup failed: ", flight.startup_error)
		quit(1)
		return
	service.attach_session(flight.session)
	observed_flight = flight
	sample_start_usec = Time.get_ticks_usec() + 10000000
	process_frame.connect(_sample_audio)
	root.tree_exiting.connect(_save_audio)
	if flight.session.radio.connected or not flight.session.input_enabled or not flight.session.physics_enabled:
		printerr("Expected live keyboard input and physical flight")
		quit(1)
		return
	print("Keyboard flight diagnostic: ", JSON.stringify({
		keyboard_selected=service.registry.selected_device_id("flight") == -1,
		radio_connected=flight.session.radio.connected, input_enabled=flight.session.input_enabled,
		physics_enabled=flight.session.physics_enabled, initial_paused=flight.session.sim.paused,
		initial_throttle=flight.session.commands.throttle, startup_error=flight.startup_error,
		focus=root.has_focus(), custom_bootstrap=true, prescribed_pose=false,
		pilot_acceptance=false}))

func _sample_audio() -> void:
	if not is_instance_valid(observed_flight):
		return
	var session: Node = observed_flight.session
	var status := str([session.sim.paused, root.has_focus(), session.holds])
	if status != last_status:
		last_status = status
		state_events.append({elapsed_s=(Time.get_ticks_usec()-sample_start_usec)/1000000.0+10.0,
			paused=session.sim.paused, focused=root.has_focus(), holds=session.holds.duplicate(), tick=session.sim.tick})
	if Time.get_ticks_usec() < sample_start_usec:
		return
	var observer: Node = observed_flight.get_node_or_null("FlightAudio")
	if observer != null and audio_samples.size() < 60000:
		audio_samples.append(observer.last_update_usec)

func _save_audio() -> void:
	var output := FileAccess.open(OS.get_environment("OPENRC_AUDIO_METRICS"), FileAccess.WRITE)
	output.store_string(JSON.stringify({source=OS.get_environment("OPENRC_AUDIO_SOURCE"),
		samples_usec=audio_samples, state_events=state_events, scope="existing FlightAudio.last_update_usec; previous render callback; 10s warmup; Dummy audio"}))
