from pathlib import Path
root=Path(__file__).resolve().parents[3]
folder=Path(__file__).resolve().parent
base=(root/'docs/research/visual-quality-implementation/VQ-07/planar-lake-2026-10-22/native-keyboard/keyboard_flight.gd').read_text()
base=base.replace('extends SceneTree','''extends SceneTree
var audio_model: GDScript
var observed_flight: Node
var audio_samples := PackedInt64Array()
var sample_start_usec: int
var state_events: Array[Dictionary] = []
var last_status := ""
''',1)
base=base.replace('\tvar service: Node', '''\taudio_model = load("res://audio/ground_audio_model.gd")
\taudio_model.source_code = FileAccess.get_file_as_string(OS.get_environment("OPENRC_AUDIO_SOURCE"))
\tif audio_model.reload() != OK:
\t\tquit(1)
\t\treturn
\tprint("AUDIO_OVERRIDE_READY ", OS.get_environment("OPENRC_AUDIO_SOURCE"))
\tvar service: Node''',1)
base=base.replace('\tservice.attach_session(flight.session)', '''\tservice.attach_session(flight.session)
\tobserved_flight = flight
\tsample_start_usec = Time.get_ticks_usec() + 10000000
\tprocess_frame.connect(_sample_audio)
\troot.tree_exiting.connect(_save_audio)''',1)
base+='''
func _sample_audio() -> void:
\tif not is_instance_valid(observed_flight):
\t\treturn
\tvar session: Node = observed_flight.session
\tvar status := str([session.sim.paused, root.has_focus(), session.holds])
\tif status != last_status:
\t\tlast_status = status
\t\tstate_events.append({elapsed_s=(Time.get_ticks_usec()-sample_start_usec)/1000000.0+10.0,
\t\t\tpaused=session.sim.paused, focused=root.has_focus(), holds=session.holds.duplicate(), tick=session.sim.tick})
\tif Time.get_ticks_usec() < sample_start_usec:
\t\treturn
\tvar observer: Node = observed_flight.get_node_or_null("FlightAudio")
\tif observer != null and audio_samples.size() < 60000:
\t\taudio_samples.append(observer.last_update_usec)

func _save_audio() -> void:
\tvar output := FileAccess.open(OS.get_environment("OPENRC_AUDIO_METRICS"), FileAccess.WRITE)
\toutput.store_string(JSON.stringify({source=OS.get_environment("OPENRC_AUDIO_SOURCE"),
\t\tsamples_usec=audio_samples, state_events=state_events, scope="existing FlightAudio.last_update_usec; previous render callback; 10s warmup; Dummy audio"}))
'''
(folder/'keyboard_audio_trial.gd').write_text(base)
