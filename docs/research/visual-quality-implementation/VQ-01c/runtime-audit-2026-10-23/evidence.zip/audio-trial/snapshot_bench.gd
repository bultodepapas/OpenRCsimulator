extends SceneTree
const Baseline = preload("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/baseline.gd")
const Candidate = preload("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/candidate.gd")
const Session = preload("res://sim/flight_session.gd")
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	var session := Session.new()
	session.physics_enabled = false
	session.input_enabled = false
	session.setup()
	root.add_child(session)
	for i in 100:
		Baseline.snapshot_contacts(session, {surfaces=[]})
		Candidate.snapshot_contacts(session, {surfaces=[]})
	var pairs: Array[Dictionary] = []
	for i in 30:
		var pair := {}
		for arm in ([false,true] if i % 2 == 0 else [true,false]):
			var model = Candidate if arm else Baseline
			var start := Time.get_ticks_usec()
			for j in 500:
				model.snapshot_contacts(session, {surfaces=[]})
			pair["candidate" if arm else "baseline"] = float(Time.get_ticks_usec()-start) / 500.0
		pairs.append(pair)
	FileAccess.open("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/audio-trial/snapshot-bench-repeat.json",FileAccess.WRITE).store_string(JSON.stringify({paired_snapshot_usec=pairs, engine=Engine.get_version_info()},"\t"))
	root.remove_child(session)
	session.free()
	print("Audio snapshot 30 paired batches complete")
	quit()
