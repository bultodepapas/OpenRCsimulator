extends "C:/DEVELOPMENT/OpenRCsimulator/tools/graphics/capture.gd"
var trial_shader: Shader
func _initialize() -> void:
	trial_shader = load("res://render/ground.gdshader")
	if OS.get_environment("OPENRC_TRIAL") == "candidate":
		trial_shader.code = FileAccess.get_file_as_string("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/ground-trial/candidate.gdshader")
	super._initialize()
