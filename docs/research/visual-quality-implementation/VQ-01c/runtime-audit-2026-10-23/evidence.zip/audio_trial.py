from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent/'audio-trial'
out.mkdir(exist_ok=True)
source=(root/'app/audio/ground_audio_model.gd').read_text()
old='var single_gear: Dictionary = gear.duplicate(true)'
assert source.count(old)==1
candidate=source.replace(old,'var single_gear: Dictionary = gear.duplicate()')
(out/'baseline.gd').write_text(source)
(out/'candidate.gd').write_text(candidate)
(out/'identity.json').write_text(json.dumps({'baseline_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest()},indent=2))
