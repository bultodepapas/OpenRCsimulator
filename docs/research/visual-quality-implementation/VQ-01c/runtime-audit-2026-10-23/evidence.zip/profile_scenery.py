from pathlib import Path
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'field'
s = (root/'app/scenery/scenery.gd').read_text()
s=s.replace('\tvar timing := {}', '\tvar timing := {}\n\tvar perf_fleet := {}\n\tvar perf_mark := 0',1)
start=s.index('\t\t\t"fleet":')
end=s.index('\t\t\t"fence":',start)
part=s[start:end]
markers=[('mesh','\t\t\t\t\tif mesh == null:'),('batch','\t\t\t\t\tvar info := ParkedAircraft.info'),('info','\t\t\t\t\tvar size := Vector3'),('support','\t\t\t\t\tvar mode := "aircraft_jet"'),('metadata','\t\t\t\t\tif shadow_strength > 0.0:'),('shadow','\t\t\t\t\tstats.fleet += 1')]
part=part.replace('\t\t\t\t\tvar mesh := ParkedAircraft.mesh','\t\t\t\t\tperf_mark = Time.get_ticks_usec()\n\t\t\t\t\tvar mesh := ParkedAircraft.mesh',1)
for name,marker in markers:
 assert marker in part
 part=part.replace(marker,'\t\t\t\t\tperf_fleet["'+name+'"] = int(perf_fleet.get("'+name+'", 0)) + Time.get_ticks_usec() - perf_mark\n\t\t\t\t\tperf_mark = Time.get_ticks_usec()\n'+marker,1)
s=s[:start]+part+s[end:]
s=s.replace('\tstats.timing_ms = timing','\tprint("FLEET_PROFILE ", JSON.stringify(perf_fleet))\n\tstats.timing_ms = timing',1)
(out/'profiled_scenery.gd').write_text(s)
p=out/'profiled_field.gd'
f=p.read_text().replace('preload("res://scenery/scenery.gd")','preload("'+(out/'profiled_scenery.gd').as_posix()+'")')
p.write_text(f)
