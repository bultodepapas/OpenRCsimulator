## Native active-flight trial bootstrap. Shader source is process-scoped through env.
extends SceneTree

func _initialize() -> void:
	_start.call_deferred()


func _start() -> void:
	if DisplayServer.get_name() == "headless":
		printerr("Native renderer required")
		quit(1)
		return
	var variant: String = OS.get_environment("OPENRC_TRIAL")
	var shader_path: String = OS.get_environment("OPENRC_GROUND_SHADER_OVERRIDE")
	if not ["baseline", "candidate"].has(variant) or shader_path.is_empty():
		printerr("Ground shader trial requires OPENRC_TRIAL=baseline|candidate and OPENRC_GROUND_SHADER_OVERRIDE")
		quit(1)
		return
	var shader_source: String = FileAccess.get_file_as_string(shader_path)
	if shader_source.is_empty():
		printerr("Cannot read ground shader override: ", shader_path)
		quit(1)
		return
	var ground_shader: Shader = load("res://render/ground.gdshader") as Shader
	if ground_shader == null:
		printerr("Cannot load the production ground shader resource")
		quit(1)
		return
	ground_shader.code = shader_source
	var runtime_shader_sha256: String = _normalized_sha256(ground_shader.code)
	if runtime_shader_sha256.is_empty() or runtime_shader_sha256 != OS.get_environment("OPENRC_GROUND_SHADER_SHA256"):
		printerr("Loaded ground Shader.code hash does not match the per-process source identity")
		quit(1)
		return
	# Load the production loader only after assigning the code. Its preload must
	# resolve to the same ResourceLoader-cached Shader instance before Main starts.
	var atmosphere_script: Script = load("res://render/atmosphere.gd") as Script
	if atmosphere_script == null:
		printerr("Cannot load Atmosphere shader loader")
		quit(1)
		return
	var loader_shader: Shader = atmosphere_script.get_script_constant_map().get("GROUND_SHADER") as Shader
	if loader_shader == null or loader_shader != ground_shader or loader_shader.code != shader_source \
			or _normalized_sha256(loader_shader.code) != runtime_shader_sha256:
		printerr("Ground shader source override did not reach Atmosphere.GROUND_SHADER")
		quit(1)
		return
	print("GROUND_OVERRIDE_READY variant=%s path=%s sha256=%s" % [
		variant, shader_path, runtime_shader_sha256])

	var service: Node = load("res://input/controller_service.gd").new()
	root.add_child(service)
	if not service.select_devices(-1, -1):
		printerr("Keyboard selection failed")
		quit(1)
		return
	var flight: Node = load("res://main.tscn").instantiate()
	flight.external_controller_selection = true
	root.add_child(flight)
	if not flight.startup_error.is_empty() or flight.session == null:
		printerr("Flight setup failed: ", flight.startup_error)
		quit(1)
		return
	service.attach_session(flight.session)
	if flight.session.radio.connected or not flight.session.input_enabled \
			or not flight.session.physics_enabled or flight.session.sim.paused:
		printerr("Expected active physics and keyboard input with no connected radio")
		quit(1)
		return
	print("Keyboard flight diagnostic: ", JSON.stringify({
		keyboard_selected = service.registry.selected_device_id("flight") == -1,
		radio_connected = flight.session.radio.connected,
		input_enabled = flight.session.input_enabled,
		physics_enabled = flight.session.physics_enabled,
		initial_paused = flight.session.sim.paused,
		initial_throttle = flight.session.commands.throttle,
		startup_error = flight.startup_error,
		focus = root.has_focus(),
		custom_bootstrap = true,
		prescribed_pose = false,
		pilot_acceptance = false}))
	print("KEYBOARD_TRIAL_READY")


func _normalized_sha256(source: String) -> String:
	var normalized: String = source.replace("\r\n", "\n").replace("\r", "\n")
	var context := HashingContext.new()
	if context.start(HashingContext.HASH_SHA256) != OK or context.update(normalized.to_utf8_buffer()) != OK:
		return ""
	return context.finish().hex_encode()
