"""Sequential native active-flight ABBA trial for the ground parcel shader guard."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TRIAL = ROOT / "tmp" / "perf-20261023" / "ground-trial"
IDENTITY = TRIAL / "identity.json"
BOOTSTRAP = HERE / "keyboard_flight_trial.gd"
RUN_CHECKED = ROOT / "tools" / "godot" / "run_checked.py"
FRAME_DIAGNOSE = ROOT / "research" / "performance" / "frame_diagnose.py"
ORDER = ("baseline", "candidate", "candidate", "baseline")
SCENARIOS = {
    "stik-club": {
        "aircraft": "jensen-das-ugly-stik-60",
        "landscape": "club_field",
    },
    "avanti-green": {
        "aircraft": "sebart-avanti-s-a200-p100rx",
        "landscape": "green_paradise",
    },
}
SOURCE_FILES = (
    "app/main.gd",
    "app/main.tscn",
    "app/render/atmosphere.gd",
    "app/render/frame_samples.gd",
    "app/render/frame_diagnostics.gd",
    "app/input/controller_service.gd",
    "app/sim/flight_session.gd",
)


def normalized_text_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_text(encoding="utf-8").encode("utf-8")).hexdigest()


def byte_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def checked_identity() -> dict:
    identity = json.loads(IDENTITY.read_text(encoding="utf-8"))
    expected = {
        "source_sha256": normalized_text_sha256(TRIAL / "baseline.gdshader"),
        "candidate_sha256": normalized_text_sha256(TRIAL / "candidate.gdshader"),
    }
    if identity != expected:
        raise RuntimeError(f"ground-trial identity does not match source files: {identity} != {expected}")
    if normalized_text_sha256(ROOT / "app" / "render" / "ground.gdshader") != expected["source_sha256"]:
        raise RuntimeError("current production ground.gdshader differs from the retained baseline source")
    return {**expected, "baseline_file_sha256": byte_sha256(TRIAL / "baseline.gdshader"),
            "candidate_file_sha256": byte_sha256(TRIAL / "candidate.gdshader")}


def source_identity() -> dict:
    def git(*args: str) -> str:
        return subprocess.run(["git", *args], cwd=ROOT, check=True, capture_output=True,
                              text=True, encoding="utf-8").stdout.strip()

    return {
        "head": git("rev-parse", "HEAD"),
        "status_porcelain": git("status", "--porcelain"),
        "files_sha256": {name: byte_sha256(ROOT / name) for name in SOURCE_FILES},
        "trial_shader": checked_identity(),
    }


def nearest_rank(values: list[float], probability: float) -> float | None:
    usable = sorted(float(value) for value in values if math.isfinite(float(value)))
    if not usable:
        return None
    return usable[max(0, math.ceil(probability * len(usable)) - 1)]


def percentiles(values: list[float]) -> dict:
    return {"p50": nearest_rank(values, 0.50), "p95": nearest_rank(values, 0.95),
            "p99": nearest_rank(values, 0.99), "count": len(values)}


def frame_metrics(report: dict) -> dict:
    raw = report.get("raw_metrics", {})
    diagnostic_meta = report.get("frame_diagnostics", {})
    timing_available = bool(diagnostic_meta.get("render_timing_available", False))
    result = {"frame_ms": report.get("frame_ms", {}),
              "render_timing_available": timing_available}
    for key, output in (("render_cpu_ms", "render_cpu_ms"),
                        ("render_gpu_ms", "render_gpu_ms"),
                        ("frame_setup_cpu_ms", "frame_setup_cpu_ms"),
                        ("observer_poll_usec", "observer_poll_usec")):
        values = [float(value) for value in raw.get(key, [])]
        stats = percentiles(values)
        positive = sum(value > 0.0 for value in values)
        stats["positive_fraction"] = positive / len(values) if values else 0.0
        stats["timing_usable"] = timing_available and (
            key != "render_gpu_ms" or stats["positive_fraction"] >= 0.95)
        if key == "render_gpu_ms" and not stats["timing_usable"]:
            stats["usable_p95"] = None
        else:
            stats["usable_p95"] = stats["p95"] if stats["timing_usable"] else None
        result[output] = stats
    return result


def validate_report(report: dict, checked: dict, bootstrap_log: str,
                    variant: str, shader_path: Path, shader_hash: str) -> list[str]:
    errors: list[str] = []
    if not checked.get("ok"):
        errors.append(f"checked runner verdict is {checked.get('reason')}")
    if not report.get("complete"):
        errors.append("frame collection is incomplete")
    if report.get("failure"):
        errors.append(f"frame logger failure: {report['failure']}")
    if report.get("route") != "live-input":
        errors.append(f"expected live-input route; found {report.get('route')}")
    if report.get("window") != "1920x1080":
        errors.append(f"expected 1920x1080 window; found {report.get('window')}")
    if not report.get("vsync") or report.get("max_fps") != 0:
        errors.append("expected VSync enabled with max_fps=0")
    if not report.get("input_enabled"):
        errors.append("input was disabled at collection end")
    simulation = report.get("simulation", {})
    if not simulation.get("physics_enabled") or simulation.get("paused"):
        errors.append("physics was disabled or simulation paused at collection end")
    if simulation.get("fault"):
        errors.append(f"simulation fault at collection end: {simulation.get('fault')}")
    if simulation.get("ticks", 0) <= 0 or report.get("measured_simulation", {}).get("ticks", 0) <= 0:
        errors.append("no simulation tick progress was recorded")
    session = report.get("session_at_report", {})
    if session.get("crashed"):
        errors.append("session was crashed at collection end")
    if not session.get("window_focused"):
        errors.append("window was not focused at collection end")
    if session.get("holds"):
        errors.append(f"session holds remained at collection end: {session['holds']}")
    if "Keyboard flight diagnostic:" not in bootstrap_log:
        errors.append("keyboard bootstrap status was not logged")
    if "KEYBOARD_TRIAL_READY" not in bootstrap_log:
        errors.append("keyboard bootstrap did not reach its ready marker")
    marker = f"GROUND_OVERRIDE_READY variant={variant} path={shader_path} sha256={shader_hash}"
    if marker not in bootstrap_log:
        errors.append("runtime Shader.code hash/source override marker did not match the selected variant")
    return errors


def start_gpu_sampler(path: Path, enabled: bool):
    fields = "timestamp,utilization.gpu,clocks.current.graphics,clocks.current.memory,temperature.gpu,power.draw"
    path.write_text(f"# nvidia-smi fields: {fields}; loop=1s\n", encoding="utf-8")
    if not enabled:
        return None, None, {"available": False, "reason": "disabled by caller"}
    executable = shutil.which("nvidia-smi")
    if executable is None:
        path.write_text(f"# nvidia-smi fields: {fields}; unavailable on PATH\n", encoding="utf-8")
        return None, None, {"available": False, "reason": "nvidia-smi not found on PATH"}
    stream = path.open("a", encoding="utf-8", newline="")
    try:
        process = subprocess.Popen(
            [executable, f"--query-gpu={fields}", "--format=csv,noheader,nounits", "--loop=1"],
            cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError as error:
        stream.close()
        path.write_text(f"# nvidia-smi launch failed: {error}\n", encoding="utf-8")
        return None, None, {"available": False, "reason": f"launch failed: {error}"}
    return process, stream, {"available": True, "fields": fields, "interval_s": 1}


def stop_gpu_sampler(process, stream) -> None:
    if process is None:
        return
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)
    if stream is not None:
        stream.close()


def run_one(out: Path, scenario_name: str, scenario: dict, index: int,
            variant: str, identity: dict, godot: Path, gpu_enabled: bool) -> dict:
    label = f"{scenario_name}-{index:02d}-{variant}"
    run_dir = out / "runs" / label
    run_dir.mkdir(parents=True, exist_ok=False)
    frame_path = run_dir / "frametimes.json"
    override = TRIAL / ("baseline.gdshader" if variant == "baseline" else "candidate.gdshader")
    shader_hash = identity["source_sha256" if variant == "baseline" else "candidate_sha256"]
    checks_dir = out / "checks" / label
    command = [
        sys.executable, str(RUN_CHECKED), "--out-dir", str(checks_dir), "--label", label,
        "--timeout", "120", "--require-text", "GROUND_OVERRIDE_READY",
        "--require-text", "KEYBOARD_TRIAL_READY", "--",
        str(godot), "--path", str(ROOT / "app"), "--audio-driver", "Dummy",
        "--resolution", "1920x1080", "--fullscreen", "--screen", "0", "--max-fps", "0",
        "--script", str(BOOTSTRAP), "--",
        f"--aircraft={scenario['aircraft']}", f"--landscape={scenario['landscape']}",
        "--start=airborne_half_power", "--view=pilot", "--look_az=49", "--look_el=-1",
        "--look_alt=1.7", f"--frametimes={frame_path}", "--warmup=10", "--t=60",
        "--frame-diagnostics", "--frametimes-max-frames=60000",
        "--case=ground-parcel-active-flight",
    ]
    env = dict(os.environ)
    env.update({
        "OPENRC_TRIAL": variant,
        "OPENRC_GROUND_SHADER_OVERRIDE": str(override),
        "OPENRC_GROUND_SHADER_SHA256": shader_hash,
    })
    trial_record = {
        "format": "openrc-native-ground-trial-run v1", "label": label,
        "scenario": scenario_name, "aircraft_id": scenario["aircraft"],
        "landscape_id": scenario["landscape"], "variant": variant,
        "shader_source": str(override), "shader_normalized_sha256": shader_hash,
        "shader_file_sha256": byte_sha256(override), "command": command,
        "environment": {key: env[key] for key in (
            "OPENRC_TRIAL", "OPENRC_GROUND_SHADER_OVERRIDE", "OPENRC_GROUND_SHADER_SHA256")},
        "source_identity": source_identity(), "started_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(run_dir / "run.json", trial_record)
    telemetry_process, telemetry_stream, telemetry = start_gpu_sampler(
        run_dir / "gpu-telemetry.csv", gpu_enabled)
    started = time.monotonic()
    try:
        checked_exit = subprocess.run(command, cwd=ROOT, env=env, check=False).returncode
    finally:
        stop_gpu_sampler(telemetry_process, telemetry_stream)
    elapsed = time.monotonic() - started
    check_reports = list(checks_dir.glob("*/report.json"))
    check_logs = list(checks_dir.glob("*/engine.log"))
    if len(check_reports) != 1 or len(check_logs) != 1:
        raise RuntimeError(f"expected one checked report and log under {checks_dir}; got {len(check_reports)} and {len(check_logs)}")
    checked = json.loads(check_reports[0].read_text(encoding="utf-8"))
    engine_log = check_logs[0]
    log_text = engine_log.read_text(encoding="utf-8", errors="replace")
    if not frame_path.is_file():
        raise RuntimeError(f"native frame report was not written: {frame_path}")
    report = json.loads(frame_path.read_text(encoding="utf-8"))
    diagnosis = run_dir / "diagnosis.json"
    diagnosis_command = [
        sys.executable, str(FRAME_DIAGNOSE), "--report", str(frame_path),
        "--log", str(engine_log), "--out", str(diagnosis), "--budget-ms", "16.667", "--top", "10",
    ]
    diagnosis_exit = subprocess.run(diagnosis_command, cwd=ROOT, check=False).returncode
    errors = validate_report(report, checked, log_text, variant, override, shader_hash)
    if checked_exit != 0:
        errors.append(f"run_checked.py exited {checked_exit}")
    if diagnosis_exit != 0:
        errors.append(f"frame_diagnose.py exited {diagnosis_exit}")
    metrics = frame_metrics(report)
    metrics["measured_simulation"] = report.get("measured_simulation", {})
    metrics["simulation"] = report.get("simulation", {})
    metrics["session_at_report"] = report.get("session_at_report", {})
    metrics["input_enabled"] = report.get("input_enabled", False)
    metrics["window"] = report.get("window", "")
    metrics["vsync"] = report.get("vsync", False)
    metrics["vsync_mode"] = report.get("vsync_mode")
    metrics["max_fps"] = report.get("max_fps")
    metrics["backend"] = report.get("backend", "")
    metrics["frame_diagnostics"] = report.get("frame_diagnostics", {})
    record = {
        **trial_record, "complete": not errors, "validation_errors": errors,
        "checked_exit": checked_exit, "checked_report": str(check_reports[0]),
        "engine_log": str(engine_log), "frame_report": str(frame_path),
        "frame_diagnosis": str(diagnosis),
        "gpu_telemetry": {**telemetry, "path": str(run_dir / "gpu-telemetry.csv")},
        "elapsed_wall_s": elapsed, "frame_report_complete": report.get("complete", False),
        "frame_report_sha256": byte_sha256(frame_path), "metrics": metrics,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(run_dir / "run.json", record)
    return record


def compare_runs(runs: list[dict]) -> dict:
    metric_paths = ("frame_ms.p50", "frame_ms.p95", "frame_ms.p99",
                    "render_cpu_ms.p95", "render_gpu_ms.usable_p95",
                    "simulation.elapsed_time_s", "measured_simulation.ticks")

    def get_path(value: dict, path: str):
        for key in path.split("."):
            value = value.get(key) if isinstance(value, dict) else None
        return value

    variants = {}
    for name in ("baseline", "candidate"):
        selected = [run for run in runs if run["variant"] == name and run["complete"]]
        variants[name] = {
            path: statistics.median(values) if values else None
            for path in metric_paths
            for values in [[float(get_path(run["metrics"], path)) for run in selected
                            if get_path(run["metrics"], path) is not None]]
        }
        variants[name]["run_count"] = len(selected)
    pairs = []
    # ABBA yields one baseline→candidate and one candidate→baseline adjacent pair.
    for base_index, candidate_index in ((0, 1), (3, 2)):
        base = runs[base_index]
        candidate = runs[candidate_index]
        deltas = {}
        for path in metric_paths:
            left = get_path(candidate["metrics"], path)
            right = get_path(base["metrics"], path)
            deltas[path] = float(left) - float(right) if left is not None and right is not None else None
        pairs.append({"baseline_run": base["label"], "candidate_run": candidate["label"],
                      "candidate_minus_baseline": deltas})
    return {"aggregation": "median of per-run statistics; raw frame samples are not pooled",
            "variants": variants, "adjacent_pairs": pairs}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", required=True, choices=sorted(SCENARIOS))
    parser.add_argument("--out", required=True, type=Path, help="new, empty campaign output directory")
    parser.add_argument("--godot", type=Path,
                        default=ROOT / ".tools" / "Godot_v4.7.2-stable_win64_console.exe")
    parser.add_argument("--no-gpu-telemetry", action="store_true", help="skip optional 1 Hz nvidia-smi sidecar")
    args = parser.parse_args()
    out = args.out.resolve()
    if out.exists():
        parser.error(f"output must be new and not exist: {out}")
    if not args.godot.is_file() or not BOOTSTRAP.is_file() or not RUN_CHECKED.is_file():
        parser.error("pinned Godot, bootstrap or checked runner is missing")
    out.mkdir(parents=True)
    identity = source_identity()
    campaign = {
        "format": "openrc-native-ground-trial-campaign v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scenario": args.scenario, "order": list(ORDER), "target": SCENARIOS[args.scenario],
        "resolution": "1920x1080", "fullscreen": True, "screen": 0,
        "vsync": "normal project setting", "max_fps": 0,
        "warmup_s": 10, "sample_s": 60, "frame_diagnostics": True,
        "engine": str(args.godot.resolve()), "engine_sha256": byte_sha256(args.godot.resolve()),
        "source_identity": identity, "runs": [], "complete": False,
    }
    campaign_path = out / "campaign.json"
    write_json(campaign_path, campaign)
    failed = False
    for index, variant in enumerate(ORDER, start=1):
        print(f"\n=== {index}/4 {args.scenario} {variant} ===", flush=True)
        record = run_one(out, args.scenario, SCENARIOS[args.scenario], index, variant,
                         identity["trial_shader"], args.godot.resolve(), not args.no_gpu_telemetry)
        campaign["runs"].append({"label": record["label"], "variant": variant,
                                 "complete": record["complete"], "metrics": record["metrics"],
                                 "validation_errors": record["validation_errors"]})
        write_json(campaign_path, campaign)
        if not record["complete"]:
            failed = True
            print(f"Stopping after invalid run; see {record['frame_report']} and {record['validation_errors']}",
                  file=sys.stderr, flush=True)
            break
    if len(campaign["runs"]) == 4 and not failed:
        campaign["comparison"] = compare_runs(campaign["runs"])
        campaign["complete"] = True
    campaign["finished_utc"] = datetime.now(timezone.utc).isoformat()
    write_json(campaign_path, campaign)
    print(f"Campaign evidence: {campaign_path}", flush=True)
    return 1 if failed or not campaign["complete"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
