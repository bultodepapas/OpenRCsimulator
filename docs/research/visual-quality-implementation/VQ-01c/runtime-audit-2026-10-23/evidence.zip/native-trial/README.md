# Native active-flight shader pair prep

This scratch prep is for the exact-zero parcel guard comparison in `../ground-trial/`. It leaves `app/` untouched. Run it only when the root agent has released the native engine/GPU lease and the desktop has focus.

It reuses the retained `VQ-07` keyboard bootstrap contract: select the normal keyboard through `ControllerService`, instantiate ordinary `main.tscn`, attach the live `FlightSession`, and require input, physics, unpaused state and a disconnected radio. Before `main.tscn` loads, the trial bootstrap reads `OPENRC_TRIAL` and `OPENRC_GROUND_SHADER_OVERRIDE`, loads the production shader resource, assigns the selected source to `Shader.code`, then verifies that `Atmosphere.GROUND_SHADER` references that same mutated loader resource. Each engine process gets its own environment and exits before the next variant. No production source or on-disk shader is modified.

Run Stik/Club first:

```powershell
python tmp/perf-20261023/native-trial/native_active_pair.py `
  --scenario stik-club `
  --out tmp/perf-20261023/native-trial/stik-club-abba-01
```

If that comparison warrants the second aircraft, run it separately:

```powershell
python tmp/perf-20261023/native-trial/native_active_pair.py `
  --scenario avanti-green `
  --out tmp/perf-20261023/native-trial/avanti-green-abba-01
```

Each command runs exactly four sequential processes in **baseline, candidate, candidate, baseline** order. Every process uses the pinned Godot 4.7.2 console launcher, native Compatibility renderer, 1920×1080 fullscreen on screen 0, explicit `--max-fps 0` with the normal VSync setting, dummy audio, and a neutral keyboard-controlled active flight. The logger captures 10 seconds of warm-up plus 60 seconds of measured wall time and enables `--frame-diagnostics`. The script stops after an invalid/incomplete run and retains the artifacts already produced. The output directory must be new.

The Stik/Club condition is `jensen-das-ugly-stik-60` / `club_field`; Avanti/Green is `sebart-avanti-s-a200-p100rx` / `green_paradise`. Both use `airborne_half_power`, pilot camera, and the same view arguments. Per-run artifacts include the exact command, process environment variant and shader hashes, checked console log/report, frame JSON, offline `frame_diagnose.py` result, plus optional 1 Hz `nvidia-smi` utilization/clock/temperature/power CSV. The campaign result compares **run-level** frame/render percentiles and the two adjacent baseline/candidate pairs; it never pools frame samples to claim confidence.

The native frame report retains measured start/end ticks, simulation active/paused/fault state, input-enabled state, end-of-run crash/focus/hold state, window size, VSync/cap and renderer timing metadata. Those session flags are end snapshots rather than a pause/focus/crash history. `run.json` records both the on-disk production source identities and the exact selected override file hashes; the bootstrap hashes the normalized runtime `Shader.code` and requires it to match the per-process source identity before loading `main.tscn`. Thus the frame report's built-in code provenance remains an on-disk source hash, while the selected runtime shader hash is separately verified and retained. `physics_step_usec` is the configured/smoothed step monitor, not a per-tick CPU-cost measurement. GPU timing is delayed by Godot and zeros are ambiguous; the reducer reports a GPU p95 as usable only when native timing is available and at least 95% of measured samples are positive. Engine `render_video_memory_bytes` is an engine estimate, not process RSS or free VRAM. FPS does not qualify physics.

Do not interpret this as display, driver, pilot or broad hardware qualification. The known desktop is a virtual 1920×1080 output with persistent video/GPU clients. WSL is currently unavailable on this host; use the pinned native Windows engine for this measurement. The short offscreen pilot trial showed clock/drift sensitivity, so interpret each ABBA as two run-level paired observations and repeat after any apparent gain before promotion.
