from pathlib import Path
import json, hashlib, zipfile, subprocess
root=Path(__file__).resolve().parents[2]
src=Path(__file__).resolve().parent
dest=root/'docs/research/visual-quality-implementation/VQ-01c/runtime-audit-2026-10-23'
records=[]
pngs=[]
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in sorted(src.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:
            continue
        if p.suffix.lower()=='.png':
            pngs.append({'path':str(p.relative_to(root)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
            continue
        if p.suffix.lower() not in {'.json','.gd','.gdshader','.py','.log','.csv','.md'}:
            continue
        data=p.read_bytes()
        name=str(p.relative_to(src)).replace('\\','/')
        archive.writestr(name,data)
        records.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    production={}
    for name in ['app/audio/ground_audio_model.gd','app/main.gd','app/tests/test_ground_audio.gd','app/render/ground.gdshader','app/render/windsock.gd']:
        data=(root/name).read_bytes()
        production[name]=hashlib.sha256(data).hexdigest()
        archive.writestr('final-source/'+name,data)
manifest={'format':'openrc-runtime-audit-evidence v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
          'production_sha256':production,'files':records,'excluded_png_sha256':pngs,
          'archive_sha256':hashlib.sha256((dest/'evidence.zip').read_bytes()).hexdigest(),
          'limits':['No images retained in archive','See README for rejected and invalid measurements','Absolute-path probes target this Windows checkout; use retained commands and matching repository revision']}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Bundled',len(records),'artifacts;', (dest/'evidence.zip').stat().st_size,'bytes; PNGs excluded',len(pngs))
