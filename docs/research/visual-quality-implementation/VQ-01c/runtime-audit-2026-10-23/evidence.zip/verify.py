from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parents[2]
out=root/'tmp/perf-20261023/verification'
scripts=['test_ground_contact','test_lake_ground_contact','test_lake_session','test_wheel_session','test_engine_audio','test_powertrain_audio','test_glow_audio','test_audio_bus_freshness','test_frame_samples','test_golden','test_checkpoint','test_simulation']
rows=[]
for name in scripts:
    cmd=[sys.executable,str(root/'tools/godot/run_checked.py'),'--out-dir',str(out/name),'--timeout','180','--',str(root/'.tools/Godot_v4.7.2-stable_win64_console.exe'),'--headless','--path',str(root/'app'),'--audio-driver','Dummy','--script',f'res://tests/{name}.gd']
    result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
    reports=list((out/name).glob('*/report.json'))
    report=json.loads(reports[-1].read_text()) if reports else {}
    rows.append({'test':name,'exit':result.returncode,'report':str(reports[-1]) if reports else '', 'counts':report.get('counts')})
    print(name,result.returncode,report.get('counts'),flush=True)
    if result.returncode: print(result.stdout[-4000:],result.stderr[-2000:],flush=True)
    (out/'summary.json').write_text(json.dumps(rows,indent=2))
sys.exit(1 if any(r['exit'] for r in rows) else 0)
