from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'field'
out.mkdir(exist_ok=True)
source = root / 'app/render/field.gd'
text = source.read_text(encoding='utf-8')
marks = [
 ('ground', '\tvar front_azimuth := Treeline.front_azimuth_deg(field)'),
 ('trees', '\tfor cue: Dictionary in field.get("flight_cues", []):'),
 ('cues', '\tvar scenery_options := Scenery.options()'),
 ('lake_resolve', '\tScenery.attach(result, field, lighting, lake)'),
 ('scenery', '\tvar lake_node := LakeWorld.attach'),
 ('lake', '\tvar scenery_node := result.get_node_or_null("Scenery")'),
 ('grass', '\tif LandscapeOptions.enabled() and field.get("id", "") == "default":'),
 ('ridges_countryside', '\tFieldProjectedShadows.attach(result, field, lighting)'),
 ('shadows', '\tresult.set_meta("lighting_materials", materials)'),
]
text = text.replace('\tvar result: Node3D = Node3D.new()', '\tvar perf_start := Time.get_ticks_usec()\n\tvar result: Node3D = Node3D.new()', 1)
for name, marker in marks:
 assert marker in text, marker
 text = text.replace(marker, '\tprint("FIELD_PHASE '+name+' ", Time.get_ticks_usec() - perf_start)\n\tperf_start = Time.get_ticks_usec()\n'+marker, 1)
(out/'profiled_field.gd').write_text(text, encoding='utf-8')
(out/'identity.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'profile_sha256':hashlib.sha256(text.encode()).hexdigest()},indent=2))
probe = '''extends SceneTree
func _initialize() -> void:
    _run.call_deferred()
func _run() -> void:
    load("res://render/shader_clock.gd").register()
    var field: Dictionary = load("res://data/field_loader.gd").load_from()
    assert(field.ok)
    var builder: Script = load("%s")
    for i in 2:
        var begin := Time.get_ticks_usec()
        var built: Node3D = builder.build(field.field)
        print("FIELD_TOTAL ", i, " ", Time.get_ticks_usec() - begin)
        root.add_child(built)
        await process_frame
        built.queue_free()
        await process_frame
    quit()
''' % (out/'profiled_field.gd').as_posix()
(out/'probe.gd').write_text(probe,encoding='utf-8')
print(out)
