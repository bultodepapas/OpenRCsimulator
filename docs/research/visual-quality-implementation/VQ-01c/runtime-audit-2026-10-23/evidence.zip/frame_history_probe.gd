extends SceneTree
const Hud = preload("res://render/hud.gd")
const COUNT := 20000
var mismatches := 0
func _initialize() -> void:
	var baseline := PackedFloat64Array()
	var candidate := PackedFloat64Array()
	var tape := PackedFloat64Array()
	var source = JSON.parse_string(FileAccess.get_file_as_string("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/native-trial/stik-club-abba-01/runs/stik-club-01-baseline/frametimes.json"))
	for value in source.frame_deltas_s:
		tape.append(float(value))
	if tape.is_empty():
		printerr("Empty frame tape")
		quit(1)
		return
	for value in tape:
		baseline.append(value)
		candidate.append(value)
		if baseline.size() > Hud.FRAMES:
			baseline = baseline.slice(baseline.size()-Hud.FRAMES)
		if candidate.size() > Hud.FRAMES:
			candidate.remove_at(0)
		if baseline.to_byte_array() != candidate.to_byte_array() or Hud.perf_line(baseline, 1000.0) != Hud.perf_line(candidate, 1000.0):
			mismatches += 1
	for i in 4:
		_measure(false, tape)
		_measure(true, tape)
	var pairs: Array[Dictionary] = []
	for i in 30:
		var pair := {}
		for arm in ([false,true] if i % 2 == 0 else [true,false]):
			pair["candidate" if arm else "baseline"] = _measure(arm, tape)
		pairs.append(pair)
	var report := {mismatches=mismatches, frames=tape.size(), paired_update_usec=pairs,
		iterations_per_arm=COUNT, capacity=Hud.FRAMES, engine=Engine.get_version_info()}
	FileAccess.open("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/frame-history-result.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Frame history parity mismatches: ",mismatches)
	quit(0 if mismatches == 0 else 1)
func _measure(candidate: bool, tape: PackedFloat64Array) -> float:
	var history := PackedFloat64Array()
	history.resize(Hud.FRAMES)
	var start := Time.get_ticks_usec()
	if candidate:
		for i in COUNT:
			history.append(tape[i % tape.size()])
			if history.size() > Hud.FRAMES:
				history.remove_at(0)
	else:
		for i in COUNT:
			history.append(tape[i % tape.size()])
			if history.size() > Hud.FRAMES:
				history = history.slice(history.size()-Hud.FRAMES)
	return float(Time.get_ticks_usec() - start) / COUNT
