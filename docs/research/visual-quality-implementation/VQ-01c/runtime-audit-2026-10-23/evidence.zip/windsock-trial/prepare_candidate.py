from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

TRIAL_DIR = Path(__file__).resolve().parent
REPO = TRIAL_DIR.parents[2]
SOURCE = REPO / "app" / "render" / "windsock.gd"
BASELINE = TRIAL_DIR / "windsock-baseline.gd"
CANDIDATE = TRIAL_DIR / "windsock-candidate.gd"
METADATA = TRIAL_DIR / "candidate-change.json"
OLD = "\tvar mapped := ArrayMesh.new()\n\tmapped.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)\n\tvar surface := SurfaceTool.new()\n\tsurface.create_from(mapped, 0)"
NEW = "\tvar surface := SurfaceTool.new()\n\tsurface.create_from_arrays(arrays, Mesh.PRIMITIVE_TRIANGLES)"

source = SOURCE.read_text(encoding="utf-8")
count = source.count(OLD)
if count != 1:
    raise SystemExit(f"expected exactly one target block in {SOURCE}, found {count}")
candidate = source.replace(OLD, NEW, 1)
BASELINE.write_text(source, encoding="utf-8", newline="\n")
CANDIDATE.write_text(candidate, encoding="utf-8", newline="\n")

patch = "".join(difflib.unified_diff(
    source.splitlines(keepends=True), candidate.splitlines(keepends=True),
    fromfile="app/render/windsock.gd", tofile="tmp/perf-20261023/windsock-trial/windsock-candidate.gd"))
if not patch or patch.count("@@") != 2 or OLD in candidate:
    raise SystemExit("candidate source did not reduce to the single requested mesh conversion")
report = {
    "format": "openrc-windsock-trial-candidate v1",
    "source": "app/render/windsock.gd",
    "baseline": "tmp/perf-20261023/windsock-trial/windsock-baseline.gd",
    "candidate": "tmp/perf-20261023/windsock-trial/windsock-candidate.gd",
    "change": "Replace the mapped ArrayMesh plus SurfaceTool.create_from(mapped, 0) with SurfaceTool.create_from_arrays(arrays, Mesh.PRIMITIVE_TRIANGLES); keep generate_tangents() unchanged.",
    "scope": "No geometry, UV, normal, tangent, node, or material source edits.",
    "source_sha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
    "baseline_sha256": hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
    "candidate_sha256": hashlib.sha256(candidate.encode("utf-8")).hexdigest(),
    "baseline_matches_source": BASELINE.read_bytes() == source.encode("utf-8"),
    "single_block_replacement_verified": True,
}
METADATA.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
