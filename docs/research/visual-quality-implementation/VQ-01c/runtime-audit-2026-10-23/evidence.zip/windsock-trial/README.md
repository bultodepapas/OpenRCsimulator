# Windsock create-from-arrays trial

This is an isolated CPU comparison for the VQ04a windsock build. The production renderer remains unchanged. `prepare_candidate.py` copies the current `app/render/windsock.gd` to `windsock-baseline.gd` and generates `windsock-candidate.gd` by replacing only the temporary `ArrayMesh` plus `SurfaceTool.create_from(mapped, 0)` step with `SurfaceTool.create_from_arrays(arrays, Mesh.PRIMITIVE_TRIANGLES)`. It leaves `generate_tangents()` and every geometry, UV, normal, tangent, node, and material source unchanged. `candidate-change.json` records the source hashes and single-block check.

The GDScript harness registers the production `ShaderClock` global uniforms before creating materials, then follows the VQ04a default/minimum/maximum/non-round dimension grid. It compares every node path, class, stored property, and metadata value; each material slot, its property values, shader code and uniforms; material reference-alias groups; and every mesh surface-array slot byte-for-byte, including generated tangents. For changed normal and tangent arrays, mismatch details also include component maxima, vector/direction deltas, and tangent handedness changes. It then performs 24 untimed full builds per arm followed by 30 full-build pairs with alternating order. Cue duplication and freeing the returned root sit outside each timer. The report has raw paired microseconds, summary statistics, exact-array hashes, source hashes, and mismatch details.

The comparison runs both renderless/headless and with the native display/renderer. The native run does not draw a frame, so it checks the native resource path and build behavior but does not measure GPU time or visual output. Godot 4.7.2 uses the same `SurfaceTool` mesh-array parser for these two entry points; the standard pinned build uses float32 `real_t`. The intermediate `ArrayMesh` conversion can still narrow values in a double-precision engine build, so this probe's byte-parity result applies to the engine binary named in its JSON.

Run `prepare_candidate.py` before either comparison if the production baseline is still the intended source. On a fresh checkout, import the app once first using the pinned Godot build. Then run the following separately, on an idle machine, with a new output path for each run. The harness refuses to overwrite reports.

```powershell
$Godot = (Resolve-Path '.tools/Godot_v4.7.2-stable_win64_console.exe').Path
$Harness = (Resolve-Path 'tmp/perf-20261023/windsock-trial/compare_windsock_build.gd').Path
$Baseline = (Resolve-Path 'tmp/perf-20261023/windsock-trial/windsock-baseline.gd').Path
$Candidate = (Resolve-Path 'tmp/perf-20261023/windsock-trial/windsock-candidate.gd').Path
$HeadlessOut = (Join-Path (Get-Location).Path 'tmp/perf-20261023/windsock-trial/headless.json')
& $Godot --headless --path app --audio-driver Dummy --script $Harness -- `
  "--baseline=$Baseline" "--candidate=$Candidate" "--out=$HeadlessOut" '--mode=headless'
if ($LASTEXITCODE -ne 0) { throw 'Headless windsock trial failed; inspect engine output and JSON.' }
```

```powershell
$Godot = (Resolve-Path '.tools/Godot_v4.7.2-stable_win64_console.exe').Path
$Harness = (Resolve-Path 'tmp/perf-20261023/windsock-trial/compare_windsock_build.gd').Path
$Baseline = (Resolve-Path 'tmp/perf-20261023/windsock-trial/windsock-baseline.gd').Path
$Candidate = (Resolve-Path 'tmp/perf-20261023/windsock-trial/windsock-candidate.gd').Path
$NativeOut = (Join-Path (Get-Location).Path 'tmp/perf-20261023/windsock-trial/native2.json')
& $Godot --path app --audio-driver Dummy --script $Harness -- `
  "--baseline=$Baseline" "--candidate=$Candidate" "--out=$NativeOut" '--mode=native'
if ($LASTEXITCODE -ne 0) { throw 'Native windsock trial failed; inspect engine output and JSON.' }
```
