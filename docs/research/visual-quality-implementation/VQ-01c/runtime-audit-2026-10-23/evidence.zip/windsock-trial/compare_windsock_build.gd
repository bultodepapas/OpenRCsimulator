extends SceneTree
## Same-process VQ04a build-grid parity plus paired full Windsock.build timings.
## CPU construction only: the probe does not render a frame or measure GPU work.

const FieldLoader = preload("res://data/field_loader.gd")
const ShaderClock = preload("res://render/shader_clock.gd")
const BUILD_WARMUPS_PER_ARM: int = 24
const BUILD_TIMING_PAIRS: int = 30
const DETAIL_LIMIT: int = 32
const FABRIC_SHADER_PARAMETER_NAMES: Array[String] = [
	"fabric_color", "fabric_normal", "fabric_roughness",
	"length_m", "circumference_m", "throat_diameter_m", "tail_diameter_m",
	"basket_height_m", "arm_m", "basket_yaw_rad", "inflation", "centerline_points",
]
const SUPPORT_SHADER_PARAMETER_NAMES: Array[String] = [
	"metal_normal", "metal_roughness", "concrete_color", "concrete_normal",
]

var _baseline: Variant
var _candidate: Variant
var _baseline_path: String = ""
var _candidate_path: String = ""
var _out_path: String = ""
var _launch_mode: String = "unspecified"
var _mismatch_count: int = 0
var _mismatches: Array[Dictionary] = []


func _initialize() -> void:
	# Windsock deformation reads the production sim_clock global uniform.
	# Register it before any shader material is created or compiled by the probe.
	ShaderClock.register()
	var options: Dictionary = _parse_args(OS.get_cmdline_user_args())
	_baseline_path = str(options.get("baseline", "")).replace("\\", "/")
	_candidate_path = str(options.get("candidate", "")).replace("\\", "/")
	_out_path = str(options.get("out", "")).replace("\\", "/")
	_launch_mode = str(options.get("mode", "unspecified"))
	if _baseline_path.is_empty() or _candidate_path.is_empty() or _out_path.is_empty():
		_fail("--baseline, --candidate, and --out absolute paths are required")
		return
	if not _baseline_path.is_absolute_path() or not _candidate_path.is_absolute_path() \
			or not _out_path.is_absolute_path():
		_fail("--baseline, --candidate, and --out must be absolute paths")
		return
	if FileAccess.file_exists(_out_path):
		_fail("refusing to overwrite comparison output: " + _out_path)
		return
	if not FileAccess.file_exists(_baseline_path) or not FileAccess.file_exists(_candidate_path):
		_fail("baseline or candidate GDScript does not exist")
		return
	_baseline = load(_baseline_path)
	_candidate = load(_candidate_path)
	if _baseline == null or not _baseline is GDScript:
		_fail("could not load baseline GDScript: " + _baseline_path)
		return
	if _candidate == null or not _candidate is GDScript:
		_fail("could not load candidate GDScript: " + _candidate_path)
		return
	_run()


func _run() -> void:
	var loaded: Dictionary = FieldLoader.load_from()
	if not bool(loaded.get("ok", false)):
		_fail("default field failed validation: " + str(loaded.get("errors", [])), 1)
		return
	var cues: Array = loaded.get("field", {}).get("flight_cues", []).filter(
		func(cue: Dictionary) -> bool: return cue.get("type") == "windsock")
	if cues.size() != 1:
		_fail("expected exactly one validated default windsock cue", 1)
		return
	var default_cue: Dictionary = cues[0]
	var fixtures: Array[Dictionary] = [
		{"name": "default", "dimensions": {}},
		{"name": "minimum_valid_dimensions", "dimensions": {
			"length": 0.5, "pole_height": 2.0, "throat_diameter": 0.1, "tail_diameter": 0.05}},
		{"name": "maximum_valid_dimensions", "dimensions": {
			"length": 5.0, "pole_height": 10.0, "throat_diameter": 1.0, "tail_diameter": 0.99}},
		{"name": "non_round_valid_dimensions", "dimensions": {
			"length": 1.234567, "pole_height": 3.6,
			"throat_diameter": 0.314159, "tail_diameter": 0.12345}},
	]
	var fixture_reports: Array[Dictionary] = []
	var all_mesh_slots: int = 0
	var all_mesh_bytes: int = 0
	for fixture: Dictionary in fixtures:
		var cue: Dictionary = default_cue.duplicate(true)
		for dimension: String in fixture.dimensions:
			cue[dimension] = fixture.dimensions[dimension]
		var baseline_root: Node3D = _baseline.build(cue.duplicate(true))
		var candidate_root: Node3D = _candidate.build(cue.duplicate(true))
		if baseline_root == null or candidate_root == null:
			_fail("renderer returned a null root for " + str(fixture.name), 1)
			return
		var mismatch_start: int = _mismatch_count
		var node_report: Dictionary = _compare_nodes_and_materials(
			str(fixture.name), baseline_root, candidate_root)
		var mesh_report: Dictionary = _compare_mesh_arrays(
			str(fixture.name), baseline_root, candidate_root)
		fixture_reports.append({
			"name": fixture.name,
			"exact": _mismatch_count == mismatch_start,
			"node_count": node_report.node_count,
			"material_bindings_checked": node_report.material_bindings_checked,
			"mesh_surfaces_checked": mesh_report.surface_count,
			"mesh_array_slots_checked": mesh_report.array_slots,
			"mesh_array_bytes_compared": mesh_report.array_bytes,
			"baseline_mesh_sha256": mesh_report.baseline_sha256,
			"candidate_mesh_sha256": mesh_report.candidate_sha256,
		})
		all_mesh_slots += int(mesh_report.array_slots)
		all_mesh_bytes += int(mesh_report.array_bytes)
		baseline_root.free()
		candidate_root.free()
	var timing: Dictionary = _measure_paired_builds(default_cue)
	var report := {
		"format": "openrc-windsock-build-trial v1",
		"complete": true,
		"passed": _mismatch_count == 0,
		"engine": Engine.get_version_info().string,
		"platform": OS.get_name(),
		"launch_mode": _launch_mode,
		"display_server": DisplayServer.get_name(),
		"renderer": "headless" if DisplayServer.get_name() == "headless" else RenderingServer.get_current_rendering_method(),
		"adapter": "" if DisplayServer.get_name() == "headless" else RenderingServer.get_video_adapter_name(),
		"fixture": "VQ04a validated default windsock plus min/max/non-round build-grid dimensions",
		"parity": {
			"scope": "all node trees and stored node properties, material assignments and material properties, every mesh surface and every surface-array slot byte-for-byte",
			"geometry_uv_normal_tangent_generation_source": "unchanged; generated arrays, including normals and tangents, are compared byte-for-byte",
			"fixtures": fixture_reports,
			"fixtures_exact": _mismatch_count == 0,
			"mesh_array_slots_checked": all_mesh_slots,
			"mesh_array_bytes_compared": all_mesh_bytes,
			"mismatch_count": _mismatch_count,
			"mismatch_details": _mismatches,
		},
		"build_timing": timing,
		"sources_sha256": {
			"baseline_renderer": FileAccess.get_sha256(_baseline_path),
			"candidate_renderer": FileAccess.get_sha256(_candidate_path),
			"harness": FileAccess.get_sha256(get_script().resource_path),
		},
		"limitations": "Full Windsock.build CPU construction only; no frame rendering, GPU timing, or full-flight performance claim.",
	}
	DirAccess.make_dir_recursive_absolute(_out_path.get_base_dir())
	var output := FileAccess.open(_out_path, FileAccess.WRITE)
	if output == null:
		_fail("cannot create report: " + _out_path, 2)
		return
	output.store_string(JSON.stringify(report, "\t") + "\n")
	output.close()
	print("Windsock trial: %d array slots, %d mismatches; wrote %s" % [
		all_mesh_slots, _mismatch_count, _out_path])
	quit(0 if _mismatch_count == 0 else 1)


func _compare_nodes_and_materials(
		case_name: String, baseline_root: Node3D, candidate_root: Node3D) -> Dictionary:
	var baseline_nodes: Array[Dictionary] = []
	var candidate_nodes: Array[Dictionary] = []
	_collect_nodes(baseline_root, ".", baseline_nodes)
	_collect_nodes(candidate_root, ".", candidate_nodes)
	_compare_value("nodes.count", baseline_nodes.size(), candidate_nodes.size(), {"case": case_name})
	var material_bindings: int = 0
	var baseline_reference_groups: Dictionary = {}
	var candidate_reference_groups: Dictionary = {}
	for index: int in range(maxi(baseline_nodes.size(), candidate_nodes.size())):
		var context := {"case": case_name, "node_index": index}
		var has_baseline: bool = index < baseline_nodes.size()
		var has_candidate: bool = index < candidate_nodes.size()
		_compare_value("nodes.present", has_baseline, has_candidate, context)
		if not has_baseline or not has_candidate:
			continue
		var baseline_row: Dictionary = baseline_nodes[index]
		var candidate_row: Dictionary = candidate_nodes[index]
		context.path = baseline_row.path
		_compare_value("nodes.path", baseline_row.path, candidate_row.path, context)
		var baseline_node: Node = baseline_row.node
		var candidate_node: Node = candidate_row.node
		_compare_value("nodes.class", baseline_node.get_class(), candidate_node.get_class(), context)
		_compare_value("nodes.properties_and_metadata",
			_node_snapshot(baseline_node), _node_snapshot(candidate_node), context)
		if baseline_node is MeshInstance3D or candidate_node is MeshInstance3D:
			material_bindings += _compare_material_bindings(
				case_name, str(baseline_row.path), baseline_node, candidate_node,
				baseline_reference_groups, candidate_reference_groups)
	var baseline_fabric: MeshInstance3D = baseline_root.get_node_or_null("Fabric") as MeshInstance3D
	var candidate_fabric: MeshInstance3D = candidate_root.get_node_or_null("Fabric") as MeshInstance3D
	if baseline_fabric != null and candidate_fabric != null \
			and baseline_fabric.mesh != null and candidate_fabric.mesh != null:
		var baseline_view: Dictionary = baseline_root.get_meta("_windsock_view", {})
		var candidate_view: Dictionary = candidate_root.get_meta("_windsock_view", {})
		var baseline_meta_material: Material = baseline_view.get("material") as Material
		var candidate_meta_material: Material = candidate_view.get("material") as Material
		_compare_value("materials.metadata_fabric_reference_alias",
			baseline_meta_material == baseline_fabric.mesh.surface_get_material(0),
			candidate_meta_material == candidate_fabric.mesh.surface_get_material(0),
			{"case": case_name, "node": "Fabric"})
	return {"node_count": baseline_nodes.size(), "material_bindings_checked": material_bindings}


func _collect_nodes(node: Node, path: String, result: Array[Dictionary]) -> void:
	result.append({"path": path, "node": node})
	for child: Node in node.get_children():
		_collect_nodes(child, path + "/" + str(child.name), result)


func _node_snapshot(node: Node) -> Dictionary:
	var properties: Dictionary = {}
	for property: Dictionary in node.get_property_list():
		if (int(property.get("usage", 0)) & PROPERTY_USAGE_STORAGE) == 0:
			continue
		var property_name: String = str(property.name)
		properties[property_name] = _value_snapshot(node.get(property_name))
	var metadata: Dictionary = {}
	for meta_name: StringName in node.get_meta_list():
		metadata[str(meta_name)] = _value_snapshot(node.get_meta(meta_name))
	return {"name": str(node.name), "class": node.get_class(), "properties": properties, "metadata": metadata}


func _compare_material_bindings(
		case_name: String, node_path: String, baseline_node: Node, candidate_node: Node,
		baseline_reference_groups: Dictionary, candidate_reference_groups: Dictionary) -> int:
	var context := {"case": case_name, "node": node_path}
	var baseline_is_mesh: bool = baseline_node is MeshInstance3D
	var candidate_is_mesh: bool = candidate_node is MeshInstance3D
	_compare_value("materials.mesh_instance_present", baseline_is_mesh, candidate_is_mesh, context)
	if not baseline_is_mesh or not candidate_is_mesh:
		return 0
	var baseline_instance: MeshInstance3D = baseline_node as MeshInstance3D
	var candidate_instance: MeshInstance3D = candidate_node as MeshInstance3D
	_compare_value("materials.material_override",
		_material_assignment_snapshot(baseline_instance.material_override, baseline_reference_groups),
		_material_assignment_snapshot(candidate_instance.material_override, candidate_reference_groups), context)
	var baseline_mesh: Mesh = baseline_instance.mesh
	var candidate_mesh: Mesh = candidate_instance.mesh
	if baseline_mesh == null or candidate_mesh == null:
		return 0
	var baseline_count: int = baseline_mesh.get_surface_count()
	var candidate_count: int = candidate_mesh.get_surface_count()
	_compare_value("materials.surface_count", baseline_count, candidate_count, context)
	var checked: int = 0
	for surface_index: int in range(maxi(baseline_count, candidate_count)):
		var surface_context: Dictionary = context.duplicate(true)
		surface_context.surface = surface_index
		var baseline_surface_material: Material = baseline_mesh.surface_get_material(surface_index) \
			if surface_index < baseline_count else null
		var candidate_surface_material: Material = candidate_mesh.surface_get_material(surface_index) \
			if surface_index < candidate_count else null
		var baseline_override: Material = baseline_instance.get_surface_override_material(surface_index) \
			if surface_index < baseline_count else null
		var candidate_override: Material = candidate_instance.get_surface_override_material(surface_index) \
			if surface_index < candidate_count else null
		_compare_value("materials.surface_assignment",
			_material_assignment_snapshot(baseline_surface_material, baseline_reference_groups),
			_material_assignment_snapshot(candidate_surface_material, candidate_reference_groups), surface_context)
		_compare_value("materials.surface_override",
			_material_assignment_snapshot(baseline_override, baseline_reference_groups),
			_material_assignment_snapshot(candidate_override, candidate_reference_groups), surface_context)
		checked += 2
	return checked + 1


func _material_snapshot(material: Material) -> Variant:
	if material == null:
		return null
	var result: Dictionary = {
		"reference": _resource_reference(material),
		"stored_properties": _stored_property_snapshot(material),
	}
	if material is ShaderMaterial:
		var shader_material: ShaderMaterial = material as ShaderMaterial
		var shader: Shader = shader_material.shader
		result["shader"] = _resource_reference(shader)
		result["shader_code_sha256"] = _sha256_text(shader.code) if shader != null else ""
		var parameters: Dictionary = {}
		var parameter_names: Array[String] = SUPPORT_SHADER_PARAMETER_NAMES \
			if shader != null and shader.resource_path.ends_with("windsock_support.gdshader") \
			else FABRIC_SHADER_PARAMETER_NAMES
		for parameter: String in parameter_names:
			parameters[parameter] = _value_snapshot(shader_material.get_shader_parameter(parameter))
		result["shader_parameters"] = parameters
	return result


func _material_assignment_snapshot(material: Material, reference_groups: Dictionary) -> Variant:
	if material == null:
		return null
	var instance_id: int = material.get_instance_id()
	if not reference_groups.has(instance_id):
		reference_groups[instance_id] = reference_groups.size()
	return {"reference_group": reference_groups[instance_id], "material": _material_snapshot(material)}


func _stored_property_snapshot(object: Object) -> Dictionary:
	var properties: Dictionary = {}
	for property: Dictionary in object.get_property_list():
		if (int(property.get("usage", 0)) & PROPERTY_USAGE_STORAGE) == 0:
			continue
		var property_name: String = str(property.name)
		properties[property_name] = _value_snapshot(object.get(property_name))
	return properties


func _resource_reference(resource: Resource) -> Dictionary:
	return {
		"class": resource.get_class(),
		"path": resource.resource_path,
		"name": resource.resource_name,
		"local_to_scene": resource.resource_local_to_scene,
	}


func _value_snapshot(value: Variant) -> Variant:
	if value == null:
		return null
	if value is Resource:
		return {"resource": _resource_reference(value as Resource)}
	if value is Node:
		var object_script: Script = (value as Node).get_script() as Script
		return {"node": (value as Node).get_class(), "name": str((value as Node).name),
			"script": "" if object_script == null else object_script.resource_path}
	if value is Object:
		var object_script: Script = (value as Object).get_script() as Script
		return {"object": (value as Object).get_class(),
			"script": "" if object_script == null else object_script.resource_path}
	if value is Vector2:
		return [value.x, value.y]
	if value is Vector2i:
		return [value.x, value.y]
	if value is Vector3:
		return [value.x, value.y, value.z]
	if value is Vector3i:
		return [value.x, value.y, value.z]
	if value is Vector4:
		return [value.x, value.y, value.z, value.w]
	if value is Vector4i:
		return [value.x, value.y, value.z, value.w]
	if value is Color:
		return [value.r, value.g, value.b, value.a]
	if value is AABB:
		return {"position": _value_snapshot(value.position), "size": _value_snapshot(value.size)}
	if value is Rect2:
		return {"position": _value_snapshot(value.position), "size": _value_snapshot(value.size)}
	if value is Basis:
		return {"x": _value_snapshot(value.x), "y": _value_snapshot(value.y), "z": _value_snapshot(value.z)}
	if value is Quaternion:
		return [value.x, value.y, value.z, value.w]
	if value is Transform2D:
		return {"x": _value_snapshot(value.x), "y": _value_snapshot(value.y),
			"origin": _value_snapshot(value.origin)}
	if value is Transform3D:
		return {"basis": _value_snapshot(value.basis), "origin": _value_snapshot(value.origin)}
	if value is Plane:
		return {"normal": _value_snapshot(value.normal), "d": value.d}
	if value is NodePath or value is StringName:
		return str(value)
	if value is Dictionary:
		var dictionary: Dictionary = {}
		for key: Variant in value:
			dictionary[str(key)] = _value_snapshot(value[key])
		return dictionary
	if value is Array:
		var array: Array = []
		for item: Variant in value:
			array.append(_value_snapshot(item))
		return array
	return value


func _compare_mesh_arrays(
		case_name: String, baseline_root: Node3D, candidate_root: Node3D) -> Dictionary:
	var baseline_nodes: Array[Dictionary] = []
	var candidate_nodes: Array[Dictionary] = []
	_collect_nodes(baseline_root, ".", baseline_nodes)
	_collect_nodes(candidate_root, ".", candidate_nodes)
	var baseline_hash := HashingContext.new()
	var candidate_hash := HashingContext.new()
	baseline_hash.start(HashingContext.HASH_SHA256)
	candidate_hash.start(HashingContext.HASH_SHA256)
	var surfaces: int = 0
	var slots: int = 0
	var byte_count: int = 0
	for node_index: int in range(maxi(baseline_nodes.size(), candidate_nodes.size())):
		if node_index >= baseline_nodes.size() or node_index >= candidate_nodes.size():
			continue
		var baseline_node: Node = baseline_nodes[node_index].node
		var candidate_node: Node = candidate_nodes[node_index].node
		if not baseline_node is MeshInstance3D or not candidate_node is MeshInstance3D:
			continue
		var baseline_instance: MeshInstance3D = baseline_node as MeshInstance3D
		var candidate_instance: MeshInstance3D = candidate_node as MeshInstance3D
		var context := {"case": case_name, "node": str(baseline_nodes[node_index].path)}
		var baseline_mesh: Mesh = baseline_instance.mesh
		var candidate_mesh: Mesh = candidate_instance.mesh
		_compare_value("meshes.present", baseline_mesh != null, candidate_mesh != null, context)
		if baseline_mesh == null or candidate_mesh == null:
			continue
		_compare_value("meshes.aabb", _value_snapshot(baseline_mesh.get_aabb()),
			_value_snapshot(candidate_mesh.get_aabb()), context)
		var baseline_count: int = baseline_mesh.get_surface_count()
		var candidate_count: int = candidate_mesh.get_surface_count()
		_compare_value("meshes.surface_count", baseline_count, candidate_count, context)
		for surface_index: int in range(maxi(baseline_count, candidate_count)):
			var surface_context: Dictionary = context.duplicate(true)
			surface_context.surface = surface_index
			var has_baseline: bool = surface_index < baseline_count
			var has_candidate: bool = surface_index < candidate_count
			_compare_value("meshes.surface_present", has_baseline, has_candidate, surface_context)
			if not has_baseline or not has_candidate:
				continue
			surfaces += 1
			var baseline_primitive: int = baseline_mesh.surface_get_primitive_type(surface_index)
			var candidate_primitive: int = candidate_mesh.surface_get_primitive_type(surface_index)
			_compare_value("meshes.primitive_type", baseline_primitive, candidate_primitive, surface_context)
			var baseline_arrays: Array = baseline_mesh.surface_get_arrays(surface_index)
			var candidate_arrays: Array = candidate_mesh.surface_get_arrays(surface_index)
			_compare_value("meshes.array_slot_count", baseline_arrays.size(), candidate_arrays.size(), surface_context)
			var base_limit: int = maxi(baseline_arrays.size(), candidate_arrays.size())
			for array_index: int in range(base_limit):
				var array_context: Dictionary = surface_context.duplicate(true)
				array_context.array = array_index
				var baseline_value: Variant = baseline_arrays[array_index] if array_index < baseline_arrays.size() else null
				var candidate_value: Variant = candidate_arrays[array_index] if array_index < candidate_arrays.size() else null
				var baseline_bytes: PackedByteArray = _surface_array_bytes(baseline_value)
				var candidate_bytes: PackedByteArray = _surface_array_bytes(candidate_value)
				_compare_value("meshes.array_type", typeof(baseline_value), typeof(candidate_value), array_context)
				_compare_value("meshes.array_element_count", _packed_array_count(baseline_value),
					_packed_array_count(candidate_value), array_context)
				if baseline_bytes != candidate_bytes:
					var mismatch_details_before: int = _mismatches.size()
					_compare_value("meshes.array_bytes", _byte_summary(baseline_bytes),
						_byte_summary(candidate_bytes), array_context, true)
					if _mismatches.size() > mismatch_details_before:
						_mismatches[mismatch_details_before]["numeric_delta"] = _array_delta_summary(
							baseline_value, candidate_value, array_index)
				var label: PackedByteArray = (str(context.node) + "|" + str(surface_index) + "|" + str(array_index)
					+ "|" + str(typeof(baseline_value)) + "|" + str(_packed_array_count(baseline_value)) + "|").to_utf8_buffer()
				baseline_hash.update(label)
				baseline_hash.update(baseline_bytes)
				candidate_hash.update(label)
				candidate_hash.update(candidate_bytes)
				slots += 1
				byte_count += baseline_bytes.size()
	return {
		"surface_count": surfaces,
		"array_slots": slots,
		"array_bytes": byte_count,
		"baseline_sha256": baseline_hash.finish().hex_encode(),
		"candidate_sha256": candidate_hash.finish().hex_encode(),
	}


func _surface_array_bytes(value: Variant) -> PackedByteArray:
	if value is PackedByteArray:
		return value
	if value is PackedInt32Array or value is PackedInt64Array \
			or value is PackedFloat32Array or value is PackedFloat64Array \
			or value is PackedVector2Array or value is PackedVector3Array \
			or value is PackedVector4Array or value is PackedColorArray:
		return value.to_byte_array()
	return var_to_bytes(value)


func _packed_array_count(value: Variant) -> int:
	if value is PackedByteArray or value is PackedInt32Array or value is PackedInt64Array \
			or value is PackedFloat32Array or value is PackedFloat64Array \
			or value is PackedStringArray or value is PackedVector2Array \
			or value is PackedVector3Array or value is PackedVector4Array \
			or value is PackedColorArray:
		return value.size()
	return -1


func _byte_summary(bytes: PackedByteArray) -> Dictionary:
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(bytes)
	return {"byte_count": bytes.size(), "sha256": hash.finish().hex_encode()}


func _array_delta_summary(baseline: Variant, candidate: Variant, array_index: int) -> Dictionary:
	if baseline is PackedVector3Array and candidate is PackedVector3Array \
			and baseline.size() == candidate.size():
		var component_max: Array[float] = [0.0, 0.0, 0.0]
		var max_length_delta: float = 0.0
		var max_direction_delta_deg: float = 0.0
		for index: int in range(baseline.size()):
			var before: Vector3 = baseline[index]
			var after: Vector3 = candidate[index]
			var delta: Vector3 = after - before
			component_max[0] = maxf(component_max[0], absf(delta.x))
			component_max[1] = maxf(component_max[1], absf(delta.y))
			component_max[2] = maxf(component_max[2], absf(delta.z))
			max_length_delta = maxf(max_length_delta, delta.length())
			if before.length_squared() > 0.0 and after.length_squared() > 0.0:
				var cosine: float = clampf(before.normalized().dot(after.normalized()), -1.0, 1.0)
				max_direction_delta_deg = maxf(max_direction_delta_deg, rad_to_deg(acos(cosine)))
		return {
			"meaning": "normal" if array_index == Mesh.ARRAY_NORMAL else "vector3",
			"element_count": baseline.size(),
			"max_abs_by_component": component_max,
			"max_abs_component": maxf(component_max[0], maxf(component_max[1], component_max[2])),
			"max_vector_delta_length": max_length_delta,
			"max_direction_delta_deg": max_direction_delta_deg,
		}
	if baseline is PackedFloat32Array and candidate is PackedFloat32Array \
			and baseline.size() == candidate.size():
		var component_max: Array[float] = [0.0, 0.0, 0.0, 0.0]
		var max_direction_delta_deg: float = 0.0
		var handedness_sign_changes: int = 0
		for index: int in range(baseline.size()):
			var component: int = index % 4
			var before: float = baseline[index]
			var after: float = candidate[index]
			component_max[component] = maxf(component_max[component], absf(after - before))
			if component == 3:
				if (before < 0.0) != (after < 0.0):
					handedness_sign_changes += 1
			elif component == 2:
				var base_offset: int = index - 2
				var before_xyz := Vector3(baseline[base_offset], baseline[base_offset + 1], baseline[base_offset + 2])
				var after_xyz := Vector3(candidate[base_offset], candidate[base_offset + 1], candidate[base_offset + 2])
				if before_xyz.length_squared() > 0.0 and after_xyz.length_squared() > 0.0:
					var cosine: float = clampf(before_xyz.normalized().dot(after_xyz.normalized()), -1.0, 1.0)
					max_direction_delta_deg = maxf(max_direction_delta_deg, rad_to_deg(acos(cosine)))
		return {
			"meaning": "tangent_xyzw" if array_index == Mesh.ARRAY_TANGENT else "float32_groups_of_4",
			"element_count": baseline.size(),
			"max_abs_by_xyzw_component": component_max,
			"max_abs_xyz_component": maxf(component_max[0], maxf(component_max[1], component_max[2])),
			"max_abs_w_component": component_max[3],
			"max_direction_delta_deg": max_direction_delta_deg,
			"w_sign_changes": handedness_sign_changes,
		}
	return {"meaning": "non-numeric-or-different-array-type", "baseline_type": typeof(baseline),
		"candidate_type": typeof(candidate), "baseline_count": _packed_array_count(baseline),
		"candidate_count": _packed_array_count(candidate)}


func _measure_paired_builds(cue: Dictionary) -> Dictionary:
	for warmup: int in range(BUILD_WARMUPS_PER_ARM):
		if warmup % 2 == 0:
			_warm_build(_baseline, cue)
			_warm_build(_candidate, cue)
		else:
			_warm_build(_candidate, cue)
			_warm_build(_baseline, cue)
	var samples: Array[Dictionary] = []
	for pair: int in range(BUILD_TIMING_PAIRS):
		var baseline_usec: int
		var candidate_usec: int
		var first: String = "baseline" if pair % 2 == 0 else "candidate"
		if first == "baseline":
			baseline_usec = _measure_build(_baseline, cue)
			candidate_usec = _measure_build(_candidate, cue)
		else:
			candidate_usec = _measure_build(_candidate, cue)
			baseline_usec = _measure_build(_baseline, cue)
		samples.append({"pair": pair + 1, "first": first,
			"baseline_build_usec": baseline_usec,
			"candidate_build_usec": candidate_usec,
			"candidate_minus_baseline_usec": candidate_usec - baseline_usec})
	var baseline_values: Array[float] = []
	var candidate_values: Array[float] = []
	var paired_deltas: Array[float] = []
	for sample: Dictionary in samples:
		baseline_values.append(float(sample.baseline_build_usec))
		candidate_values.append(float(sample.candidate_build_usec))
		paired_deltas.append(float(sample.candidate_minus_baseline_usec))
	var baseline_summary: Dictionary = _timing_summary(baseline_values)
	var candidate_summary: Dictionary = _timing_summary(candidate_values)
	var delta_summary: Dictionary = _timing_summary(paired_deltas)
	var mean_baseline: float = float(baseline_summary.mean_usec)
	var mean_candidate: float = float(candidate_summary.mean_usec)
	return {
		"method": "Full Windsock.build; cue duplication before timer and root.free() after timer; paired order alternates.",
		"fixture": "validated default field windsock",
		"warmup_builds_per_arm": BUILD_WARMUPS_PER_ARM,
		"pairs": BUILD_TIMING_PAIRS,
		"baseline": baseline_summary,
		"candidate": candidate_summary,
		"paired_delta": delta_summary,
		"mean_speedup_ratio": mean_baseline / maxf(mean_candidate, 1.0),
		"mean_reduction_percent": (1.0 - mean_candidate / maxf(mean_baseline, 1.0)) * 100.0,
		"raw_pairs": samples,
	}


func _warm_build(script: Variant, cue: Dictionary) -> void:
	var root: Node3D = script.build(cue.duplicate(true))
	if root != null:
		root.free()


func _measure_build(script: Variant, cue: Dictionary) -> int:
	var build_cue: Dictionary = cue.duplicate(true)
	var began: int = Time.get_ticks_usec()
	var root: Node3D = script.build(build_cue)
	var elapsed: int = Time.get_ticks_usec() - began
	if root != null:
		root.free()
	return elapsed


func _timing_summary(values: Array[float]) -> Dictionary:
	var sorted: Array[float] = values.duplicate()
	sorted.sort()
	var total: float = 0.0
	for value: float in values:
		total += value
	var median: float = 0.0
	if not sorted.is_empty():
		var middle: int = sorted.size() / 2
		median = sorted[middle] if sorted.size() % 2 == 1 else (sorted[middle - 1] + sorted[middle]) * 0.5
	return {"mean_usec": total / maxf(float(values.size()), 1.0), "median_usec": median,
		"samples": values}


func _sha256_text(value: String) -> String:
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(value.to_utf8_buffer())
	return hash.finish().hex_encode()


func _compare_value(
		label: String, baseline: Variant, candidate: Variant, context: Dictionary,
		force_mismatch: bool = false) -> void:
	if not force_mismatch and baseline == candidate:
		return
	_mismatch_count += 1
	if _mismatches.size() < DETAIL_LIMIT:
		_mismatches.append({"context": context.duplicate(true), "field": label,
			"baseline": baseline, "candidate": candidate})


func _parse_args(args: PackedStringArray) -> Dictionary:
	var result: Dictionary = {}
	for argument: String in args:
		if argument.begins_with("--baseline="):
			result["baseline"] = argument.trim_prefix("--baseline=")
		elif argument.begins_with("--candidate="):
			result["candidate"] = argument.trim_prefix("--candidate=")
		elif argument.begins_with("--out="):
			result["out"] = argument.trim_prefix("--out=")
		elif argument.begins_with("--mode="):
			result["mode"] = argument.trim_prefix("--mode=")
	return result


func _fail(message: String, code: int = 2) -> void:
	printerr(message)
	quit(code)
