extends SceneTree

const FlightSession := preload("res://sim/flight_session.gd")
const Aero := preload("res://physics/aero.gd")
const Air := preload("res://physics/air_data.gd")
const GroundEffect := preload("res://physics/ground_effect.gd")
const M := preload("res://physics/math3d.gd")
const RB := preload("res://physics/rigid_body.gd")
const SAMPLES := 50000
const PAIRS := 10

func _initialize() -> void:
	var session := FlightSession.new()
	session.setup(FlightSession.Scenarios.AIRCRAFT)
	session.reset()
	var state: PackedFloat64Array = session.sim.state
	var model: Dictionary = session.aircraft.model
	var d: Dictionary = session._deflections(session.sim.aux)
	var air: Dictionary = session.air_data(state, 0.0)
	var downwash: float = session.sim.aux[session.downwash_index()] if session.downwash_index() >= 0 else NAN
	var ge: PackedFloat64Array = GroundEffect.factors(state, model, NAN)
	var local_weight: float = Aero.local_flow_weight(state, air, d, model, downwash, ge)
	var prop: Dictionary = model.propulsion
	print("PROFILE case=Stik-trim stations=%d local_weight=%.9f downwash_nan=%s ge_size=%d slipstream=%s" % [model.envelope.station_ys.size(), local_weight, str(is_nan(downwash)), ge.size(), str(not prop.get("slipstream", {}).is_empty())])
	var exact_cases := 0
	var rng := RandomNumberGenerator.new()
	rng.seed = 0x51A0
	var probe: PackedFloat64Array = state.duplicate()
	for i in 1000:
		probe[RB.VEL] = rng.randf_range(-40.0, 60.0)
		probe[RB.VEL + 1] = rng.randf_range(-20.0, 20.0)
		probe[RB.VEL + 2] = rng.randf_range(-20.0, 20.0)
		probe[RB.RATE] = rng.randf_range(-4.0, 4.0)
		probe[RB.RATE + 1] = rng.randf_range(-4.0, 4.0)
		probe[RB.RATE + 2] = rng.randf_range(-4.0, 4.0)
		var probe_air: Dictionary = session.air_data(probe, 0.0)
		var reference: float = Aero.local_flow_weight(probe, probe_air, d, model, downwash, ge)
		var candidate: float = _candidate_local_flow_weight(probe, probe_air, d, model, downwash, ge)
		if PackedFloat64Array([reference]).to_byte_array() != PackedFloat64Array([candidate]).to_byte_array():
			push_error("exactness mismatch case %d: %s vs %s" % [i, str(reference), str(candidate)])
			quit(2)
			return
		exact_cases += 1
	print("EXACT candidate_vs_reference=%d/1000" % exact_cases)
	var base_times: Array[float] = []
	var candidate_times: Array[float] = []
	for pair in PAIRS:
		if pair % 2 == 0:
			base_times.append(_measure(func() -> void: Aero.local_flow_weight(state, air, d, model, downwash, ge)))
			candidate_times.append(_measure(func() -> void: _candidate_local_flow_weight(state, air, d, model, downwash, ge)))
		else:
			candidate_times.append(_measure(func() -> void: _candidate_local_flow_weight(state, air, d, model, downwash, ge)))
			base_times.append(_measure(func() -> void: Aero.local_flow_weight(state, air, d, model, downwash, ge)))
	base_times.sort()
	candidate_times.sort()
	print("TIMING reference_median_us=%.3f candidate_median_us=%.3f paired_median_reduction_pct=%.2f samples_per_batch=%d pairs=%d" % [_median(base_times), _median(candidate_times), 100.0 * (1.0 - _median(candidate_times) / _median(base_times)), SAMPLES, PAIRS])
	print("TIMING raw_reference=%s raw_candidate=%s" % [str(base_times), str(candidate_times)])
	session.free()
	quit()

func _measure(body: Callable) -> float:
	var start: int = Time.get_ticks_usec()
	for i in SAMPLES:
		body.call()
	return float(Time.get_ticks_usec() - start) / SAMPLES

func _median(values: Array[float]) -> float:
	return 0.5 * (values[values.size() / 2 - 1] + values[values.size() / 2])

func _candidate_local_flow_weight(s: PackedFloat64Array, air: Dictionary, d: Dictionary, model: Dictionary,
		downwash_cl: float, ge: PackedFloat64Array) -> float:
	var env: Dictionary = model.envelope
	var surfaces: Dictionary = model.surfaces
	var limit: float = surfaces.attached_limit
	var v: PackedFloat64Array = air.v_air
	var p: float = s[RB.RATE]
	var q: float = s[RB.RATE+1]
	var r: float = s[RB.RATE+2]
	var a1: float = env.a1
	var a1_span: float = a1 - limit
	var blend := maxf(Aero._smoothstep((absf(air.alpha)-limit)/a1_span), Aero.sideslip_weight(air.beta, env))
	if blend == 1.0:
		return blend
	var v0: float = v[0]
	var v1: float = v[1]
	var v2: float = v[2]
	var n1_span: float = float(env.n1) - limit
	var position: PackedFloat64Array = model.reference.arp_le
	var cg: PackedFloat64Array = model.cg_le
	var arm_x: float = -(position[0]-cg[0]) + 0.0
	var arm_y: float = position[1]-cg[1]
	var arm_z: float = -(position[2]-cg[2]) + 0.0
	var twist: PackedFloat64Array = surfaces.get("station_incidence", PackedFloat64Array())
	var has_twist := not twist.is_empty()
	var ys: PackedFloat64Array = env.station_ys
	var aileron_effect: float = surfaces.wing_aileron_effectiveness
	var da_right: float = d.aileron_right
	var da_left: float = d.aileron_left
	for i in ys.size():
		var y: float = ys[i]
		var station_y: float = arm_y + y
		var rate_x: float = q*arm_z - r*station_y
		var rate_y: float = r*arm_x - p*arm_z
		var rate_z: float = p*station_y - q*arm_x
		var flow_x: float = v0 + rate_x
		var flow_z: float = v2 + rate_z
		var da: float = da_right if y > 0 else da_left
		var rate_speed := M.sqrt_(rate_x*rate_x + rate_y*rate_y + rate_z*rate_z)
		blend = maxf(blend, Aero._smoothstep((M.atan2_(rate_speed, float(air.V))-limit)/a1_span))
		if blend == 1.0:
			return blend
		var angle := wrapf(M.atan2_(flow_z, flow_x) + aileron_effect*da, -PI, PI)
		if has_twist:
			angle = wrapf(angle + twist[i], -PI, PI)
		blend = maxf(blend, Aero._smoothstep((absf(angle)-limit)/(a1_span if angle >= 0.0 else n1_span)))
		if blend == 1.0:
			return blend
	var tail_span: float = float(surfaces.tail_local_limit) - limit
	for tail_index in 2:
		var vertical := tail_index == 1
		var tail: Dictionary = surfaces.vertical if vertical else surfaces.horizontal
		var tail_position: PackedFloat64Array = tail.position
		var tx: float = -(tail_position[0]-cg[0])
		var ty: float = tail_position[1]-cg[1]
		var tz: float = -(tail_position[2]-cg[2])
		var rate_x: float = q*tz - r*ty
		var rate_y: float = r*tx - p*tz
		var rate_z: float = p*ty - q*tx
		var flow_x: float = v0 + rate_x
		var component: float = v1 + rate_y if vertical else v2 + rate_z
		var rate_speed := M.sqrt_(rate_x*rate_x + rate_y*rate_y + rate_z*rate_z)
		blend = maxf(blend, Aero._smoothstep((M.atan2_(rate_speed, float(air.V))-limit)/a1_span))
		if blend == 1.0:
			return blend
		var control: float = -float(d.rudder) if vertical else float(d.elevator)
		var angle: float
		if not vertical and tail.has("free_slope"):
			var wake: float = downwash_cl
			if is_nan(wake):
				wake = Aero._wing_lift_coefficient_with(s, air, d, model, ge, true)
			var scale: float = ge[ys.size()+1] if not ge.is_empty() else 1.0
			angle = wrapf(M.atan2_(component, flow_x) - Aero.downwash_angle(wake * scale,
				float(tail.downwash_per_cl), M.sqrt_(flow_x*flow_x + component*component))
				+ float(tail.elevator_tau)*control + float(tail.free_incidence), -PI, PI)
		else:
			angle = wrapf(M.atan2_(component, flow_x) + tail.control_effectiveness*control + tail.incidence, -PI, PI)
		blend = maxf(blend, Aero._smoothstep((absf(angle)-limit)/tail_span))
	return blend
