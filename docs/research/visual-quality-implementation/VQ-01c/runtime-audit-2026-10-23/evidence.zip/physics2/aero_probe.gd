extends SceneTree

const FlightSession := preload("res://sim/flight_session.gd")
const Aero := preload("res://physics/aero.gd")
const Air := preload("res://physics/air_data.gd")

func _initialize() -> void:
	var session := FlightSession.new()
	session.setup(FlightSession.Scenarios.AIRCRAFT)
	session.reset()
	var state: PackedFloat64Array = session.sim.state
	var model: Dictionary = session.aircraft.model
	var aux: PackedFloat64Array = session.sim.aux
	var d: Dictionary = session._deflections(aux)
	var air: Dictionary = session.air_data(state, 0.0)
	var rho: float = session.air_density(state)
	var stations: int = model.envelope.get("station_ys", PackedFloat64Array()).size()
	var local_weight: float = Aero.local_flow_weight(state, air, d, model)
	var prop: Dictionary = model.propulsion
	print("PROBE stations=%d local_weight=%.9f slipstream=%s glow=%s" % [stations, local_weight, str(not prop.get("slipstream", {}).is_empty()), str(prop.get("type", ""))])
	_measure("wing_flow", func() -> void: Aero._wing_flow(state, air, d, model), 30000)
	_measure("local_loads", func() -> void: Aero._local_loads(state, air, d, model, rho), 20000)
	_measure("global_loads", func() -> void: Aero._global_loads(state, air, d, model, rho), 20000)
	_measure("aero_loads", func() -> void: Aero.loads(state, air, d, model, rho), 20000)
	session.free()
	quit()

func _measure(name: String, body: Callable, count: int) -> void:
	var best := 1.0e30
	for run in 5:
		var start: int = Time.get_ticks_usec()
		for i in count:
			body.call()
		best = minf(best, float(Time.get_ticks_usec() - start) / count)
	print("PROFILE %s best_us_per_call=%.3f samples=%d repeats=5" % [name, best, count])
