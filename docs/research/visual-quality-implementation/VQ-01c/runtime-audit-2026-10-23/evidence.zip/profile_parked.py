from pathlib import Path
out = Path(__file__).resolve().parent / 'field'
root = Path(__file__).resolve().parents[2]
s=(root/'app/scenery/parked_aircraft.gd').read_text()
s=s.replace('\tif path.is_empty() or not ResourceLoader.exists(path):','\tvar perf0 := Time.get_ticks_usec()\n\tvar cached := ResourceLoader.has_cached(path)\n\tif path.is_empty() or not ResourceLoader.exists(path):',1)
s=s.replace('\tvar resource: Resource = load(path)','\tvar perf1 := Time.get_ticks_usec()\n\tvar resource: Resource = load(path)\n\tprint("PARKED_PROFILE ", aircraft, " ", configuration, " cached=", cached, " exists_us=", perf1-perf0, " load_us=", Time.get_ticks_usec()-perf1)',1)
(out/'profiled_parked.gd').write_text(s)
p=out/'profiled_scenery.gd'
p.write_text(p.read_text().replace('preload("res://scenery/parked_aircraft.gd")','preload("'+(out/'profiled_parked.gd').as_posix()+'")'))
