from pathlib import Path
import subprocess, os, json, hashlib, sys, statistics

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'ground-trial'
out.mkdir(exist_ok=True)
source = (root / 'app/render/ground.gdshader').read_text()
old = '\tcol *= mix(vec3(1.0), parcel(world_pos.xz), far * parcel_strength);\n'
assert source.count(old) == 1
candidate = source.replace(old, '')
mark = '\tvec2 turf_dy = dFdy(world_pos.xz);\n'
assert candidate.count(mark) == 1
candidate = candidate.replace(mark, mark + '\tfloat parcel_weight = far * parcel_strength;\n\tif (parcel_weight != 0.0) {\n\t\tcol *= mix(vec3(1.0), parcel(world_pos.xz), parcel_weight);\n\t}\n')
(out / 'candidate.gdshader').write_text(candidate)
(out / 'baseline.gdshader').write_text(source)
(out / 'identity.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(), 'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest()}, indent=2))
harness = '''extends "C:/DEVELOPMENT/OpenRCsimulator/tools/graphics/capture.gd"
var trial_shader: Shader
func _initialize() -> void:
	trial_shader = load("res://render/ground.gdshader")
	if OS.get_environment("OPENRC_TRIAL") == "candidate":
		trial_shader.code = FileAccess.get_file_as_string("C:/DEVELOPMENT/OpenRCsimulator/tmp/perf-20261023/ground-trial/candidate.gdshader")
	super._initialize()
'''
(out / 'capture.gd').write_text(harness)
if len(sys.argv) == 1:
    sys.exit()
mode = sys.argv[1]
for view in (['pilot', 'lake'] if mode == 'profile' else ['all']):
    for i, version in enumerate(['baseline', 'candidate', 'candidate', 'baseline'] if mode == 'profile' else ['baseline', 'candidate']):
        name = f'{mode}-{view}-{i}-{version}'
        dest = out/name
        if dest.exists():
            continue
        env = dict(os.environ, OPENRC_TRIAL=version)
        command = [sys.executable, str(root/'tools/godot/run_checked.py'), '--out-dir', str(out/'checks'/name), '--timeout','120','--', str(root/'.tools/Godot_v4.7.2-stable_win64_console.exe'), '--path', str(root/'app'), '--audio-driver','Dummy','--resolution','1920x1080','--script',str(out/'capture.gd'), '--','--out',str(dest),'--width','1920','--view',view]
        if mode == 'profile': command += ['--seconds','20']
        result = subprocess.run(command, env=env)
        if result.returncode: sys.exit(result.returncode)
        data=json.loads((dest/'report.json').read_text())
        if mode=='profile':
            samples=data['cases'][0]['profile']['samples_wall_cpu_gpu_ms']
            print(name, {k:round(statistics.median(s[k] for s in samples),4) for k in ['wall_ms','cpu_ms','gpu_ms']},flush=True)
