import ctypes
from ctypes import wintypes
from pathlib import Path
import json
import subprocess
import sys
import time

b = Path(__file__).resolve().parent
root = b.parents[1]
variant = sys.argv[1]
app = b / (sys.argv[2] if len(sys.argv) > 2 else 'baseline/app')
output = b / ('window-close-' + variant)
assert not Path(str(output) + '.json').exists()
command = [str(root / '.tools/Godot_v4.7.2-stable_win64.exe'), '--path', str(app),
           '--audio-driver', 'Dummy', '--resolution', '1280x720', '--max-fps', '60',
           '--script', str(b / 'window_close_probe.gd'), '--', '--quick-flight', '--start=runway', '--out=' + str(output)]
started = time.monotonic()
with output.with_suffix('.log').open('w', encoding='utf-8') as stream:
    proc = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, cwd=root)
    ready = Path(str(output) + '.ready')
    while not ready.exists() and proc.poll() is None and time.monotonic() - started < 100:
        time.sleep(0.1)
    if not ready.exists():
        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
        raise SystemExit('No ready signal; inspect log')
    data = json.loads(ready.read_text())
    user32 = ctypes.windll.user32
    matches = []
    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def callback(hwnd, _):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == data['pid'] and user32.IsWindowVisible(hwnd):
            matches.append(hwnd)
        return True
    user32.EnumWindows(callback, 0)
    assert matches, 'No visible window owned by probe'
    for hwnd in matches:
        user32.PostMessageW(hwnd, 0x0010, 0, 0)
    try:
        code = proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
        raise SystemExit('WM_CLOSE did not finish; inspect log')
result = json.loads(Path(str(output) + '.json').read_text())
result.update(exit_code=code, elapsed_s=time.monotonic() - started, command=command, ready=data)
Path(str(output) + '-result.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
