from pathlib import Path
import hashlib
import json
import math
import re

b = Path(__file__).resolve().parent
root = b.parents[1]
dest = root / 'docs/research/visual-quality-implementation/VQ-01c/runtime-audit-2026-10-19'

def read(name):
    return json.loads((b / name).read_text())

def ranks(values):
    ordered = sorted(values)
    return {f'p{p}': ordered[math.ceil(len(ordered) * p / 100) - 1] for p in [50, 95, 99]}

frame = read('candidate-airborne-short.json')
monitor = read('candidate-airborne-short.json.monitors.json')
native = {
    'scope': '15-second native live-input diagnostic; not a before/after performance comparison or full-session acceptance',
    'complete': frame['complete'], 'failure': frame['failure'],
    'frames': frame['frames'], 'sample_seconds': frame['actual_sample_s'],
    'wall_frame_ms_nearest_rank': ranks([v / 1000 for v in frame['frame_wall_usec']]),
    'measured_simulation': frame['measured_simulation'],
    'end_paused': frame['simulation']['paused'], 'end_fault': frame['simulation']['fault'],
    'pause_events': monitor['pause_events'],
    'raw_metrics_nearest_rank': {k: ranks(v) for k, v in frame['raw_metrics'].items()},
    'observer_metrics_nearest_rank': {k: ranks([s[k] for s in monitor['samples']])
                                    for k in ['render_cpu_ms', 'render_gpu_ms', 'static_memory', 'video_memory', 'resources', 'nodes', 'orphans']},
    'observer_metrics_scope': '984 read-only observations covering warm-up and sample; not synchronized one-to-one with the 878 measured frame intervals',
    'limits': ['Shared workstation; foreground and cache temperatures uncontrolled.',
               'Process and physics engine monitors are aggregate; no independent per-method GDScript profiler capture.',
               'Render CPU/GPU timers exclude scripting and physics.'],
}
(b / 'candidate-airborne-short-reduction.json').write_text(json.dumps(native, indent=2) + '\n')

owned = ['app/app_root.gd', 'app/tests/test_ui_quit.gd', 'app/tests/test_runway_transaction.gd', 'app/tests/test_workshop_trial.gd']
identities = {}
for name in owned:
    current = hashlib.sha256((root / name).read_bytes()).hexdigest()
    frozen = hashlib.sha256((b / 'candidate' / name).read_bytes()).hexdigest()
    assert current == frozen, name
    identities[name] = current

def log_check(name):
    content = (b / name).read_text(errors='replace')
    return {'log': name, 'engine_error_lines': re.findall(r'^.*(?:SCRIPT ERROR:|^ERROR:).*$', content, re.M),
            'retention_warnings': re.findall(r'^.*(?:leaked at exit|still in use at exit).*$', content, re.M),
            'result_lines': [line for line in content.splitlines()
                             if any(x in line for x in [' checks,', ' failed', 'FAIL golden'])][-8:]}

ledger = {
    'date': '2026-10-19', 'engine': '4.7.2.stable.official.ed1daf0bf',
    'all_release_checks_passed': False,
    'source_sha256_final_owned_files': identities,
    'scope_notes': ['Frozen results apply to retained snapshots; live-tree follow-ups are point-in-time results on a concurrently edited tree, not a complete immutable current-tree qualification.',
                    'No golden re-recording, staging, commit or push was performed by this audit.',
                    'Current-tree follow-up results supersede individual initial failures only; they do not erase the retained failing campaign.',
                    'Current checkpoint/atmosphere/runway/RC-menu improvements came from parallel tracks and were not isolated as part of this repair.'],
    'campaigns': {name: read(name) for name in ['verification-jobs-results.json', 'baseline-verification-jobs-results.json',
                                              'current-verification-jobs-results.json', 'current-quit-jobs-results.json',
                                              'candidate-workshop-jobs-results.json', 'transaction-jobs-results.json']},
    'final_followups': {name: log_check(name) for name in ['quit-test-current.log', 'quit-test-candidate-r2.log',
                                                         'current-runway-transaction.log', 'lifecycle/test_workshop_trial_corrected.log',
                                                         'candidate-workshop-corrected.log', 'simulation/current-checkpoint.log',
                                                         'lifecycle/test_rcv_menu_current.log']},
    'parse': read('render/parse/parse-summary.json'),
    'parse_followup': 'The final Workshop fixture changed after the 1043-script parse copy; its corrected current and frozen-candidate scripts were separately compiled and executed: 38 checks, zero failures.',
    'native_short': native,
    'performance_candidate': {'integrated': False, 'diagnostic_gain_percent': 3.9445628997867805,
                              'adoption_gate_percent': 5, 'exact_executed_probe_source_preserved': False,
                              'decision': 'Reject. Variable gain below gate, plus missing exact executed source.'},
    'remaining': [
        {'priority': 'P1', 'finding': 'Four existing golden replay mismatches remain identical on baseline, initial candidate and current tree.',
         'acceptance': 'Owning physics track explains source/reference divergence and restores intended replay acceptance without unreviewed golden replacement.'},
        {'priority': 'P2', 'finding': 'Measured Home and Fly first draws exceed existing loading goals.',
         'acceptance': 'Repeat the existing loading protocol with controlled source/cache state, isolate the expensive stage and meet its documented targets without transition regressions.'},
        {'priority': 'P2', 'finding': 'Full uninterrupted native frame/CPU qualification is incomplete; short unpaused sample still has poor p95 pacing.',
         'acceptance': 'Controlled uninterrupted representative session with source identities, adequate simulation progress, no faults, and the existing frame/CPU gates.'},
        {'priority': 'P3', 'finding': 'Long-duration memory, physical-device, export and platform acceptance remain open.',
         'acceptance': 'Complete existing 50-cycle/30-minute soak and relevant device/export/platform checks.'}],
    'not_run': ['Complete app/test.sh suite and generators', 'Full capture/export matrix', 'Independent pilot flight and physical input devices',
                'Gameplay on non-Windows operating systems', '50-cycle/30-minute memory soak', 'Per-method GDScript profiler trace'],
}
for result in ledger['final_followups'].values():
    assert not result['engine_error_lines'], result
    assert not result['retention_warnings'], result
(dest / 'verification-summary.json').write_text(json.dumps(ledger, indent=2) + '\n')
print(json.dumps(native, indent=2))
print('Final owned-file hashes match the verified frozen candidate; verification ledger written.')
