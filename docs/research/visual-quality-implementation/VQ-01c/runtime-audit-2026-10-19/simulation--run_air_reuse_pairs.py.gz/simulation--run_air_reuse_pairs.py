#!/usr/bin/env python3
"""Alternating full-session reference/candidate callbacks on the frozen app snapshot."""

from __future__ import annotations

import json
import statistics
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "air-reuse-pairs"
GODOT = ROOT / ".tools" / "Godot_v4.7.2-stable_win64_console.exe"
PROJECT = ROOT / "tmp" / "godot-audit-20261019" / "baseline" / "app"
PROBE = Path(__file__).with_name("session_probe_candidate.gd")
SEQUENCE = ["off", "on", "on", "off", "off", "on"]


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=False)
    reports: list[dict] = []
    fingerprints: set[str] = set()
    for index, candidate in enumerate(SEQUENCE, start=1):
        report_path = OUT / f"run-{index:02d}-{candidate}.json"
        log_path = OUT / f"run-{index:02d}-{candidate}.log"
        cmd = [
            str(GODOT), "--headless", "--path", str(PROJECT), "--audio-driver", "Dummy",
            "--script", str(PROBE), "--", f"--output={report_path}",
            "--aircraft=jensen-das-ugly-stik-60", "--case=trim",
            "--warmup-ticks=2400", "--sample-ticks=12000", "--observer=on",
            f"--candidate={candidate}",
        ]
        started = time.monotonic()
        completed = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=300)
        elapsed = time.monotonic() - started
        log_path.write_text(completed.stdout + completed.stderr, encoding="utf-8")
        if completed.returncode != 0 or not report_path.exists():
            print(f"failed {index}/6 candidate={candidate} exit={completed.returncode} elapsed={elapsed:.1f}s", flush=True)
            print((completed.stdout + completed.stderr)[-6000:], file=sys.stderr)
            return 1
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if not report.get("complete") or report.get("completed") != {"warmup_ticks": 2400, "sample_ticks": 12000}:
            print(f"incomplete {index}/6 candidate={candidate}: {report.get('failure')}", flush=True)
            return 1
        if report.get("stage_route") != "_wheel_evaluate" or not report.get("direct_stage_equal"):
            print(f"route/parity guard failed {index}/6: {report.get('stage_route')}", flush=True)
            return 1
        fingerprints.add(report["fingerprint"])
        report["variant"] = candidate
        report["elapsed_wall_s"] = round(elapsed, 3)
        report["median_tick_usec"] = statistics.median(report["tick_usec"])
        report["p95_tick_usec"] = statistics.quantiles(report["tick_usec"], n=20)[18]
        report["median_simulation_usec"] = statistics.median(report["simulation_usec"])
        reports.append(report)
        print(f"done {index}/6 candidate={candidate} wall={elapsed:.1f}s "
              f"tick-med={report['median_tick_usec']:.1f}us "
              f"sim-med={report['median_simulation_usec']:.1f}us "
              f"fingerprint={report['fingerprint'][:12]}", flush=True)

    if len(fingerprints) != 1:
        print(f"trajectory fingerprints diverged: {sorted(fingerprints)}", file=sys.stderr)
        return 1
    base = [r["median_tick_usec"] for r in reports if r["variant"] == "off"]
    candidate = [r["median_tick_usec"] for r in reports if r["variant"] == "on"]
    pairs = []
    for left in range(0, len(reports), 2):
        pair = reports[left:left + 2]
        reference = next(r["median_tick_usec"] for r in pair if r["variant"] == "off")
        changed = next(r["median_tick_usec"] for r in pair if r["variant"] == "on")
        pairs.append({"order": [r["variant"] for r in pair], "reference_median_usec": reference,
                      "candidate_median_usec": changed, "gain_percent": 100.0 * (reference - changed) / reference})
    summary = {
        "format": "openrc-air-reuse-scratch-pairs-v1",
        "project_snapshot": str(PROJECT),
        "probe_sha256": __import__("hashlib").sha256(PROBE.read_bytes()).hexdigest(),
        "aircraft_id": "jensen-das-ugly-stik-60", "route": "_wheel_evaluate",
        "warmup_ticks": 2400, "sample_ticks": 12000, "pairs": pairs,
        "reference_median_of_run_medians_usec": statistics.median(base),
        "candidate_median_of_run_medians_usec": statistics.median(candidate),
        "aggregate_gain_percent": 100.0 * (statistics.median(base) - statistics.median(candidate)) / statistics.median(base),
        "fingerprint": next(iter(fingerprints)),
        "runs": [{k: r[k] for k in ("variant", "elapsed_wall_s", "median_tick_usec", "p95_tick_usec",
                                       "median_simulation_usec", "fingerprint", "candidate_calls",
                                       "direct_stage_equal", "stage_route", "measured_wall_usec")} for r in reports],
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
