extends SceneTree

const Recorder := preload("res://sim/recorder.gd")
var output := ""
var observed: RefCounted

class RedirectedRecorder extends Recorder:
	var output_path := ""
	func stop(_path := "") -> Error:
		return super.stop(output_path)

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	var app: Node = load("res://app_root.tscn").instantiate()
	app.user_args = PackedStringArray(["--quick-flight"])
	root.add_child(app)
	var flight: Node = app.get("flight")
	if flight == null or not flight.startup_error.is_empty():
		push_error("window-close fixture failed to start")
		quit(1)
		return
	flight.recorder.detach()
	var recorder := RedirectedRecorder.new(flight.session.sim)
	recorder.output_path = output + ".csv"
	flight.recorder = recorder
	observed = recorder
	recorder.start(flight.session.trace_meta())
	await process_frame
	await process_frame
	var ready := FileAccess.open(output + ".ready", FileAccess.WRITE)
	ready.store_string(JSON.stringify({"pid": OS.get_process_id(), "rows": recorder.trace.row_count(),
		"auto_accept_quit": auto_accept_quit}))
	ready.close()

func _finalize() -> void:
	if observed != null:
		var result := FileAccess.open(output + ".json", FileAccess.WRITE)
		if result != null:
			result.store_string(JSON.stringify({"recording": observed.recording, "note": observed.note,
				"rows": observed.trace.row_count(), "csv_exists": FileAccess.file_exists(output + ".csv")}))
