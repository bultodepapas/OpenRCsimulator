extends SceneTree

const FlightSession := preload("res://sim/flight_session.gd")
const Golden := preload("res://tests/golden_flights.gd")
const OUTPUT_DIR := "C:/DEVELOPMENT/OpenRCsimulator/tmp/godot-audit-r2-20261019/replay/baseline-regenerated"


func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute(OUTPUT_DIR)
	var session := FlightSession.new()
	session.setup()
	root.add_child(session)
	var failures := 0
	for name in Golden.NAMES:
		var g: Dictionary = Golden.record(session, name)
		if g.is_empty():
			printerr("FAIL record %s: rejected by v1 eligibility guard" % name)
			failures += 1
			continue
		var path := OUTPUT_DIR.path_join(name + ".json")
		var file := FileAccess.open(path, FileAccess.WRITE)
		if file == null:
			printerr("FAIL write %s: %s" % [name, FileAccess.get_open_error()])
			failures += 1
			continue
		file.store_string(JSON.stringify(g, " ", false, true) + "\n")
		file.close()
		var replay: Dictionary = Golden.replay(session, g)
		print("%s: record %d ticks; self-replay %s: %s" % [name, int(g.ticks), "ok" if replay.ok else "FAIL", replay.message])
		if not replay.ok:
			failures += 1
	print("regenerated %d golden flights, %d failures; output=%s" % [Golden.NAMES.size(), failures, OUTPUT_DIR])
	quit(1 if failures > 0 else 0)
