import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASELINE = ROOT / "tmp/godot-audit-r2-20261019/baseline/app"
REPLAY_DIR = Path(__file__).parent
OLD_REV = "bfc32834f69656103627c70654566cf092d6dfd9"
NEW_REV = "a518147ab64cfc3d8bf7b44b28d8669c4559fc9e"
NAMES = ["roll_15", "pull_throttle", "rudder_doublet", "glide_15"]
SOURCE_PATHS = [
    "app/data/aircraft/jensen_ugly_stik_60.json",
    "app/sim/flight_session.gd",
    "app/physics/aircraft_data.gd",
    "app/physics/mass_inventory.gd",
    "app/physics/fixed_datum_body.gd",
    "app/physics/trim.gd",
    "app/sim/liquid_fuel_flight.gd",
    "app/physics/glow/fuel_mass.gd",
    "app/sim/scenarios.gd",
    "app/sim/maneuvers.gd",
    "app/tests/golden_flights.gd",
    "app/tests/replay_policy.gd",
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def normalized_sha(data):
    return sha(data.replace(bytes([13, 10]), bytes([10])))


def git_show(revision, path):
    try:
        return subprocess.check_output(["git", "show", f"{revision}:{path}"], cwd=ROOT, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        return None


def parsed_json(data):
    return json.loads(data.decode("utf-8-sig"))


def find_item(data, item_id):
    return next((item for item in data.get("inventory", []) if item.get("id") == item_id), {})

old_aircraft = parsed_json(git_show(OLD_REV, SOURCE_PATHS[0]))
new_aircraft = parsed_json(git_show(NEW_REV, SOURCE_PATHS[0]))

def mass(item):
    return item.get("mass", {}).get("value")

old_stamp_records = {}
new_stamp_records = {}
artifact_hashes = {}
for name in NAMES:
    old_path = ROOT / "app/tests/golden" / f"{name}.json"
    new_path = REPLAY_DIR / "baseline-regenerated" / f"{name}.json"
    old_raw, new_raw = old_path.read_bytes(), new_path.read_bytes()
    old_doc, new_doc = parsed_json(old_raw), parsed_json(new_raw)
    old_stamp_records[name] = old_doc.get("stamp", {}).get("build", {})
    new_stamp_records[name] = new_doc.get("stamp", {}).get("build", {})
    artifact_hashes[name] = {
        "saved_sha256_bytes": sha(old_raw),
        "saved_stamp": old_stamp_records[name],
        "regenerated_sha256_bytes": sha(new_raw),
        "regenerated_stamp": new_stamp_records[name],
    }

sources = {}
for path in SOURCE_PATHS:
    rel = path.removeprefix("app/")
    old_git = git_show(OLD_REV, path)
    new_git = git_show(NEW_REV, path)
    frozen_path = BASELINE / rel
    frozen = frozen_path.read_bytes() if frozen_path.exists() else None
    sources[path] = {
        "bfc32834_sha256_lf": normalized_sha(old_git) if old_git is not None else None,
        "a518147ab_sha256_lf": normalized_sha(new_git) if new_git is not None else None,
        "baseline_app_sha256_lf": normalized_sha(frozen) if frozen is not None else None,
        "baseline_matches_a518147ab": frozen is not None and new_git is not None and normalized_sha(frozen) == normalized_sha(new_git),
        "added_after_bfc32834": old_git is None and new_git is not None,
    }

history_paths = [
    "app/data/aircraft/jensen_ugly_stik_60.json",
    "app/sim/flight_session.gd",
    "app/physics/aircraft_data.gd",
]
history = {}
for path in history_paths:
    history[path] = subprocess.check_output(
        ["git", "log", "--ancestry-path", "--format=%h %cs %s", f"{OLD_REV}..{NEW_REV}", "--", path],
        cwd=ROOT,
        text=True,
    ).strip().splitlines()

scenario_text = (BASELINE / "sim/scenarios.gd").read_text(encoding="utf-8-sig")
match = re.search(r'const AIRCRAFT := "([^"]+)"', scenario_text)

report = {
    "audit": "offline comparison of saved v1 goldens against regenerated current baseline records",
    "saved_reference_revision_label": OLD_REV,
    "regeneration_baseline_revision_label": NEW_REV,
    "saved_glide_stamp_object_available": subprocess.run(["git", "cat-file", "-e", "3084098c^{commit}"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0,
    "default_aircraft_path": match.group(1) if match else None,
    "golden_artifacts": artifact_hashes,
    "source_sha256_lf": sources,
    "default_aircraft_data_delta_bfc_to_a518": {
        "balance_configuration": [old_aircraft.get("balance", {}).get("configuration"), new_aircraft.get("balance", {}).get("configuration")],
        "fuel_system_present": ["fuel_system" in old_aircraft, "fuel_system" in new_aircraft],
        "fuel_half_tank_kg": [mass(find_item(old_aircraft, "item_fuel_main")), mass(find_item(new_aircraft, "item_fuel_main"))],
        "virtual_balance_mass_kg": [mass(find_item(old_aircraft, "item_balance_mass_virtual")), mass(find_item(new_aircraft, "item_balance_mass_virtual"))],
        "aero_coefficients": {
            key: [old_aircraft.get("aero", {}).get("coefficients", {}).get(key, {}).get("value"), new_aircraft.get("aero", {}).get("coefficients", {}).get(key, {}).get("value")]
            for key in ["CLq", "Cmq", "Cnr"]
        },
    },
    "history_bfc_to_a518": history,
    "review_notes": [
        "The frozen app source files under baseline/app match revision a518147ab for every listed source path; text hashes normalize CRLF to LF.",
        "golden_flights.gd, replay_policy.gd, and scenarios.gd have identical bfc32834/a518147ab hashes; replay/tolerance logic and default scenario path did not change across these revisions.",
        "The maneuver input transition ticks are identical between saved and regenerated records; regenerated trimmed command values differ.",
        "Three saved records stamp bfc32834; glide_15 stamps 3084098c, whose commit object is not present in this local Git database.",
    ],
    "commands": [
        "python tmp/godot-audit-r2-20261019/replay/compare_saved_regenerated.py",
        "git diff --unified=4 bfc32834 a518147ab -- app/data/aircraft/jensen_ugly_stik_60.json",
        "git log --ancestry-path --format=\"%h %cs %s\" bfc32834..a518147ab -- app/data/aircraft/jensen_ugly_stik_60.json app/sim/flight_session.gd app/physics/aircraft_data.gd",
    ],
}
(REPLAY_DIR / "source-provenance.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
