import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OLD = ROOT / "app/tests/golden"
NEW = Path(__file__).parent / "baseline-regenerated"
NAMES = ["roll_15", "pull_throttle", "rudder_doublet", "glide_15"]
BODY = [
    ("position", ["north_m", "east_m", "down_m"], 1),
    ("velocity", ["u_mps", "v_mps", "w_mps"], 4),
    ("attitude", ["qw", "qx", "qy", "qz"], 7),
    ("rate", ["p_radps", "q_radps", "r_radps"], 11),
]
INPUT_NAMES = ["cmd_roll", "cmd_pitch", "cmd_yaw", "cmd_throttle"]
AUX_NAMES = {
    0: "engine_rpm", 1: "servo_roll", 2: "servo_pitch", 3: "servo_yaw",
    13: "downwash",
}


def first_and_max(old_rows, new_rows, field_index):
    first = None
    max_item = (0.0, None, None, None, None)
    for old, new in zip(old_rows, new_rows):
        tick = int(old[0])
        if field_index >= len(old) or field_index >= len(new):
            continue
        a, b = old[field_index], new[field_index]
        if isinstance(a, (int, float)) and not isinstance(a, bool) and isinstance(b, (int, float)) and not isinstance(b, bool):
            delta = abs(float(a) - float(b))
            if delta and first is None:
                first = (tick, a, b, delta)
            if delta > max_item[0]:
                max_item = (delta, tick, a, b, field_index)
        elif a != b and first is None:
            first = (tick, a, b, None)
    return first, max_item


for name in NAMES:
    old = json.loads((OLD / f"{name}.json").read_text(encoding="utf-8-sig"))
    new = json.loads((NEW / f"{name}.json").read_text(encoding="utf-8-sig"))
    print(f"[{name}] ticks={old['ticks']} mode={old['mode']} speed={old['speed']}; regenerated ticks={new['ticks']} mode={new['mode']} speed={new['speed']}")
    old_ticks = [int(row[0]) for row in old["inputs"]]
    new_ticks = [int(row[0]) for row in new["inputs"]]
    print(f"input schedule ticks: saved={old_ticks}; regenerated={new_ticks}; identical={old_ticks == new_ticks}")
    for a, b in zip(old["inputs"], new["inputs"]):
        old_cmd = [float(x) for x in a[1:5]]
        new_cmd = [float(x) for x in b[1:5]]
        changed = [f"{key} {x:.17g}->{y:.17g}" for key, x, y in zip(INPUT_NAMES, old_cmd, new_cmd) if x != y]
        print(f"  input tick {int(a[0])}: " + (", ".join(changed) if changed else "exact"))

    old_body, new_body = old["checkpoints"], new["checkpoints"]
    print(f"body checkpoint ticks identical={ [int(x[0]) for x in old_body] == [int(x[0]) for x in new_body] }")
    for label, fields, start in BODY:
        hits = []
        worst = (0.0, None, None, None, None)
        for a, b in zip(old_body, new_body):
            for offset, field in enumerate(fields):
                idx = start + offset
                delta = abs(float(a[idx]) - float(b[idx]))
                if delta:
                    hits.append((int(a[0]), field, a[idx], b[idx], delta))
                if delta > worst[0]:
                    worst = (delta, int(a[0]), field, a[idx], b[idx])
        if hits:
            first = hits[0]
            print(f"  {label}: first tick={first[0]} {first[1]} {first[2]:.17g}->{first[3]:.17g} abs={first[4]:.9g}; max tick={worst[1]} {worst[2]} abs={worst[0]:.9g}")
        else:
            print(f"  {label}: exact")

    old_aux, new_aux = old.get("aux_checkpoints", []), new.get("aux_checkpoints", [])
    aux_rows_equal = old_aux == new_aux
    print(f"auxiliary checkpoints exact={aux_rows_equal}; rows saved={len(old_aux)} regenerated={len(new_aux)}")
    if old_aux and new_aux:
        changed_indices = []
        for index in range(1, min(len(old_aux[0]), len(new_aux[0]))):
            first, worst = first_and_max(old_aux, new_aux, index)
            if first is not None:
                aux_index = index - 1
                changed_indices.append(aux_index)
                label = AUX_NAMES.get(aux_index, f"aux[{aux_index}]")
                print(f"  {label}: first tick={first[0]} {first[1]:.17g}->{first[2]:.17g} abs={first[3]:.9g}; max abs={worst[0]:.9g} at tick={worst[1]}")
        all_indices = list(range(len(old_aux[0]) - 1))
        unchanged = [i for i in all_indices if i not in changed_indices]
        print(f"  unchanged auxiliary indices exact={unchanged}")

    old_modes, new_modes = old.get("mode_checkpoints", []), new.get("mode_checkpoints", [])
    print(f"mode checkpoints exact={old_modes == new_modes}; rows saved={len(old_modes)} regenerated={len(new_modes)}")
    print()
