from pathlib import Path
import gzip
import hashlib
import io
import json
import math
import re
import subprocess
import tarfile

b = Path(__file__).resolve().parent
root = b.parents[1]
dest = root / 'docs/research/visual-quality-implementation/VQ-01c/runtime-audit-2026-10-19/round-2'
dest.mkdir(exist_ok=True)

def read(rel):
    return json.loads((b / rel).read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

current_source = root / 'app/scenery/scenery.gd'
candidate_source = b / 'probes/scenery_timing_candidate.gd'
assert current_source.read_bytes() == candidate_source.read_bytes()
identities = read('current-verification-identities.json')
assert sha(current_source.read_bytes()) == identities['app/scenery/scenery.gd']

campaigns = {p.name: json.loads(p.read_text()) for p in sorted(b.glob('*-jobs-results.json'))}
current = campaigns['current-verification-jobs-results.json']
assert len(current) == 2 and all(j['exit_code'] == 0 and not j['timeout'] for j in current)
for job in current:
    assert not any('ERROR:' in issue or 'FAIL' in issue or 'leaked' in issue or 'in use at exit' in issue
                   for issue in job['issues']), job
smoke = read('current-loading-smoke.json')
assert smoke['complete'] and len(smoke['cycles']) == 3
assert all(not row['paused_at_first_draw'] and row['tick_at_first_draw'] == 12 and row['orphan_nodes'] == 0
           for row in smoke['cycles'])
assert smoke['shutdown']['audio_released'] and smoke['shutdown']['remaining_playbacks'] == 0
assert smoke['shutdown']['settings_removed']

scenery_checks = {}
for label in ['baseline', 'candidate', 'current']:
    rel = f'verify-scenery-{label}.log'
    lines = (b / rel).read_text(errors='replace').splitlines()
    scenery_checks[label] = {'log': rel, 'passed_assertions': sum(line.startswith('ok   ') for line in lines),
                              'failures': [line for line in lines if line.startswith('FAIL')],
                              'engine_errors': [line for line in lines if 'ERROR:' in line],
                              'retention_warnings': [line for line in lines if 'leaked' in line or 'in use at exit' in line]}
assert scenery_checks['current']['passed_assertions'] == 126
assert not scenery_checks['current']['failures']

v4 = read('loading/attribution-v4-reduction.json')
assert v4['complete'] and len(v4['rows']) == 7
cold = v4['rows'][0]
new_ms = cold['vegetation_ms'] + cold['population_ms']
coverage = {'cold_build_ms': cold['build_ms'], 'newly_reported_ms': new_ms,
            'previous_reported_percent': 100 * (cold['timing_sum_ms'] - new_ms) / cold['build_ms'],
            'now_reported_percent': 100 * cold['timing_sum_ms'] / cold['build_ms']}

# Verify the source copies actually used for the accepted attribution runs.
for version in [1, 3, 4]:
    folder = b / f'loading/attribution-v{version}-sources'
    index = json.loads((folder / 'archive-manifest.json').read_text())
    entries = index.get('files', index)
    for rel, details in entries.items():
        if not isinstance(details, (str, dict)):
            continue
        expected = details if isinstance(details, str) else details.get('sha256')
        if expected:
            p = folder / rel
            assert p.is_file() and sha(p.read_bytes()) == expected, (version, rel)

summary = {
    'date': '2026-10-19', 'timezone': 'America/Bogota',
    'engine': '4.7.2.stable.official.ed1daf0bf',
    'all_release_checks_passed': False,
    'owned_production_change': {'path': 'app/scenery/scenery.gd', 'inserted_lines': 4,
                                'sha256': sha(current_source.read_bytes()),
                                'behavior': 'Additional vegetation/population construction timings in existing scenery stats.',
                                'performance_speedup_claimed': False},
    'profiling_coverage': coverage,
    'scenery_checks': scenery_checks,
    'native_baseline': read('baseline-native-reduction.json'),
    'paused_presentation_diagnostic': read('profile-reduction.json'),
    'final_current_smoke': smoke,
    'campaigns': campaigns,
    'replay_findings': {'stored_goldens_failed': 4, 'fresh_scratch_self_replays_exact': 4,
                        'same_transition_ticks_and_modes': True, 'same_command_values': False,
                        'first_trim_command_body_velocity_attitude_difference_tick': 0,
                        'conclusion': 'Different initial trim and subsequent source/data history support reference drift; no replay algorithm defect confirmed.',
                        'limits': 'Dirty historical source is not reconstructible from its commit label; glide stamp object is unavailable. No goldens changed.'},
    'rejected_scene_cache': {'decision': 'Do not integrate.',
                             'reason': 'Native split warm load 0.529/0.545 ms and instantiate 0.055/0.063 ms leave little repeat cost to remove; earlier 0.23-second warm creation did not reproduce.',
                             'corrected_microprobe': 'loading/resource_cache_probe_v3.gd'},
    'excluded_attempts': [
        {'run': 'profile-native', 'reason': 'Paused at tick35, menu hold; excluded from active-flight qualification.'},
        {'run': 'loading-attribution-v2', 'reason': 'Duplicate scratch local prevented parsing; never reached valid gameplay.'},
        {'run': 'loading/resource-cache-probe-native.json', 'reason': 'Flawed strong-reference sequencing; exact v2 probe source unavailable. Corrected v3 is retained.'}],
    'remaining': [
        {'priority': 'P1', 'finding': 'Stored golden/source reconciliation remains a release-validation gate.'},
        {'priority': 'P2', 'finding': 'Cold script/scenery construction and loading budget remain open; variable host/cache history prevents a speedup claim.'},
        {'priority': 'P2', 'finding': '345.523ms native frame stall cause and full-session CPU/frame qualification remain open.'},
        {'priority': 'P3', 'finding': 'Full app/test.sh, exports, physical devices, independent pilot, other-OS gameplay and long soak were not completed.'}],
    'scope': 'Frozen-source diagnostic measurements plus point-in-time current-tree verification. Concurrent WIP, nonreserved workstation and uncontrolled caches; no immutable whole-current-tree or target-hardware qualification.',
}
(dest / 'verification-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(b / 'owned-change.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'app/scenery/scenery.gd'], cwd=root))

paths = set()
for suffix in ['*.json', '*.log', '*.py', '*.diff', '*.txt']:
    paths.update(p for p in b.glob(suffix) if p.is_file() and p.name != 'progress.json')
paths.update(p for p in (b / 'probes').glob('*') if p.is_file())
paths.update(p for p in (b / 'replay').rglob('*') if p.is_file())
for suffix in ['*.json', '*.txt', '*.gd', '*.py']:
    paths.update(p for p in (b / 'loading').glob(suffix) if p.is_file() and p.name != 'resource_cache_probe_v2_candidate.gd')
for version in [1, 2, 3, 4]:
    paths.update(p for p in (b / f'loading/attribution-v{version}-sources').rglob('*') if p.is_file())

items = [(str(p.relative_to(b)).replace('\\', '/'), p.read_bytes()) for p in sorted(paths)]
for rel in ['app/scenery/scenery.gd', 'app/tests/test_scenery_build.gd', 'app/data/aircraft/jensen_ugly_stik_60.json']:
    items.append(('baseline-inputs/' + rel, (b / 'baseline' / rel).read_bytes()))
for p in sorted((b / 'baseline/app/tests/golden').glob('*.json')):
    items.append(('reference-goldens/' + p.name, p.read_bytes()))
items.append(('integrated/app/scenery/scenery.gd', current_source.read_bytes()))

buffer = io.BytesIO()
file_manifest = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for rel, data in items:
        entry = tarfile.TarInfo(rel)
        entry.size = len(data)
        entry.mtime = 0
        entry.mode = 0o644
        archive.addfile(entry, io.BytesIO(data))
        file_manifest.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
packed = gzip.compress(buffer.getvalue(), mtime=0)
(dest / 'evidence.tar.gz').write_bytes(packed)
manifest = {
    'date': '2026-10-19', 'source_head_at_snapshot': read('baseline-manifest.json')['head_at_start'],
    'head_at_pack': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
    'status_at_pack': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root).decode(),
    'archive': 'evidence.tar.gz', 'archive_sha256': sha(packed), 'archive_bytes': len(packed),
    'source_sha256': {'app/scenery/scenery.gd': sha(current_source.read_bytes())},
    'engine_sha256': {name: sha((root / '.tools' / name).read_bytes()) for name in
                      ['Godot_v4.7.2-stable_win64_console.exe', 'Godot_v4.7.2-stable_win64.exe']},
    'notes': ['No stage, commit or push command was issued by this audit.',
              'Full uncommitted frozen application remains in local scratch; manifest hashes alone cannot reconstruct it from a clean clone.',
              'Accepted timing/probe source versions are retained with hashes. Failed or flawed attempts are retained separately and excluded.',
              'Unrelated dirty work and external commits were preserved.'],
    'files': file_manifest,
}
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Packaged {len(items)} evidence files, {len(packed)} compressed bytes.')
print(json.dumps(coverage, indent=2))
