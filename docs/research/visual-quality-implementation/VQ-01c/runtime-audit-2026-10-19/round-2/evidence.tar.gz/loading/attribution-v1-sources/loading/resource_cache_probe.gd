# Isolated PackedScene cache probe for the production flight route.
# A strong hold from the previous run remains alive through the next load call.
# No instance is added to the SceneTree, so _ready() and the flight build do not run.
extends SceneTree

const SCENE_PATH := "res://main.tscn"
const EXPECTED_ROOT_NAME := "Main"
const EXPECTED_SCRIPT_PATH := "res://main.gd"
const RETENTION_ORDER := ["weak", "strong", "weak", "strong"]

var _output_path := ""
var _previous_scene_ref: WeakRef
var _previous_script_ref: WeakRef
var _strong_scene: PackedScene
var _runs: Array[Dictionary] = []


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="):
			_output_path = arg.trim_prefix("--output=")
		else:
			_fail("Unknown option: " + arg)
			return
	if _output_path.is_empty() or FileAccess.file_exists(_output_path):
		_fail("Provide a new --output path")
		return
	if not ResourceLoader.exists(SCENE_PATH, "PackedScene"):
		_fail("Flight PackedScene is missing: " + SCENE_PATH)
		return

	for index in RETENTION_ORDER.size():
		var retention: String = RETENTION_ORDER[index]
		var previous_strong_held_during_load := _strong_scene != null

		# WeakRef inspection briefly obtains a reference, then drops it before load().
		var previous_scene: Dictionary = _observe(_previous_scene_ref)
		var previous_script: Dictionary = _observe(_previous_script_ref)
		var cache_before := ResourceLoader.has_cached(SCENE_PATH)
		var load_started := Time.get_ticks_usec()
		var scene: PackedScene = ResourceLoader.load(
			SCENE_PATH, "PackedScene", ResourceLoader.CACHE_MODE_REUSE
		) as PackedScene
		var load_elapsed := Time.get_ticks_usec() - load_started
		if scene == null:
			_fail("ResourceLoader.load did not return a PackedScene")
			return

		var scene_id := scene.get_instance_id()
		var instantiate_started := Time.get_ticks_usec()
		var instance: Node = scene.instantiate()
		var instantiate_elapsed := Time.get_ticks_usec() - instantiate_started
		if instance == null:
			_fail("PackedScene.instantiate returned null")
			return
		if not instance is Node3D or instance.name != EXPECTED_ROOT_NAME:
			var bad_root_identity := "%s (%s)" % [instance.name, instance.get_class()]
			instance.free()
			_fail("Flight scene root identity changed: " + bad_root_identity)
			return

		var script_resource: Script = instance.get_script() as Script
		if script_resource == null or script_resource.resource_path != EXPECTED_SCRIPT_PATH:
			instance.free()
			_fail("Flight scene script identity changed: %s" % ("" if script_resource == null else script_resource.resource_path))
			return
		var script_id := script_resource.get_instance_id()
		var scene_weak: WeakRef = weakref(scene)
		var script_weak: WeakRef = weakref(script_resource)
		var run := {
			"index": index + 1,
			"retention_after_load": retention,
			"previous_strong_held_during_load": previous_strong_held_during_load,
			"cache_before_load": cache_before,
			"load_usec": load_elapsed,
			"scene_instance_id": scene_id,
			"same_scene_as_previous_weak": previous_scene.alive and previous_scene.instance_id == scene_id,
			"previous_scene_weak_alive_before_load": previous_scene.alive,
			"previous_scene_instance_id": previous_scene.instance_id,
			"instantiate_usec": instantiate_elapsed,
			"instance_root_name": instance.name,
			"instance_root_class": instance.get_class(),
			"instance_script_path": script_resource.resource_path,
			"instance_script_id": script_id,
			"same_script_as_previous_weak": previous_script.alive and previous_script.instance_id == script_id,
			"previous_script_weak_alive_before_load": previous_script.alive,
			"previous_script_instance_id": previous_script.instance_id,
		}
		instance.free()
		instance = null
		script_resource = null
		var replaced_previous_strong := _strong_scene != null
		_strong_scene = null
		if retention == "strong":
			_strong_scene = scene
		scene = null
		await process_frame
		run["replaced_previous_strong_after_load"] = replaced_previous_strong
		run["cache_after_release"] = ResourceLoader.has_cached(SCENE_PATH)
		run["scene_weak_after_release"] = _observe(scene_weak)
		run["script_weak_after_release"] = _observe(script_weak)
		_runs.append(run)
		_previous_scene_ref = scene_weak
		_previous_script_ref = script_weak

	var final_strong_release := false
	if _strong_scene != null:
		_strong_scene = null
		final_strong_release = true
		await process_frame
	var report := {
		"format": "openrc-packed-scene-cache-probe v2",
		"complete": true,
		"scene_path": SCENE_PATH,
		"cache_mode": "CACHE_MODE_REUSE",
		"retention_order": RETENTION_ORDER,
		"retention_semantics": "Each mode applies after its load; a prior strong hold survives through the next ResourceLoader.load, then is released after that call.",
		"timed_sections": "ResourceLoader.load and PackedScene.instantiate separately; no add_child or _ready work",
		"final_strong_reference_released": final_strong_release,
		"final_cache_state": ResourceLoader.has_cached(SCENE_PATH),
		"final_scene_weak": _observe(_previous_scene_ref),
		"final_script_weak": _observe(_previous_script_ref),
		"engine": Engine.get_version_info(),
		"runs": _runs,
	}
	_write_report(report)
	quit(0)


func _observe(reference: WeakRef) -> Dictionary:
	if reference == null:
		return {"alive": false, "instance_id": 0}
	var recovered: Object = reference.get_ref()
	var observation := {
		"alive": recovered != null,
		"instance_id": recovered.get_instance_id() if recovered != null else 0,
	}
	recovered = null
	return observation


func _write_report(report: Dictionary) -> void:
	var file := FileAccess.open(_output_path, FileAccess.WRITE)
	if file == null:
		push_error("Cannot create probe report: " + _output_path)
		quit(2)
		return
	file.store_string(JSON.stringify(report, "\t") + "\n")
	file.close()
	print("PackedScene cache probe: %d loads -> %s" % [_runs.size(), _output_path])


func _fail(message: String) -> void:
	push_error(message)
	var failure := {
	"format": "openrc-packed-scene-cache-probe v2",
		"complete": false,
		"error": message,
		"scene_path": SCENE_PATH,
		"engine": Engine.get_version_info(),
		"runs": _runs,
	}
	if not _output_path.is_empty() and not FileAccess.file_exists(_output_path):
		_write_report(failure)
	quit(1)
