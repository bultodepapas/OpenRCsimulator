"""Create a timing-only overlay on the frozen VQ-01c baseline copy.

This writes only below tmp/godot-audit-r2-20261019/loading/. Before patching, it
restores only the five instrumented scripts from the frozen app and materializes
manifest-pinned sibling inputs needed by res://../ paths. It never mutates the
frozen baseline or production application. The parent runs the generated Godot
probe serially after the uninstrumented baseline measurement.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shutil


ROOT = Path(__file__).resolve().parents[3]
OWNED = ROOT / "tmp/godot-audit-r2-20261019" / "loading"
APP = OWNED / "instrumented-app"
BASELINE_APP = ROOT / "tmp/godot-audit-r2-20261019" / "baseline" / "app"
PROBE_SOURCE = ROOT / "research" / "performance" / "loading_probe.gd"
PROBE = OWNED / "attributed_loading_probe.gd"
HELPER_REL = "audit/loading_attribution.gd"
PATCHED_SCRIPTS = (
    "app_root.gd",
    "ui/home_scene.gd",
    "main.gd",
    "render/field.gd",
    "render/lake/lake_world.gd",
)
HELPER_TEXT = '''extends RefCounted

static var _phase := "unassigned"
static var _sequence := 0
static var _samples: Array[Dictionary] = []


static func set_phase(value: String) -> void:
\t_phase = value


static func begin() -> int:
\treturn Time.get_ticks_usec()


static func finish(label: String, started_usec: int, details: Dictionary = {}) -> void:
\t_sequence += 1
\tvar row: Dictionary = {"sequence": _sequence, "phase": _phase, "call": label,
\t\t"elapsed_usec": Time.get_ticks_usec() - started_usec}
\trow.merge(details, true)
\t_samples.append(row)


static func snapshot() -> Array[Dictionary]:
\treturn _samples.duplicate(true)
'''

PATCH_COUNTS: dict[str, int] = {}


def read_text(path: Path) -> str:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return stream.read()


def write_text(path: Path, text: str) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        stream.write(text)


def newline_of(text: str) -> str:
    return "\r\n" if "\r\n" in text else "\n"


def replace_once(relative: str, old: str, new: str) -> None:
    path = APP / relative
    text = read_text(path)
    nl = newline_of(text)
    old_text = old.replace("\n", nl)
    new_text = new.replace("\n", nl)
    count = text.count(old_text)
    if count != 1:
        raise RuntimeError(f"{relative}: expected one patch anchor, found {count}: {old!r}")
    write_text(path, text.replace(old_text, new_text, 1))
    PATCH_COUNTS[relative] = PATCH_COUNTS.get(relative, 0) + 1


def add_helper_constant(relative: str) -> None:
    path = APP / relative
    text = read_text(path)
    match = re.search(r"(?m)^extends [^\r\n]+", text)
    if match is None:
        raise RuntimeError(f"{relative}: no extends declaration")
    line_end = match.end()
    if text.startswith("\r\n", line_end):
        nl = "\r\n"
        line_end += 2
    elif text.startswith("\n", line_end):
        nl = "\n"
        line_end += 1
    else:
        raise RuntimeError(f"{relative}: extends declaration has no newline")
    line = f'const LoadingAttribution := preload("res://{HELPER_REL}")'
    write_text(path, text[:line_end] + line + nl + text[line_end:])
    PATCH_COUNTS[relative] = PATCH_COUNTS.get(relative, 0) + 1


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def prepare_frozen_inputs() -> dict[str, str]:
    manifest = json.loads((OWNED / "baseline-manifest.json").read_text(encoding="utf-8"))
    baseline_files: dict[str, str] = manifest["files"]

    # The previous interrupted run may have changed only these five scripts.
    # Validate the frozen originals, then reset this exact patch surface.
    for relative in PATCHED_SCRIPTS:
        key = f"app/{relative}"
        source = BASELINE_APP / relative
        expected = baseline_files.get(key)
        if expected is None or not source.is_file() or sha256(source) != expected:
            raise RuntimeError(f"Frozen baseline script missing or hash-mismatched: {key}")
        target = APP / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    # Preserve the repository's original sibling layout for res://../ paths,
    # while requiring every copied input to match the frozen manifest.
    sibling_files = {key: value for key, value in baseline_files.items() if not key.startswith("app/")}
    for relative, expected in sibling_files.items():
        source = ROOT / Path(relative)
        target = OWNED / Path(relative)
        if not source.is_file() or sha256(source) != expected:
            raise RuntimeError(f"Frozen sibling input missing or hash-mismatched: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    return baseline_files


def write_hash_manifests() -> None:
    root_manifest = json.loads((OWNED / "baseline-manifest.json").read_text(encoding="utf-8"))
    original_files = root_manifest["files"]
    (OWNED / "baseline-source-hashes.json").write_text(
        json.dumps({"head_at_start": root_manifest["head_at_start"], "files": original_files}, indent=2) + "\n",
        encoding="utf-8",
    )
    executed: dict[str, str] = {}
    for relative in sorted(original_files):
        if relative.startswith("app/"):
            path = APP / relative.removeprefix("app/")
        else:
            path = OWNED / Path(relative)
        if not path.is_file():
            raise RuntimeError(f"Frozen executed input missing from instrumented workspace: {relative}")
        executed[relative] = sha256(path)
    executed[f"app/{HELPER_REL}"] = sha256(APP / HELPER_REL)
    executed["../attributed_loading_probe.gd"] = sha256(PROBE)
    executed["../research/performance/loading_probe.gd"] = sha256(PROBE_SOURCE)
    (OWNED / "executed-source-hashes.json").write_text(
        json.dumps({"head_at_start": root_manifest["head_at_start"], "files": executed}, indent=2) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    if not APP.is_dir() or not BASELINE_APP.is_dir() or not (OWNED / "baseline-manifest.json").is_file():
        raise RuntimeError("Expected the ready frozen copy and its manifest under tmp/godot-audit-r2-20261019")
    prepare_frozen_inputs()
    audit_dir = APP / "audit"
    audit_dir.mkdir(exist_ok=True)
    write_text(audit_dir / "loading_attribution.gd", HELPER_TEXT)

    for relative in PATCHED_SCRIPTS:
        add_helper_constant(relative)

    # Home route: distinguish data load, world/field composition, and preview construction.
    replace_once("ui/home_scene.gd", "\t_lighting = TimeOfDayLighting.snapshot(lighting_config)",
        "\tvar _audit_home_lighting_usec := LoadingAttribution.begin()\n"
        "\t_lighting = TimeOfDayLighting.snapshot(lighting_config)\n"
        "\tLoadingAttribution.finish(\"TimeOfDayLighting.snapshot / Home\", _audit_home_lighting_usec)")
    replace_once("ui/home_scene.gd", "\tvar loaded_field: Dictionary = FieldLoader.load_from(field_path)",
        "\tvar _audit_home_field_load_usec := LoadingAttribution.begin()\n"
        "\tvar loaded_field: Dictionary = FieldLoader.load_from(field_path)\n"
        "\tLoadingAttribution.finish(\"FieldLoader.load_from / Home\", _audit_home_field_load_usec, {\"path\": field_path})")
    replace_once("ui/home_scene.gd",
        "\tvar build_field := func() -> void: add_child(Landscapes.build(landscape_id, field, snapshot))",
        "\tvar build_field := func() -> void:\n"
        "\t\tvar _audit_home_landscape_usec := LoadingAttribution.begin()\n"
        "\t\tvar _home_field_root := Landscapes.build(landscape_id, field, snapshot)\n"
        "\t\tLoadingAttribution.finish(\"Landscapes.build / Home\", _audit_home_landscape_usec, {\"landscape_id\": landscape_id})\n"
        "\t\tadd_child(_home_field_root)")
    replace_once("ui/home_scene.gd",
        "\t_environment = World.build(self, field, build_field, {}, snapshot, night_options).environment",
        "\tvar _audit_home_world_usec := LoadingAttribution.begin()\n"
        "\tvar _home_world: Dictionary = World.build(self, field, build_field, {}, snapshot, night_options)\n"
        "\t_environment = _home_world.environment\n"
        "\tLoadingAttribution.finish(\"World.build / Home\", _audit_home_world_usec)")
    replace_once("ui/home_scene.gd", "\t_shadow = Shadow.create(self)\n\tshow_aircraft(aircraft)",
        "\tvar _audit_home_shadow_usec := LoadingAttribution.begin()\n"
        "\t_shadow = Shadow.create(self)\n"
        "\tLoadingAttribution.finish(\"Shadow.create / Home\", _audit_home_shadow_usec)\n"
        "\tvar _audit_home_aircraft_usec := LoadingAttribution.begin()\n"
        "\tshow_aircraft(aircraft)\n"
        "\tLoadingAttribution.finish(\"HomeScene.show_aircraft\", _audit_home_aircraft_usec, {\"aircraft_id\": aircraft})")
    replace_once("ui/home_scene.gd",
        "\tvar built: Dictionary = _preview_models[id] if retained else AirplaneBuilder.build(id)",
        "\tvar built: Dictionary\n"
        "\tif retained:\n"
        "\t\tbuilt = _preview_models[id]\n"
        "\telse:\n"
        "\t\tvar _audit_preview_build_usec := LoadingAttribution.begin()\n"
        "\t\tbuilt = AirplaneBuilder.build(id)\n"
        "\t\tLoadingAttribution.finish(\"AirplaneBuilder.build / Home preview\", _audit_preview_build_usec, {\"aircraft_id\": id})")

    # App shell: measure only the normal Home and Fly creation calls; existing whole-sync probe remains authoritative.
    replace_once("app_root.gd", "func show_home() -> void:",
        "func show_home() -> void:\n\tvar _audit_show_home_usec := LoadingAttribution.begin()")
    replace_once("app_root.gd",
        "\thome_scene = HomeScene.new(aircraft, field_path, lighting_config, night_options, preferences.get(\"sky_config\", SkyConfig.defaults()), landscape_id) # still backdrop\n"
        "\t_connect_home_preview(home_scene)\n\tadd_child(home_scene)",
        "\tvar _audit_home_scene_new_usec := LoadingAttribution.begin()\n"
        "\thome_scene = HomeScene.new(aircraft, field_path, lighting_config, night_options, preferences.get(\"sky_config\", SkyConfig.defaults()), landscape_id) # still backdrop\n"
        "\tLoadingAttribution.finish(\"HomeScene.new\", _audit_home_scene_new_usec)\n"
        "\t_connect_home_preview(home_scene)\n"
        "\tvar _audit_home_scene_add_usec := LoadingAttribution.begin()\n"
        "\tadd_child(home_scene)\n"
        "\tLoadingAttribution.finish(\"HomeScene.add_child / _ready\", _audit_home_scene_add_usec)")
    replace_once("app_root.gd", "\tvar home := Home.new()",
        "\tvar _audit_home_ui_new_usec := LoadingAttribution.begin()\n"
        "\tvar home := Home.new()\n"
        "\tLoadingAttribution.finish(\"Home.new\", _audit_home_ui_new_usec)")
    replace_once("app_root.gd", "\thome.update_hidden.connect(_on_update_hidden)\n\tscreens.push(\"home\", home)",
        "\thome.update_hidden.connect(_on_update_hidden)\n"
        "\tvar _audit_home_screen_push_usec := LoadingAttribution.begin()\n"
        "\tscreens.push(\"home\", home)\n"
        "\tLoadingAttribution.finish(\"ScreenStack.push Home\", _audit_home_screen_push_usec)")
    replace_once("app_root.gd",
        "\tif not _update_info.is_empty():\n\t\thome.show_update(_update_info) # the notice survives a flight: Home is rebuilt after End flight",
        "\tif not _update_info.is_empty():\n\t\thome.show_update(_update_info) # the notice survives a flight: Home is rebuilt after End flight\n"
        "\tLoadingAttribution.finish(\"AppRoot.show_home\", _audit_show_home_usec)")
    replace_once("app_root.gd", "func start_flight(request: Dictionary = {}) -> void:",
        "func start_flight(request: Dictionary = {}) -> void:\n\tvar _audit_start_flight_usec := LoadingAttribution.begin()")
    replace_once("app_root.gd", "\tflight = _create_flight(route_aircraft_id)",
        "\tvar _audit_create_flight_usec := LoadingAttribution.begin()\n"
        "\tflight = _create_flight(route_aircraft_id)\n"
        "\tLoadingAttribution.finish(\"AppRoot._create_flight\", _audit_create_flight_usec, {\"aircraft_id\": route_aircraft_id})")
    replace_once("app_root.gd", "\tadd_child(flight)\n\tif is_random and flight.startup_error.is_empty():",
        "\tvar _audit_flight_add_usec := LoadingAttribution.begin()\n"
        "\tadd_child(flight)\n"
        "\tLoadingAttribution.finish(\"AppRoot.add_child flight / Main._ready\", _audit_flight_add_usec, {\"aircraft_id\": route_aircraft_id})\n"
        "\tif is_random and flight.startup_error.is_empty():")
    replace_once("app_root.gd", "\t\t\tflight.add_child(hint) # freed with the flight\n\n\nfunc _create_flight",
        "\t\t\tflight.add_child(hint) # freed with the flight\n"
        "\tLoadingAttribution.finish(\"AppRoot.start_flight\", _audit_start_flight_usec, {\"aircraft_id\": route_aircraft_id})\n\n\nfunc _create_flight")

    # Fly route: identify data load, scene/world, aircraft, and physics session construction.
    replace_once("main.gd", "\tvar loaded_field: Dictionary = FieldLoader.load_from(field_path)",
        "\tvar _audit_flight_field_load_usec := LoadingAttribution.begin()\n"
        "\tvar loaded_field: Dictionary = FieldLoader.load_from(field_path)\n"
        "\tLoadingAttribution.finish(\"FieldLoader.load_from / Fly\", _audit_flight_field_load_usec, {\"path\": field_path})")
    replace_once("main.gd", "\tif not _build_world():",
        "\tvar _audit_flight_world_total_usec := LoadingAttribution.begin()\n"
        "\tvar _flight_world_ok := _build_world()\n"
        "\tLoadingAttribution.finish(\"Main._build_world\", _audit_flight_world_total_usec)\n"
        "\tif not _flight_world_ok:")
    replace_once("main.gd", "\t\tsession.setup(physics_path, aircraft_id if _electric_demo.is_empty() and _experimental_aircraft_path.is_empty() else \"\")",
        "\t\tvar _audit_session_setup_usec := LoadingAttribution.begin()\n"
        "\t\tsession.setup(physics_path, aircraft_id if _electric_demo.is_empty() and _experimental_aircraft_path.is_empty() else \"\")\n"
        "\t\tLoadingAttribution.finish(\"FlightSession.setup\", _audit_session_setup_usec, {\"aircraft_id\": aircraft_id})")
    replace_once("main.gd", "\tsession.set_field(field) # E3a: the wheels roll on this field's runway, mown and rough surfaces",
        "\tvar _audit_session_field_usec := LoadingAttribution.begin()\n"
        "\tsession.set_field(field) # E3a: the wheels roll on this field's runway, mown and rough surfaces\n"
        "\tLoadingAttribution.finish(\"FlightSession.set_field\", _audit_session_field_usec)")
    replace_once("main.gd", "\tsession.reset()\n\tGroundGear.attach(_airplane, session)",
        "\tvar _audit_session_reset_usec := LoadingAttribution.begin()\n"
        "\tsession.reset()\n"
        "\tLoadingAttribution.finish(\"FlightSession.reset\", _audit_session_reset_usec)\n"
        "\tGroundGear.attach(_airplane, session)")
    replace_once("main.gd", "\t_airplane = AirplaneBuilder.build(aircraft_id, NAN, workshop_trial.get(\"presentation\", {}))",
        "\tvar _audit_flight_aircraft_usec := LoadingAttribution.begin()\n"
        "\t_airplane = AirplaneBuilder.build(aircraft_id, NAN, workshop_trial.get(\"presentation\", {}))\n"
        "\tLoadingAttribution.finish(\"AirplaneBuilder.build / Fly\", _audit_flight_aircraft_usec, {\"aircraft_id\": aircraft_id})")
    replace_once("main.gd", "\tvar built: Dictionary = World.build(self, field, _build_field, {}, snapshot, night_options)",
        "\tvar _audit_flight_world_usec := LoadingAttribution.begin()\n"
        "\tvar built: Dictionary = World.build(self, field, _build_field, {}, snapshot, night_options)\n"
        "\tLoadingAttribution.finish(\"World.build / Fly\", _audit_flight_world_usec)")
    replace_once("main.gd",
        "\t_field_node = Landscapes.build(landscape_id, field, _lighting if lighting_config.get(\"mode\", \"legacy\") != \"legacy\" else {})\n\tadd_child(_field_node)",
        "\tvar _audit_flight_landscape_usec := LoadingAttribution.begin()\n"
        "\t_field_node = Landscapes.build(landscape_id, field, _lighting if lighting_config.get(\"mode\", \"legacy\") != \"legacy\" else {})\n"
        "\tLoadingAttribution.finish(\"Landscapes.build / Fly\", _audit_flight_landscape_usec, {\"landscape_id\": landscape_id})\n"
        "\tadd_child(_field_node)")

    # Field internals: isolate geometry, lake data/terrain, scenery and vegetation from World.build.
    replace_once("render/field.gd",
        "static func build(field: Dictionary, lighting: Dictionary = {}, extra_grass_exclusions: Array = []) -> Node3D:",
        "static func build(field: Dictionary, lighting: Dictionary = {}, extra_grass_exclusions: Array = []) -> Node3D:\n"
        "\tvar _audit_field_build_usec := LoadingAttribution.begin()")
    replace_once("render/field.gd",
        "\tresult.set_meta(\"lighting_snapshot\", lighting.duplicate(true))\n\treturn result",
        "\tresult.set_meta(\"lighting_snapshot\", lighting.duplicate(true))\n"
        "\tLoadingAttribution.finish(\"Field.build\", _audit_field_build_usec)\n"
        "\treturn result")
    replace_once("render/field.gd", "\tvar grass: ShaderMaterial = Ground.grass_material(lighting)",
        "\tvar _audit_grass_material_usec := LoadingAttribution.begin()\n"
        "\tvar grass: ShaderMaterial = Ground.grass_material(lighting)\n"
        "\tLoadingAttribution.finish(\"Ground.grass_material\", _audit_grass_material_usec)")
    replace_once("render/field.gd", "\tvar consolidated: bool = Ground.configure_surfaces(grass, field.surfaces)",
        "\tvar _audit_surface_configuration_usec := LoadingAttribution.begin()\n"
        "\tvar consolidated: bool = Ground.configure_surfaces(grass, field.surfaces)\n"
        "\tLoadingAttribution.finish(\"Ground.configure_surfaces\", _audit_surface_configuration_usec)")
    replace_once("render/field.gd", "\tfor object_data: Dictionary in field.objects:\n\t\tresult.add_child(Treeline.build(object_data, field.pilot))",
        "\tfor object_data: Dictionary in field.objects:\n"
        "\t\tvar _audit_treeline_usec := LoadingAttribution.begin()\n"
        "\t\tvar _treeline_node := Treeline.build(object_data, field.pilot)\n"
        "\t\tLoadingAttribution.finish(\"Treeline.build\", _audit_treeline_usec, {\"object_id\": str(object_data.get(\"id\", \"\"))})\n"
        "\t\tresult.add_child(_treeline_node)")
    replace_once("render/field.gd", "\tvar lake_resolution := LakeWorld.resolve(field, scenery_options)",
        "\tvar _audit_lake_resolve_usec := LoadingAttribution.begin()\n"
        "\tvar lake_resolution := LakeWorld.resolve(field, scenery_options)\n"
        "\tLoadingAttribution.finish(\"LakeWorld.resolve\", _audit_lake_resolve_usec)")
    replace_once("render/field.gd", "\tScenery.attach(result, field, lighting, lake)",
        "\tvar _audit_scenery_attach_usec := LoadingAttribution.begin()\n"
        "\tScenery.attach(result, field, lighting, lake)\n"
        "\tLoadingAttribution.finish(\"Scenery.attach\", _audit_scenery_attach_usec)")
    replace_once("render/field.gd", "\tvar lake_node := LakeWorld.attach(result, field, grass, lake, lighting, bool(scenery_options.audio))",
        "\tvar _audit_lake_attach_usec := LoadingAttribution.begin()\n"
        "\tvar lake_node := LakeWorld.attach(result, field, grass, lake, lighting, bool(scenery_options.audio))\n"
        "\tLoadingAttribution.finish(\"LakeWorld.attach\", _audit_lake_attach_usec)")
    replace_once("render/field.gd", "\tvar near_grass: Node3D\n\tif scenery_node != null and field.id == \"default\":",
        "\tvar near_grass: Node3D\n"
        "\tvar _audit_near_grass_usec := LoadingAttribution.begin()\n"
        "\tvar _near_grass_builder := \"ImportedNearGrass.build\" if scenery_node != null and field.id == \"default\" else \"NearGrass.build\"\n"
        "\tif scenery_node != null and field.id == \"default\":")
    replace_once("render/field.gd", "\t\tnear_grass = NearGrass.build(field, grass, exclusions)\n\tresult.add_child(near_grass)",
        "\t\tnear_grass = NearGrass.build(field, grass, exclusions)\n"
        "\tLoadingAttribution.finish(_near_grass_builder, _audit_near_grass_usec)\n"
        "\tresult.add_child(near_grass)")
    replace_once("render/field.gd", "\tFieldProjectedShadows.attach(result, field, lighting)",
        "\tvar _audit_projected_shadows_usec := LoadingAttribution.begin()\n"
        "\tFieldProjectedShadows.attach(result, field, lighting)\n"
        "\tLoadingAttribution.finish(\"FieldProjectedShadows.attach\", _audit_projected_shadows_usec)")
    replace_once("render/field.gd", "\t\tvar ridges := DistantRidges.build(lighting)\n\t\tresult.add_child(ridges)",
        "\t\tvar _audit_ridges_usec := LoadingAttribution.begin()\n"
        "\t\tvar ridges := DistantRidges.build(lighting)\n"
        "\t\tLoadingAttribution.finish(\"DistantRidges.build\", _audit_ridges_usec)\n"
        "\t\tresult.add_child(ridges)")

    # Lake path: expose both first-use signature verification and actual terrain mesh creation.
    replace_once("render/lake/lake_world.gd", "\tvar loaded := Loader.load_from(str(options().path))",
        "\tvar _audit_lake_file_load_usec := LoadingAttribution.begin()\n"
        "\tvar loaded := Loader.load_from(str(options().path))\n"
        "\tLoadingAttribution.finish(\"LakeLoader.load_from\", _audit_lake_file_load_usec)")
    replace_once("render/lake/lake_world.gd", "\t\tvar loaded := FieldLoader.load_from(FieldLoader.DEFAULT_PATH)",
        "\t\tvar _audit_default_field_signature_usec := LoadingAttribution.begin()\n"
        "\t\tvar loaded := FieldLoader.load_from(FieldLoader.DEFAULT_PATH)\n"
        "\t\tLoadingAttribution.finish(\"FieldLoader.load_from / LakeWorld default signature\", _audit_default_field_signature_usec)")
    replace_once("render/lake/lake_world.gd",
        "\tvar node := Terrain.build(lake, ground_material, surfaces.rects, lighting)",
        "\tvar _audit_lake_terrain_usec := LoadingAttribution.begin()\n"
        "\tvar node := Terrain.build(lake, ground_material, surfaces.rects, lighting)\n"
        "\tLoadingAttribution.finish(\"LakeTerrain.build\", _audit_lake_terrain_usec)")

    # Preserve the existing real Home/Fly workflow and add phase labels plus collected nested call timings.
    probe_text = read_text(PROBE_SOURCE)
    probe_nl = newline_of(probe_text)
    probe_text = probe_text.replace("extends SceneTree" + probe_nl,
        "extends SceneTree" + probe_nl + f'const LoadingAttribution := preload("res://{HELPER_REL}")' + probe_nl, 1)
    probe_text = probe_text.replace("\tvar before_home := Time.get_ticks_usec()\n\troot.add_child(app)".replace("\n", probe_nl),
        ("\tvar before_home := Time.get_ticks_usec()\n"
         "\tLoadingAttribution.set_phase(\"home_initial\")\n"
         "\troot.add_child(app)").replace("\n", probe_nl), 1)
    probe_text = probe_text.replace("\t\tvar begin := Time.get_ticks_usec()\n\t\tfly.pressed.emit()".replace("\n", probe_nl),
        ("\t\tLoadingAttribution.set_phase(\"fly_cycle_%02d\" % (index + 1))\n"
         "\t\tvar begin := Time.get_ticks_usec()\n"
         "\t\tfly.pressed.emit()").replace("\n", probe_nl), 1)
    probe_text = probe_text.replace("\t\tvar return_begin := Time.get_ticks_usec()\n\t\tapp.call(\"end_flight\")".replace("\n", probe_nl),
        ("\t\tLoadingAttribution.set_phase(\"home_return_%02d\" % (index + 1))\n"
         "\t\tvar return_begin := Time.get_ticks_usec()\n"
         "\t\tapp.call(\"end_flight\")").replace("\n", probe_nl), 1)
    probe_text = probe_text.replace("\t\t\"cycles\": samples,".replace("\n", probe_nl),
        "\t\t\"construction_attribution\": LoadingAttribution.snapshot(),\n\t\t\"cycles\": samples,".replace("\n", probe_nl), 1)
    if probe_text == read_text(PROBE_SOURCE):
        raise RuntimeError("No loading-probe instrumentation was applied")
    write_text(PROBE, probe_text)

    changed = {
        relative: {"sha256": sha256(APP / relative)} for relative in sorted(PATCH_COUNTS)
    }
    write_hash_manifests()
    root_manifest = json.loads((OWNED / "baseline-manifest.json").read_text(encoding="utf-8"))
    (OWNED / "instrumentation-manifest.json").write_text(
        json.dumps({
            "baseline_head": root_manifest["head_at_start"],
            "baseline_manifest_sha256": sha256(OWNED / "baseline-manifest.json"),
            "instrumenter_sha256": sha256(Path(__file__).resolve()),
            "scope": "timing-only instrumentation in an isolated copy; no baseline/production edits",
            "baseline_file_count": len(root_manifest["files"]),
            "changed_app_files": changed,
            "patch_counts": PATCH_COUNTS,
            "helper_sha256": sha256(APP / HELPER_REL),
            "original_probe_sha256": sha256(PROBE_SOURCE),
            "executed_probe_sha256": sha256(PROBE),
        }, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Instrumented {len(PATCH_COUNTS)} app files in {APP}")
    print(f"Probe: {PROBE}")
    print(f"Hashes: {OWNED / 'baseline-source-hashes.json'}; {OWNED / 'executed-source-hashes.json'}")


if __name__ == "__main__":
    main()
