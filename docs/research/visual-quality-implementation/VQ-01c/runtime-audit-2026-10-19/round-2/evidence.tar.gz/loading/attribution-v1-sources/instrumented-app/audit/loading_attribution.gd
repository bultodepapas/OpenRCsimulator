extends RefCounted

static var _phase := "unassigned"
static var _sequence := 0
static var _samples: Array[Dictionary] = []


static func set_phase(value: String) -> void:
	_phase = value


static func begin() -> int:
	return Time.get_ticks_usec()


static func finish(label: String, started_usec: int, details: Dictionary = {}) -> void:
	_sequence += 1
	var row: Dictionary = {"sequence": _sequence, "phase": _phase, "call": label,
		"elapsed_usec": Time.get_ticks_usec() - started_usec}
	row.merge(details, true)
	_samples.append(row)


static func snapshot() -> Array[Dictionary]:
	return _samples.duplicate(true)
