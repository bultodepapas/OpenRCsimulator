extends SceneTree

var files: PackedStringArray = []
var failed: PackedStringArray = []

func _initialize() -> void:
	_collect("res://")
	files.sort()
	for path in files:
		var script := ResourceLoader.load(path, "GDScript") as GDScript
		if script == null or script.reload() != OK:
			failed.append(path)
	print("BATCH_PARSE_COMPLETE files=%d failed=%d" % [files.size(), failed.size()])
	for path in failed:
		printerr("BATCH_PARSE_FAIL ", path)
	quit(1 if not failed.is_empty() else 0)

func _collect(path: String) -> void:
	for name in DirAccess.get_files_at(path):
		if name.ends_with(".gd"):
			files.append(path.path_join(name))
	for name in DirAccess.get_directories_at(path):
		if name not in [".godot", ".tools", "tmp", "captures"]:
			_collect(path.path_join(name))
