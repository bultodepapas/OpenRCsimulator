import ctypes
from ctypes import wintypes
from pathlib import Path
import json
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
root = base.parents[1]
engine = root / '.tools/Godot_v4.7.2-stable_win64_console.exe'
config = json.loads(Path(sys.argv[1]).read_text())
results = []
for job in config:
    log = base / (job['name'] + '.log')
    command = [str(engine), '--path', str(base / job.get('app', 'baseline/app')), *job['args']]
    started = time.monotonic()
    with log.open('w', encoding='utf-8') as stream:
        proc = subprocess.Popen(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        try:
            code = proc.wait(timeout=job.get('timeout', 180))
            timeout = False
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            code = proc.wait()
            timeout = True
    text = log.read_text(encoding='utf-8', errors='replace')
    issues = [line for line in text.splitlines() if any(x in line for x in ('ERROR:', 'WARNING:', 'FAIL', 'leaked', 'in use at exit'))]
    result = dict(name=job['name'], command=command, exit_code=code, timeout=timeout,
                  elapsed_s=time.monotonic()-started, issues=issues)
    results.append(result)
    (base / (Path(sys.argv[1]).stem + '-results.json')).write_text(json.dumps(results, indent=2))
    print(json.dumps(result), flush=True)
