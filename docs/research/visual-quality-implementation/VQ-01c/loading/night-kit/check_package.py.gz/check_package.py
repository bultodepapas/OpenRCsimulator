from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path(__file__).resolve().parents[2]
out=root/'tmp/dt11b-integration'
empty=out/'empty'
empty.mkdir(exist_ok=True)
(empty/'project.godot').write_text('config_version=5\n')
package=out/'package'
probe=package/'GodotProbe.exe'
shutil.copy2(root/'.tools/Godot_v4.7.2-stable_win64.exe',probe)
exe=package/'OpenRC.exe'
records=[]
def run(name,cmd,env=None):
    p=subprocess.run([str(x) for x in cmd],cwd=empty,env=env,capture_output=True,timeout=120)
    log=p.stdout+p.stderr
    (out/(name+'.log')).write_bytes(log)
    ok=p.returncode==0 and not re.search(rb'(?m)^(?:SCRIPT |SHADER )?ERROR:',log)
    records.append({'name':name,'command':[str(x) for x in cmd],'cwd':str(empty),'exit_code':p.returncode,'pass':ok})
    print(name,ok,flush=True)
    return ok
base=[probe,'--headless','--path',empty,'--audio-driver','Dummy']
for mode in ['on','off']:
    env=os.environ.copy()
    env.update(OPENRC_SCENERY=mode,OPENRC_SCENERY_AUDIO='off',OPENRC_SCENERY_QUALITY='high',OPENRC_SCENERY_FILE='')
    run('pack-field-'+mode,base+['--script',root/'app/tests/check_field_pack.gd','--',exe,hashlib.sha256((root/'app/data/fields/default.json').read_bytes()).hexdigest()],env)
run('pack-rotorcraft',base+['--main-pack',exe,'--script',root/'research/aircraft-standardization/rotorcraft_package_smoke.gd'])
run('pack-night-kit',base+['--main-pack',exe,'--script',root/'app/tests/test_night_kit.gd'])
run('release-trace',[exe,'--headless','--audio-driver','Dummy','--','--trace='+str(out/'release-trace.csv'),'--t=1'])
run('trace-check',['python',root/'app/tests/check_trimmed_flight.py',out/'release-trace.csv','--duration=1'])
(out/'package-checks.json').write_text(json.dumps(records,indent=2)+'\n')
assert all(r['pass'] for r in records)
