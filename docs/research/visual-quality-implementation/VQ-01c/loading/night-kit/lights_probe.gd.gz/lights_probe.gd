extends SceneTree

const Builder := preload("res://render/airplane.gd")
const Catalog := preload("res://app_state/aircraft_catalog.gd")
const Reference := preload("aircraft_lights_reference.gd")
const Candidate := preload("aircraft_lights_candidate.gd")

func _initialize() -> void:
	var results := []
	for id in Catalog.airplane_visual_families():
		var plane: Dictionary = Builder.build(id)
		if plane.is_empty():
			push_error("Cannot build " + id)
			quit(1)
			return
		var records := []
		for pair in 5:
			var samples := {}
			var snapshots := {}
			for variant in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
				var begin := Time.get_ticks_usec()
				var kit: Node3D = Reference.attach(plane.root) if variant == "reference" else Candidate.attach(plane.root)
				samples[variant] = Time.get_ticks_usec() - begin
				snapshots[variant] = var_to_bytes(snapshot(kit))
				plane.root.remove_child(kit)
				kit.free()
			if snapshots.reference != snapshots.candidate:
				push_error("Kit geometry/material/placement mismatch " + id)
				quit(1)
				return
			samples["equal"] = true
			records.append(samples)
		plane.root.free()
		results.append({aircraft = id, pairs = records})
	var path := OS.get_cmdline_user_args()[0]
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_string(JSON.stringify(results, "\t") + "\n")
	print("Exact night-kit parity across five families and five alternating pairs each")
	quit()

func snapshot(kit: Node3D) -> Array:
	var rows := []
	for child in kit.get_children():
		var row := {name = child.name, transform = child.transform, visible = child.visible, meta = {}}
		for key in child.get_meta_list():
			row.meta[key] = child.get_meta(key)
		if child is MeshInstance3D:
			row["surfaces"] = []
			row["shadow"] = child.cast_shadow
			row["margin"] = child.extra_cull_margin
			for surface in child.mesh.get_surface_count():
				var mat: ShaderMaterial = child.mesh.surface_get_material(surface)
				var params := {}
				for param in mat.shader.get_shader_uniform_list():
					params[param.name] = mat.get_shader_parameter(param.name)
				row.surfaces.append({arrays = child.mesh.surface_get_arrays(surface), shader = mat.shader.code, params = params})
		if child is SpotLight3D:
			row["light"] = [child.light_energy, child.spot_range, child.spot_angle, child.light_color, child.shadow_enabled]
		rows.append(row)
	return rows
