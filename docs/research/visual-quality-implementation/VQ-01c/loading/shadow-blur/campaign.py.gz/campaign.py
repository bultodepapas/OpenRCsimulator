from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parent
out=root/'native'
out.mkdir(exist_ok=True)
before=json.loads((root/'source-before.json').read_text())
def verify():
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before['source_sha256'].items())
verify()
records=[]
for run in range(1,6):
    report=out/f'{run:02d}.json'
    command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script',str(root/'probe.gd'),'--','--directory='+str(root),'--output='+str(report)]
    if run%2==0: command.append('--reverse')
    with (out/f'{run:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    log=(out/f'{run:02d}.log').read_text()
    clean=result.returncode==0 and 'ERROR:' not in log and 'WARNING:' not in log and json.loads(report.read_text())['complete']
    records.append({'run':run,'command':command,'exit_code':result.returncode,'clean':clean})
    (out/'campaign.json').write_text(json.dumps(records,indent=2))
    print(run,'clean',clean,flush=True)
    assert clean
verify()
