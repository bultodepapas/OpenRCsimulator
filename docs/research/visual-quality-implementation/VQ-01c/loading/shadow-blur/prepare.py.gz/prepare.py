from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent
original=Path('app/render/shadow.gd').read_text()
(root/'reference.gd').write_text(original)
start=original.index('static func _blur(')
candidate=original[:start]+'''## Keep the original row-major sum order; hoist repeated edge clamping out of the nine taps.
static func _blur(m: PackedFloat32Array) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(m.size())
	for j in SIZE:
		var previous_row := maxi(j - 1, 0) * SIZE
		var current_row := j * SIZE
		var next_row := mini(j + 1, SIZE - 1) * SIZE
		for i in SIZE:
			var left := maxi(i - 1, 0)
			var right := mini(i + 1, SIZE - 1)
			var acc := 0.0
			acc += m[previous_row + left]
			acc += m[previous_row + i]
			acc += m[previous_row + right]
			acc += m[current_row + left]
			acc += m[current_row + i]
			acc += m[current_row + right]
			acc += m[next_row + left]
			acc += m[next_row + i]
			acc += m[next_row + right]
			out[current_row + i] = acc / 9.0
	return out
'''
(root/'candidate.gd').write_text(candidate)
paths=['app/render/shadow.gd','app/render/projected_shadow.gd','app/render/projected_shadow_mask.gdshader','app/render/projected_shadow_receiver.gdshader','app/spec.gd','app/project.godot','.tools/Godot_v4.7.2-stable_win64.exe']
manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}}
(root/'source-before.json').write_text(json.dumps(manifest,indent=2))
