from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent
reports=[json.loads(p.read_text()) for p in sorted((root/'native').glob('[0-9][0-9].json'))]
samples=[dict(s,run=i+1) for i,d in enumerate(reports) for s in d['samples']]
workloads=[]
for workload in ['silhouette','create']:
    medians={v:statistics.median(s['usec'] for s in samples if s['workload']==workload and s['variant']==v and s['pair']>0) for v in ['reference','candidate']}
    first={v:statistics.median(s['usec'] for s in samples if s['workload']==workload and s['variant']==v and s['pair']==0) for v in ['reference','candidate']}
    per_run=[{v:statistics.median(s['usec'] for s in samples if s['workload']==workload and s['variant']==v and s['run']==i and s['pair']>0) for v in ['reference','candidate']} for i in range(1,6)]
    workloads.append({'workload':workload,'warm_median_usec':medians,'first_pair_median_usec':first,'per_run_warm_median_usec':per_run,'warm_reduction_pct':100*(1-medians['candidate']/medians['reference'])})
result={'runs':len(reports),'exact_pairs':sum(d['exact_pairs'] for d in reports),'warm_samples_per_variant_workload':45,'workloads':workloads}
(root/'summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
