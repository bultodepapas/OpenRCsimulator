from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
source=(root/'candidate.gd').read_text().replace('var previous_row := maxi(j - 1, 0) * SIZE','var previous_row := j * SIZE')
assert source!=(root/'candidate.gd').read_text()
(root/'mutation.gd').write_text(source)
command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--headless','--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script',str(root/'test_shadow_blur.gd'),'--','--shadow='+str(root/'mutation.gd')]
with (root/'mutation.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
text=(root/'mutation.log').read_text()
detected=result.returncode!=0 and text.count('FAIL ')==24 and 'FAIL corner adjacent edge contributes two of nine taps' in text and 'ERROR:' not in text
(root/'mutation.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'detected':detected,'expected_failure':True,'assertion_failures':text.count('FAIL ')},indent=2))
print(text)
assert detected
