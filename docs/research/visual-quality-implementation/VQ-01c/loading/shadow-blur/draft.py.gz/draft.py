from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
base=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('app').resolve()),'--audio-driver','Dummy']
for native in [False,True]:
    name='draft-native' if native else 'draft-headless'
    command=base+([] if native else ['--headless'])+['--script',str(root/'test_shadow_blur.gd'),'--','--shadow='+str(root/'candidate.gd')]
    with (root/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    text=(root/(name+'.log')).read_text()
    (root/(name+'.json')).write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2))
    print(text)
    assert result.returncode==0 and 'ERROR:' not in text
