from pathlib import Path
import hashlib,json,gzip,shutil,difflib,subprocess
root=Path(__file__).resolve().parent
out=Path('docs/research/visual-quality-implementation/VQ-01c/loading/shadow-blur')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((root/'source-before.json').read_text())
for path,expected in before['source_sha256'].items():
    if path=='app/render/shadow.gd':
        assert sha(root/'reference.gd')==expected
        continue
    assert sha(Path(path))==expected, path
    if not path.startswith('.tools/'):
        target=out/'source'/(path+'.gz')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(gzip.compress(Path(path).read_bytes(),mtime=0))
assert Path('app/render/shadow.gd').read_text()==(root/'candidate.gd').read_text()
assert Path('app/tests/test_shadow_blur.gd').read_text()==(root/'test_shadow_blur.gd').read_text()
for folder in ['native','checks']:
    for p in (root/folder).iterdir():
        target=out/folder/p.name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,target)
for p in root.iterdir():
    if p.suffix in ['.gd','.py']:
        (out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    elif p.suffix in ['.json','.log']: shutil.copyfile(p,out/p.name)
patch=''.join(difflib.unified_diff((root/'reference.gd').read_text().splitlines(True),Path('app/render/shadow.gd').read_text().splitlines(True),fromfile='a/app/render/shadow.gd',tofile='b/app/render/shadow.gd'))
(out/'runtime.patch').write_text(patch)
ledger=json.loads((out/'native/campaign.json').read_text())
assert len(ledger)==5 and all(r['clean'] for r in ledger)
records=json.loads((out/'checks/results.json').read_text())
assert len(records)==6 and all(r['exit_code']==0 and not r['errors'] and not r['warnings'] for r in records)
assert json.loads((out/'mutation.json').read_text())['detected']
manifest={'step':'DT-11a','date':'2026-10-14','starting_head':before['head'],
    'retention_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'scope':'Current-tree targeted shadow-mask/carrier construction; pinned direct dependencies unchanged during timing; no whole-app snapshot or loading/FPS qualification',
    'sources':{p:sha(Path(p)) for p in ['app/render/shadow.gd','app/tests/test_shadow_blur.gd']},
    'dependencies_verified_unchanged':True,
    'checks':{'headless_blur':50,'headless_projected_shadow':37,'headless_world_presentation':17,'headless_field_integration':39,'native_blur':50,'native_projected_shadow':37,'exact_native_pairs':100,'native_processes':5,'mutation_assertion_failures':24},
    'artifacts':{p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='evidence-manifest.json'}}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('retained',len(manifest['artifacts']),'artifacts; dependency and runtime hashes verified')
