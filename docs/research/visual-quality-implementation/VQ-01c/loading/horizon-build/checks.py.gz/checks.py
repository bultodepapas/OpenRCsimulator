from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parent
out=root/'checks'
out.mkdir(exist_ok=True)
records=[]
for native,names in [(False,['test_horizon','test_field_surfaces','test_field_integration','test_world_presentation_context']), (True,['test_horizon'])]:
    for name in names:
        label=name+('-native' if native else '-headless')
        command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve())]+([] if native else ['--headless'])+['--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script','res://tests/'+name+'.gd']
        with (out/(label+'.log')).open('w') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
        text=(out/(label+'.log')).read_text()
        records.append({'name':label,'command':command,'exit_code':result.returncode,'errors':'ERROR:' in text,'warnings':[s for s in text.splitlines() if 'WARNING:' in s],'sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()})
        (out/'results.json').write_text(json.dumps(records,indent=2))
        print(label,result.returncode,'errors',records[-1]['errors'],flush=True)
        assert result.returncode==0 and not records[-1]['errors']
