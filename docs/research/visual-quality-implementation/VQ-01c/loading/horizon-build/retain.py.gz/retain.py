from pathlib import Path
import hashlib,json,gzip,shutil,difflib,subprocess
root=Path(__file__).resolve().parent
out=Path('docs/research/visual-quality-implementation/VQ-01c/loading/horizon-build')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((root/'source-before.json').read_text())
for path,expected in before['source_sha256'].items():
    if path=='app/render/horizon.gd':
        assert sha(root/'reference.gd')==expected
        continue
    assert sha(Path(path))==expected, path
    if not path.startswith('.tools/'):
        target=out/'source'/(path+'.gz')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(gzip.compress(Path(path).read_bytes(),mtime=0))
assert Path('app/render/horizon.gd').read_text()==(root/'candidate.gd').read_text()
assert Path('app/tests/test_horizon.gd').read_text()==(root/'test-original.gd').read_text()
for folder in ['native','exploration','checks','mutation']:
    for p in (root/folder).iterdir():
        target=out/folder/p.name
        target.parent.mkdir(parents=True,exist_ok=True)
        if p.suffix=='.gd': target.with_suffix('.gd.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
        else: shutil.copyfile(p,target)
for p in root.iterdir():
    if p.suffix in ['.gd','.py']:
        (out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    elif p.suffix in ['.json','.log']: shutil.copyfile(p,out/p.name)
patch=''.join(difflib.unified_diff((root/'reference.gd').read_text().splitlines(True),Path('app/render/horizon.gd').read_text().splitlines(True),fromfile='a/app/render/horizon.gd',tofile='b/app/render/horizon.gd'))
(out/'runtime.patch').write_text(patch)
ledger=json.loads((out/'native/campaign.json').read_text())
assert len(ledger)==5 and all(r['clean'] for r in ledger)
records=json.loads((out/'checks/results.json').read_text())
assert len(records)==5 and all(r['exit_code']==0 and not r['errors'] and not r['warnings'] for r in records[:4])
assert records[4]['errors'] and records[4]['name']=='test_horizon-native'
assert json.loads((out/'mutation/result.json').read_text())['detected']
manifest={'step':'DT-11a','date':'2026-10-14','starting_head':before['head'],
    'retention_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'scope':'Targeted horizon mesh construction; direct input hashes unchanged during timing; current-tree headless integration; native atmosphere-texture shutdown remains unresolved',
    'sources':{p:sha(Path(p)) for p in ['app/render/horizon.gd','app/tests/test_horizon.gd']},
    'dependencies_verified_unchanged':True,
    'checks':{'headless_horizon':19,'headless_field_surfaces':19,'headless_field_integration':39,'headless_world_presentation':17,'exact_native_pairs':40,'exploratory_native_pairs':24,'native_processes':5,'float32_mutation_detected':True,'combined_native_horizon_test_clean':False,'native_texture_shutdown_errors_reproduced_on_reference':4},
    'artifacts':{p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='evidence-manifest.json'}}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('retained',len(manifest['artifacts']),'artifacts; dependency and runtime hashes verified')
