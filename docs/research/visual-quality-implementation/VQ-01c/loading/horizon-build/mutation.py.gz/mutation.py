from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
out=root/'mutation'
out.mkdir(exist_ok=True)
source=(root/'candidate.gd').read_text().replace('PackedFloat64Array()', 'PackedFloat32Array()')
assert source!=(root/'candidate.gd').read_text()
(out/'candidate.gd').write_text(source)
(out/'reference.gd').write_bytes((root/'reference.gd').read_bytes())
command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script',str(root/'probe.gd'),'--','--directory='+str(out),'--output='+str(out/'parity.json')]
with (out/'parity.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
text=(out/'parity.log').read_text()
data=json.loads((out/'parity.json').read_text())
detected=result.returncode!=0 and not data['complete'] and len(data['failures'])==8 and 'ERROR:' not in text
(out/'result.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'expected_failure':True,'detected':detected},indent=2))
print(text)
assert detected
