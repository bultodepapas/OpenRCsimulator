from pathlib import Path
import json,hashlib,subprocess
root=Path(__file__).resolve().parent
source=Path('app/render/horizon.gd').read_text()
(root/'reference.gd').write_text(source)
needle='\tvertices[0] = Vector3.ZERO\n'
trig='''	# Each ring uses the same azimuths. Keep scalar float64 precision until the vertex boundary.
	var east := PackedFloat64Array()
	var south := PackedFloat64Array()
	east.resize(SAMPLES)
	south.resize(SAMPLES)
	for col: int in SAMPLES:
		var angle: float = TAU * float(col) / SAMPLES
		east[col] = sin(angle)
		south[col] = -cos(angle)
'''
angles=source.replace(needle,needle+trig).replace('\t\t\tvar angle: float = TAU * float(col) / SAMPLES\n\t\t\tvar x: float = sin(angle)\n\t\t\tvar z: float = -cos(angle)', '\t\t\tvar x: float = east[col]\n\t\t\tvar z: float = south[col]')
old='''	for col: int in SAMPLES:
		indices.append_array(PackedInt32Array([0, 1 + col, 1 + (col + 1) % SAMPLES]))
	for row: int in radii.size() - 1:
		for col: int in SAMPLES:
			var a: int = 1 + row * SAMPLES + col
			var b: int = 1 + row * SAMPLES + (col + 1) % SAMPLES
			indices.append_array(PackedInt32Array([a, a + SAMPLES, b, b, a + SAMPLES, b + SAMPLES]))
'''
new='''	# Allocate the fan and ring triangles once, preserving winding and accumulation order.
	indices.resize(SAMPLES * (3 + (radii.size() - 1) * 6))
	var cursor: int = 0
	for col: int in SAMPLES:
		indices[cursor] = 0
		indices[cursor + 1] = 1 + col
		indices[cursor + 2] = 1 + (col + 1) % SAMPLES
		cursor += 3
	for row: int in radii.size() - 1:
		for col: int in SAMPLES:
			var a: int = 1 + row * SAMPLES + col
			var b: int = 1 + row * SAMPLES + (col + 1) % SAMPLES
			indices[cursor] = a
			indices[cursor + 1] = a + SAMPLES
			indices[cursor + 2] = b
			indices[cursor + 3] = b
			indices[cursor + 4] = a + SAMPLES
			indices[cursor + 5] = b + SAMPLES
			cursor += 6
'''
assert old in source
(root/'angles.gd').write_text(angles)
(root/'indices.gd').write_text(source.replace(old,new))
(root/'candidate.gd').write_text(angles.replace(old,new))
paths=['app/render/horizon.gd','app/data/fields/horizon.json','app/project.godot','.tools/Godot_v4.7.2-stable_win64.exe']
(root/'source-before.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}},indent=2))
