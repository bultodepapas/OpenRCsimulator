from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent
reports=[json.loads(p.read_text()) for p in sorted((root/'native').glob('[0-9][0-9].json'))]
samples=[dict(s,run=i+1) for i,d in enumerate(reports) for s in d['samples']]
warm={v:statistics.median(s['usec'] for s in samples if s['variant']==v and s['pair']>0) for v in ['reference','candidate']}
first={v:statistics.median(s['usec'] for s in samples if s['variant']==v and s['pair']==0) for v in ['reference','candidate']}
per_run=[{v:statistics.median(s['usec'] for s in samples if s['variant']==v and s['run']==i and s['pair']>0) for v in ['reference','candidate']} for i in range(1,6)]
explore=json.loads((root/'exploration/01.json').read_text())['samples']
ablations={v:statistics.median(s['usec'] for s in explore if s['variant']==v and s['pair']>0) for v in ['reference','angles','indices','candidate']}
summary={'runs':len(reports),'exact_native_pairs':sum(d['exact_pairs'] for d in reports),'warm_samples_per_variant':35,'warm_median_usec':warm,'first_pair_median_usec':first,'per_run_warm_median_usec':per_run,'warm_reduction_pct':100*(1-warm['candidate']/warm['reference']),'exploration_median_usec':ablations}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
