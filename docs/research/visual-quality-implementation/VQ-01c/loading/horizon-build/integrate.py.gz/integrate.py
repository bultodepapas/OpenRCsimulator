from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
before=json.loads((root/'source-before.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before['source_sha256'].items())
ledger=json.loads((root/'native/campaign.json').read_text())
assert len(ledger)==5 and all(r['clean'] for r in ledger)
assert Path('app/render/horizon.gd').read_text()==(root/'reference.gd').read_text()
Path('app/render/horizon.gd').write_bytes((root/'candidate.gd').read_bytes())
print('Verified pinned inputs unchanged during timing; integrated exact-output candidate.')
