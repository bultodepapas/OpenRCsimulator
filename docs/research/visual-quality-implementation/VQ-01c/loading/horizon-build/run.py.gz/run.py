from pathlib import Path
import subprocess,json,sys
root=Path(__file__).resolve().parent
explore='--explore' in sys.argv
out=root/('exploration' if explore else 'native')
out.mkdir(exist_ok=True)
records=[]
for run in range(1,2 if explore else 6):
    command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script',str(root/'probe.gd'),'--','--directory='+str(root),'--output='+str(out/f'{run:02d}.json')]
    if explore: command.append('--explore')
    if run%2==0: command.append('--reverse')
    with (out/f'{run:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    text=(out/f'{run:02d}.log').read_text()
    clean=result.returncode==0 and 'ERROR:' not in text and 'WARNING:' not in text and json.loads((out/f'{run:02d}.json').read_text())['complete']
    records.append({'run':run,'command':command,'exit_code':result.returncode,'clean':clean})
    (out/'campaign.json').write_text(json.dumps(records,indent=2))
    print(run,clean,text[-90:],flush=True)
    assert clean
