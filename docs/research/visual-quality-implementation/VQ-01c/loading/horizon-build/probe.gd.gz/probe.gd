extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var directory := ""
	var output := ""
	var exploratory := false
	var reverse := false
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--directory="): directory = arg.trim_prefix("--directory=")
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
		if arg == "--explore": exploratory = true
		if arg == "--reverse": reverse = true
	if directory.is_empty() or output.is_empty() or DisplayServer.get_name() == "headless":
		quit(2)
		return
	var variants: Array[String] = ["reference", "candidate"]
	if exploratory: variants = ["reference", "angles", "indices", "candidate"]
	var scripts := {}
	for variant in variants: scripts[variant] = load(directory.path_join(variant + ".gd"))
	var samples := []
	var failures := []
	var pairs := 0
	for pair in range(8):
		var order := variants.duplicate()
		if (pair % 2 == 0) == reverse: order.reverse()
		var shapes := {}
		for variant in order:
			var begin := Time.get_ticks_usec()
			var shape: ArrayMesh = scripts[variant].mesh()
			samples.append({pair = pair, variant = variant, usec = Time.get_ticks_usec() - begin})
			shapes[variant] = shape
		for variant in variants:
			if variant == "reference": continue
			pairs += 1
			if not _same(shapes.reference, shapes[variant]): failures.append(variant + ":" + str(pair))
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify({complete = failures.is_empty(), failures = failures, exact_pairs = pairs, samples = samples,
		engine = Engine.get_version_info(), adapter = RenderingServer.get_video_adapter_name(),
		scope = "native horizon mesh construction including profile validation; readback outside timing; shared host; not total field/startup or FPS"}, "\t"))
	file.close()
	print("horizon exact mesh pairs=", pairs, " failures=", failures)
	await process_frame
	await process_frame
	quit(0 if failures.is_empty() else 1)

func _same(a: ArrayMesh, b: ArrayMesh) -> bool:
	if a == null or b == null or a == b: return false
	if a.get_surface_count() != 1 or b.get_surface_count() != 1: return false
	return var_to_bytes(a.get_aabb()) == var_to_bytes(b.get_aabb()) \
		and a.surface_get_primitive_type(0) == b.surface_get_primitive_type(0) \
		and a.surface_get_material(0) == b.surface_get_material(0) \
		and var_to_bytes(a.surface_get_arrays(0)) == var_to_bytes(b.surface_get_arrays(0))
