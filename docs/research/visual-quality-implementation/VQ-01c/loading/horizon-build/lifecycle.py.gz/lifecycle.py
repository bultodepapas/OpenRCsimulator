from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
source=Path('app/tests/test_horizon.gd').read_text()
(root/'test-original.gd').write_text(source)
original_reference=source.replace('res://render/horizon.gd',(root/'reference.gd').as_posix())
(root/'test-original-reference.gd').write_text(original_reference)
fixed=source.replace('func _initialize() -> void:\n', '''func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	_check_horizon()
	# Let local atmosphere/material references retire before native renderer shutdown.
	await process_frame
	await process_frame
	quit(1 if failures else 0)


func _check_horizon() -> void:
''',1).replace('\t\tquit(1)\n\t\treturn', '\t\treturn')
# The wrapper owns exit after the resource-creating scope has returned.
assert fixed.endswith('\tquit(1 if failures else 0)\n')
fixed=fixed[:-len('\tquit(1 if failures else 0)\n')]
(root/'test-candidate.gd').write_text(fixed)
(root/'test-fixed-reference.gd').write_text(fixed.replace('res://render/horizon.gd',(root/'reference.gd').as_posix()))
records=[]
for name in ['test-original-reference','test-fixed-reference','test-candidate']:
    command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script',str(root/(name+'.gd'))]
    with (root/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    text=(root/(name+'.log')).read_text()
    records.append({'name':name,'command':command,'exit_code':result.returncode,'errors':text.count('ERROR:'),'assertions_passed':'19 checks, 0 failed' in text,'warnings':'WARNING:' in text})
    (root/'lifecycle.json').write_text(json.dumps(records,indent=2))
    print(name,result.returncode,'errors',records[-1]['errors'],flush=True)
    assert result.returncode==0 and records[-1]['assertions_passed']
    if name!='test-original-reference': assert records[-1]['errors']==0 and not records[-1]['warnings']
