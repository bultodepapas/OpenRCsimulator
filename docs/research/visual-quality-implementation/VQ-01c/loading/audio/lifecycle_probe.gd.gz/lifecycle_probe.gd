extends SceneTree

const Effects := preload("res://render/lake/water_effects.gd")
const Lake := preload("res://data/lake_loader.gd")
var _refs: Array[WeakRef] = []

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var mode := args[0]
	var lake: Dictionary = Lake.load_from().lake
	var camera := Camera3D.new()
	root.add_child(camera)
	camera.current = true
	var samples := []
	for cycle in 30:
		var player := Effects.ambient_player(lake)
		root.add_child(player)
		camera.position = player.position
		await physics_frame
		await process_frame
		_refs.append(weakref(player.stream))
		_refs.append(weakref(player.get_stream_playback()))
		if mode == "stop":
			player.stop()
			player.stream = null
		player.queue_free()
		await process_frame
		await process_frame
		samples.append({cycle = cycle + 1, alive = alive(), nodes = int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))})
	var before_drain := alive()
	if mode == "drain":
		await create_timer(0.2).timeout
	var after_drain := alive()
	var file := FileAccess.open(args[1], FileAccess.WRITE)
	file.store_string(JSON.stringify({mode = mode, samples = samples, before_drain = before_drain,
		after_drain = after_drain, mix_rate = AudioServer.get_mix_rate(), next_mix = AudioServer.get_time_to_next_mix()}, "\t") + "\n")
	file.close()
	print("AUDIO ", mode, " before=", before_drain, " after=", after_drain)
	camera.free()
	quit()

func alive() -> int:
	var count := 0
	for ref in _refs:
		if ref.get_ref() != null:
			count += 1
	return count
