from pathlib import Path
import subprocess,json,re
root=Path(__file__).resolve().parents[2]
out=root/'tmp/dt11a-audio'
package=root/'tmp/dt11b-integration/package'
records=[]
for name,cycles in [('pack-2a',2),('pack-2b',2),('pack-50',50)]:
    command=[str(package/'GodotProbe.exe'),'--path',str(root/'tmp/dt11b-integration/empty'),
             '--main-pack',str(package/'OpenRC.exe'),'--audio-driver','Dummy','--resolution','1280x720',
             '--max-fps','60','--verbose','--script',str(root/'research/performance/loading_probe.gd'),
             '--','--output='+str(out/(name+'.json')),'--cycles='+str(cycles)]
    p=subprocess.run(command,capture_output=True,timeout=360)
    log=p.stdout+p.stderr
    (out/(name+'.log')).write_bytes(log)
    record={'name':name,'command':command,'exit_code':p.returncode,
            'engine_error':bool(re.search(rb'(?m)^(?:SCRIPT |SHADER )?ERROR:',log)),
            'leaked':b'instances were leaked' in log}
    records.append(record)
    (out/'package-checks.json').write_text(json.dumps(records,indent=2)+'\n')
    print(record['name'],record['exit_code'],record['engine_error'],record['leaked'],flush=True)
    if p.returncode or record['engine_error'] or record['leaked']: break
