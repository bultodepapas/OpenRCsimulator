from pathlib import Path
import subprocess,json,re
root=Path(__file__).resolve().parents[2]
out=root/'tmp/dt11a-audio'
records=[]
for trial in range(1,4):
    for mode in ['free','stop','drain']:
        name=f'{mode}-{trial}'
        command=[str(root/'.tools/Godot_v4.7.2-stable_win64_console.exe'),'--headless','--path',str(root/'app'),'--audio-driver','Dummy','--verbose','--script',str(out/'lifecycle_probe.gd'),'--',mode,str(out/(name+'.json'))]
        p=subprocess.run(command,capture_output=True,timeout=60)
        log=p.stdout+p.stderr
        (out/(name+'.log')).write_bytes(log)
        row={'name':name,'command':command,'exit_code':p.returncode,'engine_error':bool(re.search(rb'(?m)^(?:SCRIPT )?ERROR:',log)),'leaked':b'instances were leaked' in log}
        records.append(row)
        print(row['name'],row['exit_code'],row['engine_error'],row['leaked'],flush=True)
(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
