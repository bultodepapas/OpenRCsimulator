from pathlib import Path
import subprocess, json

root=Path(__file__).resolve().parent
app=root/'comparison/app'
source=app/'render/ground.gd'
original=source.read_bytes()
candidate=original.decode().replace('\r\n', '\n')
mutated=candidate.replace('static var _default_grass_bytes := PackedByteArray()',
    'static var _default_grass_bytes := PackedByteArray()\nstatic var _shared_default: Image')
start=mutated.index('static func _default_grass_image() -> Image:')
end=mutated.index('\n\n## Pack contained',start)
mutated=mutated[:start]+'''static func _default_grass_image() -> Image:
	if _shared_default == null:
		_shared_default = grass_image()
		_default_grass_bytes = _shared_default.get_data()
	return _shared_default
'''+mutated[end:]
(root/'mutation-shared-image.gd').write_text(mutated)
command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--headless','--path',str(app),
    '--audio-driver','Dummy','--script',str(root/'test_ground_image_cache.gd')]
try:
    source.write_text(mutated)
    with (root/'checks/mutation-shared-image.log').open('w') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,timeout=60)
    log=(root/'checks/mutation-shared-image.log').read_text()
    detected=result.returncode!=0 and 'FAIL cold image edits do not mutate a live warm image' in log
    (root/'checks/mutation-shared-image.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'detected':detected,'expected_failure':True},indent=2))
    print('shared image mutation rejected:',detected)
    if not detected: raise SystemExit(1)
finally:
    source.write_bytes(original)
