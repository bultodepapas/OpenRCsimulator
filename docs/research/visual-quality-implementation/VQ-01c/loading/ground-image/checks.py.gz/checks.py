from pathlib import Path
import subprocess, json, hashlib

ROOT = Path(__file__).resolve().parent
APP = ROOT/'comparison/app'
ENGINE = Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()
OUT = ROOT/'checks'
OUT.mkdir()
records=[]
def run(name, app, script, native=False, extra=()):
    command=[str(ENGINE), '--path',str(app),'--audio-driver','Dummy']
    if not native: command += ['--headless']
    command+=['--script',str(script),*extra]
    log=OUT/f'{name}.log'
    with log.open('w') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
    text=log.read_text()
    item={'name':name,'command':command,'exit_code':result.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
          'engine_errors':any(x in text for x in ['ERROR:', 'SCRIPT ERROR']),
          'warnings':[line for line in text.splitlines() if 'WARNING:' in line],
          'passing_check_lines':sum(line.startswith('ok') or line.startswith('PASS') for line in text.splitlines())}
    records.append(item)
    (OUT/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name, result.returncode, 'errors', item['engine_errors'], 'warnings', len(item['warnings']),flush=True)
    if result.returncode or item['engine_errors']: raise SystemExit(name+' failed')

run('cache-native',APP,ROOT/'test_ground_image_cache.gd',True)
run('cache-shared-tree',Path('app').resolve(),Path('app/tests/test_ground_image_cache.gd').resolve())
for name in ['test_field_surfaces','test_near_grass','test_field_integration','test_world_presentation_context','test_workshop_trial']:
    run(name,APP,'res://tests/'+name+'.gd')
