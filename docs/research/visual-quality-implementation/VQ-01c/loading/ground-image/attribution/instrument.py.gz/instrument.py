from pathlib import Path
import subprocess, json, hashlib

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'source/app'
anchors = {
    'render/field.gd': ('static func build(', [
        'var grass:', 'for surface:', 'for object_data:', 'for cue:',
        'if not field.get("flight_cues"', 'var scenery_options', 'Scenery.attach(',
        'var lake_node', 'var scenery_node', 'if LandscapeOptions.enabled()',
        'FieldProjectedShadows.attach(', 'return result']),
    'render/world/world.gd': ('static func build(', [
        'var world_environment', 'var field_node', 'var sun :=', 'var lights_node',
        'var airfield_lighting', 'if field.get("id", "") == "default":',
        'parent.set_meta("night_options"', 'return {environment']),
    'ui/home_scene.gd': ('func _init(', [
        'var env:', '_shadow =', 'show_aircraft(', 'var pos :=', 'World.update(']),
    'main.gd': ('func _build_world(', [
        '_airplane =', 'var snapshot:', 'var built:', '_field_world_lighting =',
        '_extent =', '_shadow =', 'Shadow.bind_model(', '_night_kit =', '_camera =', 'return true']),
}
changed = []
for rel, (function, prefixes) in anchors.items():
    p = APP / rel
    original = p.read_text(encoding='utf-8')
    (ROOT / (rel.replace('/', '_') + '.original')).write_text(original, encoding='utf-8')
    lines = original.splitlines(keepends=True)
    active = False
    output = []
    for line in lines:
        if line.startswith(function):
            active = True
            output.extend([line, '\tvar dt_phase_clock := Time.get_ticks_usec()\n'])
            continue
        if active and (line.startswith('func ') or line.startswith('static func ')):
            active = False
        if active and line.startswith('\t') and not line.startswith('\t\t') and any(line.strip().startswith(x) for x in prefixes):
            label = rel + ' before ' + line.strip()[:75]
            output.append('\tprint("DT_PHASE ", ' + json.dumps(label) + ', " ", Time.get_ticks_usec() - dt_phase_clock)\n')
            output.append('\tdt_phase_clock = Time.get_ticks_usec()\n')
        output.append(line)
    p.write_text(''.join(output), encoding='utf-8')
    changed.append(rel)
(ROOT/'instrumented-files.json').write_text(json.dumps(changed, indent=2))

