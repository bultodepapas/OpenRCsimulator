from pathlib import Path
import subprocess, json, time, hashlib, statistics

ROOT = Path(__file__).resolve().parent
APP = ROOT/'comparison/app'
ENGINE = Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()
PROBE = ROOT/'loading_probe.gd'
PROBE.write_bytes(Path('research/performance/loading_probe.gd').read_bytes())
OUT = ROOT/'pairs-complete'
OUT.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {'source_commit':'5f7f4ad529940743bdc16e3d9691243a8a1c6cd8',
    'engine_sha256':sha(ENGINE), 'probe_sha256':sha(PROBE),
    'source_archive_sha256':sha(Path('tmp/vq02a-completion/source.zip')),
    'reference_sha256':sha(ROOT/'ground_reference.gd'), 'candidate_sha256':sha(ROOT/'ground_candidate.gd'),
    'scope':'Alternating serial process pairs; two Home/Fly cycles each; OS/import/driver caches and host load uncontrolled.', 'runs':[]}
for pair in range(1,6):
    for variant in (['reference','candidate'] if pair%2 else ['candidate','reference']):
        (APP/'render/ground.gd').write_bytes((ROOT/f'ground_{variant}.gd').read_bytes())
        name=f'{pair:02}-{variant}'
        report=OUT/f'{name}.json'
        log=OUT/f'{name}.log'
        command=[str(ENGINE),'--path',str(APP),'--audio-driver','Dummy','--resolution','1280x720',
                 '--max-fps','60','--script',str(PROBE),'--','--output='+str(report),'--cycles=2']
        begin=time.monotonic()
        with log.open('w') as out:
            result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,timeout=90)
        text=log.read_text()
        data=json.loads(report.read_text()) if report.exists() else {}
        valid=result.returncode==0 and data.get('complete',False) and not any(s in text for s in ['ERROR:', 'WARNING:', 'SCRIPT ERROR'])
        active=bool(data) and all(not c['paused_at_first_draw'] and c['tick_at_first_draw']>0 for c in data['cycles'])
        record={'pair':pair,'variant':variant,'command':command,'exit_code':result.returncode,
                'elapsed_s':time.monotonic()-begin,'complete_clean':valid,'active_draws':active,
                'report_sha256':sha(report) if report.exists() else None,'log_sha256':sha(log)}
        manifest['runs'].append(record)
        (OUT/'campaign.json').write_text(json.dumps(manifest,indent=2)+'\n')
        print(name, 'clean',valid,'active',active, 'home',data.get('home_first_draw_engine_elapsed_usec'),flush=True)
        if not valid: raise SystemExit('Invalid run; stop and retain evidence')
(APP/'render/ground.gd').write_bytes((ROOT/'ground_candidate.gd').read_bytes())
rows=[]
for pair in range(1,6):
    a=json.loads((OUT/f'{pair:02}-reference.json').read_text())
    b=json.loads((OUT/f'{pair:02}-candidate.json').read_text())
    row={'pair':pair}
    for label, fn in {
        'home':lambda d:d['home_first_draw_engine_elapsed_usec'],
        'home_sync':lambda d:d['home_sync_usec'],
        'first_fly':lambda d:d['cycles'][0]['fly_first_draw_usec'],
        'first_fly_sync':lambda d:d['cycles'][0]['fly_sync_usec'],
        'warm_fly':lambda d:d['cycles'][1]['fly_first_draw_usec'],
        'return_home':lambda d:d['cycles'][0]['return_first_draw_usec'],
    }.items(): row[label]={'reference_usec':fn(a),'candidate_usec':fn(b),'gain_pct':100*(fn(a)-fn(b))/fn(a)}
    rows.append(row)
summary={key:{'reference_median_usec':statistics.median(x[key]['reference_usec'] for x in rows),
              'candidate_median_usec':statistics.median(x[key]['candidate_usec'] for x in rows),
              'paired_gains_pct':[x[key]['gain_pct'] for x in rows]} for key in rows[0] if key!='pair'}
(OUT/'metrics.json').write_text(json.dumps({'pairs':rows,'summary':summary},indent=2)+'\n')
print(json.dumps(summary,indent=2))
