## Isolated CPU material-construction attribution, no frame-time claim.
extends SceneTree

var _failed := false


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var output := ""
	var reference_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="):
			output = arg.trim_prefix("--output=")
		elif arg.begins_with("--reference="):
			reference_path = arg.trim_prefix("--reference=")
		else:
			push_error("Unknown argument: " + arg)
			quit(2)
			return
	if output.is_empty() or reference_path.is_empty() or FileAccess.file_exists(output):
		push_error("Provide --reference and a new --output")
		quit(2)
		return
	var reference: Script = load(reference_path)
	var candidate: Script = load("res://render/ground.gd")
	load("res://render/shader_clock.gd").register()
	var samples: Array = []
	for pair in range(6):
		var order := ["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]
		var signatures: Dictionary = {}
		for variant: String in order:
			var builder: Script = reference if variant == "reference" else candidate
			var begin := Time.get_ticks_usec()
			var material: ShaderMaterial = builder.grass_material()
			var elapsed := Time.get_ticks_usec() - begin
			var signature := _signature(material)
			signatures[variant] = signature
			samples.append({pair = pair, variant = variant, construction_usec = elapsed,
				cold_default = pair == 0, signature_sha256 = signature.sha256_text()})
			material = null
		if signatures.reference != signatures.candidate:
			_failed = true
	var report := {format = "openrc-grass-material-probe v1", complete = not _failed,
		scope = "CPU material construction including texture submission; readback/signatures outside timed interval; no draw or GPU-time claim",
		engine = Engine.get_version_info(), adapter = RenderingServer.get_video_adapter_name(),
		cache_bytes = candidate._default_grass_bytes.size(), samples = samples}
	var file := FileAccess.open(output, FileAccess.WRITE)
	if file == null:
		push_error("Cannot create output")
		quit(2)
		return
	file.store_string(JSON.stringify(report, "\t") + "\n")
	file.close()
	print("grass material parity: ", not _failed)
	quit(1 if _failed else 0)


func _signature(material: ShaderMaterial) -> String:
	var signature: Array = [material.shader.resource_path]
	for uniform: Dictionary in RenderingServer.get_shader_parameter_list(material.shader.get_rid()):
		var key := str(uniform.name)
		var value: Variant = material.get_shader_parameter(key)
		if value is Texture2D:
			var image: Image = value.get_image()
			var digest := HashingContext.new()
			digest.start(HashingContext.HASH_SHA256)
			digest.update(image.get_data())
			value = [image.get_size(), image.get_format(), image.has_mipmaps(), digest.finish().hex_encode()]
		signature.append([key, value])
	return var_to_bytes(signature).hex_encode()
