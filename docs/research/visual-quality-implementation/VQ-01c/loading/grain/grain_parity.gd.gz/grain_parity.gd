extends SceneTree
func _initialize() -> void:
    var reference: Script = load("C:/DEVELOPMENT/OpenRCsimulator/tmp/dt11a-startup/finish-reference.gd")
    var candidate: Script = load("res://aircraft/ugly_stik_finish.gd")
    var start := Time.get_ticks_usec()
    var before: ImageTexture = reference.call("grain")
    var before_usec := Time.get_ticks_usec() - start
    start = Time.get_ticks_usec()
    var after: ImageTexture = candidate.call("grain")
    var after_usec := Time.get_ticks_usec() - start
    var old_image := before.get_image()
    var new_image := after.get_image()
    var same := old_image.get_data() == new_image.get_data() and old_image.get_size() == new_image.get_size() and old_image.get_format() == new_image.get_format() and old_image.get_mipmap_count() == new_image.get_mipmap_count()
    var hash := HashingContext.new()
    hash.start(HashingContext.HASH_SHA256)
    hash.update(new_image.get_data())
    print(JSON.stringify({"reference_usec": before_usec, "candidate_usec": after_usec, "equal": same, "image_sha256": hash.finish().hex_encode(), "bytes": new_image.get_data().size(), "mipmaps": new_image.get_mipmap_count()}))
    quit(0 if same else 1)
