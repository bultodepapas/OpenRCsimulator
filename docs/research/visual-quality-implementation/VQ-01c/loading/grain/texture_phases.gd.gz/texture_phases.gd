extends SceneTree
const Finish := preload("res://aircraft/ugly_stik_finish.gd")
func _initialize() -> void:
    for method: String in ["atlas", "normal_map", "grain"]:
        var start := Time.get_ticks_usec()
        var texture: ImageTexture = Finish.atlas() if method == "atlas" else Finish.normal_map() if method == "normal_map" else Finish.grain()
        var elapsed := Time.get_ticks_usec() - start
        print("TEXTURE ", method, " usec=", elapsed, " bytes=", texture.get_image().get_data().size())
    quit()

