from pathlib import Path
root=Path(__file__).resolve().parent
source=Path('app/tests/test_downloaded_habitats.gd').read_text()
source=source.replace('\t_test_default_guard(field, scenery, lake)\n','\t_test_default_guard(field, scenery, lake)\n\t_test_shore_retry(field, scenery, lake)\n',1)
source+='''

## DT-11a: rejecting a crowded candidate must preserve the deterministic seed tape.
func _test_shore_retry(field: Dictionary, scenery: Dictionary, lake: Dictionary) -> void:
	var exclusions := Habitats.exclusions_for(scenery) # Shore plants must not exclude the bank itself.
	var surfaces := _surface_rects(field)
	var anchor: Dictionary = Habitats._shore_cluster_anchors(lake)[0]
	var selected: Array[Dictionary] = []
	var sequence := {next = 1}
	var first := Habitats._append_shore_plant(selected, field, exclusions, surfaces, lake,
		sequence, anchor, "reed_aredon", 0, 0, "reed", 0.85)
	_check("shore retry fixture accepts a seed-1 search", not first.is_empty())
	if first.is_empty(): return
	_check("accepted search consumes through its seed without appending selected",
		sequence.next == int(first.seed) + 1 and selected.is_empty())
	selected.append(first.duplicate(true))
	var selected_bytes := var_to_bytes(selected)
	sequence.next = int(first.seed)
	var next := Habitats._append_shore_plant(selected, field, exclusions, surfaces, lake,
		sequence, anchor, "reed_aredon", 0, 0, "reed", 0.85)
	_check("retry rejects the occupied seed and finds another shore point", not next.is_empty())
	if next.is_empty(): return
	_check("retry keeps the exact spacing and seed progression",
		int(next.seed) > int(first.seed) and sequence.next == int(next.seed) + 1
		and Vector2(next.north, next.east).distance_to(Vector2(first.north, first.east)) >= 0.85)
	var bank := LakeSurface.sample_terrain_validated(lake, next.north, next.east)
	_check("retry still satisfies dry-bank and exclusion constraints",
		bank.covered and bank.region == "bank" and bank.signed_shore_distance_m <= -0.75
		and bank.signed_shore_distance_m >= -4.5 and bank.ground_down_m > 0.0
		and bank.signed_bank_distance_m > 0.0 and Grass.accepts(next.north, next.east, field, exclusions))
	sequence.next = 900001
	var exhausted := Habitats._append_shore_plant(selected, field, exclusions, surfaces, lake,
		sequence, anchor, "reed_aredon", 0, 0, "reed", 1000000000.0)
	_check("crowded search consumes exactly 64 candidates and preserves selected",
		exhausted.is_empty() and sequence.next == 900065 and var_to_bytes(selected) == selected_bytes)
'''
(root/'test_downloaded_candidate.gd').write_text(source,newline='\n')
(root/'test_downloaded_repaired_reference.gd').write_text(source.replace('res://scenery/botanical_habitats.gd',(root/'reference.gd').as_posix()),newline='\n')
