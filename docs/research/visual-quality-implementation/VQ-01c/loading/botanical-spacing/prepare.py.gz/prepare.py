from pathlib import Path
import hashlib, json, subprocess
root = Path(__file__).resolve().parent
source = Path('app/scenery/botanical_habitats.gd').read_text()
(root/'reference.gd').write_text(source, newline='\n')
block = '\t\tvar bank_sample := _shore_sample(lake, north, east, field, exclusions)\n\t\tif bank_sample.is_empty():\n\t\t\tcontinue\n'
assert source.count(block) == 1
source = source.replace(block, '')
anchor = '\t\tif not spaced:\n\t\t\tcontinue\n'
assert source.count(anchor) == 1
source = source.replace(anchor, anchor + '\t\t# Reject crowded candidates before the more expensive terrain and footprint queries.\n' + block)
(root/'candidate.gd').write_text(source, newline='\n')
for variant in ['reference', 'candidate']:
    scenery = Path('app/scenery/scenery.gd').read_text().replace('res://scenery/botanical_habitats.gd', (root/f'{variant}.gd').as_posix())
    (root/f'scenery_{variant}.gd').write_text(scenery, newline='\n')
    field = Path('app/render/field.gd').read_text().replace('res://scenery/scenery.gd', (root/f'scenery_{variant}.gd').as_posix())
    (root/f'field_{variant}.gd').write_text(field, newline='\n')
paths = [p for p in Path('app').rglob('*') if p.is_file() and '.godot' not in p.parts and p.suffix in ['.gd','.json','.godot']]
(root/'source-before.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}},indent=2))
