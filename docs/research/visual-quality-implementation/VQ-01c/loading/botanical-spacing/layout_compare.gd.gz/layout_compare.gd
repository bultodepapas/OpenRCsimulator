extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var directory: String = get_script().resource_path.get_base_dir()
	var output := ""
	var trace := false
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
		if arg == "--trace": trace = true
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var reference: Script = load(directory.path_join("trace_reference.gd" if trace else "reference.gd"))
	var candidate: Script = load(directory.path_join("trace_candidate.gd" if trace else "candidate.gd"))
	var field_result: Dictionary = load("res://data/field_loader.gd").load_from()
	var scenery_result: Dictionary = load("res://scenery/scenery_loader.gd").load_from("res://data/scenery/default.json", field_result.field)
	var lake_result: Dictionary = load("res://data/lake_loader.gd").load_from()
	if not field_result.ok or not scenery_result.ok or not lake_result.ok:
		quit(2)
		return
	var cases: Array[Dictionary] = []
	for kind: String in ["default", "no_lake", "shifted_pilot", "blocked_shore", "invalid_lake", "foreign_field"]:
		for quality: String in ["low", "balanced", "high"]:
			var field: Dictionary = field_result.field.duplicate(true)
			var scenery: Dictionary = scenery_result.scenery.duplicate(true)
			var lake: Dictionary = lake_result.lake.duplicate(true)
			if kind == "no_lake": lake = {}
			if kind == "shifted_pilot":
				field.pilot.north += 3.0
				field.pilot.east -= 2.0
			if kind == "foreign_field": field.id = "foreign"
			if kind == "invalid_lake": lake = {id = "invalid"}
			if kind == "blocked_shore":
				var bank: PackedFloat64Array = lake.bank_ne_m
				var min_n := INF
				var min_e := INF
				var max_n := -INF
				var max_e := -INF
				for index in range(0, bank.size(), 2):
					min_n = minf(min_n, bank[index])
					max_n = maxf(max_n, bank[index])
					min_e = minf(min_e, bank[index+1])
					max_e = maxf(max_e, bank[index+1])
				var points: Array[Vector2] = [Vector2(min_n-5, min_e-5), Vector2(max_n+5, min_e-5), Vector2(max_n+5, max_e+5), Vector2(min_n-5, max_e+5)]
				scenery.groups.append({id = "test_shore_blocker", type = "patch", surface = "gravel", points = points})
			var input_bytes := var_to_bytes([field, scenery, lake])
			if trace:
				reference._probe_shore_calls = 0
				candidate._probe_shore_calls = 0
			var expected: Array = reference.layout(field, scenery, quality, lake)
			var actual: Array = candidate.layout(field, scenery, quality, lake)
			var expected_bytes := var_to_bytes(expected)
			var actual_bytes := var_to_bytes(actual)
			cases.append({kind = kind, quality = quality, plants = expected.size(),
				exact = expected_bytes == actual_bytes,
				inputs_unchanged = input_bytes == var_to_bytes([field, scenery, lake]),
				reference_sha256 = _hash(expected_bytes), candidate_sha256 = _hash(actual_bytes)})
			if trace:
				cases.back()["shore_calls"] = {reference = reference._probe_shore_calls, candidate = candidate._probe_shore_calls}
	var complete := cases.all(func(row: Dictionary) -> bool: return row.exact and row.inputs_unchanged)
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify({complete = complete, cases = cases}, "\t"))
	file.close()
	print("botanical layout parity: %d cases complete=%s" % [cases.size(), complete])
	quit(0 if complete else 1)

func _hash(bytes: PackedByteArray) -> String:
	var context := HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(bytes)
	return context.finish().hex_encode()
