from pathlib import Path
import hashlib, json, statistics, subprocess, sys
root = Path(__file__).resolve().parent
identities = json.loads((root/'source-before.json').read_text())['hashes']
runs=[]
for index in range(5):
    for name,digest in identities.items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
    output=root/f'field-{index+1}.json'
    command=[sys.executable,'tools/godot/run_checked.py','--out-dir',str(root/'checks'),'--label',f'field-{index+1}',
        '--timeout','120','--require-text','field comparison pairs=6 failures=[]','--',
        '.tools/Godot_v4.7.2-stable_win64_console.exe','--path','app','--audio-driver','Dummy','--script',str(root/'field_compare.gd'),
        '--','--output='+str(output)]
    if index%2: command+=['--reverse']
    subprocess.run(command,check=True)
    data=json.loads(output.read_text())
    assert data['complete'] and not data['failures']
    runs.append({v:{k:statistics.median(s[k] for s in data['samples'] if s['pair']>0 and s['variant']==v)
        for k in ['usec','botanical_ms']} for v in ['reference','candidate']})
summary={'runs':runs,'exact_field_pairs':30,'median_of_process_medians':{v:{k:statistics.median(r[v][k] for r in runs)
    for k in ['usec','botanical_ms']} for v in ['reference','candidate']}}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
for name,digest in identities.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
print(json.dumps(summary))
