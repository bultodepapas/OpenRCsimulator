from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
checks=[('test_botanical_habitats.gd','0 failures'),('test_downloaded_habitats.gd','0 failures'),
        ('test_woodland_edge_habitat.gd','0 failures'),('test_field_integration.gd','all field integration checks passed'),
        ('test_scenery_build.gd','all scenery build checks passed')]
for name,marker in checks:
    subprocess.run([sys.executable,'tools/godot/run_checked.py','--out-dir',str(root/'checks'),
        '--label',name.removesuffix('.gd'),'--timeout','120','--require-text',marker,'--',
        '.tools/Godot_v4.7.2-stable_win64_console.exe','--headless','--path','app','--audio-driver','Dummy',
        '--script','res://tests/'+name],check=True)
