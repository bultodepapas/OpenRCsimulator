from pathlib import Path
root=Path(__file__).resolve().parent
signature='static func _shore_sample(lake: Dictionary, north: float, east: float, field: Dictionary,\n\texclusions: Array) -> Dictionary:\n'
for variant in ['reference','candidate']:
    source=(root/f'{variant}.gd').read_text()
    assert source.count(signature)==1
    source=source.replace('extends RefCounted','extends RefCounted\nstatic var _probe_shore_calls := 0',1)
    source=source.replace(signature,signature+'\t_probe_shore_calls += 1\n',1)
    (root/f'trace_{variant}.gd').write_text(source,newline='\n')
