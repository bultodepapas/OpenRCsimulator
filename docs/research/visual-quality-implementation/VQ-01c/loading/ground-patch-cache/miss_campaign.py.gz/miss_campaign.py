from pathlib import Path
import json
import statistics
import subprocess
import sys
root = Path(__file__).resolve().parent
medians = []
for index in range(5):
    output = root / f'miss-{index+1}.json'
    command = [sys.executable, 'tools/godot/run_checked.py', '--out-dir', str(root / 'checks'),
        '--label', f'miss-{index+1}', '--timeout', '60', '--require-text', 'pairs=12 exact=12 samples=24', '--',
        '.tools/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'app',
        '--script', str(root / 'patch_miss_probe.gd'), '--', '--output=' + str(output)]
    if index % 2: command.append('--reverse')
    subprocess.run(command, check=True)
    data = json.loads(output.read_text())
    assert data['complete'] and not data['failures']
    medians.append(data['medians_usec_excluding_pair_1'])
summary = {'process_medians_usec': medians, 'exact_pairs': 60,
    'median_of_process_medians_usec': {v: statistics.median(m[v] for m in medians) for v in ['reference','candidate']}}
(root / 'miss-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
