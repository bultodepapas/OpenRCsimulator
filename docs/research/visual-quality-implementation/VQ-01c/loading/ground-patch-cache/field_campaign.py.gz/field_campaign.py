from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import sys

root = Path(__file__).resolve().parent
engine = Path('.tools/Godot_v4.7.2-stable_win64_console.exe').resolve()
identity_paths = list(Path('app').rglob('*.gd')) + list(Path('app/data').rglob('*.json')) + [Path('app/project.godot')]
hashes = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in identity_paths}
runs=[]
for index in range(5):
    out = root/f'field-run-{index+1}.json'
    command=[sys.executable,'tools/godot/run_checked.py','--out-dir',str(root/'checks'),
             '--label',f'field-{index+1}','--timeout','120','--require-text','field comparison pairs=6 failures=[]','--',
             str(engine),'--path','app','--audio-driver','Dummy','--script',str(root/'field_compare.gd'),
             '--','--output='+str(out)]
    if index%2: command+=['--reverse']
    subprocess.run(command,check=True)
    data=json.loads(out.read_text())
    assert data['complete'] and not data['failures']
    med={v:statistics.median(s['usec'] for s in data['samples'] if s['variant']==v and s['pair']>0) for v in ['reference','candidate']}
    runs.append({'run':index+1,**med,'reduction_percent':100*(1-med['candidate']/med['reference'])})
    for path,digest in hashes.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
summary={'runs':runs,'exact_pairs':30,'cache_bytes':data['cache_bytes'],'cache_entries':data['cache_entries'],
         'median_of_run_medians_usec':{v:statistics.median(r[v] for r in runs) for v in ['reference','candidate']}}
m=summary['median_of_run_medians_usec']
summary['reduction_percent']=100*(1-m['candidate']/m['reference'])
(root/'field-summary.json').write_text(json.dumps(summary,indent=2))
(root/'campaign-input-hashes.json').write_text(json.dumps(hashes,indent=2))
print(json.dumps(summary,indent=2))
