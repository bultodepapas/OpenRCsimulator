from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
engine = '.tools/Godot_v4.7.2-stable_win64_console.exe'
checks = [
    ('cache', 'test_ground_patch_cache.gd', '94 checks, 0 failures'),
    ('ground', 'test_scenery_ground_lu08.gd', 'LU08 scenery ground checks passed'),
    ('gravel', 'test_landscape_gravel.gd', '0 failures'),
    ('scenery', 'test_scenery_build.gd', 'all scenery build checks passed'),
    ('field', 'test_field_integration.gd', 'all field integration checks passed'),
    ('surfaces', 'test_field_surfaces.gd', '0 failed'),
    ('flow', 'test_world_flow.gd', '0 failed'),
]
for label, script, marker in checks:
    command = [sys.executable, 'tools/godot/run_checked.py', '--out-dir', str(root / 'checks'),
        '--label', 'production-' + label, '--timeout', '120', '--require-text', marker, '--',
        engine, '--headless', '--path', 'app', '--audio-driver', 'Dummy', '--script', 'res://tests/' + script]
    subprocess.run(command, check=True)
for script in ['res://scenery/ground_features.gd', 'res://tests/test_ground_patch_cache.gd']:
    subprocess.run([sys.executable, 'tools/godot/run_checked.py', '--out-dir', str(root / 'checks'),
        '--label', 'production-parse', '--timeout', '60', '--', engine, '--headless', '--path', 'app',
        '--script', script, '--check-only'], check=True)
