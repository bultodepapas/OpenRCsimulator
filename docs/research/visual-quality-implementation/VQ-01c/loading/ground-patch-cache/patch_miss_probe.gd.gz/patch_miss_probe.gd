## DT-11a CPU-only miss-cost comparison for the default gravel patch.
## The production caller in scenery.gd converts normalized group.points with _xz(), then passes
## group.surface, effective theme and group.seed to GroundFeatures.patch(). This probe uses the
## same field/scenery loaders and Scenery._xz helper, with the default scenery theme and identity kit transform.
## Run headless: godot --headless --path app --script <absolute path to this file> -- --output=<new report path> [--reverse]
extends SceneTree

const FieldLoader = preload("res://data/field_loader.gd")
const SceneryLoader = preload("res://scenery/scenery_loader.gd")
const Scenery = preload("res://scenery/scenery.gd")
const MeshKit = preload("res://scenery/mesh_kit.gd")

const PAIR_COUNT := 12

var _reference_path := ""
var _candidate_path := ""
var _output_path := ""
var _reverse := false
var _reference: Script
var _candidate: Script
var _samples: Array[Dictionary] = []
var _failures: Array[Dictionary] = []
var _exact_pairs := 0


func _initialize() -> void:
	var pair_dir: String = get_script().resource_path.get_base_dir()
	_reference_path = pair_dir.path_join("ground_reference.gd")
	_candidate_path = pair_dir.path_join("ground_candidate.gd")
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--output="):
			_output_path = argument.trim_prefix("--output=")
		elif argument == "--reverse":
			_reverse = true
	if _output_path.is_empty():
		push_error("Pass --output=<new report path>")
		quit(2)
		return
	if FileAccess.file_exists(_output_path):
		push_error("Refusing to overwrite existing report: " + _output_path)
		quit(2)
		return
	_reference = load(_reference_path) as Script
	_candidate = load(_candidate_path) as Script
	_run.call_deferred()


func _run() -> void:
	if _reference == null:
		_failures.append({stage = "load", variant = "reference", path = _reference_path})
	if _candidate == null:
		_failures.append({stage = "load", variant = "candidate", path = _candidate_path})
	var patch_input := _default_gravel_patch()
	if not bool(patch_input.get("ok", false)):
		_failures.append({stage = "input", detail = patch_input.get("error", "default gravel patch unavailable")})
	if _reference != null and _candidate != null and bool(patch_input.get("ok", false)):
		_run_pairs(patch_input)
	var medians := {
		"reference": _median_usec("reference", 1),
		"candidate": _median_usec("candidate", 1),
	}
	var report := {
		complete = _failures.is_empty() and _samples.size() == PAIR_COUNT * 2 and _exact_pairs == PAIR_COUNT,
		pair_count = PAIR_COUNT,
		exact_pairs = _exact_pairs,
		first_pair_retained_but_excluded_from_medians = 1,
		medians_usec_excluding_pair_1 = medians,
		variants = {reference = _reference_path, candidate = _candidate_path},
		input = patch_input.get("metadata", {}),
		cache_policy = "candidate static cache cleared outside timing before every timed call",
		renderer_requirement = "none; CPU-only patch generation is valid headless",
		samples = _samples,
		failures = _failures,
	}
	var output := FileAccess.open(_output_path, FileAccess.WRITE)
	if output == null:
		push_error("Could not create report: " + _output_path)
		quit(2)
		return
	output.store_string(JSON.stringify(report, "\t"))
	output.close()
	print("patch miss probe complete: pairs=%d exact=%d samples=%d medians_usec=%s failures=%d output=%s" % [
		PAIR_COUNT, _exact_pairs, _samples.size(), JSON.stringify(medians), _failures.size(), _output_path,
	])
	quit(0 if bool(report.complete) else 1)


func _default_gravel_patch() -> Dictionary:
	var loaded_field: Dictionary = FieldLoader.load_from()
	if not bool(loaded_field.get("ok", false)):
		return {ok = false, error = "default field load failed: %s" % str(loaded_field.get("errors", []))}
	var loaded_scenery: Dictionary = SceneryLoader.load_from(SceneryLoader.DEFAULT_PATH, loaded_field.field)
	if not bool(loaded_scenery.get("ok", false)):
		return {ok = false, error = "default scenery load failed: %s" % str(loaded_scenery.get("errors", []))}
	var scenery: Dictionary = loaded_scenery.scenery
	var patch_group: Dictionary = {}
	for group: Dictionary in scenery.groups:
		if group.get("type") == "patch" and group.get("surface") == "gravel":
			patch_group = group
			break
	if patch_group.is_empty():
		return {ok = false, error = "normalized default scenery has no gravel patch group"}
	var polygon := PackedVector2Array()
	for point: Vector2 in patch_group.points:
		polygon.append(Scenery._xz(point))
	return {
		ok = true,
		poly = polygon,
		surface = str(patch_group.surface),
		theme = str(scenery.theme),
		seed = int(patch_group.seed),
		metadata = {
			field_id = str(loaded_field.field.get("id", "")),
			scenery_path = SceneryLoader.DEFAULT_PATH,
			group_id = str(patch_group.id),
			point_count = polygon.size(),
			surface = str(patch_group.surface),
			theme = str(scenery.theme),
			seed = int(patch_group.seed),
			transform = "identity (same fresh ground-cell MeshKit transform as Scenery.build)",
		},
	}


func _run_pairs(patch_input: Dictionary) -> void:
	var polygon: PackedVector2Array = patch_input.poly
	var surface: String = patch_input.surface
	var theme: String = patch_input.theme
	var seed: int = patch_input.seed
	for pair_index in PAIR_COUNT:
		var order: Array[String] = ["reference", "candidate"]
		var reference_first := (pair_index % 2) == 0
		if _reverse:
			reference_first = not reference_first
		if not reference_first:
			order.reverse()
		var outputs := {}
		for variant: String in order:
			# Allocate/reset before the clock. Only the patch call is measured.
			_candidate._patch_cache.clear()
			_candidate._patch_cache_bytes = 0
			var kit := MeshKit.new()
			kit.xf = Transform3D.IDENTITY
			var started := Time.get_ticks_usec()
			if variant == "reference":
				_reference.patch(kit, polygon, surface, theme, seed)
			else:
				_candidate.patch(kit, polygon, surface, theme, seed)
			var elapsed_usec := Time.get_ticks_usec() - started
			# Snapshot and exact byte comparison stay outside the timed section.
			var arrays := _mesh_array_bytes(kit)
			outputs[variant] = arrays
			_samples.append({
				pair = pair_index + 1,
				variant = variant,
				order_index = order.find(variant),
				usec = elapsed_usec,
				vertices = kit.verts.size(),
				cache_cleared_before_call = true,
			})
		if outputs.reference == outputs.candidate:
			_exact_pairs += 1
		else:
			var different_arrays: Array[String] = []
			var labels: Array[String] = ["verts", "norms", "cols"]
			for index in labels.size():
				if outputs.reference[index] != outputs.candidate[index]:
					different_arrays.append(labels[index])
			_failures.append({pair = pair_index + 1, reason = "exact packed-array bytes differ", arrays = different_arrays})


func _mesh_array_bytes(kit: MeshKit) -> Array:
	return [kit.verts.to_byte_array(), kit.norms.to_byte_array(), kit.cols.to_byte_array()]


func _median_usec(variant: String, first_pair_excluded: int) -> int:
	var values: Array[int] = []
	for sample: Dictionary in _samples:
		if sample.variant == variant and int(sample.pair) > first_pair_excluded:
			values.append(int(sample.usec))
	values.sort()
	return values[int(values.size() / 2)] if not values.is_empty() else 0
