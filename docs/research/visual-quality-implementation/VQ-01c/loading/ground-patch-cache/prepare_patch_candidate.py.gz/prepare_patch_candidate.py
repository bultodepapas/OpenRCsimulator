from pathlib import Path
import json
import hashlib
import subprocess

root = Path(__file__).resolve().parent
source = Path('app/scenery/ground_features.gd').read_text()
(root / 'ground_reference.gd').write_text(source, newline='\n')
constants = '''
# DT-11a: reuse exact patch buffers across Home/Fly builds, never scene resources.
# FIFO bounds include serialized keys and geometry; container overhead is count-bounded.
const PATCH_CACHE_MAX_ENTRIES := 8
const PATCH_CACHE_MAX_BYTES := 4 * 1024 * 1024
static var _patch_cache: Array[Dictionary] = []
static var _patch_cache_bytes: int = 0

'''
source = source.replace('\n\n# ---------------- tracks and patches', '\n' + constants + '\n# ---------------- tracks and patches', 1)
signature = 'static func patch(k: MeshKit, poly: PackedVector2Array, surface: String, theme: String, seed: int) -> void:\n'
wrapper = '''	var key := var_to_bytes([poly, surface, theme, seed, k.xf])
	for entry: Dictionary in _patch_cache:
		if entry.key == key:
			var arrays: Array = bytes_to_var(entry.payload)
			k.verts.append_array(arrays[0])
			k.norms.append_array(arrays[1])
			k.cols.append_array(arrays[2])
			return
	var first_vertex := k.verts.size()
	_patch_uncached(k, poly, surface, theme, seed)
	var payload := var_to_bytes([k.verts.slice(first_vertex), k.norms.slice(first_vertex), k.cols.slice(first_vertex)])
	var entry_bytes := key.size() + payload.size()
	if entry_bytes > PATCH_CACHE_MAX_BYTES:
		return
	while _patch_cache.size() >= PATCH_CACHE_MAX_ENTRIES or _patch_cache_bytes + entry_bytes > PATCH_CACHE_MAX_BYTES:
		var oldest: Dictionary = _patch_cache.pop_front()
		_patch_cache_bytes -= oldest.key.size() + oldest.payload.size()
	_patch_cache.append({key = key, payload = payload})
	_patch_cache_bytes += entry_bytes


static func _patch_uncached(k: MeshKit, poly: PackedVector2Array, surface: String, theme: String, seed: int) -> void:
'''
assert source.count(signature)==1
source = source.replace(signature, signature + wrapper)
(root / 'ground_candidate.gd').write_text(source, newline='\n')
for variant in ['reference','candidate']:
    scenery = Path('app/scenery/scenery.gd').read_text().replace('res://scenery/ground_features.gd', (root / f'ground_{variant}.gd').as_posix())
    (root / f'scenery_{variant}.gd').write_text(scenery, newline='\n')
    field = Path('app/render/field.gd').read_text().replace('res://scenery/scenery.gd', (root / f'scenery_{variant}.gd').as_posix())
    (root / f'field_{variant}.gd').write_text(field, newline='\n')
manifest = {'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            'status':subprocess.check_output(['git','status','--short'],text=True),
            'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('app/scenery/ground_features.gd'),Path('app/scenery/scenery.gd'),Path('app/render/field.gd'),Path('app/data/scenery/default.json'),Path('app/data/fields/default.json'),Path('app/project.godot')]}}
(root / 'source-before.json').write_text(json.dumps(manifest, indent=2))
