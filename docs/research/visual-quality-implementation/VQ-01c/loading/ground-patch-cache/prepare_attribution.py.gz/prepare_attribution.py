from pathlib import Path

root = Path(__file__).resolve().parent
source = Path('app/render/field.gd').read_text()
source = source.replace('var result: Node3D = Node3D.new()', 'var phase_start := Time.get_ticks_usec()\n\tvar result: Node3D = Node3D.new()', 1)
markers = [
    ('\tfor surface: Dictionary in field.surfaces:', 'ground_material'),
    ('\tfor object_data: Dictionary in field.objects:', 'surface_geometry'),
    ('\tfor cue: Dictionary in field.get("flight_cues", []):', 'treeline'),
    ('\tvar scenery_options := Scenery.options()', 'flight_cues'),
    ('\tScenery.attach(result, field, lighting, lake)', 'lake_resolve'),
    ('\tvar lake_node := LakeWorld.attach', 'scenery'),
    ('\tvar scenery_node := result.get_node_or_null("Scenery")', 'lake_build'),
    ('\tif LandscapeOptions.enabled() and field.get("id", "") == "default":', 'near_grass'),
    ('\tFieldProjectedShadows.attach(result, field, lighting)', 'ridges'),
    ('\tresult.set_meta("lighting_materials", materials)', 'field_shadows'),
]
for marker, label in markers:
    assert marker in source, marker
    source = source.replace(marker, '\tprint("FIELD_PHASE ' + label + ' ", (Time.get_ticks_usec() - phase_start) / 1000.0)\n\tphase_start = Time.get_ticks_usec()\n' + marker, 1)
(root / 'attributed_field.gd').write_text(source, newline='\n')
