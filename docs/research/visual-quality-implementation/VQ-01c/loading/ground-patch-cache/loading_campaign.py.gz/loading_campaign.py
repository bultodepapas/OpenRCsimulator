from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path.cwd()
snapshot = root / 'snapshot'
resume = '--resume' in sys.argv
if not resume:
    snapshot.mkdir(exist_ok=False)

def copy_file(src, dst):
    path = Path(src)
    relative = path.relative_to(repo / 'app')
    if relative.parts[0] == 'assets' or relative.parts[:2] == ('.godot', 'imported'):
        os.link(src, dst)  # Immutable resource bytes; never run import in this snapshot.
    else:
        shutil.copy2(src, dst)
    return dst

if not resume:
    shutil.copytree(repo / 'app', snapshot / 'app', copy_function=copy_file)
    shutil.copytree(repo / 'assets' / 'aircraft' / 'ugly-stik-60', snapshot / 'assets' / 'aircraft' / 'ugly-stik-60')
    shutil.copy2(repo / 'assets/aircraft/model-bindings.json', snapshot / 'assets/aircraft/model-bindings.json')
identities = {p.relative_to(snapshot / 'app').as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (snapshot / 'app').rglob('*') if p.is_file() and '.godot' not in p.parts and p.suffix in ('.gd', '.json', '.godot')}
(root / 'loading-input-hashes.json').write_text(json.dumps(identities, indent=2))
engine = repo / '.tools/Godot_v4.7.2-stable_win64_console.exe'
for pair in range(3):
    order = ['reference', 'candidate'] if pair % 2 == 0 else ['candidate', 'reference']
    for variant in order:
        shutil.copyfile(root / f'ground_{variant}.gd', snapshot / 'app/scenery/ground_features.gd')
        output = root / f'loading-{pair+1}-{variant}.json'
        command = [sys.executable, 'tools/godot/run_checked.py', '--out-dir', str(root / 'checks'),
                   '--label', f'loading-{pair+1}-{variant}', '--timeout', '120', '--require-text', 'loading probe: 3 Home/Fly cycles', '--',
                   str(engine), '--path', str(snapshot / 'app'), '--audio-driver', 'Dummy', '--resolution', '1280x720', '--max-fps', '60',
                   '--script', str(repo / 'research/performance/loading_probe.gd'), '--', '--cycles=3', '--output=' + str(output)]
        subprocess.run(command, check=True)
        data = json.loads(output.read_text())
        assert data['complete'], output
        for path, digest in identities.items():
            if path != 'scenery/ground_features.gd':
                assert hashlib.sha256((snapshot / 'app' / path).read_bytes()).hexdigest() == digest, path
        print('completed', pair+1, variant, flush=True)
