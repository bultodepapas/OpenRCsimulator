from pathlib import Path
root=Path(__file__).resolve().parent
for name in ['probe.gd','parity.json','parity.log','run.json']:
    (root/('refined-'+name)).write_bytes((root/name).read_bytes())
source=(root/'probe.gd').read_text().replace('["reference", "transform-only", "candidate"]','["reference", "candidate"]').replace('["candidate", "transform-only", "reference"]','["candidate", "reference"]').replace('["transform-only", "candidate"]','["candidate"]')
source=source.replace('var _scripts: Dictionary = {}','var _scripts: Dictionary = {}\nvar _shadows: Dictionary = {}')
source=source.replace('_scripts[variant] = load(directory.path_join(variant + ".gd"))','_scripts[variant] = load(directory.path_join(variant + ".gd"))\n\t\t_shadows[variant] = load(directory.path_join("shadow-" + variant + ".gd"))')
source=source.replace('_compare(built.root, "aircraft:" + id, -INF)','_compare(built.root, "aircraft:" + id, -INF)\n\t\t_compare_bind(built.root, "bind:" + id)')
source += '''

func _compare_bind(model: Node3D, label: String) -> void:
	for pair in range(6):
		var shapes := {}
		for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
			var host := Node3D.new()
			var carrier: MeshInstance3D = _shadows[variant].create(host)
			var start := Time.get_ticks_usec()
			_shadows[variant].bind_model(carrier, model)
			_samples.append({workload = label, pair = pair, variant = variant, usec = Time.get_ticks_usec() - start})
			var projector: Node = carrier.get_node("ProjectedShadow")
			var viewport: SubViewport = projector.viewport
			var proxy: MeshInstance3D = viewport.get_child(2)
			shapes[variant] = {mesh = proxy.mesh, bounds = projector.bounds, triangles = projector.triangle_count}
			host.free()
		_pairs += 1
		if not _same(shapes.reference, shapes.candidate): _failures.append(label + ":" + str(pair))
'''
(root/'probe.gd').write_text(source)
for variant in ['reference','candidate']:
    shadow=Path('app/render/shadow.gd').read_text().replace('res://render/projected_shadow.gd',(root/(variant+'.gd')).as_posix())
    (root/('shadow-'+variant+'.gd')).write_text(shadow)
