from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent
reports=[json.loads(p.read_text()) for p in sorted((root/'native').glob('[0-9][0-9].json'))]
samples=[dict(s,run=i+1) for i,d in enumerate(reports) for s in d['samples'] if s['pair']>0]
summary=[]
for workload in sorted({s['workload'] for s in samples}):
    if workload.startswith('field:'): continue
    medians={v:statistics.median(s['usec'] for s in samples if s['workload']==workload and s['variant']==v) for v in ['reference','candidate']}
    by_run=[{v:statistics.median(s['usec'] for s in samples if s['workload']==workload and s['variant']==v and s['run']==i) for v in ['reference','candidate']} for i in range(1,4)]
    summary.append({'workload':workload, 'median_usec':medians, 'reduction_pct':100*(1-medians['candidate']/medians['reference']), 'run_medians_usec':by_run})
field={v:statistics.median(sum(s['usec'] for s in samples if s['workload'].startswith('field:') and s['variant']==v and s['run']==i and s['pair']==p) for i in range(1,4) for p in range(1,6)) for v in ['reference','candidate']}
result={'warm_samples_per_variant_workload':15, 'reports':3,'exact_pairs':sum(d['pairs'] for d in reports), 'field_collect_55_meshes_aggregate_median_usec':field,'workloads':summary}
(root/'summary.json').write_text(json.dumps(result,indent=2))
for row in summary:
    print(row['workload'],row['median_usec'],round(row['reduction_pct'],1),'%',row['run_medians_usec'])
print('field aggregate',field)
