from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).resolve().parent
out=root/'native'
out.mkdir(exist_ok=True)
command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('tmp/dt11a-grass-selection/source/app').resolve()),'--audio-driver','Dummy','--script',str(root/'probe.gd'),'--','--directory='+str(root)]
ledger=[]
for run in range(1,4):
    with (out/f'{run:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    report=root/'parity.json'
    target=out/f'{run:02d}.json'
    target.write_bytes(report.read_bytes())
    text=(out/f'{run:02d}.log').read_text()
    data=json.loads(target.read_text())
    clean=result.returncode==0 and 'ERROR:' not in text and 'WARNING:' not in text and data['complete']
    ledger.append({'run':run,'command':command,'exit_code':result.returncode,'clean':clean,'report_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
    (out/'campaign.json').write_text(json.dumps(ledger,indent=2))
    print(run,'clean',clean,'pairs',data['pairs'],flush=True)
    assert clean
