extends SceneTree

const Builder = preload("res://render/airplane.gd")
const Field = preload("res://render/field.gd")
const Loader = preload("res://data/field_loader.gd")

var _samples: Array = []
var _failures: Array = []
var _pairs := 0
var _scripts: Dictionary = {}
var _shadows: Dictionary = {}

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var directory := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--directory="): directory = arg.trim_prefix("--directory=")
	if directory.is_empty() or DisplayServer.get_name() == "headless":
		quit(2)
		return
	for variant: String in ["reference", "candidate"]:
		_scripts[variant] = load(directory.path_join(variant + ".gd"))
		_shadows[variant] = load(directory.path_join("shadow-" + variant + ".gd"))
	load("res://render/shader_clock.gd").register()
	for id: String in [Builder.STIK_ID, Builder.EXTRA_ID, Builder.AVANTI_ID, Builder.P51_ID, Builder.TIMBER_ID, Builder.X_CELL_ID]:
		var built: Dictionary = Builder.build(id)
		if built.is_empty() or not built.has("root"):
			_failures.append("build:" + id)
			continue
		_compare(built.root, "aircraft:" + id, -INF)
		_compare_bind(built.root, "bind:" + id)
		built.root.free()
	var field: Node3D = Field.build(Loader.load_from().field)
	for model in field.find_children("*", "MeshInstance3D", true, false):
		if str(model.name).begins_with("cell_") or str(model.name).begins_with("cue_"):
			_compare(model, "field:" + str(model.name), 0.04)
	field.free()
	var file := FileAccess.open(directory.path_join("parity.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({complete = _failures.is_empty(), failures = _failures, pairs = _pairs, samples = _samples,
		engine = Engine.get_version_info(), adapter = RenderingServer.get_video_adapter_name(),
		scope = "Native collect constructor only, alternating order; exclude pair zero; shared host; no startup or FPS claim"}, "\t"))
	file.close()
	print("shadow geometry pairs=", _pairs, " failures=", _failures)
	await process_frame
	await process_frame
	quit(0 if _failures.is_empty() else 1)

func _compare(model: Node3D, label: String, threshold: float) -> void:
	for pair in range(6):
		var shapes := {}
		for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
			var start := Time.get_ticks_usec()
			var shape: Dictionary = _scripts[variant].collect(model, threshold)
			_samples.append({workload = label, pair = pair, variant = variant, usec = Time.get_ticks_usec() - start, triangles = shape.get("triangles", 0)})
			shapes[variant] = shape
		for variant: String in ["candidate"]:
			_pairs += 1
			if not _same(shapes.reference, shapes[variant]):
				_failures.append(label + ":" + variant + ":" + str(pair))

func _same(a: Dictionary, b: Dictionary) -> bool:
	if a.is_empty() or b.is_empty(): return a.is_empty() == b.is_empty()
	return var_to_bytes(a.bounds) == var_to_bytes(b.bounds) and a.triangles == b.triangles \
		and var_to_bytes(a.mesh.surface_get_arrays(0)) == var_to_bytes(b.mesh.surface_get_arrays(0))


func _compare_bind(model: Node3D, label: String) -> void:
	for pair in range(6):
		var shapes := {}
		for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
			var host := Node3D.new()
			var carrier: MeshInstance3D = _shadows[variant].create(host)
			var start := Time.get_ticks_usec()
			_shadows[variant].bind_model(carrier, model)
			_samples.append({workload = label, pair = pair, variant = variant, usec = Time.get_ticks_usec() - start})
			var projector: Node = carrier.get_node("ProjectedShadow")
			var viewport: SubViewport = projector.viewport
			var proxy: MeshInstance3D = viewport.get_child(2)
			shapes[variant] = {mesh = proxy.mesh, bounds = projector.bounds, triangles = projector.triangle_count}
			host.free()
		_pairs += 1
		if not _same(shapes.reference, shapes.candidate): _failures.append(label + ":" + str(pair))
