from pathlib import Path
root=Path(__file__).resolve().parent
original=Path('app/render/projected_shadow.gd').read_text()
assert original==Path('tmp/dt11a-grass-selection/source/app/render/projected_shadow.gd').read_text()
(root/'reference.gd').write_text(original)
candidate=original.replace('var faces := mi.mesh.get_faces()', 'var faces: PackedVector3Array = transform * mi.mesh.get_faces()').replace(':= transform * faces[', ':= faces[')
assert candidate != original
(root/'transform-only.gd').write_text(candidate)
candidate=candidate.replace('\tvar box := AABB(vertices[0], Vector3.ZERO)\n\tfor point in vertices:\n\t\tbox = box.expand(point)\n','')
candidate=candidate.replace('return {mesh = merged, bounds = box, triangles = vertices.size() / 3}', 'return {mesh = merged, bounds = merged.get_aabb(), triangles = vertices.size() / 3}')
(root/'candidate.gd').write_text(candidate)
