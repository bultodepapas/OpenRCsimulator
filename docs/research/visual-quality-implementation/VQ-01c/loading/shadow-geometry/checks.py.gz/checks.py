from pathlib import Path
import subprocess,json,hashlib,sys
root=Path(__file__).resolve().parent
native='--native' in sys.argv
out=root/('native-checks' if native else 'checks')
out.mkdir(exist_ok=True)
engine=Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()
records=[]
names=['test_shadow_collection','test_projected_shadow','test_field_projected_shadows'] if native else ['test_shadow_collection','test_projected_shadow','test_field_projected_shadows','test_field_integration','test_world_presentation_context']
for name in names:
    command=[str(engine)]+([] if native else ['--headless'])+['--path',str(Path('app').resolve()),'--audio-driver','Dummy','--script','res://tests/'+name+'.gd']
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    text=(out/(name+'.log')).read_text()
    record={'name':name,'command':command,'exit_code':result.returncode,'errors':'ERROR:' in text,'warnings':[s for s in text.splitlines() if 'WARNING:' in s], 'log_sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()}
    records.append(record)
    (out/'results.json').write_text(json.dumps(records,indent=2))
    print(name,result.returncode,'errors',record['errors'],flush=True)
    assert result.returncode==0 and not record['errors']
