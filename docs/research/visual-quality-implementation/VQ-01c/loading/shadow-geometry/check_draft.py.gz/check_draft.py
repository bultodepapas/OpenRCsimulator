from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--headless','--path',str(Path('tmp/dt11a-grass-selection/source/app').resolve()),'--audio-driver','Dummy','--script',str(root/'test_shadow_collection.gd'),'--','--collector='+str(root/'candidate.gd')]
with (root/'draft.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
(root/'draft.json').write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2))
print((root/'draft.log').read_text())
assert result.returncode==0 and 'ERROR:' not in (root/'draft.log').read_text()
