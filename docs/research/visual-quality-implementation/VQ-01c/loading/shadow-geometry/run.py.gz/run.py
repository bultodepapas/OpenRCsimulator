from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
command=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('tmp/dt11a-grass-selection/source/app').resolve()),'--audio-driver','Dummy','--script',str(root/'probe.gd'),'--','--directory='+str(root)]
with (root/'parity.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
(root/'run.json').write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2))
print((root/'parity.log').read_text())
raise SystemExit(result.returncode)
