extends SceneTree

func _initialize() -> void:
	var directory := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--directory="): directory = arg.trim_prefix("--directory=")
	var reference: Script = load(directory.path_join("reference.gd"))
	var rejected: Script = load(directory.path_join("rejected-bounds.gd"))
	var builder: Script = load("res://render/airplane.gd")
	var model: Dictionary = builder.build(builder.STIK_ID)
	var a: Dictionary = reference.collect(model.root)
	var b: Dictionary = rejected.collect(model.root)
	var arrays_equal := var_to_bytes(a.mesh.surface_get_arrays(0)) == var_to_bytes(b.mesh.surface_get_arrays(0))
	var bounds_equal := var_to_bytes(a.bounds) == var_to_bytes(b.bounds)
	var file := FileAccess.open(directory.path_join("rejected-diagnostic.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({arrays_equal = arrays_equal, bounds_equal = bounds_equal,
		reference_bounds_bytes = Array(var_to_bytes(a.bounds)), rejected_bounds_bytes = Array(var_to_bytes(b.bounds)),
		size_delta = str(b.bounds.size - a.bounds.size)}, "\t"))
	file.close()
	model.root.free()
	print("rejected bounds: arrays_equal=", arrays_equal, " bounds_equal=", bounds_equal)
	quit(0 if arrays_equal and not bounds_equal else 1)
