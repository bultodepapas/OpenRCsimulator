from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
base=[str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()),'--path',str(Path('tmp/dt11a-grass-selection/source/app').resolve()),'--audio-driver','Dummy']
command=base+['--script',str(root/'diagnostic.gd'),'--','--directory='+str(root)]
with (root/'rejected-diagnostic.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert result.returncode==0 and 'ERROR:' not in (root/'rejected-diagnostic.log').read_text()
source=(root/'candidate.gd').read_text().replace('if min_height == -INF:', 'if true:')
(root/'mutation.gd').write_text(source)
command=base+['--headless','--script',str(root/'test_shadow_collection.gd'),'--','--collector='+str(root/'mutation.gd')]
with (root/'mutation.log').open('w') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
text=(root/'mutation.log').read_text()
detected=result.returncode!=0 and 'FAIL height cutoff rejects all faces' in text and 'ERROR:' not in text
(root/'mutation.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'detected':detected,'expected_failure':True},indent=2))
assert detected
print((root/'rejected-diagnostic.log').read_text())
print('Threshold mutation detected; failures:', text.count('FAIL '))
