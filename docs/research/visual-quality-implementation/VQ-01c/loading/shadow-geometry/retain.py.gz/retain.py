from pathlib import Path
import hashlib,json,gzip,zipfile,shutil,difflib,subprocess
root=Path(__file__).resolve().parent
out=Path('docs/research/visual-quality-implementation/VQ-01c/loading/shadow-geometry')
source=Path('tmp/dt11a-grass-selection/source')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
prior_path=Path('docs/research/visual-quality-implementation/VQ-02a/coverage/verification.json')
prior=json.loads(prior_path.read_text())
archive=Path('tmp/vq02a-completion/source.zip')
assert sha(archive)==prior['archive_sha256']
imports={v['path']:v['imported_sha256'] for v in prior['import_changed_inputs']}
overlays=['app/render/ground.gd','app/scenery/imported_near_grass.gd']
expected_overlays=json.loads(Path('docs/research/visual-quality-implementation/VQ-01c/loading/grass-masks/source-verification.json').read_text())['overlay_sha256']
assert all(sha(source/p)==expected_overlays[p] for p in overlays)
mismatches=[]
with zipfile.ZipFile(archive) as z:
    inputs=[i for i in z.infolist() if not i.is_dir()]
    for i in inputs:
        if i.filename in overlays: continue
        expected=imports.get(i.filename) or hashlib.sha256(z.read(i)).hexdigest()
        if not (source/i.filename).exists() or sha(source/i.filename)!=expected: mismatches.append(i.filename)
    assert z.read('app/render/projected_shadow.gd').decode().replace('\r\n','\n')==(root/'reference.gd').read_text()
generated=prior['import_generated_files_outside_cache']
generated_mismatches=[v['path'] for v in generated if sha(source/v['path'])!=v['sha256']]
assert not mismatches and not generated_mismatches
assert Path('app/render/projected_shadow.gd').read_text()==(root/'candidate.gd').read_text()
assert Path('app/tests/test_shadow_collection.gd').read_text()==(root/'test_shadow_collection.gd').read_text()
verification={'source_commit':prior['source_commit'],'archive_sha256':sha(archive),'input_count':len(inputs),
    'import_identity_report':prior_path.as_posix(),'overlay_sha256':expected_overlays,'mismatches':mismatches,
    'generated_file_count':len(generated),'generated_file_mismatches':generated_mismatches,
    'reference_collector_equals_archive_after_line_ending_normalization':True}
(out/'source-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
for folder in ['native','checks','native-checks']:
    for p in (root/folder).iterdir():
        target=out/folder/p.name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,target)
for p in root.iterdir():
    if p.suffix in ['.gd','.py']:
        (out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    elif p.suffix in ['.log','.json'] and p.stem not in ['parity','run']:
        shutil.copyfile(p,out/p.name)
patch=''.join(difflib.unified_diff((root/'reference.gd').read_text().splitlines(True),
    Path('app/render/projected_shadow.gd').read_text().splitlines(True),fromfile='a/app/render/projected_shadow.gd',tofile='b/app/render/projected_shadow.gd'))
(out/'runtime.patch').write_text(patch)
summary=json.loads((out/'summary.json').read_text())
assert summary['exact_pairs']==1206
for p in (out/'native').glob('[0-9][0-9].json'):
    d=json.loads(p.read_text())
    assert d['complete'] and not d['failures'] and d['pairs']==402
for folder,count in [('checks',5),('native-checks',3)]:
    records=json.loads((out/folder/'results.json').read_text())
    assert len(records)==count and all(r['exit_code']==0 and not r['errors'] and not r['warnings'] for r in records)
assert json.loads((out/'mutation.json').read_text())['detected']
sources=[Path('app/render/projected_shadow.gd'),Path('app/tests/test_shadow_collection.gd')]
manifest={'step':'DT-11a','date':'2026-10-14','comparison_commit':prior['source_commit'],
    'retention_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'scope':'Native shadow collection and binding only; frozen imported source with earlier ground-image and grass-mask overlays. Current-tree focused tests; no complete loading or FPS acceptance.',
    'engines':{'.tools/Godot_v4.7.2-stable_win64.exe':sha(Path('.tools/Godot_v4.7.2-stable_win64.exe'))},
    'sources':{p.as_posix():sha(p) for p in sources},
    'checks':{'headless_collection':77,'headless_projected_shadow':37,'headless_field_projected_shadows':57,
        'headless_field_integration':39,'headless_world_presentation':17,'native_collection':77,'native_projected_shadow':37,
        'native_field_projected_shadows':57,'exact_native_pairs':1206,'native_campaign_runs':3,'cutoff_mutation_detected':True},
    'artifacts':{p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='evidence-manifest.json'}}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('retained',len(manifest['artifacts']),'artifacts; verified',len(inputs),'archive inputs and',len(generated),'generated files')
