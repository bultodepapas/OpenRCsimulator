from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'transform-only.gd').read_text()
source=source.replace('\t\tfor first in range(0, faces.size(), 3):', '\t\t# Aircraft collection has no height cutoff; preserve the packed face order.\n\t\tif min_height == -INF:\n\t\t\tvertices.append_array(faces)\n\t\t\tcontinue\n\t\tfor first in range(0, faces.size(), 3):')
(root/'candidate.gd').write_text(source)
