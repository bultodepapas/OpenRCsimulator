extends SceneTree

const Candidate = preload("res://scenery/imported_near_grass.gd")
const Field = preload("res://render/field.gd")
const FieldLoader = preload("res://data/field_loader.gd")
const SceneryLoader = preload("res://scenery/scenery_loader.gd")
const Scenery = preload("res://scenery/scenery.gd")
const LakeLoader = preload("res://data/lake_loader.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var output := ""
	var reference_path := ""
	var field_reference_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
		elif arg.begins_with("--reference="): reference_path = arg.trim_prefix("--reference=")
		elif arg.begins_with("--field-reference="): field_reference_path = arg.trim_prefix("--field-reference=")
	if DisplayServer.get_name() == "headless" or FileAccess.file_exists(output) or output.is_empty():
		quit(2)
		return
	var reference: Script = load(reference_path)
	var field_reference: Script = load(field_reference_path)
	load("res://render/shader_clock.gd").register()
	var field: Dictionary = FieldLoader.load_from().field
	var scenery: Dictionary = SceneryLoader.load_from(Scenery.options().file, field).scenery
	var masks := Candidate.exclusions_for(scenery, LakeLoader.load_from().lake)
	var samples: Array = []
	var ok := true
	for quality: String in ["low", "balanced", "high"]:
		for pair in range(6):
			var roots := {}
			for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
				var builder: Script = reference if variant == "reference" else Candidate
				var begin := Time.get_ticks_usec()
				var node: Node3D = builder.build(field, quality, masks)
				samples.append({workload = "grass_build", quality = quality, pair = pair, variant = variant, usec = Time.get_ticks_usec() - begin})
				roots[variant] = node
			ok = _same_grass(roots.reference, roots.candidate) and ok
			roots.reference.free()
			roots.candidate.free()
	for pair in range(6):
		for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
			var builder: Script = field_reference if variant == "reference" else Field
			var begin := Time.get_ticks_usec()
			var node: Node3D = builder.build(field)
			samples.append({workload = "field_build", pair = pair, variant = variant, usec = Time.get_ticks_usec() - begin})
			ok = ok and node.get_node("NearGrass").get_meta("clumps") == 150
			node.free()
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify({complete = ok, samples = samples, native_buffer_pairs = 18,
		full_masks = masks.size(), local_masks = Candidate._nearby_exclusions(field.pilot.north, field.pilot.east, masks).size(),
		engine = Engine.get_version_info(), adapter = RenderingServer.get_video_adapter_name(),
		scope = "CPU construction; readback/parity outside timings; exclude pair 0; not GPU frame time or process-cold loading"}, "\t") + "\n")
	file.close()
	await process_frame
	await process_frame
	print("grass build and native instance parity: ", ok)
	quit(0 if ok else 1)


func _same_grass(a: Node3D, b: Node3D) -> bool:
	if a.name != b.name or a.get_child_count() != b.get_child_count(): return false
	for key: StringName in a.get_meta_list():
		var av: Variant = a.get_meta(key)
		var bv: Variant = b.get_meta(key)
		if key == &"_imported_vegetation_state":
			av = av.duplicate(false)
			bv = bv.duplicate(false)
			if av.multimeshes.size() != bv.multimeshes.size(): return false
			# Fresh MultiMesh identities are compared by their complete buffers below.
			av.erase("multimeshes")
			bv.erase("multimeshes")
		if var_to_bytes(av) != var_to_bytes(bv): return false
	for index in a.get_child_count():
		var left := a.get_child(index) as MultiMeshInstance3D
		var right := b.get_child(index) as MultiMeshInstance3D
		if left == null or right == null: return false
		if left.name != right.name or left.transform != right.transform or left.cast_shadow != right.cast_shadow: return false
		if left.material_override != right.material_override: return false
		var lm := left.multimesh
		var rm := right.multimesh
		if not _same_mesh(lm.mesh, rm.mesh) or lm.instance_count != rm.instance_count or lm.use_colors != rm.use_colors \
			or lm.use_custom_data != rm.use_custom_data or lm.transform_format != rm.transform_format \
			or lm.custom_aabb != rm.custom_aabb or lm.visible_instance_count != rm.visible_instance_count: return false
		if lm.buffer.is_empty() or lm.buffer.to_byte_array() != rm.buffer.to_byte_array(): return false
	return true


func _same_mesh(a: Mesh, b: Mesh) -> bool:
	if a.get_surface_count() != b.get_surface_count(): return false
	for index in a.get_surface_count():
		if a.surface_get_material(index) != b.surface_get_material(index): return false
		if var_to_bytes(a.surface_get_arrays(index)) != var_to_bytes(b.surface_get_arrays(index)): return false
	return true
