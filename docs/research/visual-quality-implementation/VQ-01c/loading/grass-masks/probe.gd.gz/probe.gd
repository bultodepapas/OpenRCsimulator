extends SceneTree

const Candidate = preload("res://scenery/imported_near_grass.gd")
const FieldLoader = preload("res://data/field_loader.gd")
const SceneryLoader = preload("res://scenery/scenery_loader.gd")
const Scenery = preload("res://scenery/scenery.gd")
const LakeLoader = preload("res://data/lake_loader.gd")
const Mask = preload("res://render/landscape_upgrade/scenery_grass_mask.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var reference_path := ""
	var output := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--reference="):
			reference_path = arg.trim_prefix("--reference=")
		elif arg.begins_with("--output="):
			output = arg.trim_prefix("--output=")
	if output.is_empty() or reference_path.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var reference: Script = load(reference_path)
	var field: Dictionary = FieldLoader.load_from().field
	var scenery: Dictionary = SceneryLoader.load_from(Scenery.options().file, field).scenery
	var lake: Dictionary = LakeLoader.load_from().lake
	var masks := Candidate.exclusions_for(scenery, lake)
	var shifted := field.duplicate(true)
	shifted.pilot.north += 21.25
	shifted.pilot.east -= 10.75
	var off_field := field.duplicate(true)
	off_field.pilot.north = 50000.0
	var sparse := field.duplicate(true)
	sparse.surfaces = [{"type": "rough", "center_north": float(field.pilot.north),
		"center_east": float(field.pilot.east), "width_north_south": 3.0, "length_east_west": 3.0}]
	var blocked: Array = [Mask._record("block-all", "test", PackedVector2Array([
		Vector2(-1000, -1000), Vector2(-1000, 1000), Vector2(1000, 1000), Vector2(1000, -1000)]))]
	var cases := [
		{name = "default", field = field, masks = masks},
		{name = "no_masks", field = field, masks = []},
		{name = "shifted", field = shifted, masks = masks},
		{name = "sparse", field = sparse, masks = []},
		{name = "all_blocked", field = field, masks = blocked},
		{name = "off_field", field = off_field, masks = masks},
	]
	var samples: Array = []
	var ok := true
	for fixture: Dictionary in cases:
		for quality: String in ["low", "balanced", "high", "unknown"]:
			for pair in range(3):
				var signatures := {}
				for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
					var script: Script = reference if variant == "reference" else Candidate
					var begin := Time.get_ticks_usec()
					var rows: Array[Dictionary] = script.layout(fixture.field, quality, fixture.masks)
					var elapsed := Time.get_ticks_usec() - begin
					var bytes := var_to_bytes(rows)
					signatures[variant] = bytes
					var digest := HashingContext.new()
					digest.start(HashingContext.HASH_SHA256)
					digest.update(bytes)
					samples.append({fixture = fixture.name, quality = quality, pair = pair,
						variant = variant, usec = elapsed, count = rows.size(), sha256 = digest.finish().hex_encode()})
				ok = ok and signatures.reference == signatures.candidate
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify({complete = ok, samples = samples, engine = Engine.get_version_info()}, "\t") + "\n")
	file.close()
	print("grass selection parity: ", ok, " pairs=72")
	quit(0 if ok else 1)
