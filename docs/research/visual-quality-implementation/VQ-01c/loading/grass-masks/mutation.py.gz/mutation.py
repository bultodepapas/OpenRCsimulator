from pathlib import Path
import subprocess, json

root = Path(__file__).resolve().parent
source = root / 'source/app/scenery/imported_near_grass.gd'
original = source.read_bytes()
mutated = source.read_text().replace('NearGrass.RADIUS_M < min_', 'NearGrass.RADIUS_M <= min_').replace('NearGrass.RADIUS_M > max_', 'NearGrass.RADIUS_M >= max_')
out = root / 'checks'
(out / 'mutation-normalized.gd').write_bytes(mutated.encode())
command = [str(Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()), '--headless', '--path', str(root / 'source/app'), '--audio-driver', 'Dummy', '--script', str(root / 'test_grass_mask_bounds.gd')]
try:
    source.write_bytes(mutated.encode())
    with (out / 'mutation-normalized.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=60)
    log = (out / 'mutation-normalized.log').read_text()
    detected = result.returncode != 0 and log.count('FAIL expanded boundary stays inclusive:') == 4 and 'SCRIPT ERROR' not in log
    (out / 'mutation-normalized.json').write_text(json.dumps({'command':command, 'exit_code':result.returncode, 'detected':detected, 'expected_failure':True}, indent=2))
    print(log)
    assert detected
finally:
    source.write_bytes(original)
