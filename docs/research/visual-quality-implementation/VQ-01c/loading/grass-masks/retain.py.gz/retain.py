from pathlib import Path
import gzip, hashlib, json, shutil, difflib, subprocess, zipfile

root = Path(__file__).resolve().parent
out = Path('docs/research/visual-quality-implementation/VQ-01c/loading/grass-masks')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(data): return hashlib.sha256(data).hexdigest()
def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
def compress(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))

prior_path = Path('docs/research/visual-quality-implementation/VQ-02a/coverage/verification.json')
prior = json.loads(prior_path.read_text())
archive = Path('tmp/vq02a-completion/source.zip')
assert sha(archive) == prior['archive_sha256']
imports = {v['path']:v['imported_sha256'] for v in prior['import_changed_inputs']}
excluded = ['app/render/ground.gd', 'app/scenery/imported_near_grass.gd']
mismatches = []
with zipfile.ZipFile(archive) as z:
    inputs = [i for i in z.infolist() if not i.is_dir()]
    for i in inputs:
        if i.filename in excluded: continue
        expected = imports.get(i.filename) or digest(z.read(i))
        p = root / 'source' / i.filename
        if not p.exists() or sha(p) != expected: mismatches.append(i.filename)
    original = z.read('app/scenery/imported_near_grass.gd').decode().replace('\r\n', '\n')
    assert original == (root / 'reference.gd').read_text()
generated = prior['import_generated_files_outside_cache']
generated_mismatches = [x['path'] for x in generated if sha(root / 'source' / x['path']) != x['sha256']]
assert not mismatches and not generated_mismatches, (mismatches, generated_mismatches)
assert Path('app/scenery/imported_near_grass.gd').read_text() == (root / 'candidate.gd').read_text() == (root / 'source/app/scenery/imported_near_grass.gd').read_text()
assert Path('app/tests/test_grass_mask_bounds.gd').read_text() == (root / 'test_grass_mask_bounds.gd').read_text()
assert (root / 'source/app/render/ground.gd').read_text() == Path('tmp/dt11a-followup/ground_candidate.gd').read_text()
verification = {'source_commit':prior['source_commit'], 'archive_sha256':sha(archive),
    'import_identity_report':str(prior_path), 'input_count':len(inputs), 'excluded_overlays':excluded,
    'overlay_sha256':{p:sha(root / 'source' / p) for p in excluded}, 'mismatches':mismatches,
    'generated_file_count':len(generated), 'generated_file_mismatches':generated_mismatches,
    'reference_equals_archive_after_line_ending_normalization':True}
(out / 'source-verification.json').write_text(json.dumps(verification, indent=2)+'\n')
for name in ['bounds-parity.json','bounds-parity.log']:
    copy(root/name, out/name.replace('bounds-parity','layout-parity'))
for name in ['build-verified.json','build-verified.log']: copy(root/name, out/name)
for p in (root/'pairs').iterdir(): copy(p, out/'pairs'/p.name)
for p in (root/'checks').iterdir():
    if p.suffix == '.gd': compress(p, out/'checks'/(p.name+'.gz'))
    else: copy(p, out/'checks'/p.name)
copy(root/'bounds-check.log', out/'checks/bounds-draft.log')
for name in ['parity.json','parity.log']: copy(root/name, out/'rejected'/name)
compress(root/'rejected_rank_first.gd', out/'rejected/rank-first.gd.gz')
for name in ['build-parity.json','build-parity.log']: copy(root/name, out/'failed-harness'/name)
compress(root/'build_probe_first.gd', out/'failed-harness/build_probe_first.gd.gz')
for name in ['probe.gd','build_probe.gd','reference.gd','candidate.gd','field_reference.gd','campaign.py','loading_probe.gd','checks.py','mutation.py','test_grass_mask_bounds.gd','retain.py']:
    compress(root/name, out/(name+'.gz'))
patch=''.join(difflib.unified_diff((root/'reference.gd').read_text().splitlines(True),
    Path('app/scenery/imported_near_grass.gd').read_text().splitlines(True), fromfile='a/app/scenery/imported_near_grass.gd', tofile='b/app/scenery/imported_near_grass.gd'))
(out/'runtime.patch').write_text(patch)
reports = [json.loads(p.read_text()) for p in (out/'pairs').glob('[0-9][0-9]-*.json')]
assert len(reports)==10 and all(d['complete'] for d in reports)
cycles = [c for d in reports for c in d['cycles']]
assert len(cycles)==20 and all(c['nodes_at_home']==549 and c['orphan_nodes']==0 for c in cycles)
assert all((c['tick_at_first_draw'], c['nodes_in_flight']) == ((0,908) if c['paused_at_first_draw'] else (12,879)) for c in cycles)
ledger = json.loads((out/'pairs/campaign.json').read_text())
eligible_pairs = sum(all(r['active_draws'] for r in ledger['runs'] if r['pair']==i) for i in range(1,6))
assert all(r['complete_clean'] for r in ledger['runs'])
checks = json.loads((out/'checks/results.json').read_text())
assert len(checks)==7 and all(c['exit_code']==0 and not c['errors'] for c in checks)
assert json.loads((out/'checks/mutation-normalized.json').read_text())['detected']
manifest = {'step':'DT-11a', 'date':'2026-10-14', 'comparison_commit':prior['source_commit'],
    'comparison_archive_sha256':sha(archive), 'retention_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'scope':'Conservative per-build grass exclusion culling; shared host, frozen imported source plus previous ground-image cache; no release/platform/loading acceptance',
    'engines':{str(p):sha(p) for p in [Path('.tools/Godot_v4.7.2-stable_win64.exe')]},
    'sources':{str(p):sha(p) for p in [Path('app/scenery/imported_near_grass.gd'),Path('app/tests/test_grass_mask_bounds.gd'),root/'source/app/render/ground.gd']},
    'checks':{'bounds_draft':23, 'bounds_integrated_shared_tree':23, 'imported_near_grass':27,'near_grass':38,'landscape_ground_lu18':27,
        'field_surfaces':19,'field_integration':39,'world_presentation_context':17,'layout_exact_pairs':72,'native_buffer_pairs':18,'boundary_mutation_detected':True,
        'loading_complete_process_pairs':5,'loading_active_first_draws':sum(not c['paused_at_first_draw'] for c in cycles),
        'loading_paused_first_draws':sum(c['paused_at_first_draw'] for c in cycles),'loading_eligible_pairs':eligible_pairs},
    'failed_harnesses':['Native initial probe compared fresh resource identities; corrected to full mesh/instance parity.',
        'Initial boundary mutation wrote CRCRLF and failed parsing; normalized UTF-8 mutation detects four intended boundary failures.'],
    'artifacts':{p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='evidence-manifest.json'}}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'artifacts':len(manifest['artifacts']), 'checks':manifest['checks'], 'source_verification':verification},indent=2))
