from pathlib import Path
import subprocess,json,hashlib

root=Path(__file__).resolve().parent
app=root/'source/app'
engine=Path('.tools/Godot_v4.7.2-stable_win64.exe').resolve()
out=root/'checks'
out.mkdir()
records=[]
def run(name, project, script):
    command=[str(engine),'--headless','--path',str(project),'--audio-driver','Dummy','--script',str(script)]
    log=out/f'{name}.log'
    with log.open('w') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,timeout=120)
    text=log.read_text()
    record={'name':name,'command':command,'exit_code':result.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
        'errors':any(s in text for s in ['ERROR:', 'SCRIPT ERROR']), 'warnings':[s for s in text.splitlines() if 'WARNING:' in s]}
    records.append(record)
    (out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,'errors',record['errors'],flush=True)
    if result.returncode or record['errors']: raise SystemExit(name+' failed')

run('bounds-shared-tree',Path('app').resolve(),Path('app/tests/test_grass_mask_bounds.gd').resolve())
for name in ['test_imported_near_grass','test_near_grass','test_landscape_ground_lu18','test_field_surfaces','test_field_integration','test_world_presentation_context']:
    run(name,app,'res://tests/'+name+'.gd')
source=app/'scenery/imported_near_grass.gd'
original=source.read_bytes()
mutated=original.decode().replace('NearGrass.RADIUS_M < min_', 'NearGrass.RADIUS_M <= min_').replace('NearGrass.RADIUS_M > max_', 'NearGrass.RADIUS_M >= max_')
assert mutated!=original.decode()
(out/'mutation.gd').write_text(mutated)
try:
    source.write_text(mutated)
    command=[str(engine),'--headless','--path',str(app),'--audio-driver','Dummy','--script',str(root/'test_grass_mask_bounds.gd')]
    with (out/'mutation.log').open('w') as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,timeout=60)
    text=(out/'mutation.log').read_text()
    detected=result.returncode!=0 and text.count('FAIL expanded boundary stays inclusive:')==4
    (out/'mutation.json').write_text(json.dumps({'command':command,'exit_code':result.returncode,'detected':detected,'expected_failure':True},indent=2))
    print('boundary mutation rejected',detected,flush=True)
    if not detected: raise SystemExit(1)
finally:
    source.write_bytes(original)
