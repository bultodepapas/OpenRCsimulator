from pathlib import Path
import subprocess
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
lights=HERE/'baseline-self.gd'
source=(HERE/'reference.gd').read_text().replace('load("res://render/rotor/heli_night_lights.gd")', 'load("'+lights.as_posix()+'")')
lights.write_text(source,encoding='utf-8')
home=HERE/'baseline-home.gd'
home.write_text((ROOT/'app/ui/home_scene.gd').read_text().replace('"res://render/rotor/heli_night_lights.gd"','"'+lights.as_posix()+'"'),encoding='utf-8')
test=HERE/'baseline-test.gd'
test.write_text((HERE/'test-candidate.gd').read_text().replace('"res://render/rotor/heli_night_lights.gd"','"'+lights.as_posix()+'"').replace('"res://ui/home_scene.gd"','"'+home.as_posix()+'"'),encoding='utf-8')
cmd=[str(ROOT/'.tools/Godot_v4.7.2-stable_win64.exe'),'--path',str(ROOT/'app'),'--audio-driver','Dummy','--script',str(test)]
with (HERE/'baseline-native.log').open('wb') as log:
    result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(HERE/'baseline-check.json').write_text(json.dumps(dict(command=cmd,exit_code=result.returncode),indent=2))
print(result.returncode,(HERE/'baseline-native.log').read_text(),flush=True)
