extends SceneTree
const World := preload("res://render/world/world.gd")
const Loader := preload("res://data/field_loader.gd")
const Field := preload("field_phases.gd")
func _initialize() -> void:
    var field: Dictionary = Loader.load_from().field
    for i in 3:
        var node := Node3D.new()
        var begin := Time.get_ticks_usec()
        World.build(node, field, func() -> void: node.add_child(Field.build(field)))
        print("FIELD WORLD TOTAL ", i, ": ", Time.get_ticks_usec()-begin)
        node.free()
    quit()
