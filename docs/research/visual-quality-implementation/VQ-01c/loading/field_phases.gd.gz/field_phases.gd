# L5: render only validated openrc-field v1 data. No camera, aircraft or simulation state.
extends RefCounted

const Atmosphere = preload("res://render/atmosphere.gd")
const Frames = preload("res://render/frames.gd")
const Treeline = preload("res://render/treeline.gd")
const Ground = preload("res://render/ground.gd")
const NearGrass = preload("res://render/near_grass.gd")
const ImportedNearGrass = preload("res://scenery/imported_near_grass.gd")
const LakeWorld = preload("lake_world_phases.gd")
const Horizon = preload("res://render/horizon.gd")
const PilotStation = preload("res://render/pilot_station.gd")
const FlightlineBarrier = preload("res://render/flightline_barrier.gd")
const FieldProjectedShadows = preload("res://render/field_projected_shadows.gd")
const FlightCueShadows = preload("res://render/flight_cue_shadows.gd")
const Windsock = preload("res://render/windsock.gd")
const Scenery = preload("res://scenery/scenery.gd") # SC-02a: on by default; explicit scenery-off remains a no-op.
const LandscapeOptions = preload("res://render/landscape_upgrade/options.gd")
const DistantRidges = preload("res://render/landscape_upgrade/ridges.gd")
# Legacy fallback separation only; ordinary fields paint their surfaces in the rough ground pass.
const SURFACE_LIFT: Dictionary = {"rough": 0.0, "mown": 0.015, "runway": 0.03}
const GROUND_SUBDIVISIONS := 63


static func build(field: Dictionary, lighting: Dictionary = {}) -> Node3D:
	var result: Node3D = Node3D.new()
	result.name = "Field"
	# L9c: one ground pass for contained flat rectangles; retain legacy geometry for other valid fields.
	var grass: ShaderMaterial = Ground.grass_material(lighting)
	var materials: Array[ShaderMaterial] = [grass]
	var station := Frames.ned_to_render([field.pilot.north, field.pilot.east, 0.0])
	grass.set_shader_parameter("pilot_xz", Vector2(station.x, station.z)) # Phase 2: the macro tone is pinned here
	var consolidated: bool = Ground.configure_surfaces(grass, field.surfaces)
	result.set_meta("surfaces_consolidated", consolidated)
	for surface: Dictionary in field.surfaces:
		if consolidated and surface.type != "rough":
			continue
		var mesh_instance: MeshInstance3D = MeshInstance3D.new()
		mesh_instance.name = surface.id
		var plane: PlaneMesh = PlaneMesh.new()
		plane.size = Vector2(surface.length_east_west, surface.width_north_south)
		if surface.type == "rough":
			# G-1: a 40 km plane of two triangles interpolates depth badly once clipped and hid the 3 cm runway in raised
			# views (SC-01: 4 of 12 views at 30 m). 64 × 64 quads (8,192 triangles, one draw) fix it with margin.
			plane.subdivide_width = GROUND_SUBDIVISIONS
			plane.subdivide_depth = GROUND_SUBDIVISIONS
		mesh_instance.mesh = plane
		# L7: replace the default footprint, never stack hills over the old plane. Small/custom rectangles
		# retain L5's flat contract. No collision or simulation heights are introduced by this renderer.
		if surface.type == "rough" and plane.size == Vector2(40000.0, 40000.0):
			var phase_0 := Time.get_ticks_usec()
			mesh_instance.mesh = Horizon.mesh()
			print("PHASE horizon: ", Time.get_ticks_usec() - phase_0)
		mesh_instance.position = Frames.ned_to_render([surface.center_north, surface.center_east, -float(SURFACE_LIFT[surface.type])])
		var half := Vector2(surface.length_east_west, surface.width_north_south) / 2.0
		mesh_instance.material_override = grass if surface.type == "rough" \
			else Ground.surface_material(grass, surface.type, Vector2(mesh_instance.position.x, mesh_instance.position.z), half)
		if not materials.has(mesh_instance.material_override):
			materials.append(mesh_instance.material_override as ShaderMaterial)
		result.add_child(mesh_instance)
	for object_data: Dictionary in field.objects:
		var phase_1 := Time.get_ticks_usec()
		result.add_child(Treeline.build(object_data, field.pilot))
		print("PHASE treeline: ", Time.get_ticks_usec() - phase_1)
	for cue: Dictionary in field.get("flight_cues", []):
		if cue.type == "pilot_station":
			result.add_child(PilotStation.build(cue))
		elif cue.type == "flightline_barrier":
			result.add_child(FlightlineBarrier.build(cue))
		else:
			result.add_child(Windsock.build(cue))
	if not field.get("flight_cues", []).is_empty():
		result.add_child(FlightCueShadows.build(field.flight_cues, lighting.has("solar")))
	var scenery_options := Scenery.options()
	var lake_resolution := LakeWorld.resolve(field, scenery_options)
	if not lake_resolution.ok:
		push_error("lake: " + "; ".join(lake_resolution.errors))
		result.set_meta("lake_error", "; ".join(lake_resolution.errors))
	var lake: Dictionary = lake_resolution.lake
	if not lake.is_empty():
		# A ground plane's optimized opaque shadow pass does not retain its shoreline discard.
		# It must not cast a solid lid over the excavated bank and bed.
		for surface: Dictionary in field.surfaces:
			if surface.type == "rough":
				(result.get_node(surface.id) as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var phase_2 := Time.get_ticks_usec()
	Scenery.attach(result, field, lighting, lake)
	print("PHASE scenery: ", Time.get_ticks_usec() - phase_2)
	var phase_3 := Time.get_ticks_usec()
	var lake_node := LakeWorld.attach(result, field, grass, lake, lighting, bool(scenery_options.audio))
	print("PHASE lake: ", Time.get_ticks_usec() - phase_3)
	if lake_node != null:
		materials.append_array(lake_node.get_meta("lighting_materials"))
	var scenery_node := result.get_node_or_null("Scenery")
	var exclusions: Array = scenery_node.get_meta("grass_exclusions", []) if scenery_node != null else []
	var near_grass: Node3D
	if scenery_node != null and field.id == "default":
		var masks := ImportedNearGrass.exclusions_for(scenery_node.get_meta("source_definition", {}), lake)
		var phase_4 := Time.get_ticks_usec()
		near_grass = ImportedNearGrass.build(field, str(scenery_options.quality), masks)
		print("PHASE near_grass: ", Time.get_ticks_usec() - phase_4)
	else:
		near_grass = NearGrass.build(field, grass, exclusions)
	result.add_child(near_grass)
	if near_grass.has_meta("lighting_material"):
		materials.append(near_grass.get_meta("lighting_material") as ShaderMaterial)
	if LandscapeOptions.enabled() and field.get("id", "") == "default":
		var phase_5 := Time.get_ticks_usec()
		var ridges := DistantRidges.build(lighting)
		print("PHASE ridges: ", Time.get_ticks_usec() - phase_5)
		result.add_child(ridges)
		materials.append(ridges.get_meta("lighting_material") as ShaderMaterial)
	var phase_6 := Time.get_ticks_usec()
	FieldProjectedShadows.attach(result, field, lighting)
	print("PHASE shadows: ", Time.get_ticks_usec() - phase_6)
	result.set_meta("lighting_materials", materials)
	result.set_meta("lighting_snapshot", lighting.duplicate(true))
	return result


## Prepare shadow geometry before a checkpoint can commit physical state. Materials are retained by this field.
static func prepare_lighting(field_node: Node3D, lighting: Dictionary) -> Dictionary:
	if not field_node.has_meta("lighting_materials"):
		return {ok = false}
	var changed: bool = field_node.get_meta("lighting_snapshot") != lighting
	var scenery: Dictionary = Scenery.prepare_lighting(field_node, lighting) if changed else {ok = true}
	return {ok = scenery.ok, changed = changed, lighting = lighting.duplicate(true), scenery = scenery}


## No await: publish one snapshot across all cached consumers while retaining scene/resource ownership.
static func commit_lighting(field_node: Node3D, prepared: Dictionary) -> bool:
	if not prepared.changed:
		return false
	if not Scenery.commit_lighting(field_node, prepared.scenery):
		return false
	var lighting: Dictionary = prepared.lighting
	for mat: ShaderMaterial in field_node.get_meta("lighting_materials"):
		Atmosphere.update_ground_material(mat, lighting)
	var cues: MeshInstance3D = field_node.get_node_or_null("FlightCueShadows") as MeshInstance3D
	if cues != null and cues.mesh.get_surface_count() > 0:
		var material: StandardMaterial3D = cues.mesh.surface_get_material(0) as StandardMaterial3D
		material.albedo_color = Color.BLACK if lighting.has("solar") else Color.WHITE
	FieldProjectedShadows.apply_lighting(field_node, lighting)
	field_node.set_meta("lighting_snapshot", lighting.duplicate(true))
	return true


static func update_lighting(field_node: Node3D, lighting: Dictionary) -> bool:
	var prepared: Dictionary = prepare_lighting(field_node, lighting)
	return commit_lighting(field_node, prepared) if prepared.ok else false
