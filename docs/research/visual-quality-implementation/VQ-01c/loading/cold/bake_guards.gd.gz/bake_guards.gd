extends SceneTree
const Loader := preload("res://data/lake_loader.gd")
const Field := preload("res://data/field_loader.gd")
const Surfaces := preload("res://physics/ground_surfaces.gd")
const Ground := preload("res://render/ground.gd")
const Production := preload("res://render/lake/lake_terrain.gd")
func _initialize() -> void:
    var lake: Dictionary = Loader.load_from().lake
    var surfaces: PackedFloat64Array = Surfaces.build(Surfaces.load_table().table, Field.load_from().field).rects
    var original: Resource = load(Production.BAKED_PATH)
    for name in ["stale", "incomplete"]:
        var resource := Resource.new()
        for key: StringName in original.get_meta_list(): resource.set_meta(key, original.get_meta(key))
        if name == "stale": resource.set_meta("format", "stale")
        else: resource.remove_meta("water_arrays")
        ResourceSaver.save(resource, get_script().resource_path.get_base_dir().path_join("bake-" + name + ".res"))
    var ground := Ground.grass_material({})
    var expected := ""
    var results := {}
    for name in ["lake_terrain_reference", "terrain-no-procedural", "terrain-missing", "terrain-stale", "terrain-incomplete"]:
        var builder: Script = load(get_script().resource_path.get_base_dir().path_join(name + ".gd"))
        var node: Node3D = builder.build(lake, ground, surfaces)
        var arrays := [node.get_node("Basin").mesh.surface_get_arrays(0), node.get_node("Water").mesh.surface_get_arrays(0)]
        var digest := Production.geometry_digest(arrays)
        if expected.is_empty(): expected = digest
        results[name] = {"sha256": digest, "matches_reference": digest == expected}
        print(name, " matches=", digest == expected)
        node.free()
        if digest != expected: quit(1); return
    var output := FileAccess.open(get_script().resource_path.get_base_dir().path_join("bake-guards.json"), FileAccess.WRITE)
    output.store_string(JSON.stringify(results, "\t") + "\n")
    output.close()
    quit()
