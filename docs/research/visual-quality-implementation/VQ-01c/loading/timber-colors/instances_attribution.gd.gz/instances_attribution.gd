extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var shader_clock: Script = load("res://render/shader_clock.gd")
	shader_clock.register()
	var loader: Script = load("res://data/field_loader.gd")
	var builder: Script = load(get_script().resource_path.get_base_dir().path_join("attributed_instances_field.gd"))
	var begin := Time.get_ticks_usec()
	var loaded: Dictionary = loader.load_from()
	print("FIELD_LOAD ", (Time.get_ticks_usec() - begin) / 1000.0)
	if not loaded.ok:
		quit(1)
		return
	for index in 3:
		print("BUILD ", index)
		begin = Time.get_ticks_usec()
		var built: Node3D = builder.build(loaded.field)
		print("FIELD_TOTAL ", (Time.get_ticks_usec() - begin) / 1000.0)
		print("SCENERY_PHASES ", JSON.stringify(built.get_node("Scenery").get_meta("stats")))
		built.free()
		await process_frame
		await process_frame
	quit()
