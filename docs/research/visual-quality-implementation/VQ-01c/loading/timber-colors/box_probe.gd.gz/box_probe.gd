extends SceneTree
const Kit = preload("res://scenery/mesh_kit.gd")
const Prefabs = preload("res://scenery/prefabs.gd")

func _initialize() -> void:
	var candidate: Script = load(get_script().resource_path.get_base_dir().path_join("box_candidate.gd"))
	var samples: Array = []
	var exact := 0
	var failures: Array = []
	for pair in 12:
		var order := ["reference", "candidate"]
		if pair % 2: order.reverse()
		var results := {}
		for variant: String in order:
			var kit: RefCounted = Kit.new() if variant == "reference" else candidate.new()
			kit.xf = Transform3D(Basis(Vector3.UP, 0.71), Vector3(2.1, 0.4, -5.8))
			var start := Time.get_ticks_usec()
			for id: String in ["pit_shelter", "barn", "farmhouse", "pylon", "church", "village_house", "silo"]:
				var moving: Array = Prefabs.build(id, kit, 193, "temperate")
				for part: Dictionary in moving:
					if part.has("node") and is_instance_valid(part.node): part.node.free()
			var elapsed := Time.get_ticks_usec() - start
			samples.append({pair=pair, variant=variant, usec=elapsed})
			results[variant] = var_to_bytes([kit.verts, kit.norms, kit.cols, kit.xf, kit.damage_ranges])
		if results.reference == results.candidate: exact += 1
		else: failures.append(pair)
	var output := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify({samples=samples, exact=exact, failures=failures}, "\t"))
	file.close()
	print("prefab pairs=", exact, " failures=", failures)
	quit(0 if failures.is_empty() else 1)
