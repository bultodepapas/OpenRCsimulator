extends "res://scenery/mesh_kit.gd"

func box(size: Vector3, c: Vector3, col: Color, bottom := false, top_col: Variant = null) -> void:
	var h := size * 0.5
	var p: Array[Vector3] = [
		xf * (c + Vector3(-h.x, -h.y, -h.z)), xf * (c + Vector3(h.x, -h.y, -h.z)),
		xf * (c + Vector3(h.x, h.y, -h.z)), xf * (c + Vector3(-h.x, h.y, -h.z)),
		xf * (c + Vector3(-h.x, -h.y, h.z)), xf * (c + Vector3(h.x, -h.y, h.z)),
		xf * (c + Vector3(h.x, h.y, h.z)), xf * (c + Vector3(-h.x, h.y, h.z)),
	]
	var mirrored := xf.basis.determinant() < 0.0
	var top: Color = top_col if top_col != null else col
	_box_quad(p[4], p[5], p[6], p[7], col, mirrored)
	_box_quad(p[1], p[0], p[3], p[2], col, mirrored)
	_box_quad(p[5], p[1], p[2], p[6], col, mirrored)
	_box_quad(p[0], p[4], p[7], p[3], col, mirrored)
	_box_quad(p[7], p[6], p[2], p[3], top, mirrored)
	if bottom:
		_box_quad(p[0], p[1], p[5], p[4], col, mirrored)

func _box_quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color, mirrored: bool) -> void:
	_box_triangle(a, b, c, col, mirrored)
	_box_triangle(a, c, d, col, mirrored)

func _box_triangle(pa: Vector3, pb: Vector3, pc: Vector3, col: Color, mirrored: bool) -> void:
	if mirrored:
		var t := pb
		pb = pc
		pc = t
	var n := (pb - pa).cross(pc - pa)
	if n.length_squared() < 1e-14:
		return
	n = n.normalized()
	verts.append(pa)
	verts.append(pc)
	verts.append(pb)
	norms.append(n)
	norms.append(n)
	norms.append(n)
	cols.append(col)
	cols.append(col)
	cols.append(col)
