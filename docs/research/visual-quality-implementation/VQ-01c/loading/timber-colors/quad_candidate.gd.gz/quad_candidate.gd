extends "res://scenery/mesh_kit.gd"

func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color) -> void:
	var pa := xf * a
	var pb := xf * b
	var pc := xf * c
	var pd := xf * d
	var mirrored := xf.basis.determinant() < 0.0
	_append_transformed_triangle(pa, pb, pc, col, mirrored)
	_append_transformed_triangle(pa, pc, pd, col, mirrored)

func _append_transformed_triangle(pa: Vector3, pb: Vector3, pc: Vector3, col: Color, mirrored: bool) -> void:
	if mirrored:
		var t := pb
		pb = pc
		pc = t
	var n := (pb - pa).cross(pc - pa)
	if n.length_squared() < 1e-14:
		return
	n = n.normalized()
	verts.append(pa)
	verts.append(pc)
	verts.append(pb)
	norms.append(n)
	norms.append(n)
	norms.append(n)
	cols.append(col)
	cols.append(col)
	cols.append(col)
