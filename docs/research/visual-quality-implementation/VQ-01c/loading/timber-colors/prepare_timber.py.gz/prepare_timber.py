from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent
source=Path('app/scenery/club_furniture.gd').read_text()
(r/'timber_reference.gd').write_text(source,newline='\n')
source=source.replace('\tvar rings: Array[PackedVector3Array] = []','\tvar rings: Array[PackedVector3Array] = []\n\tvar colors: Array[PackedColorArray] = []',1)
source=source.replace('\t\tvar ring := PackedVector3Array()','\t\tvar ring := PackedVector3Array()\n\t\tvar color_ring := PackedColorArray()',1)
source=source.replace('\t\t\tring.append(Vector3(x,p.x,p.y))','\t\t\tvar point := Vector3(x,p.x,p.y)\n\t\t\tring.append(point)\n\t\t\tcolor_ring.append(_wood_color(point,tone,seed))',1)
source=source.replace('\t\trings.append(ring)','\t\trings.append(ring)\n\t\tcolors.append(color_ring)',1)
source=source.replace('_face(k,rings[r][next],rings[r+1][next],rings[r+1][j],rings[r][j],tone,seed)',
    '_face(k,rings[r][next],rings[r+1][next],rings[r+1][j],rings[r][j],tone,\n\t\t\t\tcolors[r][next],colors[r+1][next],colors[r+1][j],colors[r][j])',1)
start=source.index('static func _face(')
end=source.index('\n\nstatic func _bolt(',start)
replacement='''static func _face(k: MeshKit, a: Vector3, b: Vector3, c: Vector3, d: Vector3, tone: Color,
		ca: Color, cb: Color, cc: Color, cd: Color) -> void:
	var first := k.cols.size()
	k.quad(a,b,c,d,tone)
	k.cols[first] = ca
	k.cols[first+1] = cc
	k.cols[first+2] = cb
	k.cols[first+3] = ca
	k.cols[first+4] = cd
	k.cols[first+5] = cc


static func _wood_color(p: Vector3, tone: Color, seed: int) -> Color:
	if _wood == null:
		_wood = Wood.get_image()
		# Filter before vertex sampling: no glittering single-texel grain or extra draw.
		_wood.resize(96,64,Image.INTERPOLATE_LANCZOS)
	var u := fposmod(p.x/0.8+float(seed)*0.173,1.0)
	var v := fposmod((p.z+p.y*2.0)/0.8+float(seed)*0.319,1.0)
	var sample := _wood.get_pixel(int(u*95),int(v*63))
	var light := (sample.r+sample.g+sample.b)/3.0
	var shade := clampf(1.0+(light-0.39)*3.0,0.78,1.18)
	shade *= 0.91+0.13*float(seed%5)/4.0
	return Color(tone.r*shade,tone.g*shade,tone.b*shade,1.0)
'''
source=source[:start]+replacement+source[end:]
(r/'timber_candidate.gd').write_text(source,newline='\n')
for variant in ['reference','candidate']:
    shed=Path('app/scenery/club_shed.gd').read_text().replace('res://scenery/club_furniture.gd',(r/f'timber_{variant}.gd').as_posix())
    (r/f'shed_{variant}.gd').write_text(shed,newline='\n')
    prefabs=Path('app/scenery/prefabs.gd').read_text().replace('res://scenery/club_furniture.gd',(r/f'timber_{variant}.gd').as_posix()).replace('res://scenery/club_shed.gd',(r/f'shed_{variant}.gd').as_posix())
    (r/f'prefabs_{variant}.gd').write_text(prefabs,newline='\n')
    scenery=Path('app/scenery/scenery.gd').read_text().replace('res://scenery/prefabs.gd',(r/f'prefabs_{variant}.gd').as_posix())
    (r/f'scenery_{variant}.gd').write_text(scenery,newline='\n')
    field=Path('app/render/field.gd').read_text().replace('res://scenery/scenery.gd',(r/f'scenery_{variant}.gd').as_posix())
    (r/f'field_{variant}.gd').write_text(field,newline='\n')
paths=[p for p in Path('app').rglob('*') if p.is_file() and '.godot' not in p.parts and p.suffix in ['.gd','.json','.godot']]
(r/'source-before.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}},indent=2))
