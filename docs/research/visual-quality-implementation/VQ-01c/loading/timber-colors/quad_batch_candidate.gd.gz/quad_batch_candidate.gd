extends "res://scenery/mesh_kit.gd"

func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color) -> void:
	var pa := xf * a
	var pb := xf * b
	var pc := xf * c
	var pd := xf * d
	var first_b := pb
	var first_c := pc
	var second_b := pc
	var second_c := pd
	if xf.basis.determinant() < 0.0:
		first_b = pc
		first_c = pb
		second_b = pd
		second_c = pc
	var first_normal := (first_b - pa).cross(first_c - pa)
	var second_normal := (second_b - pa).cross(second_c - pa)
	if first_normal.length_squared() < 1e-14 or second_normal.length_squared() < 1e-14:
		tri(a, b, c, col)
		tri(a, c, d, col)
		return
	first_normal = first_normal.normalized()
	second_normal = second_normal.normalized()
	verts.append_array(PackedVector3Array([pa, first_c, first_b, pa, second_c, second_b]))
	norms.append_array(PackedVector3Array([first_normal, first_normal, first_normal, second_normal, second_normal, second_normal]))
	cols.append_array(PackedColorArray([col, col, col, col, col, col]))
