from pathlib import Path
import sys,os,subprocess,json,hashlib,re
r=Path(__file__).resolve().parent;a=r/'complete/app';rootrepo=Path('/workspace/scratch/eba78909e368/OpenRCsimulator');tree=json.loads((r/'app-tree.json').read_text());tree_by_p={x['path']:x['sha'] for x in tree}; out=r/'checks';drivers=r/'drivers';sf=lambda n:'res://tests/test_companions_'+n+'.gd'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def index(allowed):
 for path,entry in json.loads((r/'external-source-inventory.json').read_text())['files'].items():
  data=(r/'complete'/path).read_bytes();assert sha(data)==entry['checkout_sha256'] and len(data)==entry['bytes'],path
 working_index=json.loads((r/'worktree-index.json').read_text());changed={o['path']:blob((a/o['path']).read_bytes()) for o in tree if blob((a/o['path']).read_bytes())!=working_index[o['path']]};print('index changes',changed,flush=True);assert changed==allowed,(changed,allowed);return changed
def output(name,obj):(r/name).write_text(json.dumps(obj,indent=2)+'\n')
def check(label,script,markers=(),extra=(),expect_fail=False,regex=None,budget=180):
 label="complete-"+label
 proc=subprocess.run([sys.executable,'-B',str(r/'run.py'),label,str(budget),'--script',str(script),*extra],env={**os.environ,'COMPANION_EXPECT':'|'.join(markers)})
 report=json.loads(next(out.glob(label+'-*/report.json')).read_text());log=Path(report['log']).read_text()
 assert report['complete'] and report['counts']['error']==0 and not report['missing_required_text'],report
 if expect_fail:assert report['process_exit']==1 and report['reason']=='process_exit' and report['elapsed_seconds']<30 and 'SCRIPT ERROR:' not in log, report
 else:assert report['ok'] and proc.returncode==0,report
 if label=='complete-stale-normal':
  line=next(x for x in log.splitlines() if x.startswith('FAIL actual profile admission enforces the manifest ')); parsed=json.loads(line.split('manifest ',1)[1].replace(chr(92)+chr(39),chr(39))); assert len(parsed)==2 and all('current source does not match the qualified manifest' in item for item in parsed),parsed
 if regex: assert re.search(regex,log), (label,regex,log[-5000:])
 return report,log
def stage():
 mp='data/ai/companions/behavior-manifest.json';pp='data/ai/companions/aircraft/jensen-das-ugly-stik-60.json';mf=a/mp;pf=a/pp;mb=mf.read_bytes();pb=pf.read_bytes();m=json.loads(mb);pdata=json.loads(pb);bad={k:[v,sha((a/k[6:]).read_bytes().replace(b'\r\n',b'\n'))] for k,v in m['sources'].items() if sha((a/k[6:]).read_bytes().replace(b'\r\n',b'\n'))!=v};assert set(bad)=={'res://app_root.gd','res://scenery/collision_world.gd'};assert pdata['behavior_manifest']['sha256']==sha(mb);new=mb
 for original,newsha in bad.values():assert new.count(original.encode())==1;new=new.replace(original.encode(),newsha.encode())
 assert pb.count(sha(mb).encode())==1;newp=pb.replace(sha(mb).encode(),sha(new).encode());(r/'complete-pre-candidate').mkdir(exist_ok=False);(r/'complete-pre-candidate/behavior-manifest.json').write_bytes(mb);(r/'complete-pre-candidate/jensen-das-ugly-stik-60.json').write_bytes(pb);mf.write_bytes(new);pf.write_bytes(newp);changes={mp:blob(new),pp:blob(newp)};output('candidate-identities.json',{'source_sha':'847d8d1a26b885124f6b634ee9badfe6684bef13','app_tree':'9284e4433667b079d2d29467ca1ce6d7f6bb1ed5','pins':bad,'replacements':{mp:[sha(mb),sha(new)],pp:[sha(pb),sha(newp)]},'candidate_changed_blobs':changes});return changes
if sys.argv[1]=='pre':
 ip=json.loads(next(out.glob('checkout-import-*/report.json')).read_text());assert ip['ok'] and ip['complete'],ip;index({})
 fixed=drivers/'guarded_behavior_manifest.gd';check('stale-normal',fixed,['current source set matches the expected admission outcome','actual profile admission enforces the manifest','res://app_root.gd','res://scenery/collision_world.gd'],expect_fail=True,regex=r'companion behavior manifest: [1-9]\d* checks, 2 failed');check('stale-refusal',fixed,regex=r'companion behavior manifest: [1-9]\d* checks, 0 failed')
 check('club-trajectory',sf('trajectory'),['full trajectory context:','static trajectory oracle:'],regex=r'static trajectory: [1-9]\d* checks, 0 failed',budget=240)
 check('gate-collisions','res://tests/test_scenery_destruction.gd',regex=r'scenery destruction: [1-9]\d* checks, 0 failures');index({});print('Prechecks passed; no candidate pins staged.',flush=True)
elif sys.argv[1] in ('post','resume'):
 for name in ['stale-normal','stale-refusal','club-trajectory','gate-collisions']:
  rr=json.loads(next(out.glob('complete-'+name+'-*/report.json')).read_text());assert rr['complete'] and rr['process_exit']==(1 if name=='stale-normal' else 0) and rr['counts']['error']==0,rr
 if sys.argv[1]=='post':
  index({});changes=stage()
 else:
  changes=json.loads((r/'candidate-identities.json').read_text())['candidate_changed_blobs']
 index(changes)
 checks=[('behavior-positive',drivers/'guarded_behavior_manifest.gd',[],[],r'companion behavior manifest: [1-9]\d* checks, 0 failed',60),('strict-profiles',sf('profiles'),['ok   current Stik and Club profiles validate'],[],r'companion profile validation: [1-9]\d* checks, 0 failed',60),('strict-airspace',drivers/'strict_airspace.gd',['ok   all three qualified altitude slots pass the default static world','ok   production report with real radius, gap, proxy count and hashes is written'],['--',f'--out={r}/current-club-airspace.json'],r'static airspace validation: [1-9]\d* checks, 0 failed',180),('strict-shell',drivers/'strict_shell.gd',['ok   the manager starts three real AI pilots','ok   Restart rebuilds the live group from the staged count'],[],r'Companions shell: 0 failed',240),('strict-one-Home',sf('draft_refresh'),['ok   unmodified qualified profile admits one actual companion'],[],r'companions draft refresh: [1-9]\d* checks, 0 failed',180),('strict-manager',drivers/'strict_manager.gd',[],[],r'companions manager: [1-9]\d* checks, 0 failed',180),('strict-observation',drivers/'strict_observation.gd',[],[],r'AFC COMPANION OBSERVATION CHECKS [1-9]\d* FAILED 0',180),('strict-presentation',drivers/'strict_presentation.gd',[],[],r'companion presentation: [1-9]\d* checks, 0 failed',180),('strict-lifecycle',drivers/'strict_lifecycle.gd',[],[],r'companions lifecycle: [1-9]\d* checks, 0 failed',240),('strict-seeds',sf('seeds_timing'),[],[],r'companions seeds and timing: [1-9]\d* checks, 0 failed',180),('strict-session',sf('session'),[],[],r'[1-9]\d* checks, 0 failed',180),('strict-restore',drivers/'strict_restore.gd',[],[],r'companion restore lifecycle: [1-9]\d* checks, 0 failed',180)]
 checks.extend([('home-routing','res://tests/test_ui_home.gd',['ok   route: the dynamic resolution experiment starts at Home','ok   route: --quick-flight -> direct flight'],[],r'all UI home checks passed',180),('headless-resolution-policy','res://tests/test_flight_resolution_policy.gd',[],[],r'Flight resolution policy: 0 failed',60)])
 checks.extend([('normal-home-'+str(n),drivers/'normal_home.gd',['Normal Home admitted requested fleet with production guard enabled'],['--',str(n)],r'NORMAL_HOME_FLEET ',180) for n in (1,2,3)])
 for label,script,markers,extras,rgx,t in checks:
  if sys.argv[1]=='resume' and label in ('behavior-positive','strict-profiles'):
   rr=json.loads(next(out.glob('complete-'+label+'-*/report.json')).read_text());assert rr['ok'] and rr['complete'];continue
  if label=='strict-airspace':
   label='airspace-current-output';extras=['--',f'--out={r}/current-club-airspace-closed.json']
  check(label,script,markers,extras,regex=rgx,budget=t)
 index(changes);print('All bounded candidate checks passed.',flush=True)
