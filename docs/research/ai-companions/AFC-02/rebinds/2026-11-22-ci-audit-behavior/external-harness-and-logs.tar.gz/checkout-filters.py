from pathlib import Path
import subprocess,json,hashlib,os,tempfile,shutil
r=Path(__file__).resolve().parent; repo=Path('/workspace/scratch/eba78909e368/OpenRCsimulator'); app=r/'complete/app';tree=json.loads((r/'app-tree.json').read_text());attrs=json.loads((r/'checkout-attrs.json').read_text());ref='847d8d1a26b885124f6b634ee9badfe6684bef13'
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['.gitattributes']+['app/'+o['path'] for o in tree if Path(o['path']).name=='.gitattributes'];print('effective attributes files',paths)
with tempfile.TemporaryDirectory(prefix='filtering-',dir=r) as tmp:
 g=['git','-C',tmp,'-c','core.autocrlf=false','-c','core.eol=lf'];subprocess.run([*g,'init','--quiet'],check=True); ar={}
 for name in paths:
  expected=subprocess.check_output(['git','-C',str(repo),'rev-parse',ref+':'+name]).decode().strip();f=repo/name;original=f.read_bytes();assert blob(original)==expected;out=Path(tmp)/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(original);ar[name]=[expected,sha(original)]
 subprocess.run([*g,'add','--',*paths],check=True)
 index_blob={};index_sha={};changed={}; rawmatches={}; pathsha=hashlib.sha256()
 for o in tree:
  name=o['path'];f=app/name;b=f.read_bytes();assert blob(b)==o['sha']; assert attrs[name]['filter']=='unspecified' and attrs[name]['ident']=='unspecified' and attrs[name]['working-tree-encoding']=='unspecified'
  if attrs[name]['text']=='set':
   data=subprocess.check_output([*g,'hash-object','--no-filters','-w','--stdin'],input=b).decode().strip();assert data==o['sha']
   checkout=subprocess.check_output([*g,'cat-file','--filters','--path=app/'+name,data])
   if b!=checkout:
    f.write_bytes(checkout);changed[name]={'git_blob':o['sha'],'checkout_sha256':sha(checkout),'raw_sha256':sha(b),'eol':attrs[name]['eol']};local=(repo/'app'/name).read_bytes(); assert local==checkout,(name,sha(local),sha(checkout));rawmatches[name]=True
   b=checkout
  index_blob[name]=blob(b);index_sha[name]=sha(b);pathsha.update(name.encode()+b'\0'+o['mode'].encode()+b'\0'+o['sha'].encode()+b'\0'+sha(b).encode()+b'\n')
 (r/'worktree-index.json').write_text(json.dumps(index_blob));(r/'worktree-sha256.json').write_text(json.dumps(index_sha));(r/'filtered-checkout.json').write_text(json.dumps({'source_commit':ref,'app_tree':'9284e4433667b079d2d29467ca1ce6d7f6bb1ed5','all_app_files':len(tree),'attributes_sources':ar,'core_autocrlf':False,'core_eol':'lf','changed_raw_to_checkout':changed,'source_inventory_sha256':pathsha.hexdigest(),'inventory_encoding':'Path, NUL, mode, NUL, source Git blob, NUL, worktree SHA256, LF per recursive tree listing'},indent=2)+'\n');print('changed',len(changed),'all matching actual checkout',len(rawmatches),'digest',pathsha.hexdigest());assert set(changed)=={p for p,a in attrs.items() if a['eol']=='crlf'}
