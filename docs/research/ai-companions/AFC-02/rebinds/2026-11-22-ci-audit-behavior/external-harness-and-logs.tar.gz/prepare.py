from pathlib import Path
import json,hashlib,subprocess,os,shutil,sys,tempfile,time,concurrent.futures,collections
root=Path(__file__).resolve().parent; repo=Path('/workspace/scratch/eba78909e368/OpenRCsimulator'); app=root/'complete'/'app'; app.mkdir(exist_ok=True,parents=True)
tree=json.loads((root/'app-tree.json').read_text()); expect={o['path']:o for o in tree}
def sha(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(o,b):
 if len(b)!=o['size'] or sha(b)!=o['sha']:raise ValueError(o['path'])
 f=app/o['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);f.chmod(int(o['mode'][-3:],8))
missing=collections.defaultdict(list)
for o in tree:
 f=repo/'app'/o['path']; b=f.read_bytes() if f.is_file() else b''
 if b and sha(b)==o['sha'] or o['size']==0:put(o,b)
 else:missing[o['sha']].append(o)
items=sorted(missing.items(),key=lambda pair:pair[1][0]['size'],reverse=True);batches=[(0,[]) for _ in range(24)]
for k,rs in items:
 n=min(range(len(batches)),key=lambda n:batches[n][0]);s,l=batches[n];l.append(k);batches[n]=(s+rs[0]['size'],l)
print('local',sum(1 for o in tree if (app/o['path']).exists()),'missing unique',len(items),'batch sizes',[b[0] for b in batches],flush=True)
def fetch(args):
 i,(size,shas)=args
 if not shas:return
 with tempfile.TemporaryDirectory(dir=root,prefix='objects-') as td:
  base=['git','-C',td,'-c','gc.auto=0','-c','fetch.unpackLimit=1','-c','protocol.version=2']
  subprocess.run([*base,'init','--bare','--quiet'],check=True,stdout=subprocess.DEVNULL)
  subprocess.run([*base,'remote','add','origin','https://github.com/bultodepapas/OpenRCsimulator.git'],check=True)
  for t in range(3):
   try:
    r=subprocess.run([*base,'fetch','--quiet','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--stdin','origin'],input=('\n'.join(shas)+'\n').encode(),capture_output=True,timeout=210)
    if r.returncode:raise RuntimeError(r.stderr.decode()[-1000:])
    break
   except (RuntimeError,subprocess.TimeoutExpired):
    if t==2:raise
  p=subprocess.Popen([*base,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);p.stdin.write(('\n'.join(shas)+'\n').encode());p.stdin.close()
  for s in shas:
   identity,kind,n=p.stdout.readline().split(); assert identity.decode()==s and kind==b'blob'; b=p.stdout.read(int(n));assert p.stdout.read(1)==b'\n'
   for o in missing[s]:put(o,b)
  assert p.wait()==0
 print('batch',i,'ok',size,len(shas),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(fetch,enumerate(batches)))
for o in tree:
 b=(app/o['path']).read_bytes();assert len(b)==o['size'] and sha(b)==o['sha'],o['path']
print('Verified complete app',len(tree),'files',sum(o['size'] for o in tree),'bytes',flush=True)
