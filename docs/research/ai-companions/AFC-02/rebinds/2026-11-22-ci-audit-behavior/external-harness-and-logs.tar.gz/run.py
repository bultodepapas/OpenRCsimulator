from pathlib import Path
import json,hashlib,os,sys,subprocess,shutil,time
root=Path(__file__).resolve().parent; repo=Path('/workspace/scratch/eba78909e368/OpenRCsimulator'); app=root/'complete/app'; engine=repo/'.tools/Godot_v4.8-beta2_linux.x86_64'; checks=root/'checks'; (root/'drivers').mkdir(exist_ok=True)
label=sys.argv[1]; profile=root/'profiles'/label; profile.mkdir(parents=True,exist_ok=False)
environment={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','XDG_DATA_HOME':str(profile/'data'),'XDG_CONFIG_HOME':str(profile/'config'),'XDG_CACHE_HOME':str(profile/'cache'),'XDG_STATE_HOME':str(profile/'state'),'NO_COLOR':'1'}
if label.endswith('refusal'):environment['OPENRC_BEHAVIOR_EXPECT_REFUSAL']='1'
else:environment.pop('OPENRC_BEHAVIOR_EXPECT_REFUSAL',None)
wrapped=['python3','-B',str(repo/'tools/godot/run_checked.py'),'--timeout',sys.argv[2],'--out-dir',str(checks),'--label',label];
expected=os.environ.get('COMPANION_EXPECT','')
for marker in expected.split('|'):
 if marker:wrapped+=['--require-text',marker]
wrapped+=['--',str(engine),'--headless','--path',str(app),'--audio-driver','Dummy',*sys.argv[3:]]
p=subprocess.run(wrapped,cwd=root,env=environment,capture_output=True,text=True)
(root/'checks'/f'{label}-wrapper.log').write_text(p.stdout+p.stderr)
r=json.loads(next(checks.glob(label+'-*/report.json')).read_text());print(label,r['reason'],r['process_exit'],r['counts'],r['elapsed_seconds'],r['log'],flush=True);sys.exit(p.returncode)
