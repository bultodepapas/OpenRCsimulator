extends SceneTree

func _initialize() -> void:
    var base := OS.get_environment("XDG_DATA_HOME").simplify_path() + "/"
    var actual := ProjectSettings.globalize_path("user://").simplify_path()
    if base.is_empty() or not actual.begins_with(base):
        push_error("Candidate profile isolation failed")
        quit(1)
        return
    print("Isolated production user profile verified: " + actual)
    quit(0)
