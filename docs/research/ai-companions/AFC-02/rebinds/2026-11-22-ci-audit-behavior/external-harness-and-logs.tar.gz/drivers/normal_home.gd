extends SceneTree

const Preferences := preload("res://app_state/preferences.gd")
const Profiles := preload("res://ai/companions/profile_loader.gd")
const CompanionConfig := preload("res://ai/companions/config.gd")
const UiDriver := preload("res://tests/ui_driver.gd")
const UiInput := preload("res://ui/ui_input.gd")
const PROFILE_PATH := "user://qualification-preferences.cfg"

func _initialize() -> void:
    _run.call_deferred()

func _run() -> void:
    var args := OS.get_cmdline_user_args()
    if args.size() != 1 or args[0] not in ["1", "2", "3"]:
        push_error("One qualified fleet count is required")
        quit(1)
        return
    var count := int(args[0])
    var override_before: bool = Profiles._accept_current_solver
    var bound: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/ai/companions/aircraft/jensen-das-ugly-stik-60.json"))
    var current_solver := Profiles.current_solver_qualification_identity()
    if override_before or not current_solver.get("ok", false) or current_solver.sha256 != bound.solver.sha256:
        push_error("Production solver identity or initial guard is invalid")
        quit(1)
        return
    TranslationServer.set_locale("en")
    InputMap.load_from_project_settings()
    UiInput.isolate_joypads()
    root.size = Vector2i(1920, 1080)
    var ui := UiDriver.new(self)
    if FileAccess.file_exists(PROFILE_PATH):
        push_error("Fresh profile is required")
        quit(1)
        return
    var initial: Dictionary = Preferences.load_from(PROFILE_PATH)
    initial.first_flight_hint_seen = true
    initial.companion_config = CompanionConfig.defaults()
    initial.companion_config.enabled = true
    initial.companion_config.count = count
    initial.companion_config.seed = 101
    if Preferences.save_to(PROFILE_PATH, initial) != OK:
        push_error("Could not save isolated preferences")
        quit(1)
        return
    var app: Variant = load("res://app_root.tscn").instantiate()
    app.user_args = PackedStringArray()
    app.preferences_path = PROFILE_PATH
    root.add_child(app)
    await ui.settle()
    app.home.fly_button.grab_focus()
    await ui.tap(KEY_ENTER)
    await ui.settle()
    var main: Variant = app.flight
    var status: Dictionary = {}
    if main != null:
        for frame in 1800:
            status = main.companion_status()
            if int(status.get("ticks", 0)) >= 240:
                break
            await physics_frame
    var identity: Dictionary = status.get("profile_identity", {})
    var geometry: Dictionary = status.get("airspace_report", {})
    var result := {"requested": count, "active": status.get("active", 0),
        "airborne": status.get("airborne", 0), "faulted": status.get("faulted", -1),
        "crashed": status.get("crashed", -1), "ticks": status.get("ticks", 0),
        "admitted": status.get("admitted_count", 0), "profile": identity, "airspace": geometry,
        "error": status.get("error", ""), "solver_override_before": override_before, "editor_feature": OS.has_feature("editor"),
        "solver_override_after": Profiles._accept_current_solver, "expected_solver_pin": bound.solver.sha256,
        "actual_solver_sha256": current_solver.sha256, "solver_source_count": current_solver.get("file_count", current_solver.get("source_count", 0))}
    print("NORMAL_HOME_FLEET ", JSON.stringify(result))
    var ok := main != null and int(result.active) == count and int(result.airborne) == count \
        and int(result.admitted) == count and int(result.faulted) == 0 and int(result.crashed) == 0 \
        and int(result.ticks) >= 240 and str(result.error).is_empty() \
        and str(identity.get("behavior_manifest_sha256", "")) == FileAccess.get_sha256("res://data/ai/companions/behavior-manifest.json") \
        and int(geometry.get("count", 0)) == count
    ok = ok and OS.has_feature("editor") and not Profiles._accept_current_solver and identity.get("solver_qualification_sha256", "") == current_solver.sha256
    await ui.close_app(app)
    if ok:
        print("Normal Home admitted requested fleet with production guard enabled")
    else:
        push_error("Normal Home admission or post-launch state failed")
    quit(0 if ok else 1)
