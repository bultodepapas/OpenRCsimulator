from pathlib import Path
import json,hashlib,subprocess,os,re,tempfile,sys
r=Path(__file__).resolve().parent;a=r/'complete/app';repo=Path('/workspace/scratch/eba78909e368/OpenRCsimulator');ref='847d8d1a26b885124f6b634ee9badfe6684bef13'
paths=set()
for d in [a/'data/aircraft_models',a/'data/aircraft_model_overlays']:
 for f in d.glob('*.json'):
  paths.update(re.findall(r'"(assets/[^"\n]+)"',f.read_text()))
assert len(paths)==27 and all(p.startswith('assets/aircraft/') and p.endswith('.json') for p in paths)
ancestors={'.gitattributes'}
for p in paths:ancestors.update(str(k/'.gitattributes') for k in Path(p).parents)
declared=set(subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',ref,'--','assets','.gitattributes']).decode().splitlines()); attrfiles=sorted(declared&ancestors);paths=sorted(paths);print('attributes',attrfiles)
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def sha(b):return hashlib.sha256(b).hexdigest()
with tempfile.TemporaryDirectory(dir=r,prefix='external-objects-') as td:
 g=['git','-C',td,'-c','core.autocrlf=false','-c','core.eol=lf','-c','gc.auto=0'];subprocess.run([*g,'init','--quiet'],check=True);subprocess.run([*g,'remote','add','origin','https://github.com/bultodepapas/OpenRCsimulator.git'],check=True);ids={p:subprocess.check_output(['git','-C',str(repo),'rev-parse',ref+':'+p]).decode().strip() for p in paths+attrfiles};subprocess.run([*g,'fetch','--quiet','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--stdin','origin'],input=('\n'.join(sorted(set(ids.values())))+'\n').encode(),timeout=120,check=True)
 for p in attrfiles:
  b=subprocess.check_output([*g,'cat-file','blob',ids[p]]); assert blob(b)==ids[p];t=Path(td)/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
 subprocess.run([*g,'add','--',*attrfiles],check=True);records={}
 for p in paths:
  raw=subprocess.check_output([*g,'cat-file','blob',ids[p]]);b=subprocess.check_output([*g,'cat-file','--filters','--path='+p,ids[p]]);assert blob(raw)==ids[p];f=r/'complete'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);records[p]={'git_blob':ids[p],'checkout_sha256':sha(b),'bytes':len(b)}
 raw=(json.dumps({'source_commit':ref,'collection':'All repository-relative authoring paths declared by the seven bundled model manifests and two overlay manifests','attribute_sources':{p:ids[p] for p in attrfiles},'files':records},indent=2)+'\n').encode();(r/'external-source-inventory.json').write_bytes(raw);Path('/workspace/scratch/eba78909e368/companion-renewal-validation/external-source-inventory.json').write_bytes(raw); print('attested',len(records),sum(o['bytes'] for o in records.values()), 'bytes','inventory',sha(raw))
