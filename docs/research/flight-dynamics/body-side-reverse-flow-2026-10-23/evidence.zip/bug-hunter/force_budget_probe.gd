extends SceneTree

const M := preload("res://physics/math3d.gd")
const RB := preload("res://physics/rigid_body.gd")
const Air := preload("res://physics/air_data.gd")
const Aero := preload("res://physics/aero.gd")
const AD := preload("res://physics/aircraft_data.gd")
const Commands := preload("res://input/commands.gd")

func _power(loads: PackedFloat64Array, vel: PackedFloat64Array, rates: PackedFloat64Array) -> float:
	return loads[0]*vel[0] + loads[1]*vel[1] + loads[2]*vel[2] + loads[3]*rates[0] + loads[4]*rates[1] + loads[5]*rates[2]

func _cross(a: PackedFloat64Array, b: PackedFloat64Array) -> PackedFloat64Array:
	return PackedFloat64Array([a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]])

func _vec_add(a: PackedFloat64Array, b: PackedFloat64Array) -> PackedFloat64Array:
	return PackedFloat64Array([a[0]+b[0], a[1]+b[1], a[2]+b[2]])

func _case(id: String, model: Dictionary, label: String, alpha_deg: float, beta_deg: float, speed: float, rates_in: Array) -> void:
	var alpha := deg_to_rad(alpha_deg)
	var beta := deg_to_rad(beta_deg)
	var vel := PackedFloat64Array([speed*cos(beta)*cos(alpha), speed*sin(beta), speed*cos(beta)*sin(alpha)])
	var rates := PackedFloat64Array([rates_in[0], rates_in[1], rates_in[2]])
	var state := RB.make_state(M.v3(0.0, 0.0, -20.0), vel, M.q_identity(), rates)
	var air: Dictionary = Air.compute(state, M.v3(0.0, 0.0, 0.0), Air.RHO_SEA_LEVEL)
	var d := Aero.deflections_from_surfaces(Commands.surface_deflections_deg(Commands.neutral_commands()))
	var total: PackedFloat64Array = Aero.loads(state, air, d, model, Air.RHO_SEA_LEVEL)
	var no_body_model: Dictionary = model.duplicate(true)
	no_body_model.surfaces.erase("body_cy_beta")
	no_body_model.surfaces.erase("body_crossflow_area")
	var no_body: PackedFloat64Array = Aero.loads(state, air, d, no_body_model, Air.RHO_SEA_LEVEL)
	var body := PackedFloat64Array()
	for i in 6:
		body.append(total[i]-no_body[i])
	var arp: PackedFloat64Array = model.reference.arp_le
	var cg: PackedFloat64Array = model.cg_le
	var arm := PackedFloat64Array([-(arp[0]-cg[0]), arp[1]-cg[1], -(arp[2]-cg[2])])
	var local_velocity := _vec_add(vel, _cross(rates, arm))
	var area := float(model.surfaces.get("body_crossflow_area", 0.0))
	var cyb := float(model.surfaces.get("body_cy_beta", 0.0))
	var expected_local_fy := 0.5*Air.RHO_SEA_LEVEL*(float(model.reference.S)*cyb*local_velocity[0]*local_velocity[1] - area*sqrt(local_velocity[1]*local_velocity[1]+local_velocity[2]*local_velocity[2])*local_velocity[1])
	var expected_local_mx := -arm[2]*expected_local_fy
	var expected_local_mz := arm[0]*expected_local_fy
	var expected_local_power := expected_local_fy*local_velocity[1]
	var result := {
		"aircraft": id, "case": label, "alpha_deg": alpha_deg, "beta_deg": beta_deg,
		"speed_mps": speed, "rates_rad_s": rates, "blend": Aero.local_flow_weight(state, air, d, model),
		"velocity_cg_mps": vel, "velocity_at_arp_mps": local_velocity, "arp_arm_body_m": arm,
		"total_F_N": total.slice(0, 3), "total_M_Nm": total.slice(3, 6),
		"body_side_F_N": body.slice(0, 3), "body_side_M_Nm": body.slice(3, 6),
		"total_power_Fv_plus_Momega_W": _power(total, vel, rates),
		"body_side_power_Fv_plus_Momega_W": _power(body, vel, rates),
		"local_velocity_formula_Fy_N": expected_local_fy,
		"local_velocity_formula_Mx_Nm": expected_local_mx,
		"local_velocity_formula_Mz_Nm": expected_local_mz,
		"local_velocity_formula_power_W": expected_local_power
	}
	print(JSON.stringify(result))

func _initialize() -> void:
	for id in ["gp_extra_300s_60", "f4u_corsair_250"]:
		var loaded: Dictionary = AD.load_file("res://data/aircraft/%s.json" % id)
		if not loaded.get("ok", false):
			printerr("MODEL_LOAD_FAIL %s %s" % [id, loaded])
			quit(2)
			return
		var model: Dictionary = loaded.model
		_case(id, model, "forward_beta5", 0.0, 5.0, 20.0, [0.0, 0.0, 0.0])
		_case(id, model, "reverse_alpha179_beta5", 179.0, 5.0, 20.0, [0.0, 0.0, 0.0])
		_case(id, model, "reverse_alpha179_beta5_yaw_rate_0p5", 179.0, 5.0, 20.0, [0.0, 0.0, 0.5])
		_case(id, model, "zero_translation_yaw_rate_10", 0.0, 0.0, 0.0, [0.0, 0.0, 10.0])
	quit(0)
