extends SceneTree
const Flight := preload("res://sim/flight_session.gd")
const Catalog := preload("res://app_state/aircraft_catalog.gd")
const Glow := preload("res://physics/glow/flight.gd")
const RB := preload("res://physics/rigid_body.gd")
const M := preload("res://physics/math3d.gd")

func _initialize() -> void:
    var f = Flight.new()
    f.setup(Catalog.entry("gp-extra-300s-60").data)
    f.input_enabled = false
    var g = f.trim_at(20.0, "glide")
    print("GLIDE_TRIM ", g)
    if g.get("ok", false):
        f.start = g
        f.reset()
    print("START mode=", f.start.get("mode", ""), " rpm=", f.start.get("rpm", -1), " running=", f.engine_running)
    print("CONT ", f.sim.continuous)
    print("AUX ", f.sim.aux)
    var s: PackedFloat64Array = f.start.state.duplicate()
    var speed := 20.0
    var alpha := deg_to_rad(179.0)
    var beta := deg_to_rad(5.0)
    s[RB.VEL] = speed * cos(alpha) * cos(beta)
    s[RB.VEL + 1] = speed * sin(beta)
    s[RB.VEL + 2] = speed * sin(alpha) * cos(beta)
    s[RB.ATT] = 1.0
    s[RB.ATT + 1] = 0.0
    s[RB.ATT + 2] = 0.0
    s[RB.ATT + 3] = 0.0
    f.engine_running = false
    var v: PackedFloat64Array = f.sim.continuous.duplicate()
    v[0] = 0.0
    v[7] = 0.0
    f.sim.continuous = v
    if f.sim.aux.size() > 0: f.sim.aux[0] = 0.0
    print("BODY ", s)
    print("VALUES ", v)
    print("POINT ", Glow.point(f,s,v,0.0,true))
    var point = Glow.point(f,s,v,0.0,true)
    var mass = Glow.properties(f,v[1],v[Glow.LINE_FUEL_INDEX])
    var airframe = Glow._airframe(f,s,v,point.air,point.hub_air_velocity_body_m_s,maxf(0.0,v[0]),point.propeller,point.environment.rho_kgm3)
    var coupling = Glow._stage_coupling(f,s,v,f.aircraft.model.propulsion.glow,point.state,point.source,point.propeller,airframe,mass,point.environment)
    print("MASS ",mass)
    print("AIRFRAME ",airframe)
    var install: Dictionary = f.aircraft.model.propulsion.glow
    var prop: Dictionary = f.aircraft.model.propulsion
    var coast = Glow.Source.evaluate(install.profile,0.001,Glow.admission_at(install,point.state.air_fraction,0.001),v[12],1.225*point.environment.engine_charge_ratio,false)
    var force: PackedFloat64Array = airframe.external.slice(0,3)
    var torque: PackedFloat64Array = M.sub(airframe.external.slice(3,6),M.cross(mass.cg_body_m,force))
    var omega_body: PackedFloat64Array = s.slice(RB.RATE,RB.RATE+3)
    var alpha_stopped: PackedFloat64Array = RB.inertia_mul(mass.inverse,M.sub(torque,M.cross(omega_body,RB.inertia_mul(mass.inertia,omega_body))))
    var demand: float = -point.propeller.torque_nm-float(prop.rotor_inertia)*M.dot(prop.axis,alpha_stopped)
    var friction: float = -coast.shaft_torque_nm
    print("COAST ",coast)
    print("STOPPED_BREAKAWAY demand=",demand," friction=",friction," propQ=",point.propeller.torque_nm," alpha_x=",M.dot(prop.axis,alpha_stopped)," axial=",M.dot(point.hub_air_velocity_body_m_s,prop.axis))
    print("COUPLING ",coupling)
    print("EVAL ", Glow.evaluate(s,v,0.0,f))
    print("PREPARE_RESET ", f.sim.prepare_reset(s))
    var verified: bool = point.get("ok", false) and not coupling.get("ok", true) and demand < -friction
    f.free()
    print("REVERSE_SHAFT_GUARD_CONFIRMED=", verified)
    quit(0 if verified else 1)





