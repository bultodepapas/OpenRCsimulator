from __future__ import annotations
import difflib
import hashlib
import json
import pathlib
import shutil

root = pathlib.Path(r"C:\DEVELOPMENT\OpenRCsimulator")
audit = root / "tmp/reverse-flow-audit-2026-10-23/bug-hunter/long-tail"
evidence = audit / "evidence"
source_root = root / "tmp/reverse-flow-audit-2026-10-23"
flight_script = source_root / "flight/record_tail_refinement.gd"

def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, found {count}")
    return source.replace(old, new, 1)

identity: dict[str, dict[str, str]] = {}
for variant in ("baseline", "candidate"):
    source = source_root / f"{variant}-app/app"
    dest = audit / variant / "app"
    relevant = {
        "aero": source / "physics/aero.gd",
        "glow": source / "physics/glow/flight.gd",
        "simulation": source / "sim/simulation.gd",
        "flight_session": source / "sim/flight_session.gd",
    }
    identity[variant] = {key: sha(path) for key, path in relevant.items()}

    glow_path = dest / "physics/glow/flight.gd"
    glow = glow_path.read_text(encoding="utf-8")
    helper = (
        "static func _long_tail_audit(tag: String, body: PackedFloat64Array, values: PackedFloat64Array,\n"
        "\t\tstage_time: float, details: Dictionary = {}) -> void:\n"
        "\tvar row: Dictionary = {tag = tag, stage_time_s = stage_time, body = Array(body),\n"
        "\t\tcontinuous = Array(values), details = details}\n"
        "\tprinterr(\"LONG_TAIL_GLOW \" + JSON.stringify(row, \"\", true, true))\n\n\n"
    )
    anchor = "## NITRO-06: the charge per cycle the carburettor admits at this barrel opening and speed, relative to wide open.\n"
    glow = replace_once(glow, anchor, helper + anchor, "audit helper anchor")

    old_sig = (
        "static func _stage_coupling(owner: Node, body: PackedFloat64Array, values: PackedFloat64Array,\n"
        "\t\tinstall: Dictionary, state: Dictionary, source: Dictionary, load: Dictionary,\n"
        "\t\tairframe: Dictionary, mass: Dictionary, ambient: Dictionary) -> Dictionary:"
    )
    new_sig = old_sig.replace("ambient: Dictionary)", "ambient: Dictionary, stage_time: float = NAN)")
    glow = replace_once(glow, old_sig, new_sig, "coupling signature")

    old_guard = (
        "\t\telif demand < -friction:\n"
        "\t\t\treturn {ok=false} # Reverse rotation exceeds static hold and is outside this installation's domain."
    )
    new_guard = (
        "\t\telif demand < -friction:\n"
        "\t\t\t_long_tail_audit(\"stopped_shaft_reverse_breakaway\", body, values, stage_time, {\n"
        "\t\t\t\t\"demand_nm\": demand, \"friction_limit_nm\": friction, \"load_torque_nm\": load_torque,\n"
        "\t\t\t\t\"prop_rotor_inertia_kgm2\": float(prop.rotor_inertia), \"alpha_stopped_rad_s2\": Array(alpha_stopped),\n"
        "\t\t\t\t\"external_loads\": Array(external), \"torque_about_cm_nm\": Array(torque),\n"
        "\t\t\t\t\"body_rates_rad_s\": Array(w), \"coast_shaft_torque_nm\": float(coast.shaft_torque_nm)})\n"
        "\t\t\treturn {ok=false} # Reverse rotation exceeds static hold and is outside this installation's domain."
    )
    glow = replace_once(glow, old_guard, new_guard, "stopped-shaft guard")

    old_coast = "\t\tif not coast.get(\"ok\",false): return {ok=false}"
    new_coast = (
        "\t\tif not coast.get(\"ok\",false):\n"
        "\t\t\t_long_tail_audit(\"stopped_shaft_coast_invalid\", body, values, stage_time, {\n"
        "\t\t\t\t\"load_torque_nm\": load_torque, \"coast_keys\": Array(coast.keys())})\n"
        "\t\t\treturn {ok=false}"
    )
    glow = replace_once(glow, old_coast, new_coast, "coast failure")

    old_response = "\tif not response.get(\"ok\",false): return {ok=false}"
    new_response = (
        "\tif not response.get(\"ok\",false):\n"
        "\t\t_long_tail_audit(\"rotor_response_invalid\", body, values, stage_time, {\n"
        "\t\t\t\"response_keys\": Array(response.keys()), \"rpm\": rpm, \"drive_nm\": drive, \"load_torque_nm\": load_torque})\n"
        "\t\treturn {ok=false}"
    )
    glow = replace_once(glow, old_response, new_response, "rotor response failure")

    old_bd = "\tif body_derivative.size()!=RB.SIZE: return {ok=false}"
    new_bd = (
        "\tif body_derivative.size()!=RB.SIZE:\n"
        "\t\t_long_tail_audit(\"body_derivative_malformed\", body, values, stage_time, {\n"
        "\t\t\t\"body_derivative_size\": body_derivative.size(), \"expected_size\": RB.SIZE})\n"
        "\t\treturn {ok=false}"
    )
    glow = replace_once(glow, old_bd, new_bd, "body derivative size")

    for old, new, label in [
        ("base_evaluation.source,load,airframe,feed_mass,ambient)", "base_evaluation.source,load,airframe,feed_mass,ambient,time_s)", "base coupling time"),
        ("candidate_evaluation.source,load,airframe,feed_mass,ambient)", "candidate_evaluation.source,load,airframe,feed_mass,ambient,time_s)", "candidate coupling time"),
        ("evaluation.source,load,airframe,feed_mass,ambient)", "evaluation.source,load,airframe,feed_mass,ambient,time_s)", "pickup coupling time"),
        ("result.state,result.source,result.propeller,airframe,mass,result.environment)", "result.state,result.source,result.propeller,airframe,mass,result.environment,time_s)", "evaluate coupling time"),
    ]:
        glow = replace_once(glow, old, new, label)

    # Top-level GlowFlight.evaluate rejection tags. The exact RK body/continuous state is printed by Simulation.
    for old, new, label in [
        ("\tif not result.ok: return {}", "\tif not result.ok:\n\t\t_long_tail_audit(\"evaluate_point_rejected\", body, values, time_s, {\"point_keys\": Array(result.keys())})\n\t\treturn {}", "point result"),
        ("\tif not mass.ok: return {}", "\tif not mass.ok:\n\t\t_long_tail_audit(\"evaluate_mass_rejected\", body, values, time_s, {\"mass_keys\": Array(mass.keys())})\n\t\treturn {}", "mass result"),
        ("\tif airframe.is_empty(): return {}", "\tif airframe.is_empty():\n\t\t_long_tail_audit(\"evaluate_airframe_rejected\", body, values, time_s, {})\n\t\treturn {}", "airframe result"),
        ("\tif not coupling.get(\"ok\",false): return {}", "\tif not coupling.get(\"ok\",false):\n\t\t_long_tail_audit(\"evaluate_coupling_rejected\", body, values, time_s, {\"coupling_keys\": Array(coupling.keys()), \"load_torque_nm\": float(result.propeller.torque_nm)})\n\t\treturn {}", "coupling result"),
    ]:
        glow = replace_once(glow, old, new, label)
    glow_path.write_text(glow, encoding="utf-8")

    sim_path = dest / "sim/simulation.gd"
    sim = sim_path.read_text(encoding="utf-8")
    old_counter = (
        "\tvar f := func(s: PackedFloat64Array, stage_t: float) -> PackedFloat64Array:\n"
        "\t\tif not stage_error.message.is_empty():"
    )
    new_counter = (
        "\tvar audit_rk_eval := [0]\n"
        "\tvar f := func(s: PackedFloat64Array, stage_t: float) -> PackedFloat64Array:\n"
        "\t\taudit_rk_eval[0] += 1\n"
        "\t\tif not stage_error.message.is_empty():"
    )
    sim = replace_once(sim, old_counter, new_counter, "RK stage counter")
    old_bad = (
        "\t\t\tif not _joint_stage_is_valid(candidate):\n"
        "\t\t\t\tstage_error.message = \"RK joint stage evaluation is nonfinite or malformed\""
    )
    new_bad = (
        "\t\t\tif not _joint_stage_is_valid(candidate):\n"
        "\t\t\t\tvar audit_row: Dictionary = {tick = tick, rk_stage_eval = audit_rk_eval[0],\n"
        "\t\t\t\t\tstep_start_s = t, stage_time_s = stage_t, body = Array(s.slice(0, RB.SIZE)),\n"
        "\t\t\t\t\tcontinuous = Array(s.slice(RB.SIZE)), result_type = type_string(typeof(candidate))}\n"
        "\t\t\t\tif candidate is Dictionary:\n"
        "\t\t\t\t\taudit_row.result_keys = Array(candidate.keys())\n"
        "\t\t\t\t\tfor field: String in [\"loads\", \"derivative\", \"rotor_momentum\", \"body_derivative\"]:\n"
        "\t\t\t\t\t\tvar field_value: Variant = candidate.get(field, null)\n"
        "\t\t\t\t\t\tif field_value is PackedFloat64Array:\n"
        "\t\t\t\t\t\t\taudit_row[field] = Array(field_value)\n"
        "\t\t\t\t\t\telif field_value != null:\n"
        "\t\t\t\t\t\t\taudit_row[field] = str(field_value)\n"
        "\t\t\t\tprinterr(\"LONG_TAIL_RK_REJECT \" + JSON.stringify(audit_row, \"\", true, true))\n"
        "\t\t\t\tstage_error.message = \"RK joint stage evaluation is nonfinite or malformed\""
    )
    sim = replace_once(sim, old_bad, new_bad, "RK joint failure capture")

    # Make joint-result rejection identify the failing field without changing the acceptance predicate.
    old_shape = (
        "\tif not candidate is Dictionary or not candidate.has_all([\"loads\", \"derivative\", \"rotor_momentum\"]):\n"
        "\t\treturn false"
    )
    new_shape = (
        "\tif not candidate is Dictionary or not candidate.has_all([\"loads\", \"derivative\", \"rotor_momentum\"]):\n"
        "\t\tvar audit_keys: Array = Array(candidate.keys()) if candidate is Dictionary else []\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE shape type=\", type_string(typeof(candidate)), \" keys=\", audit_keys)\n"
        "\t\treturn false"
    )
    sim = replace_once(sim, old_shape, new_shape, "joint shape validation")
    old_size = "\tif candidate.size() != expected_size:\n\t\treturn false"
    new_size = (
        "\tif candidate.size() != expected_size:\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE key_count expected=\", expected_size, \" actual=\", candidate.size(), \" keys=\", Array(candidate.keys()))\n"
        "\t\treturn false"
    )
    sim = replace_once(sim, old_size, new_size, "joint key count validation")
    old_body = "\tif candidate.has(\"body_derivative\") and not _array_is_finite(candidate.body_derivative, RB.SIZE):\n\t\treturn false"
    new_body = (
        "\tif candidate.has(\"body_derivative\") and not _array_is_finite(candidate.body_derivative, RB.SIZE):\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE field=body_derivative size=\", candidate.body_derivative.size(), \" values=\", Array(candidate.body_derivative))\n"
        "\t\treturn false"
    )
    sim = replace_once(sim, old_body, new_body, "joint body derivative validation")
    old_context = "\tif candidate.has(\"stage_context\") and typeof(candidate.stage_context) != TYPE_DICTIONARY:\n\t\treturn false"
    new_context = (
        "\tif candidate.has(\"stage_context\") and typeof(candidate.stage_context) != TYPE_DICTIONARY:\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE field=stage_context type=\", type_string(typeof(candidate.stage_context)))\n"
        "\t\treturn false"
    )
    sim = replace_once(sim, old_context, new_context, "joint stage context validation")
    old_final = (
        "\treturn _loads_are_valid(candidate.loads) and _array_is_finite(candidate.derivative, continuous.size()) \\\n"
        "\t\tand _array_is_finite(candidate.rotor_momentum, 3)"
    )
    new_final = (
        "\tif not _loads_are_valid(candidate.loads):\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE field=loads size=\", candidate.loads.size(), \" values=\", Array(candidate.loads))\n"
        "\t\treturn false\n"
        "\tif not _array_is_finite(candidate.derivative, continuous.size()):\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE field=derivative size=\", candidate.derivative.size(), \" values=\", Array(candidate.derivative))\n"
        "\t\treturn false\n"
        "\tif not _array_is_finite(candidate.rotor_momentum, 3):\n"
        "\t\tprinterr(\"LONG_TAIL_VALIDATE field=rotor_momentum size=\", candidate.rotor_momentum.size(), \" values=\", Array(candidate.rotor_momentum))\n"
        "\t\treturn false\n"
        "\treturn true"
    )
    sim = replace_once(sim, old_final, new_final, "joint field validation")
    sim_path.write_text(sim, encoding="utf-8")

    # Run the prior direct scenario unchanged except to retain the last committed full state on failure.
    direct = dest / "long_tail_direct.gd"
    shutil.copy2(flight_script, direct)
    run = direct.read_text(encoding="utf-8")
    old_final_report = "\trow.final_tick = session.sim.tick\n\trow.final_fault_reason = session.sim.fault_reason"
    new_final_report = (
        "\trow.final_tick = session.sim.tick\n"
        "\trow.final_state = Array(session.sim.state)\n"
        "\trow.final_continuous = Array(session.sim.continuous)\n"
        "\trow.final_aux = Array(session.sim.aux)\n"
        "\trow.final_inputs = Array(session.sim.inputs)\n"
        "\trow.final_last_loads = Array(session.sim.last_loads)\n"
        "\trow.final_fault_reason = session.sim.fault_reason"
    )
    run = replace_once(run, old_final_report, new_final_report, "direct final-state output")
    direct.write_text(run, encoding="utf-8")

    (dest / "longtail_source_identity.json").write_text(json.dumps(identity[variant], indent=2), encoding="utf-8")

(audit / "evidence/source-identities.json").write_text(json.dumps(identity, indent=2), encoding="utf-8")
baseline_aero = (source_root / "baseline-app/app/physics/aero.gd").read_text(encoding="utf-8").splitlines(True)
candidate_aero = (source_root / "candidate-app/app/physics/aero.gd").read_text(encoding="utf-8").splitlines(True)
(audit / "evidence/source-variant.diff").write_text(
    "".join(difflib.unified_diff(baseline_aero, candidate_aero, fromfile="baseline/aero.gd", tofile="candidate/aero.gd")),
    encoding="utf-8")
print(json.dumps(identity, indent=2))
