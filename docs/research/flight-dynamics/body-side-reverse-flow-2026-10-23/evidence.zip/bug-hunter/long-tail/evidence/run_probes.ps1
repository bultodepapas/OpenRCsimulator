$ErrorActionPreference = 'Stop'
$repo = 'C:\DEVELOPMENT\OpenRCsimulator'
$audit = Join-Path $repo 'tmp\reverse-flow-audit-2026-10-23\bug-hunter\long-tail'
$runner = Join-Path $repo 'tools\godot\run_checked.py'
$godot = Join-Path $repo '.tools\Godot_v4.7.2-stable_win64_console.exe'
if (-not (Test-Path -LiteralPath $runner)) { throw "Checked runner not found at $runner" }
if (-not (Test-Path -LiteralPath $godot)) { throw "Godot console executable not found at $godot" }
foreach ($variant in @('baseline', 'candidate')) {
    $project = Join-Path $audit ($variant + '\app')
    $out = Join-Path $audit ('evidence\matched-' + $variant)
    $checkedOut = Join-Path $out 'checked'
    New-Item -ItemType Directory -Force -Path $checkedOut | Out-Null
    $label = 'long-tail-' + $variant + '-matched'
    $godotArgs = @('--headless', '--path', $project, '--script', 'res://long_tail_direct.gd', '--',
        '--out=' + $out, '--rates=240', '--duration=2', '--suffix=matched')
    & python $runner --out-dir $checkedOut --label $label --timeout 180 -- @godotArgs
    $code = $LASTEXITCODE
    if ($code -notin @(0, 1)) { throw "Unexpected checked-runner exit code $code for $variant; inspect $checkedOut" }
}
