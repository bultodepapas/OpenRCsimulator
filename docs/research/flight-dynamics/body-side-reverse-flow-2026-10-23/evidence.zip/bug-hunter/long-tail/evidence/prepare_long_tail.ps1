$ErrorActionPreference = 'Stop'
$repo = 'C:\DEVELOPMENT\OpenRCsimulator'
$audit = Join-Path $repo 'tmp\reverse-flow-audit-2026-10-23\bug-hunter\long-tail'
$variants = @(
    @{ Name = 'baseline'; Source = (Join-Path $repo 'tmp\reverse-flow-audit-2026-10-23\baseline-app\app') },
    @{ Name = 'candidate'; Source = (Join-Path $repo 'tmp\reverse-flow-audit-2026-10-23\candidate-app\app') }
)
foreach ($variant in $variants) {
    $project = Join-Path $audit ($variant.Name + '\app')
    New-Item -ItemType Directory -Force -Path $project | Out-Null
    Copy-Item -LiteralPath (Join-Path $variant.Source 'project.godot') -Destination $project
    Get-ChildItem -LiteralPath $variant.Source -File -Force | ForEach-Object {
        if ($_.Name -ne 'project.godot') { Copy-Item -LiteralPath $_.FullName -Destination $project }
    }
    foreach ($dir in Get-ChildItem -LiteralPath $variant.Source -Directory -Force) {
        if ($dir.Name -in @('.godot', '.tools', 'tmp', 'physics', 'sim')) { continue }
        $link = Join-Path $project $dir.Name
        New-Item -ItemType Junction -Path $link -Target $dir.FullName | Out-Null
    }
    Copy-Item -LiteralPath (Join-Path $variant.Source 'physics') -Destination $project -Recurse
    Copy-Item -LiteralPath (Join-Path $variant.Source 'sim') -Destination $project -Recurse
    New-Item -ItemType Directory -Force -Path (Join-Path $audit ($variant.Name + '\output')) | Out-Null
}
