from pathlib import Path
import difflib
root = Path(r"C:\DEVELOPMENT\OpenRCsimulator")
audit = root / "tmp/reverse-flow-audit-2026-10-23/bug-hunter/long-tail"
evidence = audit / "evidence"
source_root = root / "tmp/reverse-flow-audit-2026-10-23"
for variant in ("baseline", "candidate"):
    src = source_root / f"{variant}-app/app"
    inst = audit / variant / "app"
    out = []
    for rel in ("physics/glow/flight.gd", "sim/simulation.gd", "long_tail_direct.gd"):
        original = (src / rel).read_text(encoding="utf-8") if rel != "long_tail_direct.gd" else             (source_root / "flight/record_tail_refinement.gd").read_text(encoding="utf-8")
        changed = (inst / rel).read_text(encoding="utf-8")
        out.extend(difflib.unified_diff(original.splitlines(True), changed.splitlines(True),
            fromfile=f"{variant}-source/{rel}", tofile=f"{variant}-instrumented/{rel}"))
    (evidence / f"{variant}-instrumentation.patch").write_text("".join(out), encoding="utf-8")
