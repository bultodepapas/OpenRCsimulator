"""Build the bounded matched baseline/candidate diagnostic summary."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[5]
EVIDENCE = ROOT / "tmp/reverse-flow-audit-2026-10-23/bug-hunter/long-tail/evidence"
SOURCE = ROOT / "tmp/reverse-flow-audit-2026-10-23"
COMMAND_COLUMNS = (
    "cmd_roll", "cmd_pitch", "cmd_yaw", "cmd_throttle",
    "raw_roll", "raw_pitch", "raw_yaw", "raw_throttle",
    "input_0", "input_1", "input_2", "input_3",
)
INITIAL_FIELDS = (
    "initial_state", "initial_aux", "initial_continuous", "initial_modes",
    "initial_inputs", "initial_commands", "initial_raw", "initial_last_loads",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_variant(name: str) -> tuple[dict, list[dict[str, str]], dict]:
    folder = EVIDENCE / f"matched-{name}"
    report = json.loads((folder / "refinement-results.json").read_text(encoding="utf-8"))["results"][0]
    with (folder / "extra-tail-u0-240-matched-metrics.csv").open(encoding="utf-8", newline="") as stream:
        metrics = list(csv.DictReader(stream))
    checked_path = next((folder / "checked").glob("*/report.json"))
    checked = json.loads(checked_path.read_text(encoding="utf-8"))
    engine_log = next((folder / "checked").glob("*/engine.log")).read_text(encoding="utf-8", errors="replace")
    glow = next(
        json.loads(line.removeprefix("LONG_TAIL_GLOW "))
        for line in engine_log.splitlines()
        if line.startswith("LONG_TAIL_GLOW ") and '"tag":"stopped_shaft_reverse_breakaway"' in line
    )
    rk = next(
        json.loads(line.removeprefix("LONG_TAIL_RK_REJECT "))
        for line in engine_log.splitlines()
        if line.startswith("LONG_TAIL_RK_REJECT ")
    )
    source_aero = SOURCE / f"{name}-app/app/physics/aero.gd"
    return report, metrics, {
        "aero_sha256": sha256(source_aero),
        "instrumented_solver_sha256": report["solver_sha256"],
        "final_tick": report["final_tick"],
        "fault_reason": report["final_fault_reason"],
        "initial": {field: report[field] for field in INITIAL_FIELDS},
        "initial_aux_13": report["initial_aux"][13],
        "accepted_metric_rows": len(metrics),
        "fault": {
            "tag": glow["tag"],
            "tick": rk["tick"],
            "step_start_s": rk["step_start_s"],
            "rk_stage_eval": rk["rk_stage_eval"],
            "stage_time_s": rk["stage_time_s"],
            "body_stage": glow["body"],
            "continuous_stage": glow["continuous"],
            "demand_nm": glow["details"]["demand_nm"],
            "friction_limit_nm": glow["details"]["friction_limit_nm"],
            "excess_over_limit_nm": abs(glow["details"]["demand_nm"]) - glow["details"]["friction_limit_nm"],
            "fraction_over_limit": abs(glow["details"]["demand_nm"]) / glow["details"]["friction_limit_nm"] - 1.0,
            "load_torque_nm": glow["details"]["load_torque_nm"],
            "prop_rotor_inertia_kgm2": glow["details"]["prop_rotor_inertia_kgm2"],
            "alpha_stopped_rad_s2": glow["details"]["alpha_stopped_rad_s2"],
            "coast_shaft_torque_nm": glow["details"]["coast_shaft_torque_nm"],
            "empty_stage_return": rk["result_type"] == "Dictionary" and not rk["result_keys"],
        },
        "checked_runner": {
            "process_exit": checked["process_exit"],
            "complete": checked["complete"],
            "reason": checked["reason"],
            "errors": checked["counts"]["error"],
            "warnings": checked["counts"]["warning"],
            "parse_error_lines": sum(
                1 for line in engine_log.splitlines()
                if "Parse Error" in line or "SCRIPT ERROR" in line or line.startswith("ERROR:")
            ),
        },
    }


baseline_report, baseline_rows, baseline = load_variant("baseline")
candidate_report, candidate_rows, candidate = load_variant("candidate")
initial_equal = {
    field: baseline["initial"][field] == candidate["initial"][field]
    for field in INITIAL_FIELDS
}
commands_equal = len(baseline_rows) == len(candidate_rows) and all(
    all(left[column] == right[column] for column in COMMAND_COLUMNS)
    for left, right in zip(baseline_rows, candidate_rows, strict=True)
)
first_divergence = {}
for column in ("body_u_end_mps", "body_v_end_mps", "body_w_end_mps"):
    first = next(
        (index for index, (left, right) in enumerate(zip(baseline_rows, candidate_rows, strict=True))
         if left[column] != right[column]),
        None,
    )
    first_divergence[column] = None if first is None else {
        "interval_tick": int(baseline_rows[first]["interval_tick"]),
        "endpoint_tick": int(baseline_rows[first]["endpoint_tick"]),
    }

result = {
    "format": "openrc-matched-long-tail-diagnostic v1",
    "scenario": {
        "aircraft": "Extra 300s 60",
        "rate_hz": 240,
        "duration_s": 2.0,
        "start_altitude_m": 300.0,
        "initial_body_velocity_mps": [4.0, 0.35, 0.0],
        "initial_pitch_deg": 82.0,
        "engine_mode": "glide; stopped shaft; neutral raw controls",
    },
    "baseline": baseline,
    "candidate": candidate,
    "pair": {
        "initial_fields_equal": initial_equal,
        "initial_snapshot_equal": all(initial_equal.values()),
        "initial_aux_13_downwash_mps": baseline["initial_aux_13"],
        "initial_commands_equal": baseline["initial"]["initial_commands"] == candidate["initial"]["initial_commands"],
        "accepted_command_and_input_rows_equal": commands_equal,
        "accepted_row_count": min(len(baseline_rows), len(candidate_rows)),
        "first_state_divergence": first_divergence,
        "baseline_and_candidate_both_stop_at_tick_255": baseline["final_tick"] == candidate["final_tick"] == 255,
        "legacy_tick_260_run_is_excluded": "Legacy baseline run had different downwash aux[13], so it is not a matched before/after pair.",
    },
}
(EVIDENCE / "matched_comparison.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
print(EVIDENCE / "matched_comparison.json")
