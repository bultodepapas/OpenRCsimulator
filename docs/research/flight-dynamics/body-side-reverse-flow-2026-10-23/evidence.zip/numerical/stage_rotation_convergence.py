import math

def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]

def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

def qmul(a, b):
    w,x,y,z=a; e,i,j,k=b
    return [w*e-x*i-y*j-z*k, w*i+x*e+y*k-z*j, w*j-x*k+y*e+z*i, w*k+x*j-y*i+z*e]

def qrotate_source(q, v, normalize=False):
    if normalize:
        n=math.sqrt(sum(x*x for x in q))
        q=[x/n for x in q]
    u=q[1:]
    t=[2*x for x in cross(u,v)]
    ut=cross(u,t)
    return [v[i]+q[0]*t[i]+ut[i] for i in range(3)]

def qnorm(q):
    n=math.sqrt(sum(x*x for x in q))
    return [x/n for x in q]

def derivative(s, stage_normalize_rotation):
    pos=s[0:3]; v=s[3:6]; q=s[6:10]; w=s[10:13]
    pd=qrotate_source(q,v,stage_normalize_rotation)
    vd=[-x for x in cross(w,v)]
    qd=[0.5*x for x in qmul(q,[0.0,*w])]
    return pd+vd+qd+[0.0,0.0,0.0]

def axpy(a,k,b):
    return [x+k*y for x,y in zip(a,b)]

def rk4_step(s,dt,stage_normalize_rotation):
    f=lambda x: derivative(x,stage_normalize_rotation)
    k1=f(s); k2=f(axpy(s,dt/2,k1)); k3=f(axpy(s,dt/2,k2)); k4=f(axpy(s,dt,k3))
    out=[x+dt/6*(a+2*b+2*c+d) for x,a,b,c,d in zip(s,k1,k2,k3,k4)]
    out[6:10]=qnorm(out[6:10])
    return out

def integrate(n,stage_normalize_rotation):
    s=[0.0,0.0,0.0, 1.0,0.0,0.0, 1.0,0.0,0.0,0.0, 0.0,0.0,2.0]
    for _ in range(n): s=rk4_step(s,1.0/n,stage_normalize_rotation)
    q_exact=[math.cos(1.0),0.0,0.0,math.sin(1.0)]
    v_exact=[math.cos(2.0),-math.sin(2.0),0.0]
    errors=[math.sqrt(sum((s[i]-v)**2 for i,v in enumerate([1.0,0.0,0.0]))),
            math.sqrt(sum((s[3+i]-v_exact[i])**2 for i in range(3))),
            math.sqrt(sum((s[6+i]-q_exact[i])**2 for i in range(4)))]
    return errors

print('free rigid body: isotropic inertia, omega=(0,0,2), v_body(0)=(1,0,0), q(0)=identity; T=1')
for normalize in (False,True):
    label='source stage rotations' if not normalize else 'unit-normalized stage rotations (control)'
    print(label)
    prev=None
    for n in (10,20,40,80,160,320):
        e=integrate(n,normalize)
        ratio=(prev[0]/e[0]) if prev else float('nan')
        print(f'N={n:3d} position_error={e[0]:.9e} ratio={ratio:.5f} velocity_error={e[1]:.3e} attitude_error={e[2]:.3e}')
        prev=e

# Force/moment power identity: a strip force and moment r x F at CG.
r=[-0.23,0.41,0.08]; v=[12.0,-1.5,2.0]; w=[0.3,-0.5,0.8]; f=[-4.0,0.0,-7.0]
m=cross(r,f); vp=[v[i]+cross(w,r)[i] for i in range(3)]
left=dot(f,v)+dot(m,w); right=dot(f,vp)
print(f'power identity residual={left-right:.17e}; left={left:.17g}; right={right:.17g}')

# Flat-plate continuation used after separation: check local wing force through u=0.
def plate_force(u,w,rho=1.225,area=0.03,cd0=0.03,cd90=1.8):
    speed=math.hypot(u,w)
    if speed==0.0: return (0.0,0.0)
    alpha=math.atan2(w,u)
    cl=0.5*cd90*math.sin(2*alpha)
    cd=cd0+cd90*(math.sin(alpha)**2)
    scale=-0.5*rho*speed*area*cd
    fx=u*scale; fz=w*scale
    lift=0.5*rho*speed*speed*area*cl
    fx+=lift*w/speed; fz-=lift*u/speed
    return fx,fz
print('u=0 crossing at w=+3 (N, per 0.03 m^2 section):')
for u in (-1e-3,-1e-6,0.0,1e-6,1e-3):
    print(f'u={u:+.1e} F=({plate_force(u,3.0)[0]:+.12e},{plate_force(u,3.0)[1]:+.12e})')
