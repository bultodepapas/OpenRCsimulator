import math

def cross(a,b): return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def qmul(a,b):
    w,x,y,z=a; e,i,j,k=b
    return [w*e-x*i-y*j-z*k,w*i+x*e+y*k-z*j,w*j-x*k+y*e+z*i,w*k+x*j-y*i+z*e]
def qr(q,v,norm=False):
    if norm:
        m=math.sqrt(sum(x*x for x in q)); q=[x/m for x in q]
    u=q[1:]; t=[2*x for x in cross(u,v)]; ut=cross(u,t)
    return [v[i]+q[0]*t[i]+ut[i] for i in range(3)]
def qnorm(q):
    m=math.sqrt(sum(x*x for x in q)); return [x/m for x in q]
def deriv(s,norm):
    v=s[3:6]; q=s[6:10]; w=s[10:13]
    qc=[q[0],-q[1],-q[2],-q[3]]
    gb=qr(qc,[0,0,9.81],norm)
    vd=[gb[i]-cross(w,v)[i] for i in range(3)]
    return qr(q,v,norm)+vd+[.5*x for x in qmul(q,[0,*w])]+[0,0,0]
def axpy(a,k,b): return [x+k*y for x,y in zip(a,b)]
def step(s,h,norm):
    f=lambda x:deriv(x,norm); k1=f(s);k2=f(axpy(s,h/2,k1));k3=f(axpy(s,h/2,k2));k4=f(axpy(s,h,k3))
    o=[x+h/6*(a+2*b+2*c+d) for x,a,b,c,d in zip(s,k1,k2,k3,k4)];o[6:10]=qnorm(o[6:10]);return o
def run(n,norm):
    s=[0,0,0,0,0,0,1,0,0,0,0,2,0]
    for _ in range(n):s=step(s,1/n,norm)
    q=[math.cos(1),0,math.sin(1),0];v=qr([q[0],-q[1],-q[2],-q[3]],[0,0,9.81])
    exactp=[0,0,4.905];exactv=[x for x in v]
    ep=math.sqrt(sum((s[i]-exactp[i])**2 for i in range(3)));ev=math.sqrt(sum((s[3+i]-exactv[i])**2 for i in range(3)))
    eq=math.sqrt(sum((s[6+i]-q[i])**2 for i in range(4)))
    return ep,ev,eq
print('gravity-only rigid body; omega=(0,2,0), g_NED=(0,0,9.81), T=1')
for norm in (False,True):
    print('stage rotations normalized' if norm else 'source stage rotations')
    prev=None
    for n in (10,20,40,80,160):
        e=run(n,norm); print(f'N={n} pos={e[0]:.9e} ratio={(prev[0]/e[0] if prev else float("nan")):.5f} vel={e[1]:.3e} q={e[2]:.3e}');prev=e
