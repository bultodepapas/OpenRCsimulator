"""Retain the bounded D10-R3-R1 experiment, never whole runtime copies."""
from pathlib import Path
import hashlib
import json
import os
import zipfile

repo = Path(__file__).resolve().parents[2]
scratch = Path(__file__).resolve().parent
out = repo / 'docs/research/flight-dynamics/body-side-reverse-flow-2026-10-23'
members = {}

def add(path, name):
    if name in members:
        raise ValueError(name)
    members[name] = path

def tree(path, prefix, excludes=()):
    for directory, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in excludes)
        for name in sorted(files):
            file = Path(directory) / name
            if file.suffix.lower() in {'.json', '.csv', '.orfl', '.log', '.txt', '.md', '.gd', '.py', '.ps1', '.patch', '.diff'}:
                add(file, prefix + '/' + file.relative_to(path).as_posix())

for name in ['baseline-identity.json', 'isolated-change.json', 'force-budget-comparison.json',
             'pre-existing.patch', 'implementation.patch', 'aero.before.gd', 'aero.candidate.gd',
             'test_body_side_force.before.gd', 'body_side_regression.gd', 'package_evidence.py']:
    add(scratch / name, name)

# Retain exact bytes for the solver fingerprint, dependencies and configurations.
baseline = scratch / 'baseline-app/app'
for folder in ['physics', 'sim', 'failures', 'input', 'data']:
    tree(baseline / folder, 'baseline-source/app/' + folder)
add(baseline / 'project.godot', 'baseline-source/app/project.godot')
add(scratch / 'candidate-app/app/physics/aero.gd', 'candidate-source/app/physics/aero.gd')
add(repo / 'app/tests/test_body_side_force.gd', 'current-test/test_body_side_force.gd')

for folder in ['regression', 'controls', 'numerical']:
    tree(scratch / folder, folder)
for folder in ['baseline-body-side-bx7bbvj0', 'candidate-parse-dybb2ibz',
               'force-budget-candidate-49vng29v', 'stopped-glow-domain-clean-f7_t1zj7']:
    tree(scratch / 'checks' / folder, 'checks/' + folder)
tree(scratch / 'expected-failures/reverse-regression-before-r2-8368_4qa',
     'expected-failures/reverse-regression-before-r2-8368_4qa')
for name in ['force_budget_probe.gd', 'glow_reverse_probe_clean.gd']:
    add(scratch / 'bug-hunter' / name, 'bug-hunter/' + name)
tree(scratch / 'bug-hunter/force-budget-probe-r1-6qqenox4',
     'bug-hunter/force-budget-probe-r1-6qqenox4')
tree(scratch / 'bug-hunter/long-tail/evidence', 'bug-hunter/long-tail/evidence')

for file in sorted((scratch / 'flight').iterdir()):
    if file.is_file() and file.suffix in {'.gd', '.py'}:
        add(file, 'flight/' + file.name)
for folder in ['baseline', 'baseline-v2', 'exact-v2', 'candidate-v2', 'refinement-v2',
               'candidate-long-v2', 'checked-v2', 'checked-refinement-v2', 'checked-refinement-v2b', 'checked-orfl-pair-v1']:
    tree(scratch / 'flight' / folder, 'flight/' + folder)

# The timing specialist must finish before this runs. Exclude all disposable engines/apps.
tree(scratch / 'performance', 'performance', excludes=('runtime', 'runtimes', 'runtime-copies', 'baseline-app',
     'candidate-app', '.godot', 'app', '__pycache__'))

manifest = {'format': 'openrc-evidence-manifest v1', 'step': 'D10-R3-R1',
            'member_paths_relative_to': 'evidence.zip root', 'files': []}
out.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(members.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        manifest['files'].append({'path': name, 'bytes': len(data),
                                  'sha256': hashlib.sha256(data).hexdigest()})
manifest['archive_sha256'] = hashlib.sha256((out / 'evidence.zip').read_bytes()).hexdigest()
manifest['archive_bytes'] = (out / 'evidence.zip').stat().st_size
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(out / 'evidence.zip') as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(manifest['files'])
    for item in manifest['files']:
        assert hashlib.sha256(archive.read(item['path'])).hexdigest() == item['sha256']
    sources = sorted(name for name in archive.namelist()
                     if name.startswith(('baseline-source/app/physics/', 'baseline-source/app/sim/',
                                         'baseline-source/app/failures/')) and name.endswith('.gd'))
    for candidate, expected in [(False, '13b8d848df6df2cab646374c03a93f9651e240dfa634209ff77c7b52ff95df10'),
                                (True, '1d06d5160dd6b23ec619584cb9ea115eec30f4111ca23c74165eac1d9761e753')]:
        digest = hashlib.sha256()
        for name in sources:
            relative = name.removeprefix('baseline-source/app/')
            digest.update(('res://' + relative).encode())
            entry = 'candidate-source/app/physics/aero.gd' if candidate and relative == 'physics/aero.gd' else name
            digest.update(archive.read(entry))
        assert digest.hexdigest() == expected, (candidate, digest.hexdigest())
print(json.dumps({'files': len(members), 'archive_bytes': manifest['archive_bytes'],
                  'archive_sha256': manifest['archive_sha256']}))
