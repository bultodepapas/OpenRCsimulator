## Four short reverse-flow audit tapes recorded by the actual fixed-wing FlightSession.
## The extra metrics CSV is a read-only diagnostic at the same pre-step state as each solver k1.
extends SceneTree

const Flight := preload("res://sim/flight_session.gd")
const Log := preload("res://sim/flight_log.gd")
const Aero := preload("res://physics/aero.gd")
const RB := preload("res://physics/rigid_body.gd")
const M := preload("res://physics/math3d.gd")

var destination := ""
var failures := 0
var results: Array = []


func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			destination = arg.trim_prefix("--out=")
	if destination.is_empty():
		printerr("--out is required")
		quit(1)
		return
	DirAccess.make_dir_recursive_absolute(destination)
	call_deferred("_run")


func _run() -> void:
	var cards: Array[Dictionary] = [
		{name = "extra-reverse-beta5", aircraft = "res://data/aircraft/gp_extra_300s_60.json", kind = "reverse", ticks = 480},
		{name = "f4u-reverse-beta5", aircraft = "res://data/aircraft/f4u_corsair_250.json", kind = "reverse", ticks = 480},
		{name = "extra-nose-up-tail-first", aircraft = "res://data/aircraft/gp_extra_300s_60.json", kind = "tail_first", ticks = 120},
		{name = "extra-forward-pitch-pulse", aircraft = "res://data/aircraft/gp_extra_300s_60.json", kind = "forward_pitch_pulse", ticks = 480},
	]
	for card in cards:
		_run_case(card)
	var report := {
		method = "Four 2-second fixed-step FlightSession tapes at 240 Hz. Reverse-flow starts use alpha=179 deg and beta=+5 deg at 20 m/s in calm air, with engine off; the tailslide diagnostic starts at 300 m, 82 deg nose-up, body-u=4 m/s and v=0.35 m/s, with engine off; the forward control case uses the normal-rate profile and a +0.30 raw pitch input from 0.25 to 0.50 s at the Extra's level start trim. Each tape has an ORFL initial checkpoint, prescribed commands and explicit markers. The metrics CSV evaluates the Aero law at each interval start, separates the body attached-side and crossflow Fy terms, and pairs those with the aerodynamic load vector and the accepted Simulation total load vector after the tick.",
		engine = Engine.get_version_info().string,
		solver_sha256 = Log.solver_identity(),
		dt_s = 1.0 / Engine.physics_ticks_per_second,
		cases = results,
	}
	var report_path := destination.path_join("session-results.json")
	var file := FileAccess.open(report_path, FileAccess.WRITE)
	if file == null:
		failures += 1
		printerr("Cannot write session results: ", report_path)
	else:
		file.store_string(JSON.stringify(report, "\t", true, true))
		file.close()
	print("REVERSE_FLOW_BASELINE_COMPLETE failures=", failures, " cases=", results.size())
	quit(0 if failures == 0 else 1)


func _run_case(card: Dictionary) -> void:
	var session := Flight.new()
	session.setup(str(card.aircraft))
	root.add_child(session)
	session.set_physics_process(false)
	session.sim.set_physics_process(false)
	session.radio.connected = false
	session.crash_auto_restart = false
	session.rate_profile = "normal"
	if not session.is_flyable():
		_fail_case(card, "aircraft rejected: " + str(session.start_error))
		session.free()
		return
	if str(card.kind) == "forward_pitch_pulse":
		var trim: Dictionary = session.trim_at(float(session.aircraft.model.start_speed), "level")
		if not trim.get("ok", false):
			_fail_case(card, "level start trim failed: " + str(trim.get("message", "unknown")))
			session.free()
			return
		session.set_start_altitude(300.0)
	else:
		session.set_start_altitude(300.0)
		var start: Dictionary = session.start.duplicate(true)
		start.mode = "glide"
		start.throttle = 0.0
		start.rpm = 0.0
		session.start = start
	session.reset()
	session.read_raw = func() -> Dictionary:
		var sample := {roll = 0.0, pitch = 0.0, yaw = 0.0, throttle = 0.0}
		if str(card.kind) == "forward_pitch_pulse":
			var t: float = session.sim.time()
			if t >= 0.25 and t < 0.50:
				sample.pitch = 0.30
		return sample
	if session.sim.paused or not session.physics_enabled:
		_fail_case(card, "session did not accept its reset start: " + str(session.pause_reason))
		session.free()
		return
	if str(card.kind) in ["reverse", "tail_first"]:
		var state: PackedFloat64Array = session.sim.state.duplicate()
		state[RB.POS] = 0.0
		state[RB.POS + 1] = 0.0
		state[RB.POS + 2] = -300.0
		state[RB.RATE] = 0.0
		state[RB.RATE + 1] = 0.0
		state[RB.RATE + 2] = 0.0
		if str(card.kind) == "reverse":
			var speed := 20.0
			var alpha := deg_to_rad(179.0)
			var beta := deg_to_rad(5.0)
			state[RB.VEL] = speed * cos(beta) * cos(alpha)
			state[RB.VEL + 1] = speed * sin(beta)
			state[RB.VEL + 2] = speed * cos(beta) * sin(alpha)
			var identity := M.q_from_euler(0.0, 0.0, 0.0)
			for axis in 4:
				state[RB.ATT + axis] = identity[axis]
		else:
			state[RB.VEL] = 4.0
			state[RB.VEL + 1] = 0.35
			state[RB.VEL + 2] = 0.0
			var nose_up := M.q_from_euler(0.0, deg_to_rad(82.0), 0.0)
			for axis in 4:
				state[RB.ATT + axis] = nose_up[axis]
		if not session.sim.reset(state):
			_fail_case(card, "seeded diagnostic state rejected after valid FlightSession reset: " + str(session.sim.fault_reason))
			session.free()
			return
	var case_name := str(card.name)
	var log_path := destination.path_join(case_name + ".orfl")
	var metrics_path := destination.path_join(case_name + "-metrics.csv")
	if FileAccess.file_exists(log_path) or FileAccess.file_exists(metrics_path):
		_fail_case(card, "refusing to overwrite existing evidence")
		session.free()
		return
	var metrics := FileAccess.open(metrics_path, FileAccess.WRITE)
	if metrics == null:
		_fail_case(card, "could not create metrics CSV")
		session.free()
		return
	metrics.store_csv_line(PackedStringArray([
		"case", "interval_tick", "endpoint_tick", "loads_t_s",
		"u_start_mps", "v_start_mps", "w_start_mps", "alpha_start_rad", "beta_start_rad", "V_start_mps", "pitch_start_rad",
		"body_attached_Fy_N", "body_crossflow_Fy_N", "body_side_sum_Fy_N",
		"aero_Fx_N", "aero_Fy_N", "aero_Fz_N", "aero_Mx_Nm", "aero_My_Nm", "aero_Mz_Nm",
		"sim_Fx_N", "sim_Fy_N", "sim_Fz_N", "sim_Mx_Nm", "sim_My_Nm", "sim_Mz_Nm",
		"u_end_mps", "v_end_mps", "w_end_mps", "alpha_end_rad", "beta_end_rad", "V_end_mps", "pitch_end_rad", "altitude_end_m",
	]))
	var recorder := Log.new(session)
	if recorder.start(log_path) != OK:
		_fail_case(card, "FlightLog.start failed: " + recorder.failure)
		metrics.close()
		session.free()
		return
	recorder.mark("controlled baseline start; kind=" + str(card.kind) + "; altitude=300 m; 240 Hz")
	var initial_air: Dictionary = session.air_data(session.sim.state, session.sim.time())
	var row := {
		name = case_name, aircraft = str(card.aircraft), kind = str(card.kind),
		duration_s = float(card.ticks) * session.sim.dt(), target_ticks = int(card.ticks),
		initial_state = Array(session.sim.state), initial_V_mps = initial_air.V,
		initial_alpha_deg = rad_to_deg(initial_air.alpha), initial_beta_deg = rad_to_deg(initial_air.beta),
		initial_solver_sha256 = Log.solver_identity(), aircraft_identity = session.aircraft.get("input_identity", {}),
		completed = false, u_zero_crossing_tick = -1,
	}
	var crossed_u_zero := false
	var finite := true
	for step_index in int(card.ticks):
		var interval_tick: int = session.sim.tick
		var t_start: float = session.sim.time()
		var s0: PackedFloat64Array = session.sim.state.duplicate()
		var air0: Dictionary = session.air_data(s0, t_start)
		var euler0: PackedFloat64Array = M.q_to_euler(M.quat(s0[RB.ATT], s0[RB.ATT + 1], s0[RB.ATT + 2], s0[RB.ATT + 3]))
		var deflections: Dictionary = session._deflections(session.sim.aux)
		var downwash := NAN
		var wake_index: int = session.downwash_index()
		if wake_index >= 0 and wake_index < session.sim.aux.size():
			downwash = session.sim.aux[wake_index]
		var rho: float = session.air_density(s0)
		var aero: PackedFloat64Array = Aero.loads(s0, air0, deflections, session.aircraft.model, rho, downwash, session._ground_up(s0))
		var surfaces: Dictionary = session.aircraft.model.get("surfaces", {})
		var reference: Dictionary = session.aircraft.model.reference
		var attached_fy: float = 0.5 * rho * float(reference.S) * float(surfaces.get("body_cy_beta", 0.0)) * s0[RB.VEL] * s0[RB.VEL + 1]
		var crossflow_fy: float = -0.5 * rho * float(surfaces.get("body_crossflow_area", 0.0)) * M.sqrt_(s0[RB.VEL + 1] * s0[RB.VEL + 1] + s0[RB.VEL + 2] * s0[RB.VEL + 2]) * s0[RB.VEL + 1]
		if str(card.kind) == "forward_pitch_pulse" and interval_tick == 60:
			recorder.mark("forward pitch pulse begins; raw pitch=+0.30")
		elif str(card.kind) == "forward_pitch_pulse" and interval_tick == 120:
			recorder.mark("forward pitch pulse ends; raw pitch returns neutral")
		session._physics_process(session.sim.dt())
		if session.sim.paused:
			break
		session.sim.step()
		if not session.sim.fault_reason.is_empty():
			break
		var s1: PackedFloat64Array = session.sim.state
		var air1: Dictionary = session.air_data(s1, session.sim.time())
		var euler1: PackedFloat64Array = M.q_to_euler(M.quat(s1[RB.ATT], s1[RB.ATT + 1], s1[RB.ATT + 2], s1[RB.ATT + 3]))
		var total: PackedFloat64Array = session.sim.last_loads
		var fields := PackedStringArray([case_name, str(interval_tick), str(session.sim.tick), _fmt(t_start)])
		for value in [s0[RB.VEL], s0[RB.VEL + 1], s0[RB.VEL + 2], air0.alpha, air0.beta, air0.V, euler0[1], attached_fy, crossflow_fy, attached_fy + crossflow_fy]:
			fields.append(_fmt(float(value)))
		for value in aero:
			fields.append(_fmt(float(value)))
		for value in total:
			fields.append(_fmt(float(value)))
		for value in [s1[RB.VEL], s1[RB.VEL + 1], s1[RB.VEL + 2], air1.alpha, air1.beta, air1.V, euler1[1], -s1[RB.POS + 2]]:
			fields.append(_fmt(float(value)))
		metrics.store_csv_line(fields)
		for value in s1:
			finite = finite and is_finite(value)
		if not crossed_u_zero and str(card.kind) == "tail_first" and s0[RB.VEL] > 0.0 and s1[RB.VEL] <= 0.0:
			crossed_u_zero = true
			row.u_zero_crossing_tick = session.sim.tick
			row.u_zero_crossing_time_s = session.sim.time()
			row.u_before_crossing_mps = s0[RB.VEL]
			row.u_after_crossing_mps = s1[RB.VEL]
			row.nose_pitch_at_crossing_deg = rad_to_deg(euler1[1])
			recorder.mark("nose-up tail-first diagnostic crossed body-u=0")
		if not finite or not session.crash.is_empty():
			break
	recorder.mark("end of prescribed tape")
	var stop_error: Error = recorder.stop("controlled reverse-flow audit tape finished")
	metrics.close()
	row.final_tick = session.sim.tick
	row.final_state = Array(session.sim.state)
	row.final_fault_reason = session.sim.fault_reason
	row.final_crash = session.crash
	row.u_zero_crossed = crossed_u_zero
	row.finite = finite
	row.log = log_path
	row.metrics_csv = metrics_path
	row.completed = session.sim.tick == int(card.ticks) and finite and session.sim.fault_reason.is_empty() and session.crash.is_empty() and stop_error == OK
	if not row.completed:
		failures += 1
	print("FLIGHT_CASE_COMPLETE ", case_name, " complete=", row.completed, " tick=", row.final_tick,
		" u0_crossed=", row.get("u_zero_crossed", false), " fault=", row.final_fault_reason, " crash=", row.final_crash)
	results.append(row)
	session.free()


func _fail_case(card: Dictionary, message: String) -> void:
	failures += 1
	printerr("FLIGHT_CASE_FAILED ", card.get("name", "unknown"), ": ", message)
	results.append({name = str(card.get("name", "unknown")), completed = false, error = message})


func _fmt(value: float) -> String:
	return String.num(value, 17)
