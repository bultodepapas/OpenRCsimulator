## Read-only ORFL header/checkpoint/input comparison; does not create a FlightSession or step physics.
extends SceneTree

const Log := preload("res://sim/flight_log.gd")

var baseline_path := ""
var candidate_path := ""


func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--baseline="):
			baseline_path = arg.trim_prefix("--baseline=")
		elif arg.begins_with("--candidate="):
			candidate_path = arg.trim_prefix("--candidate=")
	call_deferred("_run")


func _run() -> void:
	if baseline_path.is_empty() or candidate_path.is_empty():
		printerr("--baseline and --candidate are required")
		quit(1)
		return
	var baseline := _read_log(baseline_path)
	var candidate := _read_log(candidate_path)
	if not baseline.get("ok", false) or not candidate.get("ok", false):
		printerr("ORFL_READ_FAILED baseline=", baseline.get("error", ""), " candidate=", candidate.get("error", ""))
		quit(1)
		return
	var base_header: Dictionary = baseline.header
	var cand_header: Dictionary = candidate.header
	var base_checkpoint: Dictionary = base_header.get("checkpoint", {})
	var cand_checkpoint: Dictionary = cand_header.get("checkpoint", {})
	var base_sim: Dictionary = base_checkpoint.get("simulation", {})
	var cand_sim: Dictionary = cand_checkpoint.get("simulation", {})
	var sim_fields := ["format", "tick", "dt", "state", "previous", "aux", "continuous", "inputs", "modes", "last_loads", "mass", "inertia", "gravity", "stop_at_tick"]
	var simulation_differences := {}
	for key in sim_fields:
		var a: Variant = base_sim.get(key, null)
		var b: Variant = cand_sim.get(key, null)
		if not _same(a, b):
			simulation_differences[key] = {baseline = _json_value(a), candidate = _json_value(b)}
	var checkpoint_difference := _dictionary_differences(base_checkpoint, cand_checkpoint)
	var metadata_difference := _dictionary_differences(base_header.get("metadata", {}), cand_header.get("metadata", {}))
	var config_difference := _dictionary_differences(base_checkpoint.get("configuration", {}), cand_checkpoint.get("configuration", {}))
	var command_fields := ["tick", "inputs", "raw", "sticks", "intervention"]
	var common_rows: int = mini(baseline.rows.size(), candidate.rows.size())
	var base_commands: Array = []
	var cand_commands: Array = []
	var first_command_difference := {}
	for row_index in common_rows:
		var base_row: Dictionary = baseline.rows[row_index]
		var cand_row: Dictionary = candidate.rows[row_index]
		var base_command := {}
		var cand_command := {}
		for key in command_fields:
			base_command[key] = base_row.get(key, null)
			cand_command[key] = cand_row.get(key, null)
			if first_command_difference.is_empty() and not _same(base_command[key], cand_command[key]):
				first_command_difference = {row_index = row_index, tick = base_row.get("tick", -1), field = key,
					baseline = _json_value(base_command[key]), candidate = _json_value(cand_command[key])}
		base_commands.append(base_command)
		cand_commands.append(cand_command)
	var report := {
		baseline = baseline_path,
		candidate = candidate_path,
		baseline_file_sha256 = FileAccess.get_sha256(baseline_path),
		candidate_file_sha256 = FileAccess.get_sha256(candidate_path),
		baseline_header = {dt_s = base_header.get("dt_s"), solver_sha256 = base_header.get("solver_sha256"), aircraft_path = base_header.get("aircraft_path"), aircraft_sha256 = base_header.get("aircraft", {}).get("input_identity", {}).get("sha256", ""), layout = base_header.get("layout", {})},
		candidate_header = {dt_s = cand_header.get("dt_s"), solver_sha256 = cand_header.get("solver_sha256"), aircraft_path = cand_header.get("aircraft_path"), aircraft_sha256 = cand_header.get("aircraft", {}).get("input_identity", {}).get("sha256", ""), layout = cand_header.get("layout", {})},
		checkpoint_sha256 = {baseline = _hash(base_checkpoint), candidate = _hash(cand_checkpoint), identical = _same(base_checkpoint, cand_checkpoint)},
		configuration_differences = config_difference,
		checkpoint_top_level_differences = checkpoint_difference,
		initial_simulation = {baseline_state = _json_value(base_sim.get("state")), candidate_state = _json_value(cand_sim.get("state")), baseline_aux = _json_value(base_sim.get("aux")), candidate_aux = _json_value(cand_sim.get("aux")), baseline_continuous = _json_value(base_sim.get("continuous")), candidate_continuous = _json_value(cand_sim.get("continuous")), baseline_inputs = _json_value(base_sim.get("inputs")), candidate_inputs = _json_value(cand_sim.get("inputs")), baseline_modes = _json_value(base_sim.get("modes")), candidate_modes = _json_value(cand_sim.get("modes"))},
		initial_simulation_differences = simulation_differences,
		metadata_differences = metadata_difference,
		baseline_rows = baseline.rows.size(), candidate_rows = candidate.rows.size(),
		baseline_last_tick = baseline.rows.back().get("tick", -1) if not baseline.rows.is_empty() else -1,
		candidate_last_tick = candidate.rows.back().get("tick", -1) if not candidate.rows.is_empty() else -1,
		common_rows = common_rows,
		command_tape_sha256 = {baseline_common_prefix = _hash(base_commands), candidate_common_prefix = _hash(cand_commands), identical = _same(base_commands, cand_commands)},
		first_command_difference = first_command_difference,
		baseline_event_markers = baseline.events,
		candidate_event_markers = candidate.events,
	}
	print("ORFL_PAIR_COMPARISON ", JSON.stringify(report, "\t", true, true))
	quit(0)


func _read_log(path: String) -> Dictionary:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {ok = false, error = "cannot open " + path}
	if file.get_length() < 8 or file.get_buffer(8).get_string_from_ascii() != Log.MAGIC:
		file.close()
		return {ok = false, error = "invalid ORFL magic: " + path}
	var header_packet: Dictionary = Log.read_packet(file)
	if not header_packet.get("ok", false) or header_packet.value.get("kind", "") != "header":
		file.close()
		return {ok = false, error = "invalid ORFL header: " + path}
	var rows: Array = []
	var events: Array = []
	var footer := {}
	while file.get_position() < file.get_length():
		var packet: Dictionary = Log.read_packet(file)
		if not packet.get("ok", false):
			file.close()
			return {ok = false, error = str(packet.get("error", "packet parse failed"))}
		var value: Dictionary = packet.value
		match str(value.get("kind", "")):
			"block":
				rows.append_array(value.get("rows", []))
				events.append_array(value.get("events", []))
			"footer":
				footer = value
				break
	file.close()
	return {ok = not footer.is_empty(), header = header_packet.value, rows = rows, events = events, footer = footer}


func _same(a: Variant, b: Variant) -> bool:
	return var_to_bytes(a) == var_to_bytes(b)


func _hash(value: Variant) -> String:
	return Log.sha256(var_to_bytes(value)).hex_encode()


func _dictionary_differences(a: Variant, b: Variant) -> Dictionary:
	var left: Dictionary = a if a is Dictionary else {}
	var right: Dictionary = b if b is Dictionary else {}
	var keys: Dictionary = {}
	for key in left.keys(): keys[key] = true
	for key in right.keys(): keys[key] = true
	var result := {}
	for key in keys:
		var left_value: Variant = left.get(key, null)
		var right_value: Variant = right.get(key, null)
		if not _same(left_value, right_value):
			result[str(key)] = {baseline = _json_value(left_value), candidate = _json_value(right_value)}
	return result


func _json_value(value: Variant) -> Variant:
	if value is PackedFloat64Array or value is PackedInt64Array or value is PackedByteArray:
		return Array(value)
	if value is Dictionary:
		var result := {}
		for key in value:
			result[str(key)] = _json_value(value[key])
		return result
	if value is Array:
		var result: Array = []
		for item in value:
			result.append(_json_value(item))
		return result
	return value
