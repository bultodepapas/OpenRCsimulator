extends SceneTree

const Flight := preload("res://sim/flight_session.gd")
const RB := preload("res://physics/rigid_body.gd")
const M := preload("res://physics/math3d.gd")
const Aero := preload("res://physics/aero.gd")


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var session := Flight.new()
	session.setup("res://data/aircraft/gp_extra_300s_60.json")
	root.add_child(session)
	session.set_physics_process(false)
	session.sim.set_physics_process(false)
	session.radio.connected = false
	session.crash_auto_restart = false
	session.set_start_altitude(300.0)
	var start: Dictionary = session.start.duplicate(true)
	start.mode = "glide"
	start.throttle = 0.0
	start.rpm = 0.0
	session.start = start
	session.reset()
	if session.sim.paused or not session.physics_enabled:
		printerr("CLEAN_RESET_FAILED: ", session.pause_reason)
		quit(1)
		return
	for alpha_deg in [90.0, 120.0, 150.0, 160.0, 170.0, 175.0, 178.0, 179.0, 180.0]:
		var state: PackedFloat64Array = session.sim.state.duplicate()
		state[RB.POS] = 0.0
		state[RB.POS + 1] = 0.0
		state[RB.POS + 2] = -300.0
		state[RB.VEL] = 20.0 * cos(deg_to_rad(5.0)) * cos(deg_to_rad(alpha_deg))
		state[RB.VEL + 1] = 20.0 * sin(deg_to_rad(5.0))
		state[RB.VEL + 2] = 20.0 * cos(deg_to_rad(5.0)) * sin(deg_to_rad(alpha_deg))
		state[RB.ATT] = 1.0
		state[RB.ATT + 1] = 0.0
		state[RB.ATT + 2] = 0.0
		state[RB.ATT + 3] = 0.0
		state[RB.RATE] = 0.0
		state[RB.RATE + 1] = 0.0
		state[RB.RATE + 2] = 0.0
		var candidate: Dictionary = session.sim.prepare_reset(state)
		var air: Dictionary = session.air_data(state, 0.0)
		var downwash := NAN
		var wake_index: int = session.downwash_index()
		if wake_index >= 0 and wake_index < session.sim.aux.size():
			downwash = session.sim.aux[wake_index]
		var aero: PackedFloat64Array = Aero.loads(state, air, session._deflections(session.sim.aux), session.aircraft.model, session.air_density(state), downwash, session._ground_up(state))
		var total: PackedFloat64Array = session._loads(state, 0.0)
		print("ALPHA_DIAG ", alpha_deg, " ok=", candidate.get("ok", false), " message=", candidate.get("message", ""), " aero=", Array(aero), " total=", Array(total), " accepted_loads=", Array(candidate.get("loads", PackedFloat64Array())))
	session.free()
	quit(0)
