"""Endpoint sensitivity only; does not estimate order across the u=0 kink."""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parent / 'refinement-v2'
last = {}
for hz in [240, 480, 960]:
    with (root / f'exact-{hz}/exact.csv').open(newline='') as file:
        last[hz] = list(csv.DictReader(file))[-1]
    assert float(last[hz]['t_s']) == 0.5
groups = {'position_m': ['north_m', 'east_m', 'down_m'],
          'body_velocity_mps': ['u_mps', 'v_mps', 'w_mps'],
          'angular_rate_radps': ['p_radps', 'q_radps', 'r_radps'],
          'quaternion_components': ['qw', 'qx', 'qy', 'qz']}
pairs = []
for a, b in [(240, 480), (480, 960)]:
    pairs.append({'rates_hz': [a, b], 'max_absolute_component_differences': {
        group: max(abs(float(last[a][key]) - float(last[b][key])) for key in fields)
        for group, fields in groups.items()}})
result = {'time_s': 0.5, 'meaning': 'Endpoint sensitivity, not an integrator order estimate or physical validation',
          'pairs': pairs}
(root / 'endpoint-sensitivity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
