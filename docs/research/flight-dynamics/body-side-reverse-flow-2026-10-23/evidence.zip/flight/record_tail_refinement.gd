## Candidate tail-first fixed-step refinement across the attached-body-side gate.
extends SceneTree

const Flight := preload("res://sim/flight_session.gd")
const Log := preload("res://sim/flight_log.gd")
const Aero := preload("res://physics/aero.gd")
const RB := preload("res://physics/rigid_body.gd")
const M := preload("res://physics/math3d.gd")

const EXTRA := "res://data/aircraft/gp_extra_300s_60.json"
const RHO_REF := 1.225

var destination := ""
var rates: Array[int] = [240, 480, 960]
var duration_s := 0.5
var suffix := ""
var failures := 0
var results: Array = []


func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			destination = arg.trim_prefix("--out=")
		elif arg.begins_with("--rates="):
			rates.clear()
			for raw_rate in arg.trim_prefix("--rates=").split(","):
				rates.append(int(raw_rate))
		elif arg.begins_with("--duration="):
			duration_s = float(arg.trim_prefix("--duration="))
		elif arg.begins_with("--suffix="):
			suffix = arg.trim_prefix("--suffix=")
	if destination.is_empty() or rates.is_empty():
		printerr("--out and --rates are required")
		quit(1)
		return
	DirAccess.make_dir_recursive_absolute(destination)
	call_deferred("_run")


func _run() -> void:
	for rate in rates:
		Engine.physics_ticks_per_second = rate
		_run_rate(rate)
	var report := {
		method = "Candidate Extra tail-first with neutral commands for %.6f s; Engine.physics_ticks_per_second is set before FlightSession construction and reset. Initial state is u=4 m/s, v=0.35 m/s, w=0, pitch=82 deg at 300 m in glide mode." % duration_s,
		engine = Engine.get_version_info().string,
		solver_sha256 = Log.solver_identity(),
		aircraft_sha256 = "0db71ff170ea90764ecad325940e4cbee7ed80a7200cd0171eca09e74ab1401f",
		results = results,
	}
	var report_path := destination.path_join("refinement-results.json")
	var file := FileAccess.open(report_path, FileAccess.WRITE)
	if file == null:
		failures += 1
	else:
		file.store_string(JSON.stringify(report, "\t", true, true))
		file.close()
	print("TAIL_REFINEMENT_COMPLETE failures=", failures, " rates=", results.size())
	quit(0 if failures == 0 else 1)


func _run_rate(rate: int) -> void:
	var ticks := int(round(rate * duration_s))
	var case_suffix := ("-" + suffix) if not suffix.is_empty() else ""
	var name := "extra-tail-u0-%d%s" % [rate, case_suffix]
	var session := Flight.new()
	session.setup(EXTRA)
	root.add_child(session)
	session.set_physics_process(false)
	session.sim.set_physics_process(false)
	session.radio.connected = false
	session.crash_auto_restart = false
	session.rate_profile = "normal"
	session.set_start_altitude(300.0)
	var start: Dictionary = session.start.duplicate(true)
	start.mode = "glide"
	start.throttle = 0.0
	start.rpm = 0.0
	session.start = start
	session.reset()
	if session.sim.paused or not session.physics_enabled:
		_fail_rate(name, "session did not accept its valid trim reset: " + str(session.pause_reason))
		session.free()
		return
	var state: PackedFloat64Array = session.sim.state.duplicate()
	state[RB.POS] = 0.0
	state[RB.POS + 1] = 0.0
	state[RB.POS + 2] = -300.0
	state[RB.VEL] = 4.0
	state[RB.VEL + 1] = 0.35
	state[RB.VEL + 2] = 0.0
	var nose_up := M.q_from_euler(0.0, deg_to_rad(82.0), 0.0)
	for axis in 4:
		state[RB.ATT + axis] = nose_up[axis]
	state[RB.RATE] = 0.0
	state[RB.RATE + 1] = 0.0
	state[RB.RATE + 2] = 0.0
	if not session.sim.reset(state):
		_fail_rate(name, "seeded state rejected: " + str(session.sim.fault_reason))
		session.free()
		return
	session.read_raw = func() -> Dictionary:
		return {roll = 0.0, pitch = 0.0, yaw = 0.0, throttle = 0.0}
	var log_path := destination.path_join(name + ".orfl")
	var metrics_path := destination.path_join(name + "-metrics.csv")
	if FileAccess.file_exists(log_path) or FileAccess.file_exists(metrics_path):
		_fail_rate(name, "refusing to overwrite existing evidence")
		session.free()
		return
	var metrics := FileAccess.open(metrics_path, FileAccess.WRITE)
	if metrics == null:
		_fail_rate(name, "could not create metrics CSV")
		session.free()
		return
	metrics.store_csv_line(PackedStringArray([
		"case", "rate_hz", "interval_tick", "endpoint_tick", "t_start_s",
		"body_u_start_mps", "body_v_start_mps", "body_w_start_mps", "speed_start_mps", "alpha_start_rad", "beta_start_rad", "pitch_start_rad",
		"body_attached_raw_Fy_N", "body_attached_gated_Fy_N", "body_crossflow_Fy_N", "body_side_sum_Fy_N",
		"aero_Fx_N", "aero_Fy_N", "aero_Fz_N", "aero_Mx_Nm", "aero_My_Nm", "aero_Mz_Nm",
		"sim_Fx_N", "sim_Fy_N", "sim_Fz_N", "sim_Mx_Nm", "sim_My_Nm", "sim_Mz_Nm",
		"body_u_end_mps", "body_v_end_mps", "body_w_end_mps", "pitch_end_rad",
	]))
	var recorder := Log.new(session)
	if recorder.start(log_path) != OK:
		_fail_rate(name, "FlightLog.start failed: " + recorder.failure)
		metrics.close()
		session.free()
		return
	recorder.mark("candidate tail-first start; neutral controls; 300 m; 82 deg nose-up; rate=%d Hz" % rate)
	var row := {
		name = name, rate_hz = rate, dt_s = session.sim.dt(), duration_s = duration_s, target_ticks = ticks,
		initial_state = Array(session.sim.state), solver_sha256 = Log.solver_identity(),
		aircraft_identity = session.aircraft.get("input_identity", {}),
		completed = false, u_zero_crossing_tick = -1,
	}
	var crossed := false
	var finite := true
	for iteration in ticks:
		var interval_tick: int = session.sim.tick
		var t0: float = session.sim.time()
		var s0: PackedFloat64Array = session.sim.state.duplicate()
		var air0: Dictionary = session.air_data(s0, t0)
		var euler0: PackedFloat64Array = M.q_to_euler(M.quat(s0[RB.ATT], s0[RB.ATT + 1], s0[RB.ATT + 2], s0[RB.ATT + 3]))
		var deflections: Dictionary = session._deflections(session.sim.aux)
		var downwash := NAN
		var wake_index: int = session.downwash_index()
		if wake_index >= 0 and wake_index < session.sim.aux.size():
			downwash = session.sim.aux[wake_index]
		var rho: float = session.air_density(s0)
		var aero: PackedFloat64Array = Aero.loads(s0, air0, deflections, session.aircraft.model, rho, downwash, session._ground_up(s0))
		var surfaces: Dictionary = session.aircraft.model.get("surfaces", {})
		var reference: Dictionary = session.aircraft.model.reference
		var body_factor := 0.5 * rho * float(reference.S) * float(surfaces.get("body_cy_beta", 0.0)) * s0[RB.VEL + 1]
		var attached_raw := body_factor * s0[RB.VEL]
		var attached_gated := body_factor * maxf(s0[RB.VEL], 0.0)
		var crossflow := -0.5 * rho * float(surfaces.get("body_crossflow_area", 0.0)) * M.sqrt_(s0[RB.VEL + 1] * s0[RB.VEL + 1] + s0[RB.VEL + 2] * s0[RB.VEL + 2]) * s0[RB.VEL + 1]
		session._physics_process(session.sim.dt())
		session.sim.step()
		if not session.sim.fault_reason.is_empty():
			break
		var s1: PackedFloat64Array = session.sim.state
		var euler1: PackedFloat64Array = M.q_to_euler(M.quat(s1[RB.ATT], s1[RB.ATT + 1], s1[RB.ATT + 2], s1[RB.ATT + 3]))
		var fields := PackedStringArray([name, str(rate), str(interval_tick), str(session.sim.tick), _fmt(t0)])
		for value in [s0[RB.VEL], s0[RB.VEL + 1], s0[RB.VEL + 2], air0.V, air0.alpha, air0.beta, euler0[1], attached_raw, attached_gated, crossflow, attached_gated + crossflow]:
			fields.append(_fmt(float(value)))
		for value in aero:
			fields.append(_fmt(float(value)))
		for value in session.sim.last_loads:
			fields.append(_fmt(float(value)))
		for value in [s1[RB.VEL], s1[RB.VEL + 1], s1[RB.VEL + 2], euler1[1]]:
			fields.append(_fmt(float(value)))
		metrics.store_csv_line(fields)
		for value in s1:
			finite = finite and is_finite(value)
		if not crossed and s0[RB.VEL] > 0.0 and s1[RB.VEL] <= 0.0:
			crossed = true
			row.u_zero_crossing_tick = session.sim.tick
			row.u_zero_crossing_time_s = session.sim.time()
			row.u_before_crossing_mps = s0[RB.VEL]
			row.u_after_crossing_mps = s1[RB.VEL]
			row.pitch_at_crossing_deg = rad_to_deg(euler1[1])
			recorder.mark("body-u crossed zero")
		if not finite or not session.crash.is_empty():
			break
	recorder.mark("refinement tape end at %.6f seconds" % duration_s)
	var stop_error: Error = recorder.stop("candidate fixed-step refinement finished")
	metrics.close()
	row.final_tick = session.sim.tick
	row.final_fault_reason = session.sim.fault_reason
	row.u_zero_crossed = crossed
	row.finite = finite
	row.log = log_path
	row.metrics_csv = metrics_path
	row.completed = session.sim.tick == ticks and finite and session.sim.fault_reason.is_empty() and session.crash.is_empty() and stop_error == OK and crossed
	if not row.completed:
		failures += 1
	print("TAIL_REFINEMENT_RATE ", rate, " complete=", row.completed, " tick=", row.final_tick, " crossed=", crossed, " fault=", row.final_fault_reason)
	results.append(row)
	session.free()


func _fail_rate(name: String, message: String) -> void:
	failures += 1
	printerr("TAIL_REFINEMENT_FAILED ", name, ": ", message)
	results.append({name = name, completed = false, error = message})


func _fmt(value: float) -> String:
	return String.num(value, 17)
