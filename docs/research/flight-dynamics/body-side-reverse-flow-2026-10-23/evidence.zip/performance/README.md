# Reverse-flow performance comparison (2026-10-23)

This scratch-only evidence compares the immutable baseline with the proposed
single `maxf(v0, 0.0)` gate in Extra/F4U body-side `Fy`. Only `app/physics/aero.gd`
differs between the source snapshots. The accepted set is three alternating
pairs at 720 warm-up/3,600 measured ticks per case; the longer 2,400/14,400
launches are exploratory only. The machine-readable summary and exact source
IDs, run metrics, warnings and limitations are in
[`paired/summary.json`](paired/summary.json). Raw reports and checked-runner logs
remain beside it under `paired/`, `servo/` and `native/`.

`physics_step_probe.gd` measures elapsed microseconds around the real
`Simulation.step()` call. It holds the Extra 300S state at a high positive stall
angle and at the audit's reverse condition (`V=20 m/s`, `alpha=179°`, `beta=5°`),
restoring state, inputs, servos and continuous state before every step. This
keeps `u<0`, `v!=0` and Extra's nonzero `body_cy_beta` active on every reverse
sample. The baseline attached CYbeta contribution is nonzero; the candidate
gate sets only that attached CYbeta contribution to zero, while other body-side
crossflow contributions remain. The probe stores raw samples,
nearest-rank p50/p95, result fingerprints,
machine identity and hashes of `aero.gd` plus the physics/session dependencies.
It is a headless physics microbench, not a flight or display measurement.

Use disposable app copies under a fresh output directory so Godot can write
imports without touching the immutable baseline or candidate source. The accepted
set ran three sequential pairs in alternating order `baseline → candidate`,
`candidate → baseline`, `baseline → candidate`, using the same pinned Godot
executable, 720 warm-up ticks and 3,600 measured ticks per case. A launch looks
like:

```powershell
python tools/godot/run_checked.py --out-dir <new-run-dir>/checked --label <run-id> --timeout 180 -- `
  .tools/Godot_v4.7.2-stable_win64_console.exe --headless --path <disposable-app-copy> `
  --audio-driver Dummy --script "$PWD/tmp/reverse-flow-audit-2026-10-23/performance/physics_step_probe.gd" -- `
  --output=<new-run-dir>/physics-step.json --warmup-ticks=720 --sample-ticks=3600
```

Keep every raw report and checked log. Compare each pair's p50 and p95 by case;
also report the three-run medians and ranges. Treat a delta inside run-to-run
spread, or deltas that change sign across pairs, as noise and make no speedup
claim. Require complete reports and `target_reverse_body_cy_term_nonzero=true`;
that flag confirms reverse inputs and a nonzero configured coefficient, not a
nonzero candidate force.

The control-to-surface software seam is already covered by
`app/tests/test_servo.gd`: it expects `cmd_roll=1` while `srv_roll=5/33.6` at
trace row 5, with full surface throw on tick 34 at 240 Hz. That establishes
simulated command-to-servo delay only; it excludes controller hardware, the OS
input queue, radio transport and rendered feedback latency.

The native pair completed in fullscreen at an actual logger-reported
1920×1080, with Extra 300S, a 5 s warm-up and 20 s sample per variant. Both used
the same 60 Hz screen, VSync mode, uncapped setting, Compatibility renderer,
Standard profile, MSAA 2, scale 1.0, and lake probe. Baseline/candidate frame
p50 was 16.669/16.673 ms, p95 17.118/17.119 ms, and p99 17.296/17.387 ms.
The pair is a short scripted rendering/pacing observation: its reports show
zero simulation ticks, so it does not exercise the aerodynamic branch or qualify
1080p performance. The baseline logged one ObjectDB warning at exit; neither
run had engine errors. No screenshots were saved.

## Results

The accepted headless set used 720 warm-up and 3,600 measured calls per case,
in alternating order baseline→candidate, candidate→baseline, baseline→candidate.
Each launch timed `Simulation.step()` for an Extra 300S fixed-state forward-stall
case and a reverse-flow case (`alpha=179°`, `beta=5°`, nominal `u=-19.921 m/s`,
`v=1.743 m/s`). The reverse fixture has a nonzero configured `body_cy_beta`:
the baseline attached CYbeta contribution is nonzero and the candidate gate sets
only that attached CYbeta contribution to zero; other body-side crossflow
contributions remain. The probe's fixture flag means the reverse inputs and
coefficient were present; it does not mean the candidate CYbeta contribution
remained nonzero.

| Case | p50 median B→C | Paired p50 delta median (range) | p95 median B→C | Paired p95 delta median (range) |
|---|---:|---:|---:|---:|
| Extra forward stall | 1,950→1,959 µs | −6 µs (−1,069…+30) | 2,699→2,857 µs | +187 µs (−591…+195) |
| Extra reverse flow | 2,001→1,999 µs | −18 µs (−25…+46) | 3,176→2,691 µs | −624 µs (−689…+460) |

The paired deltas vary or change sign across repeats, and the observed changes
are within run-to-run spread. No physics speedup claim is supported. All six
accepted checked reports completed; they had zero engine warning/error records
and printed two application-level aircraft-data warnings per run. The longer
2,400-warm-up/14,400-sample baseline/candidate launches are retained as
exploratory reports only and are excluded from the accepted statistics.

The existing `app/tests/test_servo.gd` passed in both variants (6 checks, 0
failures). With `cmd_roll=1`, trace row 5 has `srv_roll=5/33.6=0.1488095` after
five 240 Hz ticks (20.833 ms); full servo throw occurs at tick 34 (141.667 ms).
This measures only the simulation's software command-to-servo path. It excludes
OS input, controller hardware, radio transport and rendered feedback latency.
