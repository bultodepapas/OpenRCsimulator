## Scratch-only paired physics-step probe for the 2026-10-23 reverse-flow audit.
## Measures Simulation.step() on fixed Extra 300S states; it is not a flight test.
extends SceneTree

const Session := preload("res://sim/flight_session.gd")
const Catalog := preload("res://app_state/aircraft_catalog.gd")
const Air := preload("res://physics/air_data.gd")
const RB := preload("res://physics/rigid_body.gd")

const AIRCRAFT_ID := "gp-extra-300s-60"
const REVERSE_ALPHA := deg_to_rad(179.0)
const REVERSE_BETA := deg_to_rad(5.0)
const FIXTURE_SPEED_MPS := 20.0

var _output := ""
var _warmup_ticks := 2400
var _sample_ticks := 14400
var _failure := ""


func _initialize() -> void:
	if not _parse_args():
		printerr(_failure)
		quit(2)
		return
	call_deferred("_run")


func _parse_args() -> bool:
	var seen := {}
	for arg: String in OS.get_cmdline_user_args():
		var pair := arg.trim_prefix("--").split("=", true, 1)
		if not arg.begins_with("--") or pair.size() != 2 or seen.has(pair[0]):
			return _fail("expected unique --name=value arguments")
		seen[pair[0]] = true
		match pair[0]:
			"output": _output = pair[1]
			"warmup-ticks", "sample-ticks":
				if not pair[1].is_valid_int():
					return _fail("tick counts must be integers")
				var value: int = pair[1].to_int()
				if value < 0 or value > 72000:
					return _fail("tick counts must be within 0..72000")
				if pair[0] == "warmup-ticks":
					_warmup_ticks = value
				else:
					_sample_ticks = value
			_:
				return _fail("unknown option: " + pair[0])
	if _output.is_empty() or FileAccess.file_exists(_output):
		return _fail("output must name a new file")
	if _sample_ticks < 100:
		return _fail("sample-ticks must be at least 100 for useful percentiles")
	return true


func _run() -> void:
	var entry: Dictionary = Catalog.entry(AIRCRAFT_ID)
	if entry.is_empty() or str(entry.get("data", "")).is_empty():
		_finish_error("Extra aircraft data is unavailable")
		return
	var session := Session.new()
	session.setup(str(entry.data))
	root.add_child(session)
	session.input_enabled = false
	session.reset()
	if not session.is_flyable():
		_finish_error("Extra session is not flyable: " + str(session.pause_reason))
		session.free()
		return

	var sim: Node = session.sim
	var model: Dictionary = session.aircraft.model
	var surfaces: Dictionary = model.get("surfaces", {})
	var envelope: Dictionary = model.get("envelope", {})
	var body_cy_beta := float(surfaces.get("body_cy_beta", 0.0))
	var body_crossflow_area := float(surfaces.get("body_crossflow_area", 0.0))
	if body_cy_beta == 0.0:
		_finish_error("Extra has no nonzero body_cy_beta term for the max(u, 0) candidate to exercise")
		session.free()
		return

	var base_state: PackedFloat64Array = sim.state.duplicate()
	var base_aux: PackedFloat64Array = sim.aux.duplicate()
	var base_inputs: PackedFloat64Array = sim.inputs.duplicate()
	var base_continuous: PackedFloat64Array = sim.continuous.duplicate()
	var base_modes: PackedInt64Array = sim.modes.duplicate()
	var stalled_alpha := maxf(float(envelope.get("a2", deg_to_rad(15.0))), deg_to_rad(15.0))
	var fixtures := [
		_make_fixture("extra_stalled_forward", base_state, FIXTURE_SPEED_MPS, stalled_alpha, 0.0),
		_make_fixture("extra_reverse_alpha_179_beta_5", base_state, FIXTURE_SPEED_MPS, REVERSE_ALPHA, REVERSE_BETA),
	]
	var case_reports: Array[Dictionary] = []
	for fixture: Dictionary in fixtures:
		var case_report: Dictionary = _measure_case(
			sim, fixture, base_aux, base_inputs, base_continuous, base_modes,
			body_cy_beta, body_crossflow_area, float(envelope.get("a1", 0.0)),
			float(envelope.get("a2", 0.0)))
		case_reports.append(case_report)
		if not case_report.get("complete", false):
			_failure = str(case_report.get("failure", "case did not complete"))
			break

	var report := {
		"format": "openrc-reverse-flow-physics-step v1",
		"complete": _failure.is_empty(),
		"failure": _failure,
		"scope": "Headless CPU timing around Simulation.step() only. Extra 300S fixed-state microbench; state/input/auxiliary arrays are restored before each step so the declared stalled or reverse body flow is exercised every sample. No render, session input callback, OS input, radio latency, or physical validation.",
		"aircraft_id": AIRCRAFT_ID,
		"requested": {"warmup_ticks_per_case": _warmup_ticks, "sample_ticks_per_case": _sample_ticks},
		"source": {
			"aero_sha256": _sha256("res://physics/aero.gd"),
			"aircraft_json_sha256": _sha256(str(entry.data)),
			"simulation_sha256": _sha256("res://sim/simulation.gd"),
			"flight_session_sha256": _sha256("res://sim/flight_session.gd"),
			"air_data_sha256": _sha256("res://physics/air_data.gd"),
			"rigid_body_sha256": _sha256("res://physics/rigid_body.gd"),
			"aircraft_data_sha256": _sha256("res://physics/aircraft_data.gd"),
		},
		"machine": {
			"os": OS.get_name(),
			"processor": OS.get_processor_name(),
			"logical_cpu_count": OS.get_processor_count(),
			"architecture": Engine.get_architecture_name(),
			"godot": Engine.get_version_info().string,
		},
		"cases": case_reports,
	}
	_write_report(report)
	session.free()
	print("physics-step probe: %s / %d cases / %s" % [AIRCRAFT_ID, case_reports.size(), "complete" if _failure.is_empty() else _failure])
	quit(0 if _failure.is_empty() else 1)


func _make_fixture(case_id: String, base: PackedFloat64Array, speed: float, alpha: float, beta: float) -> Dictionary:
	var state := base.duplicate()
	var cb := cos(beta)
	state[RB.VEL] = speed * cb * cos(alpha)
	state[RB.VEL + 1] = speed * sin(beta)
	state[RB.VEL + 2] = speed * cb * sin(alpha)
	var air: Dictionary = Air.compute(state, PackedFloat64Array([0.0, 0.0, 0.0]))
	return {
		"case_id": case_id,
		"state": state,
		"nominal_alpha_rad": alpha,
		"nominal_beta_rad": beta,
		"nominal_u_mps": state[RB.VEL],
		"nominal_v_mps": state[RB.VEL + 1],
		"nominal_w_mps": state[RB.VEL + 2],
		"zero_wind_air_alpha_rad": air.alpha,
		"zero_wind_air_beta_rad": air.beta,
		"zero_wind_air_speed_mps": air.V,
	}


func _measure_case(sim: Node, fixture: Dictionary, base_aux: PackedFloat64Array, base_inputs: PackedFloat64Array,
		base_continuous: PackedFloat64Array, base_modes: PackedInt64Array,
		body_cy_beta: float, body_crossflow_area: float, stall_onset_rad: float,
		stall_end_rad: float) -> Dictionary:
	var state: PackedFloat64Array = fixture.state
	var samples := PackedInt64Array()
	var digest := HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	for index in _warmup_ticks + _sample_ticks:
		sim.state = state.duplicate()
		sim.previous = state.duplicate()
		sim.aux = base_aux.duplicate()
		sim.inputs = base_inputs.duplicate()
		sim.continuous = base_continuous.duplicate()
		sim.modes = base_modes.duplicate()
		var tick_before: int = sim.tick
		var started: int = Time.get_ticks_usec()
		sim.step()
		var elapsed: int = Time.get_ticks_usec() - started
		if sim.tick != tick_before + 1 or not str(sim.fault_reason).is_empty() or sim.paused:
			return {"case_id": fixture.case_id, "complete": false, "failure": "simulation step failed at case sample %d: tick=%d fault=%s paused=%s" % [index, sim.tick, sim.fault_reason, sim.paused]}
		digest.update(sim.state.to_byte_array())
		digest.update(sim.last_loads.to_byte_array())
		if index >= _warmup_ticks:
			samples.append(elapsed)
	var sorted := samples.duplicate()
	sorted.sort()
	var reverse_gate_exercised := float(fixture.nominal_u_mps) < 0.0 and absf(float(fixture.nominal_v_mps)) > 0.0 and body_cy_beta != 0.0
	return {
		"case_id": fixture.case_id,
		"complete": samples.size() == _sample_ticks,
		"sample_count": samples.size(),
		"unit": "microseconds_per_Simulation.step",
		"nearest_rank_p50_usec": _nearest_rank(sorted, 50.0),
		"nearest_rank_p95_usec": _nearest_rank(sorted, 95.0),
		"min_usec": sorted[0] if not sorted.is_empty() else 0,
		"max_usec": sorted[sorted.size() - 1] if not sorted.is_empty() else 0,
		"samples_usec": samples,
		"output_fingerprint": digest.finish().hex_encode(),
		"fixture": {
			"speed_mps": fixture.zero_wind_air_speed_mps,
			"nominal_alpha_rad": fixture.nominal_alpha_rad,
			"nominal_beta_rad": fixture.nominal_beta_rad,
			"zero_wind_air_alpha_rad": fixture.zero_wind_air_alpha_rad,
			"zero_wind_air_beta_rad": fixture.zero_wind_air_beta_rad,
			"u_mps": fixture.nominal_u_mps,
			"v_mps": fixture.nominal_v_mps,
			"w_mps": fixture.nominal_w_mps,
			"body_cy_beta_per_rad": body_cy_beta,
			"body_crossflow_area_m2": body_crossflow_area,
			"positive_stall_onset_rad": stall_onset_rad,
			"positive_stall_end_rad": stall_end_rad,
			"target_reverse_body_cy_term_nonzero": reverse_gate_exercised,
		},
	}


func _nearest_rank(sorted: PackedInt64Array, percentile: float) -> int:
	var rank: int = maxi(1, ceili(percentile * float(sorted.size()) / 100.0))
	return sorted[rank - 1]


func _sha256(path: String) -> String:
	var bytes: PackedByteArray = FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		return ""
	var digest := HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	digest.update(bytes)
	return digest.finish().hex_encode()


func _write_report(report: Dictionary) -> void:
	var file := FileAccess.open(_output, FileAccess.WRITE)
	if file == null:
		_failure = "cannot open output: " + str(FileAccess.get_open_error())
		printerr(_failure)
		return
	file.store_string(JSON.stringify(report, "\t", true, true) + "\n")
	file.flush()
	if file.get_error() != OK:
		_failure = "report write failed"
	file.close()


func _finish_error(reason: String) -> void:
	_failure = reason
	_write_report({
		"format": "openrc-reverse-flow-physics-step v1",
		"complete": false,
		"failure": _failure,
		"aircraft_id": AIRCRAFT_ID,
		"source": {"aero_sha256": _sha256("res://physics/aero.gd")},
		"machine": {"godot": Engine.get_version_info().string, "os": OS.get_name()},
		"cases": [],
	})
	quit(1)


func _fail(reason: String) -> bool:
	_failure = reason
	return false
