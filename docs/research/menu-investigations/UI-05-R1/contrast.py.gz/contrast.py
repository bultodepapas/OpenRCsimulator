from pathlib import Path
import subprocess, json
root = Path(__file__).resolve().parent
repo = root.parent.parent
engine = str(repo / '.tools/Godot_v4.7.2-stable_win64.exe')
records = []

def run(name, script, native=False, args=None, resolution='1280x720'):
    cmd = [engine] + ([] if native else ['--headless']) + ['--path', str(repo / 'app'), '--audio-driver', 'Dummy', '--resolution', resolution, '--script', str(script), '--'] + (args or [])
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    output = (root / (name + '.log')).read_text()
    records.append(dict(name=name, command=cmd, exit_code=result.returncode, errors='ERROR:' in output, failures=[line for line in output.splitlines() if 'FAIL' in line or 'INVALID' in line]))
    (root / 'contrast-validation.json').write_text(json.dumps(records, indent=2))
    print(json.dumps(records[-1]), flush=True)

baseline_root = root / 'baseline-app-root.gd'
baseline_root.write_text((repo / 'app/app_root.gd').read_text().replace('res://ui/home.gd', (root / 'reference.gd').as_posix()))
for name in ['ui_home_layout', 'ui_language', 'ui_home', 'ui_aircraft', 'controller_menu']:
    source = (repo / ('app/tests/test_' + name + '.gd')).read_text()
    source = source.replace('res://ui/home.gd', (root / 'reference.gd').as_posix()).replace('res://app_root.gd', baseline_root.as_posix())
    script = root / ('baseline-' + name + '.gd')
    script.write_text(source)
    run('baseline-' + name, script)

run('capture', root / 'capture.gd', native=True, args=['--directory=' + str(root)], resolution='1920x1080')
# Disposable stale-layout defect: compares only vehicle actions, ignoring printed key labels.
mutant = root / 'mutant.gd'
mutant.write_text((root / 'candidate.gd').read_text().replace('if rows == _legend_rows:', 'if not _legend_rows.is_empty() and rows[0][1] == _legend_rows[0][1]:'))
run('mutation-keyboard-layout', root / 'test_ui_home_legend.gd', args=['--home=' + str(mutant)])
