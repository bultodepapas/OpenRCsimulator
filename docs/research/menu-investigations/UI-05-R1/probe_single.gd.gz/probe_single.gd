extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var directory := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--directory="): directory = arg.trim_prefix("--directory=")
	if directory.is_empty():
		quit(2)
		return
	var scripts := {reference = load(directory.path_join("reference.gd")), candidate = load(directory.path_join("candidate.gd"))}
	var samples := []
	var counts := []
	for pair in range(24):
		for variant: String in (["reference", "candidate"] if pair % 2 == 0 else ["candidate", "reference"]):
			var home: Control = scripts[variant].new()
			root.add_child(home)
			for frame in range(4): await process_frame
			for workload: String in ["legend", "same_aircraft", "focus_regain"]:
				var before: int = home.keys_legend.get_child(0).get_instance_id()
				var begin := Time.get_ticks_usec()
				for repeat in range(1):
					if workload == "legend": home._fill_legend()
					elif workload == "same_aircraft": home.set_aircraft(home.aircraft_id)
					else: home.notification(NOTIFICATION_APPLICATION_FOCUS_IN)
				samples.append({pair = pair, variant = variant, workload = workload, calls = 1, usec = Time.get_ticks_usec() - begin})
				counts.append({variant = variant, workload = workload, nodes = home.keys_legend.find_children("*", "", true, false).size(), reused = before == home.keys_legend.get_child(0).get_instance_id()})
				await process_frame
			home.free()
			await process_frame
	var file := FileAccess.open(directory.path_join("timings.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({samples = samples, counts = counts, engine = Engine.get_version_info(), display = DisplayServer.get_name(), scope = "Home UI only; one call per sample, frame boundary between workloads; no aircraft backdrop rebuild or total Home/FPS claim"}, "\t"))
	file.close()
	print("Home legend benchmark complete")
	quit()
