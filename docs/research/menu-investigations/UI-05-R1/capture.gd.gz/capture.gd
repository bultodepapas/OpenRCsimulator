extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var directory := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--directory="): directory = arg.trim_prefix("--directory=")
	var scripts := {reference = load(directory.path_join("reference.gd")), candidate = load(directory.path_join("candidate.gd"))}
	var records := []
	var passed := true
	for locale: String in ["en", "es"]:
		TranslationServer.set_locale(locale)
		for aircraft: String in ["jensen-das-ugly-stik-60", "xcell-60-research"]:
			for controller in [false, true]:
				var images := {}
				var label := locale + ("-heli" if aircraft == "xcell-60-research" else "-plane") + ("-controller" if controller else "-keyboard")
				for variant: String in ["reference", "candidate"]:
					var home: Control = scripts[variant].new()
					home.set_aircraft(aircraft)
					home.set_controller_devices("Example Radio" if controller else "", "Example Gamepad" if controller else "")
					root.add_child(home)
					for frame in range(8): await process_frame
					# Force the same unchanged refresh paths before the captured frame.
					home._fill_legend()
					home.notification(NOTIFICATION_APPLICATION_FOCUS_IN)
					for frame in range(4): await process_frame
					await RenderingServer.frame_post_draw
					var img := root.get_texture().get_image()
					img.save_png(directory.path_join(label + "-" + variant + ".png"))
					images[variant] = img
					home.free()
					await process_frame
				var equal: bool = images.reference.get_data() == images.candidate.get_data()
				passed = passed and equal
				records.append({case = label, pixels_equal = equal, size = str(images.reference.get_size())})
	var file := FileAccess.open(directory.path_join("captures.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({complete = passed, cases = records, scope = "Home UI on the same plain viewport; EN/ES, airplane/helicopter, keyboard/controller; no 3D backdrop"}, "\t"))
	file.close()
	print("Home capture parity: ", passed)
	quit(0 if passed else 1)
