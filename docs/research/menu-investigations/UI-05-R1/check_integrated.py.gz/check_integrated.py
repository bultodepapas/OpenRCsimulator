from pathlib import Path
import subprocess, json
root = Path(__file__).resolve().parent
repo = root.parent.parent
records = []
tests = [('home_legend', False), ('home_legend', True), ('home_layout', False), ('language', False), ('input', False), ('home', False), ('aircraft', False)]
cases = [(('native-' if native else '') + name, 'res://tests/test_ui_' + name + '.gd', native) for name, native in tests]
cases += [('controls-reference', 'res://tests/test_controls_reference.gd', False), ('controller-menu', 'res://tests/test_controller_menu.gd', False)]
for name, script, native in cases:
    cmd = [str(repo / '.tools/Godot_v4.7.2-stable_win64.exe')] + ([] if native else ['--headless']) + ['--path', str(repo / 'app'), '--audio-driver', 'Dummy', '--resolution', '1280x720', '--script', script]
    with (root / ('integrated-' + name + '.log')).open('w') as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    output = (root / ('integrated-' + name + '.log')).read_text()
    records.append(dict(name=name, command=cmd, exit_code=result.returncode, errors='ERROR:' in output, failures=[line for line in output.splitlines() if 'FAIL' in line]))
    (root / 'integrated-validation.json').write_text(json.dumps(records, indent=2))
    print(json.dumps(records[-1]), flush=True)
