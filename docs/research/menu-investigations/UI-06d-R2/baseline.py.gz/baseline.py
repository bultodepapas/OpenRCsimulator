from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
repo=root.parent.parent
app_root=root/'baseline-app-root.gd'
app_root.write_text((repo/'app/app_root.gd').read_text().replace('res://ui/home.gd',(root/'reference.gd').as_posix()))
script=root/'baseline-home-test.gd'
script.write_text((repo/'app/tests/test_ui_home.gd').read_text().replace('res://ui/home.gd',(root/'reference.gd').as_posix()).replace('res://app_root.gd',app_root.as_posix()))
cmd=[str(repo/'.tools/Godot_v4.7.2-stable_win64.exe'),'--headless','--path',str(repo/'app'),'--audio-driver','Dummy','--script',str(script)]
with (root/'baseline-home.log').open('w') as log:
    result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
output=(root/'baseline-home.log').read_text()
record=dict(command=cmd,exit_code=result.returncode,checks=output.count('ok   '),issues=[line for line in output.splitlines() if 'FAIL' in line or 'ERROR:' in line or 'INVALID' in line])
(root/'baseline-home.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
