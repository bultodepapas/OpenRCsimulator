extends SceneTree
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	var directory := OS.get_cmdline_user_args()[0]
	var measurements := []
	for variant in ["reference", "candidate"]:
		var script: Script = load(directory.path_join(variant + ".gd"))
		for height in [720, 1080]:
			root.size = Vector2i(1280 if height == 720 else 1920, height)
			for lang in ["en", "es"]:
				TranslationServer.set_locale(lang)
				var home: Control = script.new()
				home.set_aircraft("xcell-60-research")
				home.set_controller_devices("", "")
				root.add_child(home)
				for frame in range(10): await process_frame
				var label := "%s-%s-%d" % [variant, lang, height]
				var sidebar: Control = home.get_node("Sidebar")
				measurements.append({case = label, sidebar_width = sidebar.size.x, button_size = str(home.start_button.size), fly_bottom = home.fly_button.get_global_rect().end.y, focus = root.gui_get_focus_owner().name})
				if lang == "es":
					await RenderingServer.frame_post_draw
					root.get_texture().get_image().save_png(directory.path_join(label + ".png"))
				if height == 720:
					var scroll: ScrollContainer = sidebar.get_node("Scroll")
					scroll.scroll_vertical = 10000
					for frame in range(4): await process_frame
					measurements[-1].legend_bottom_scrolled = home.keys_legend.get_global_rect().end.y
					if lang == "es":
						await RenderingServer.frame_post_draw
						root.get_texture().get_image().save_png(directory.path_join(label + "-scrolled.png"))
				home.free()
				await process_frame
	var file := FileAccess.open(directory.path_join("capture-metrics.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(measurements, "\t"))
	file.close()
	quit()
