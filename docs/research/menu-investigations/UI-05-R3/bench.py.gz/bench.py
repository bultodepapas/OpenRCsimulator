from pathlib import Path
import subprocess,json,statistics
out=Path(__file__).resolve().parent
repo=out.parents[1]
source=(out/'snapshot/app/app_root.gd').read_text()
(out/'app-candidate.gd').write_text(source)
(out/'app-reference.gd').write_text(source.replace('home_scene.request_aircraft(id)','home_scene.show_aircraft(id)'))
results=[]
for run in range(5):
    for variant in (['reference','candidate'] if run%2==0 else ['candidate','reference']):
        cmd=[str(repo/'.tools/Godot_v4.7.2-stable_win64.exe'),'--path',str(out/'snapshot/app'),'--audio-driver','Dummy','--resolution','1280x720','--script',str(out/'bench.gd'),'--',str(out),variant,str(run)]
        with (out/f'{variant}-{run}.log').open('w') as log:
            proc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
        text=(out/f'{variant}-{run}.log').read_text()
        assert proc.returncode==0 and 'ERROR:' not in text, text
        data=json.loads((out/f'{variant}-{run}.json').read_text())
        assert all(r['card_matches'] and r['preview_matches'] for r in data['records']), data
        results.append(data)
        print(variant,run,'complete',flush=True)
summary={}
for variant in ['reference','candidate']:
    for id in sorted({r['id'] for d in results for r in d['records']}):
        for warm in [False,True]:
            rows=[r for d in results if d['variant']==variant for r in d['records'] if r['id']==id and (r['cycle']>0)==warm]
            frames=sorted(v for r in rows for v in r['frames_usec'])
            summary[f'{variant}/{id}/{"warm" if warm else "first"}']={
                'count':len(rows),**{k.replace('_usec','_ms'):statistics.median(r[k] for r in rows)/1000 for k in ['handler_usec','feedback_usec','ready_usec']},
                'max_frame_ms':max(frames,default=0)/1000,'p95_frame_ms':frames[min(len(frames)-1,int(len(frames)*.95))]/1000 if frames else None,
                'frames_over':{str(ms):sum(v>ms*1000 for v in frames) for ms in [33,50,100]}}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
