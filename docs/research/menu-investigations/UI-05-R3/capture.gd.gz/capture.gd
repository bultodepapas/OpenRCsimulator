extends SceneTree
class PendingResources:
	extends Node
	func path_for(id: String) -> String: return id
	func request(_path: String, _callback: Callable) -> void: pass
	func cancel_for(_owner: Object, _release := true) -> void: pass
func _initialize() -> void: _run.call_deferred()
func _run() -> void:
	var directory: String = OS.get_cmdline_user_args()[0]
	var app: Node = load("res://app_root.tscn").instantiate()
	app.user_args = PackedStringArray()
	app.preferences_path = directory.path_join("capture-settings.cfg")
	DirAccess.remove_absolute(app.preferences_path)
	root.add_child(app)
	var pending := PendingResources.new()
	app.add_child(pending)
	app.home_scene.preview_resources = pending
	var control := OS.get_cmdline_user_args().size() > 1
	if control:
		# Observer control: same World/audio lifetime, no preview request at all.
		app.home.set_aircraft("sebart-avanti-s-a200-p100rx")
		app.home.set_preview_state("loading")
	else:
		app.set_aircraft("sebart-avanti-s-a200-p100rx")
	for locale in ["en", "es"]:
		app.set_language(locale)
		for frame in 6: await process_frame
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png(directory.path_join(("control-" if control else "pending-") + locale + ".png"))
	app.free()
	for frame in 4: await process_frame
	DirAccess.remove_absolute(directory.path_join("capture-settings.cfg"))
	quit()
