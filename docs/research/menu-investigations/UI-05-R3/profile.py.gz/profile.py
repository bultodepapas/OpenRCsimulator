from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
repo=out.parents[1]
app=out/'snapshot/app'
def instrument(path, markers):
    p=app/path; source=p.read_text(); (out/(p.name+'.reference')).write_text(source)
    for i,(marker,label) in enumerate(markers):
        assert marker in source, (path,marker)
        after='\n\tprint("STAGE '+label+' ", (Time.get_ticks_usec() - _probe_tick) / 1000.0)\n\t_probe_tick = Time.get_ticks_usec()'
        source=source.replace(marker,marker+after,1)
    first=markers[0][0]
    source=source.replace(first,'\tvar _probe_tick := Time.get_ticks_usec()\n'+first,1)
    p.write_text(source)
instrument('render/airplane.gd', [
 ('\tvar resolved: Dictionary = registry.describe(family)','manifest'),
 ('\tvar airplane: Dictionary = builder.call("build", manifest) if manifest.version == 2 else builder.call("build")','builder'),
 ('\tvar verified: Dictionary = registry.validate_derived(manifest, airplane)','derived'),
 ('\tvar glow: Dictionary = model.get("propulsion", {}).get("glow", {})','data')])
instrument('ui/home_scene.gd',[
 ('\tvar built: Dictionary = _preview_models[id] if retained else AirplaneBuilder.build(id)','model'),
 ('\tvar geometry: Dictionary = _preview_geometry[id]','pose_collect'),
 ('\tShadow.bind_model(_shadow, airplane.root, geometry.shape)','bind_shadow'),
 ('\tShadow.update(_shadow, basis, pos, extent.x, extent.y, direction, strength)','dress_update')])
cmd=[str(repo/'.tools/Godot_v4.7.2-stable_win64.exe'),'--path',str(app),'--audio-driver','Dummy','--resolution','1280x720','--script',str(out/'profile.gd')]
try:
    with (out/'profile.log').open('w') as log:
        result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    print((out/'profile.log').read_text())
    print('exit', result.returncode)
finally:
    for path in ['render/airplane.gd','ui/home_scene.gd']:
        p=app/path;p.write_text((out/(p.name+'.reference')).read_text())
