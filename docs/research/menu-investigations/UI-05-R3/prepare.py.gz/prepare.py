from pathlib import Path
import subprocess, shutil, json, hashlib
repo=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
dest=out/'snapshot'
dest.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','app'],cwd=repo,text=True).splitlines()
sources={}
for name in dict.fromkeys(paths):
    src=repo/name
    if not src.is_file(): continue
    target=dest/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,target)
    sources[name]=hashlib.sha256(src.read_bytes()).hexdigest()
for manifest in (dest/'app/data/aircraft_models').glob('*.json'):
    data=json.loads(manifest.read_text())
    records=[data.get('source_registry',{}), data.get('geometry',{}).get('source',{})]+data.get('authoring_sources',[])
    for rec in records:
        name=rec.get('path','')
        if name.startswith('res://') or not name: continue
        src=repo/name
        if src.is_file():
            target=dest/name; target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,target)
            sources[name]=hashlib.sha256(src.read_bytes()).hexdigest()
cache=dest/'app/.godot'
cache.mkdir(exist_ok=True)
shutil.copytree(repo/'app/.godot/imported',cache/'imported')
for name in ['uid_cache.bin','global_script_class_cache.cfg']:
    shutil.copy2(repo/'app/.godot'/name,cache/name)
(out/'sources.json').write_text(json.dumps(sources,indent=2))
print('snapshot ready',len(sources))
