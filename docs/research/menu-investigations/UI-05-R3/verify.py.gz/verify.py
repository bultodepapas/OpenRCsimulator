from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent
repo=out.parents[1]
exe=repo/'.tools/Godot_v4.7.2-stable_win64.exe'
cases=[('requests-headless','test_ui_preview_requests',True),('resources-final','test_ui_preview_resources',True),('requests-native','test_ui_preview_requests',False),('language','test_ui_language',True),('layout','test_ui_home_layout',True),('start-layout','test_ui_home_start_layout',True),('controller','test_controller_menu',True),('input','test_ui_input',True),('shadow','test_projected_shadow',True)]
results=[]
for label,test,headless in cases:
    cmd=[str(exe),'--path',str(out/'snapshot/app'),'--audio-driver','Dummy','--script','res://tests/'+test+'.gd']
    if headless: cmd.append('--headless')
    with (out/(label+'.log')).open('w') as log:
        proc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    text=(out/(label+'.log')).read_text()
    ok=proc.returncode==0 and not any(s in text for s in ['ERROR:','FAIL ','failed checks'])
    results.append(dict(test=test,label=label,command=cmd,exit_code=proc.returncode,passed=ok))
    print(label,ok,text[-700:],flush=True)
(out/'checks.json').write_text(json.dumps(results,indent=2))
raise SystemExit(not all(r['passed'] for r in results))
