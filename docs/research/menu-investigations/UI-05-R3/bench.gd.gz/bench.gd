extends SceneTree
var frame_ticks: Array[int] = []
func _initialize() -> void:
	process_frame.connect(func() -> void: frame_ticks.append(Time.get_ticks_usec()))
	_run.call_deferred()
func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var directory: String = args[0]
	var variant: String = args[1]
	var run_id: String = args[2]
	var app: Node = load(directory.path_join("app-" + variant + ".gd")).new()
	app.user_args = PackedStringArray()
	app.preferences_path = directory.path_join("bench-settings.cfg")
	DirAccess.remove_absolute(app.preferences_path)
	root.add_child(app)
	for i in 6: await process_frame
	var records := []
	for cycle in 5:
		for id: String in ["jensen-das-ugly-stik-60", "gp-extra-300s-60", "sebart-avanti-s-a200-p100rx"]:
			await process_frame
			var frame_start := frame_ticks.size() - 1
			var begin := Time.get_ticks_usec()
			app.set_aircraft(id)
			var handler := Time.get_ticks_usec() - begin
			await RenderingServer.frame_post_draw
			var feedback := Time.get_ticks_usec() - begin
			var card_matches: bool = app.home.aircraft_id == id
			var loading_visible: bool = app.home.aircraft_preview_label.visible
			var ready := feedback
			if app.home_scene.preview_pending:
				while app.home_scene.preview_pending and Time.get_ticks_usec() - begin < 15000000:
					await process_frame
				await RenderingServer.frame_post_draw
				ready = Time.get_ticks_usec() - begin
			# Include the boundary AFTER node processing: otherwise a blocking
			# final build would disappear from the frame-interval samples.
			await process_frame
			var intervals := []
			for index in range(frame_start + 1, frame_ticks.size()):
				intervals.append(frame_ticks[index] - frame_ticks[index - 1])
			records.append({cycle = cycle, id = id, handler_usec = handler, feedback_usec = feedback, ready_usec = ready,
				card_matches = card_matches, loading_visible = loading_visible, preview_matches = app.home_scene.airplane.aircraft_id == id,
				frames_usec = intervals, resource_count = app._home_preview_resources._resources.size()})
			if cycle == 0 and id == "sebart-avanti-s-a200-p100rx" and run_id == "0":
				root.get_texture().get_image().save_png(directory.path_join(variant + ".png"))
			for i in 2: await process_frame
	var memory := Performance.get_monitor(Performance.MEMORY_STATIC)
	app.free()
	for i in 5: await process_frame
	DirAccess.remove_absolute(directory.path_join("bench-settings.cfg"))
	var file := FileAccess.open(directory.path_join(variant + "-" + run_id + ".json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({variant = variant, run = run_id, records = records, static_memory = memory}, "\t"))
	file.close()
	quit()
