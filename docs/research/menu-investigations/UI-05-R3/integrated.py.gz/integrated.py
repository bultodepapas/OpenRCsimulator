from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent
repo=out.parents[1]
results=[]
for name,script in [('resources','test_ui_preview_resources'),('requests','test_ui_preview_requests'),('aircraft','test_ui_aircraft')]:
    cmd=[str(repo/'.tools/Godot_v4.7.2-stable_win64.exe'),'--headless','--path',str(repo/'app'),'--audio-driver','Dummy','--script','res://tests/'+script+'.gd']
    with (out/('integrated-'+name+'.log')).open('w') as log: proc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    text=(out/('integrated-'+name+'.log')).read_text()
    ok=proc.returncode==0 and not any(s in text for s in ['ERROR:','FAIL '])
    results.append(dict(name=name,command=cmd,exit_code=proc.returncode,passed=ok))
    print(name,ok,text[-400:],flush=True)
(out/'integrated.json').write_text(json.dumps(results,indent=2))
raise SystemExit(not all(r['passed'] for r in results))
