extends SceneTree
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://ui05_r3_profile.cfg"))
	var app: Node = load("res://app_root.tscn").instantiate()
	app.user_args = PackedStringArray()
	app.preferences_path = "user://ui05_r3_profile.cfg"
	root.add_child(app)
	await process_frame
	await process_frame
	for id in ["gp-extra-300s-60", "sebart-avanti-s-a200-p100rx", "turbo-lumber-evolution", "gp-extra-300s-60", "sebart-avanti-s-a200-p100rx"]:
		print("SELECT ", id)
		var held: PackedScene
		if id == "sebart-avanti-s-a200-p100rx":
			var resource_start := Time.get_ticks_usec()
			held = load("res://assets/aircraft/avanti-s-a200/avanti_s.glb")
			print("ISOLATED_LOAD ", (Time.get_ticks_usec() - resource_start) / 1000.0)
			resource_start = Time.get_ticks_usec()
			var instance := held.instantiate()
			print("ISOLATED_INSTANCE ", (Time.get_ticks_usec() - resource_start) / 1000.0)
			instance.free()
		var start := Time.get_ticks_usec()
		app.set_aircraft(id)
		print("HANDLER ", (Time.get_ticks_usec() - start) / 1000.0)
		await RenderingServer.frame_post_draw
		print("DRAW ", (Time.get_ticks_usec() - start) / 1000.0)
		held = null
	app.queue_free()
	await process_frame
	await process_frame
	quit()
