from pathlib import Path
import subprocess,json,statistics
root=Path(__file__).resolve().parent
repo=root.parent.parent
source=(root/'snapshot/app/app_root.gd').read_text()
for variant in ['reference','candidate']:
    (root/('app-'+variant+'.gd')).write_text(source.replace('res://ui/home_scene.gd',(root/(variant+'.gd')).as_posix()))
cmd=[str(repo/'.tools/Godot_v4.7.2-stable_win64.exe'),'--path',str(root/'snapshot/app'),'--audio-driver','Dummy','--resolution','1280x720','--script',str(root/'selection.gd'),'--',str(root)]
with (root/'selection.log').open('w') as log:
    result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
output=(root/'selection.log').read_text()
print(output)
assert result.returncode==0 and 'ERROR:' not in output
data=json.loads((root/'selection.json').read_text())
assert all(s['card_matches'] and s['preview_matches'] for s in data)
summary={id:{v:{key:statistics.median(s[key] for s in data if s['id']==id and s['variant']==v and s['cycle']>0) for key in ['usec','through_draw_usec']} for v in ['reference','candidate']} for id in sorted({s['id'] for s in data})}
(root/'selection-run.json').write_text(json.dumps(dict(command=cmd,exit_code=result.returncode,warm_median_usec=summary),indent=2))
print(json.dumps(summary,indent=2))
