extends SceneTree
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	var directory := OS.get_cmdline_user_args()[0]
	var records := []
	var captures := {}
	var pixels := []
	var memory := []
	var ids := ["jensen-das-ugly-stik-60", "gp-extra-300s-60", "sebart-avanti-s-a200-p100rx"]
	for lighting: String in ["day", "night"]:
		for variant: String in ["reference", "candidate"]:
			var script: Script = load(directory.path_join(variant + ".gd"))
			var config: Dictionary = load("res://environment/time_of_day_config.gd").defaults()
			if lighting == "night":
				config.mode = "astronomical"
				config.local_seconds = 0
			var scene: Node3D = script.new(ids[0], "res://data/fields/default.json", config)
			root.add_child(scene)
			for frame in range(6): await process_frame
			var initial_memory := Performance.get_monitor(Performance.MEMORY_STATIC)
			var warm_memory := initial_memory
			for cycle in range(5):
				for id: String in ids:
					await process_frame
					var begin := Time.get_ticks_usec()
					scene.show_aircraft(id)
					if scene.airplane.get("aircraft_id", "") != id:
						push_error("Preview did not select " + id)
						quit(2)
						return
					var elapsed := Time.get_ticks_usec() - begin
					await RenderingServer.frame_post_draw
					var presented := Time.get_ticks_usec() - begin
					records.append({variant = variant, lighting = lighting, id = id, cycle = cycle, usec = elapsed, through_draw_usec = presented})
					for frame in range(4): await process_frame
					if cycle == 1: warm_memory = Performance.get_monitor(Performance.MEMORY_STATIC)
					if cycle == 3 or cycle == 4:
						await RenderingServer.frame_post_draw
						var picture := root.get_texture().get_image()
						var key := lighting + "-" + id
						if cycle == 3:
							picture.save_png(directory.path_join(variant + "-self-" + key + ".png"))
							continue
						picture.save_png(directory.path_join(variant + "-" + key + ".png"))
						if variant == "reference": captures[key] = picture
						else: pixels.append({case = key, equal = picture.get_data() == captures[key].get_data()})
			memory.append({variant = variant, lighting = lighting, initial_static_bytes = initial_memory, warm_static_bytes = warm_memory, scene_nodes = scene.find_children("*", "", true, false).size()})
			scene.free()
			for frame in range(6): await process_frame
	var file := FileAccess.open(directory.path_join("benchmark.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({samples = records, pixels = pixels, memory = memory}, "\t"))
	file.close()
	print("Preview benchmark complete; comparisons: ", pixels)
	captures.clear()
	quit()
