extends SceneTree
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	var directory := OS.get_cmdline_user_args()[0]
	var records := []
	for variant: String in ["reference", "candidate"]:
		var app: Node = load(directory.path_join("app-" + variant + ".gd")).new()
		app.user_args = PackedStringArray()
		app.preferences_path = directory.path_join("selection-settings.cfg")
		DirAccess.remove_absolute(app.preferences_path)
		root.add_child(app)
		for frame in range(6): await process_frame
		for cycle in range(5):
			for id: String in ["jensen-das-ugly-stik-60", "gp-extra-300s-60", "sebart-avanti-s-a200-p100rx"]:
				await process_frame
				var begin := Time.get_ticks_usec()
				app.set_aircraft(id)
				var elapsed := Time.get_ticks_usec() - begin
				await RenderingServer.frame_post_draw
				var presented := Time.get_ticks_usec() - begin
				records.append({variant = variant, cycle = cycle, id = id, usec = elapsed, through_draw_usec = presented, card_matches = app.home.aircraft_id == id, preview_matches = app.home_scene.airplane.aircraft_id == id, focus = root.gui_get_focus_owner().name})
				for frame in range(3): await process_frame
		DirAccess.remove_absolute(app.preferences_path)
		app.free()
		for frame in range(6): await process_frame
	var file := FileAccess.open(directory.path_join("selection.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(records, "\t"))
	file.close()
	quit()
