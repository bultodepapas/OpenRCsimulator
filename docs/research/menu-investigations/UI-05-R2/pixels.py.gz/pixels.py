from pathlib import Path
from PIL import Image
import numpy as np,json
root=Path(__file__).resolve().parent
def difference(a,b):
    aa=np.asarray(Image.open(a).convert('RGB')).astype(np.int16)
    bb=np.asarray(Image.open(b).convert('RGB')).astype(np.int16)
    delta=np.abs(aa-bb)
    return dict(changed_pixels=int(np.count_nonzero(np.any(delta,axis=2))),max_channel_delta=int(delta.max()),mean_channel_delta=float(delta.mean()))
records=[]
for path in root.glob('reference-*.png'):
    if path.name.startswith('reference-self-'): continue
    name=path.name.removeprefix('reference-')
    records.append(dict(case=name,reference_repeat=difference(path,root/('reference-self-'+name)),candidate_repeat=difference(root/('candidate-'+name),root/('candidate-self-'+name)),comparison=difference(path,root/('candidate-'+name))))
(root/'pixel-comparison.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))
