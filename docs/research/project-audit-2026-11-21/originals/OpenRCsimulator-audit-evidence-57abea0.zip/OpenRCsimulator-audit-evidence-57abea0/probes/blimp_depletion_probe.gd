extends SceneTree
const Session=preload("res://sim/airship/session.gd")
const Data=preload("res://physics/airship/airship_data.gd")
func _initialize() -> void:
    var raw: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/airships/rc-blimp-5m.json"))
    raw.battery.capacity.value=0.05
    raw.battery.initial_soc.value=0.05
    raw.battery.cutoff_cell_voltage.value=3.2
    var s=Session.new()
    root.add_child(s)
    if not s.prepare({}, {data=raw,altitude_m=100.0}):
        print("FAIL prepare ",s.load_error)
        quit(1); return
    if not s.resume():
        print("FAIL resume ",s.pause_reason)
        quit(1); return
    print("start SOC=",s.sim.continuous[Data.SOC]," capacity_Ah=",s.model.battery.capacity," cutoff_cell=",s.model.battery.cutoff_cell," OCV0=",s.model.battery.ocv[1])
    var input=PackedFloat64Array([0.0,0.0,0.0,1.0])
    var reached=false
    var saved_body=PackedFloat64Array()
    var saved_cont=PackedFloat64Array()
    var crossing_tick=-1
    for n in 24000:
        if not s.tick_once(input):
            print("FAIL tick=",s.sim.tick," fault=",s.fault_reason," crash=",s.crash)
            quit(1); return
        var soc: float=s.sim.continuous[Data.SOC]
        if n%480==479:
            var info: Dictionary=s.telemetry_info()
            print("periodic tick=",s.sim.tick," soc=",soc," current_A=",info.battery.current_a," power_W=",info.battery.power_w," thrust_N=",info.thrust_n," altitude=",-s.sim.state[2])
        if soc<=0.0:
            crossing_tick=s.sim.tick
            saved_body=s.state_snapshot()
            saved_cont=s.continuous_snapshot()
            var info: Dictionary=s.telemetry_info()
            print("cross tick=",crossing_tick," soc=",soc," current_A=",info.battery.current_a," power_W=",info.battery.power_w," thrust_N=",info.thrust_n)
            reached=true
            break
    if not reached:
        print("FAIL did not deplete")
        quit(1); return
    for i in 480:
        if not s.tick_once(input):
            print("FAIL continuation tick=",s.sim.tick," fault=",s.fault_reason," crash=",s.crash)
            quit(1); return
    var last_body=s.state_snapshot()
    var last_cont=s.continuous_snapshot()
    var endinfo: Dictionary=s.telemetry_info()
    print("after tick=",s.sim.tick," soc=",last_cont[Data.SOC]," current_A=",endinfo.battery.current_a," power_W=",endinfo.battery.power_w," thrust_N=",endinfo.thrust_n," altitude=",-s.sim.state[2])
    var restored: bool=s.restore_checkpoint(saved_body,saved_cont)
    if not restored:
        print("FAIL restore")
        quit(1); return
    for i in 480:
        if not s.tick_once(input):
            print("FAIL replay continuation tick=",s.sim.tick," fault=",s.fault_reason," crash=",s.crash)
            quit(1); return
    var same_body=s.state_snapshot().to_byte_array()==last_body.to_byte_array()
    var same_cont=s.continuous_snapshot().to_byte_array()==last_cont.to_byte_array()
    print("restore=",restored," replay_body_exact=",same_body," replay_cont_exact=",same_cont," ticks=480")
    s.queue_free()
    print("audit_depletion_complete")
    quit()
