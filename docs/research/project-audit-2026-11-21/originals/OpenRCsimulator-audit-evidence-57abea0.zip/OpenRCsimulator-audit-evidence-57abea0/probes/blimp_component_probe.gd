extends SceneTree
const Data = preload("res://physics/airship/airship_data.gd")
const Dynamics = preload("res://physics/airship/airship_dynamics.gd")
const M = preload("res://physics/math3d.gd")
const ZERO = [0.0, 0.0, 0.0]
var model: Dictionary
var body = PackedFloat64Array([0.0,0.0,-50.0, 0.0,0.0,0.0, 1.0,0.0,0.0,0.0, 0.0,0.0,0.0])
var inp = PackedFloat64Array([0.0,0.0,0.0,1.0])
func eval_state(c: PackedFloat64Array) -> Dictionary:
    return Dynamics.evaluate(model, body, c, inp, PackedFloat64Array(ZERO), Callable(), true)
func axpy(x: PackedFloat64Array, a: float, y: PackedFloat64Array) -> PackedFloat64Array:
    var z = x.duplicate()
    for i in z.size(): z[i] += a*y[i]
    return z
func _initialize() -> void:
    var raw: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/airships/rc-blimp-5m.json"))
    var loaded: Dictionary = Data.load_document(raw)
    if not loaded.ok:
        print("FAILED stock validation ",loaded.errors)
        quit(1); return
    var d: Dictionary = Data.derive(loaded.data,1.225,9.80665,0.0)
    if not d.ok:
        print("FAILED stock derivation ",d.errors)
        quit(1); return
    model = d.model
    var c = PackedFloat64Array()
    c.resize(Data.CONTINUOUS_SIZE)
    c[Data.SOC] = 1.0
    inp = PackedFloat64Array([0.0,0.0,0.0,0.0])
    for u in [-3.0,3.0]:
        body[3]=u
        body[4]=0.5
        var result = eval_state(c)
        var total := 0.0
        for fin: Dictionary in result.info.fins:
            var f: PackedFloat64Array = fin.force
            var power: float = u*f[0]+0.5*f[1]
            total += power
            print("fin u=",u," name=",fin.id," power_W=",power," force=",f)
        print("fin_total u=",u," power_W=",total)
    body[3]=0.0
    body[4]=0.0
    raw.battery.cutoff_cell_voltage.value=3.2
    var altered: Dictionary = Data.load_document(raw)
    if not altered.ok:
        print("FAILED altered validation ",altered.errors)
        quit(1); return
    d=Data.derive(altered.data,1.225,9.80665,0.0)
    if not d.ok:
        print("FAILED altered derivation ",d.errors)
        quit(1); return
    model = d.model
    c=PackedFloat64Array([0.25,0.25,0.1,0.0, 0.0,0.0,0.0, 0.0,0.0,0.0, 0.0000001])
    inp=PackedFloat64Array([0.0,0.0,0.0,1.0])
    var h: float=1.0/240.0
    for t in 481:
        var sample: Dictionary=eval_state(c)
        if t in [0,1,2,240,480]:
            print("soc_sample tick=",t," soc=",c[Data.SOC]," dSOC=",sample.derivative[Data.SOC]," motors=",c.slice(0,4)," battery=",sample.info.battery," thrust=",sample.info.thrust_n)
        var k1: PackedFloat64Array=sample.derivative
        var k2: PackedFloat64Array=eval_state(axpy(c,h/2.0,k1)).derivative
        var k3: PackedFloat64Array=eval_state(axpy(c,h/2.0,k2)).derivative
        var k4: PackedFloat64Array=eval_state(axpy(c,h,k3)).derivative
        for i in c.size(): c[i]+=h/6.0*(k1[i]+2.0*k2[i]+2.0*k3[i]+k4[i])
    print("audit_probe_complete")
    quit()
