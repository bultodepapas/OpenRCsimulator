extends SceneTree
const Phoenix := preload("res://workshop/creator/phoenix/physics.gd")
const Packages := preload("res://workshop/creator/packages.gd")
const Propulsion := preload("res://physics/propulsion.gd")

func _initialize() -> void:
	var results: Array = []
	var base_thrust := NAN
	var base_fixed := NAN
	for count: int in [1, 2, 4, 8]:
		var block := {format = Phoenix.FORMAT, airfoil = "Synthetic", section = {
			slope = 6.0, cl_zero = 0.0, cl_at_incidence = 0.0, cl_max = 1.3, cl_min = -1.3,
			cd_min = 0.02, cl_min_drag = 0.0, stall_width_deg = 4.0},
			wing_lift_slope = Phoenix.helmbold(5.0), aspect_ratio = 5.0, body_drag_ratio = 0.03,
			mass_kg = 1.5, propeller = {diameter_m = 0.2, pitch_m = 0.15, max_rpm = 8000.0, blades = 2, count = count}}
		var ids := Phoenix.derive(block, "conventional-trainer-estimated-v1", "electric-3s-1250kv-9x6-estimated-v1", 1.0)
		if ids.is_empty():
			push_error("Failed to derive package for count %d" % count)
			quit(2)
			return
		var package: Dictionary = Packages.power(ids.power).value
		var point: Dictionary = Packages.static_thrust(package, 1.0)
		var model: Dictionary = Packages._runtime_propulsion(package, 1.0)
		var fixed: PackedFloat64Array = Propulsion.thrust_torque(PackedFloat64Array([0.0, 0.0, 0.0]), 8000.0, model, Packages.AIR_DENSITY)
		if count == 1:
			base_thrust = point.thrust_n
			base_fixed = fixed[0]
		results.append({count = count, diameter_m = package.propeller.diameter.value, ct0 = package.propeller.ct_table.value[0][1],
			rpm = point.rpm, thrust_n = point.thrust_n, expected_n = count * base_thrust,
			actual_to_expected = point.thrust_n / (count * base_thrust), fixed_rpm_thrust_n = fixed[0],
			fixed_ratio = fixed[0] / (count * base_fixed), theoretical_ratio = pow(float(count), -0.125)})
	var report := {engine = Engine.get_version_info().string, rows = results}
	var file := FileAccess.open("res://../multi-prop-result.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "  ") + "\n")
	file.close()
	print(JSON.stringify(report))
	print("MULTI_PROP_PROBE_COMPLETE")
	quit(0)
