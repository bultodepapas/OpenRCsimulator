extends SceneTree
const Conv := preload("res://workshop/creator/phoenix/converter.gd")
const Physics := preload("res://workshop/creator/phoenix/physics.gd")
const Setup := preload("res://workshop/creator/phoenix/setup.gd")
const Packages := preload("res://workshop/creator/packages.gd")
func polar() -> Array:
    var out: Array = []
    for step: int in range(-180, 181):
        var a := step * 0.5
        var cl := 0.1 + 5.7 * deg_to_rad(a)
        if a > 12.0:
            cl = 1.35 if a <= 14.0 else maxf(0.6, 1.35 - 0.05 * (a - 14.0))
        if cl < -1.0:
            cl = -1.0
        out.append_array([a, cl, 0.01 + 0.0005 * a * a])
    return out
func model() -> Dictionary:
    return {attributes = {Physical = {Weight = 1.5, Size = 1.5, Centre_of_gravity = {x = 0.0, y = 2.0, z = -5.0}, Fuselage_drag_area = {frontal = 0.006}}},
        airfoils = [{isMirrored = 1, attributes = {Airfoil = "Synthetic", Position = {x = 0.0, y = 2.0, z = 3.0}, Length = 0.75, Root_chord = 0.25, Tip_chord = 0.2, Dihedral = 3.0, Incidence = 1.0}, controlSurfaces = [{attributes = {Input = "Left Aileron", Length = 0.3, Tip_distance = 0.05, Root_chord = 0.06, Tip_chord = 0.05, Max_travel = 20.0}}]},
        {isMirrored = 1, attributes = {Airfoil = "Synthetic", Position = {x = 0.0, y = 2.5, z = -40.0}, Length = 0.25, Root_chord = 0.12, Tip_chord = 0.1}, controlSurfaces = [{attributes = {Input = "Left Elevator", Length = 0.2, Root_chord = 0.04, Tip_chord = 0.04}}]}],
        propulsion = [{type = "propeller", attributes = {Diameter = 0.2, Pitch = 0.15, Max_RPM = 8000.0, Blade_count = 2}}]}
func _initialize() -> void:
    var results: Array = []
    for count: int in [1, 2]:
        var m := model()
        if count == 2:
            var other: Dictionary = m.airfoils[0].duplicate(true)
            other.attributes.Position.y = 20.0
            m.airfoils.push_front(other)
        var summary := Conv.summarize(m, 0.01)
        var lifting := Conv.lifting_wings(summary)
        var placement := Conv._placement(summary)
        var values := Conv.definition_values(m, 0.01, placement.datum, lifting)
        var picked := Conv.layout_surfaces(m, lifting)
        var block := Physics.physics_block(m, 0.01, placement.datum, {"Synthetic": polar()}, picked.wing, picked.tail, picked.fin)
        var ids := Physics.derive(block, "conventional-trainer-estimated-v1", "electric-3s-1250kv-9x6-estimated-v1", 1.0)
        if ids.is_empty():
            push_error("derive failed")
            quit(2)
            return
        var package: Dictionary = Packages.airframe(ids.airframe).value
        var fitted := Setup.fit_planform(values["wing/span"], values["wing/root_chord"], values["wing/tip_chord"], Physics.DERIVED_TAPER_RANGE, Physics.DERIVED_ASPECT_RANGE)
        var shape := {span = values["wing/span"], root_chord = fitted.root, tip_chord = fitted.tip, dihedral_deg = 3.0, h_span = 0.5, h_chord = 0.11,
            h_position = PackedFloat64Array([0.45, 0.0, 0.0]), v_height = 0.25, v_chord = 0.11, v_position = PackedFloat64Array([0.45, 0.0, 0.0])}
        var aero := Packages.airframe_aero(package, shape)
        if aero.is_empty():
            push_error("aero failed")
            quit(2)
            return
        var profile := float(aero.quantities.CD0.value)
        var cd_section := float(block.section.cd_min)
        var body_area_equivalent: float = float(aero.wing_area) * (profile - cd_section)
        results.append({count = count, lifting_count = lifting.size(), fitted = fitted.changed, area = aero.wing_area,
            raw_main_aspect = block.aspect_ratio, emitted_aspect = aero.aspect_ratio, cd_section = cd_section,
            body_cd = block.body_drag_ratio, equivalent_body_area = body_area_equivalent, intended_body_area = 0.75 * 0.006})
    var f := FileAccess.open("res://../biplane-result.json", FileAccess.WRITE)
    f.store_string(JSON.stringify(results, "  ") + "\n")
    f.close()
    print(JSON.stringify(results))
    print("BIPLANE_PROBE_COMPLETE")
    quit(0)
