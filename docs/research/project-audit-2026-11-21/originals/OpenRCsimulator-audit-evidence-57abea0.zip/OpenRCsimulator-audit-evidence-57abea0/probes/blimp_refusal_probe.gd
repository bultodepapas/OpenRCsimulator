extends SceneTree
const Session=preload("res://sim/airship/session.gd")
func _initialize() -> void:
    var s=Session.new()
    root.add_child(s)
    var events={"resetting":0,"faulted":0}
    s.resetting.connect(func(): events.resetting+=1)
    s.faulted.connect(func(_why): events.faulted+=1)
    var first: bool=s.prepare({}, {})
    var first_error: String=s.load_error
    if not first:
        print("initial preparation failed ",first_error)
        quit(1); return
    var resumed: bool=s.resume()
    var stepped: bool=s.tick_once(PackedFloat64Array([0.0,0.0,0.0,0.0]))
    var prev_checkpoint: Dictionary=s.sim.checkpoint()
    var pre_tick: int=s.sim.tick
    var pre_reset: int=events.resetting
    print("before prepared=",first," resumed=",resumed," stepped=",stepped," tick=",pre_tick," checkpoint=",not prev_checkpoint.is_empty()," paused=",s.paused," fault=",s.fault_reason)
    var second: bool=s.prepare({}, {heading_deg=NAN})
    var after_checkpoint: Dictionary=s.sim.checkpoint()
    print("after result=",second," load_error=",s.load_error," tick=",s.sim.tick," checkpoint=",not after_checkpoint.is_empty()," fault=",s.fault_reason," sim_fault=",s.sim.fault_reason," paused=",s.paused," heading=",s.options.heading_deg," resetting_delta=",events.resetting-pre_reset," fault_count=",events.faulted)
    s.queue_free()
    print("audit_session_complete")
    quit()
