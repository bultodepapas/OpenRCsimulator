extends SceneTree
const Phoenix = preload("res://workshop/creator/phoenix/physics.gd")
const Packages = preload("res://workshop/creator/packages.gd")
func _initialize() -> void:
	var block := {
		"format": "openrc-phoenix-physics-v1", "section": {"slope": 5.0, "cl_zero": 0.0,
			"cl_at_incidence": 0.1, "cl_max": 1.4, "cl_min": -1.2, "cd_min": 0.025,
			"cl_min_drag": 0.0, "stall_width_deg": 10.0},
		"wing_lift_slope": 4.0, "aspect_ratio": 5.0, "body_drag_ratio": 0.02, "mass_kg": 2.0,
		"propeller": {"diameter_m": 0.23, "pitch_m": 0.15, "max_rpm": 8000.0, "count": 1}}
	var air := "conventional-trainer-estimated-v1"
	var power := "electric-3s-1250kv-9x6-estimated-v1"
	if not Phoenix.valid_block(block):
		printerr("INVALID_BLOCK")
		quit(1)
		return
	var before: int = Packages._derived_packages.size()
	var all_ok := true
	for i in range(100):
		var ids := Phoenix.derive(block, air, power, 0.7 + 0.001 * float(i))
		if ids.is_empty():
			all_ok = false
	var after: int = Packages._derived_packages.size()
	var payload_bytes := 0
	for value in Packages._derived_packages.values():
		payload_bytes += var_to_bytes(value).size()
	var ids := Phoenix.derive(block, air, power, 0.7)
	var after_duplicate: int = Packages._derived_packages.size()
	print("RESULT valid=%s derived=%s before=%d after=%d repeat=%d serialized_bytes=%d" % [Phoenix.valid_block(block), all_ok, before, after, after_duplicate, payload_bytes])
	quit(0 if all_ok and after - before == 200 and after_duplicate == after else 1)
