# Disposable evidence stub: an empty collision world is used in this test; these paths must never run.
extends RefCounted
static func _world_header_is_valid(_w): assert(false); return false
static func _proxy_is_valid(_p): assert(false); return false
static func nearby(_w, _n, _e, _d, _r) -> Array[Dictionary]: assert(false); return []
static func _aabb_sphere_overlap(_p, _n, _e, _d, _r): assert(false); return false
