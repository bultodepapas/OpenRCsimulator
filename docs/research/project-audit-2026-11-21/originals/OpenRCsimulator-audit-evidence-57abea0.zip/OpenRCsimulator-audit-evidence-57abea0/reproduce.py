#!/usr/bin/env python3
"""Reproduce selected OpenRC audit observations in new, disposable source fixtures.

Runs the checked runner from the supplied checkout; no repository source is modified.
The expected Phoenix-jet engine diagnostic is required, not counted as a clean pass.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / "manifests/fixtures.json").read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def check_file(path: Path, expected: str, context: str) -> None:
    if not path.is_file() or digest(path) != expected:
        raise RuntimeError(f"{context}: missing or SHA-256 mismatch: {path}")


def checked_path(base: Path, relative: str) -> Path:
    path = (base / relative).resolve()
    if not path.is_relative_to(base.resolve()):
        raise RuntimeError(f"Path escapes its root: {relative}")
    return path


def compare_values(actual, expected, where="result") -> None:
    if isinstance(expected, bool) or expected is None or isinstance(expected, str):
        if actual != expected or type(actual) is not type(expected):
            raise RuntimeError(f"{where}: {actual!r} != {expected!r}")
    elif isinstance(expected, (int, float)):
        if isinstance(actual, bool) or not isinstance(actual, (int, float)) or not math.isclose(
            actual, expected, rel_tol=1e-10, abs_tol=1e-12
        ):
            raise RuntimeError(f"{where}: {actual!r} != {expected!r}")
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise RuntimeError(f"{where}: list shape differs")
        for index, (a, e) in enumerate(zip(actual, expected)):
            compare_values(a, e, f"{where}[{index}]")
    elif isinstance(expected, dict):
        if not isinstance(actual, dict) or set(actual) != set(expected):
            raise RuntimeError(f"{where}: object fields differ")
        for key in expected:
            compare_values(actual[key], expected[key], f"{where}.{key}")
    else:
        raise RuntimeError(f"{where}: unsupported expected value")


def text_number(text: str, pattern: str, expected: float, label: str) -> None:
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError(f"Missing numerical observation: {label}")
    compare_values(float(match.group(1)), expected, label)


def make_fixture(repo: Path, out: Path, name: str) -> Path:
    spec = MANIFEST["fixtures"][name]
    dest = out / "fixtures" / name / "project"
    dest.mkdir(parents=True)
    if spec["source_count"] != len(spec["sources"]):
        raise RuntimeError(f"{name}: source count does not match its manifest")
    for item in spec["sources"]:
        source = checked_path(repo, item["path"])
        check_file(source, item["sha256"], f"{name} source")
        relative = Path(item["path"])
        if not relative.parts or relative.parts[0] != "app":
            raise RuntimeError(f"{name}: source is not below app/: {relative}")
        target = checked_path(dest, str(Path(*relative.parts[1:])))
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        check_file(target, item["sha256"], f"{name} copied source")
    settings = checked_path(HERE, spec["settings"])
    check_file(settings, spec["settings_sha256"], f"{name} settings")
    shutil.copyfile(settings, dest / "project.godot")
    if name == "blimp-session":
        stub = MANIFEST["stub"]
        source = checked_path(HERE, stub["path"])
        check_file(source, stub["sha256"], "collision stub")
        target = checked_path(dest, stub["destination"])
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    return dest


def install_probe(project: Path, original: str, installed_name: str) -> None:
    spec = MANIFEST["probes"][original]
    source = checked_path(HERE, spec["path"])
    check_file(source, spec["sha256"], "probe")
    shutil.copyfile(source, project / installed_name)


def run_checked(repo: Path, godot: Path, out: Path, project: Path, profile: Path,
                label: str, args: list[str], marker: str = "", expected_error=False) -> tuple[dict, str]:
    checks = out / "checked"
    checks.mkdir(exist_ok=True)
    before = set(checks.iterdir())
    command = [sys.executable, str(repo / MANIFEST["checked_runner"]["path"]),
               "--out-dir", str(checks), "--label", label, "--timeout", "180"]
    if marker:
        command += ["--require-text", marker]
    command += ["--", str(godot), "--headless", "--path", str(project), "--audio-driver", "Dummy"] + args
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"  # Never create Python caches inside the checkout.
    for var, leaf in [("XDG_DATA_HOME", "data"), ("XDG_CONFIG_HOME", "config"), ("XDG_CACHE_HOME", "cache")]:
        env[var] = str(profile / leaf)
        (profile / leaf).mkdir(parents=True, exist_ok=True)
    print(f"\nRunning {label}" + (" (expected checked failure)" if expected_error else ""), flush=True)
    result = subprocess.run(command, cwd=repo, env=env, check=False)
    created = list(set(checks.iterdir()) - before)
    if len(created) != 1 or not (created[0] / "report.json").is_file():
        raise RuntimeError(f"{label}: checked runner did not produce one report (exit {result.returncode})")
    report = json.loads((created[0] / "report.json").read_text(encoding="utf-8"))
    log = (created[0] / "engine.log").read_text(encoding="utf-8")
    if expected_error:
        expected = (not report.get("ok") and report.get("complete") and report.get("process_exit") == 0
                    and report.get("reason") == "engine_error" and report["counts"]["error"] == 2
                    and report["counts"]["warning"] == 0 and not report.get("missing_required_text")
                    and log.count("ERROR: String formatting error: unsupported format character.") == 2
                    and "JET_SOURCE:" in log and "with a %s m/s efflux" in log)
        if not expected or result.returncode == 0:
            raise RuntimeError(f"{label}: did not reproduce the expected engine failure: {created[0]}")
    elif result.returncode != 0 or not report.get("ok") or not report.get("complete") \
            or report["counts"] != {"error": 0, "warning": 0}:
        raise RuntimeError(f"{label}: checked run did not pass without diagnostics: {created[0]}")
    return report, log


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path, help="Checkout of the pinned OpenRC source")
    parser.add_argument("--godot", required=True, type=Path, help="Pinned Linux x86-64 Godot binary")
    parser.add_argument("--out", type=Path, help="New output directory; defaults to a new temporary directory")
    args = parser.parse_args()
    repo, godot = args.repo.resolve(), args.godot.resolve()
    if args.out:
        out = args.out.resolve()
        if out.is_relative_to(repo):
            raise RuntimeError("--out must be outside the checkout")
        out.mkdir(parents=True, exist_ok=False)
    else:
        out = Path(tempfile.mkdtemp(prefix="openrc-audit-reproduction-"))
    print(f"Disposable output: {out}", flush=True)
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], check=True,
                          capture_output=True, text=True).stdout.strip()
    if head != MANIFEST["commit"]:
        raise RuntimeError(f"Wrong checkout HEAD: {head}")
    check_file(repo / MANIFEST["checked_runner"]["path"], MANIFEST["checked_runner"]["sha256"], "checked runner")
    for item in MANIFEST["checked_runner"]["testqueue_python_sources"]:
        check_file(checked_path(repo, item["path"]), item["sha256"], "checked runner dependency")
    check_file(godot, MANIFEST["linux_x86_64_engine_sha256"], "pinned Linux Godot")
    version = subprocess.run([str(godot), "--version"], check=True, capture_output=True, text=True).stdout.strip()
    if MANIFEST["engine_version"] not in version:
        raise RuntimeError(f"Unexpected engine version: {version}")
    projects = {name: make_fixture(repo, out, name) for name in MANIFEST["fixtures"]}
    for fixture, probe, dest in [
        ("creator", "multi_prop_probe.gd", "multi_prop_probe.gd"),
        ("creator", "phoenix_jet_probe.gd", "probe_jet.gd"),
        ("creator", "phoenix_registry_probe.gd", "probe_derived_prop.gd"),
        ("biplane", "biplane_probe.gd", "biplane_probe.gd"),
        ("blimp-component", "blimp_component_probe.gd", "probe.gd"),
        ("blimp-session", "blimp_depletion_probe.gd", "depletion_probe.gd"),
        ("blimp-session", "blimp_refusal_probe.gd", "probe.gd"),
    ]:
        install_probe(projects[fixture], probe, dest)
    summary = {"format": "openrc-audit-reproduction-result v1", "source_commit": head,
               "engine_version": version, "engine_sha256": digest(godot), "checks": {}}
    for name, project in projects.items():
        report, _ = run_checked(repo, godot, out, project, out / "profiles" / name,
                                f"import-{name}", ["--import"])
        summary["checks"][f"import-{name}"] = report["reason"]
    cases = [
        ("multi-prop", "creator", "multi_prop_probe.gd", "MULTI_PROP_PROBE_COMPLETE", False),
        ("biplane", "biplane", "biplane_probe.gd", "BIPLANE_PROBE_COMPLETE", False),
        ("blimp-component", "blimp-component", "probe.gd", "audit_probe_complete", False),
        ("blimp-depletion", "blimp-session", "depletion_probe.gd", "audit_depletion_complete", False),
        ("blimp-prepare-refusal", "blimp-session", "probe.gd", "audit_session_complete", False),
        ("phoenix-jet", "creator", "probe_jet.gd", "RESULT valid=true derived=true before=0 after=2 repeat=2", True),
        ("phoenix-registry", "creator", "probe_derived_prop.gd", "RESULT valid=true derived=true before=0 after=200 repeat=200", False),
    ]
    logs = {}
    for label, fixture, probe, marker, expect_error in cases:
        report, log = run_checked(repo, godot, out, projects[fixture], out / "profiles" / fixture,
                                  label, ["--script", "res://" + probe], marker, expect_error)
        logs[label] = log
        summary["checks"][label] = "expected engine_error" if expect_error else report["reason"]
    for fixture, filename in [("creator", "multi-prop-result.json"), ("biplane", "biplane-result.json")]:
        actual = json.loads((projects[fixture].parent / filename).read_text(encoding="utf-8"))
        expected = json.loads((HERE / "results" / filename).read_text(encoding="utf-8"))
        compare_values(actual, expected, filename)
    text_number(logs["blimp-component"], r"fin_total u=-3\.0 power_W=([-+0-9.eE]+)", 0.07740875434187, "reverse fin power")
    text_number(logs["blimp-component"], r"fin_total u=3\.0 power_W=([-+0-9.eE]+)", -0.3742558831096, "forward fin power")
    text_number(logs["blimp-depletion"], r"cross tick=1103 soc=([-+0-9.eE]+)", -0.00000281805446, "depletion crossing")
    text_number(logs["blimp-depletion"], r"after tick=1583 soc=[-+0-9.eE]+ current_A=([-+0-9.eE]+)", 0.46572584622845, "post-depletion current")
    if "restore=true replay_body_exact=true replay_cont_exact=true ticks=480" not in logs["blimp-depletion"]:
        raise RuntimeError("depletion continuation did not replay exactly")
    refusal = logs["blimp-prepare-refusal"]
    if any(x not in refusal for x in ["after result=false", "checkpoint=false", "paused=true", "resetting_delta=1", "fault_count=1"]):
        raise RuntimeError("prepare-refusal observation differs")
    summary["numerical_comparison"] = "matches retained observations within 1e-10 relative / 1e-12 absolute tolerance"
    (out / "reproduction-summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"\nObservations reproduced; expected jet checked failure retained. Results: {out}", flush=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as exc:
        print(f"Reproduction failed: {exc}", file=sys.stderr)
        sys.exit(1)
