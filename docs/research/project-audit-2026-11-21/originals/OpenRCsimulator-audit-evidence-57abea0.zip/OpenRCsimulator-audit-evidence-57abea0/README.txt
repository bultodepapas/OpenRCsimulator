OPENRC SIMULATOR — SELECTED AUDIT EVIDENCE

Scope and identity
------------------
These observations use source commit 57abea025f62b20233ca281d58d2acbee4ab8b8e
and the official Linux x86-64 Godot 4.8.beta2.official.cafc17a19 executable,
SHA-256 34d0599a1f17acc76583610969878065d1b1701615af77271e32201351b9c564.
They were collected on Linux in isolated, headless, Dummy-audio fixtures. They
are software observations, not full-flight, target-GPU, FPS, native package,
physical-controller, acoustic or physical-aircraft validation. See the audit
report for findings, applicability and recommended tests.

Contents
--------
checked/ contains seven original checked-runner report.json and engine.log
pairs, unchanged. Absolute paths and command lines in those historical reports
refer to the original machine and do not purport to be paths on this machine.
The selected pairs are:

  multi-prop                       four synthetic propeller-count cases
  biplane-retry                    independent mono-/biplane comparison
  blimp-component                  stock-data fin forces and altered-cutoff study
  blimp-depletion                  altered-battery live-session continuation
  blimp-prepare-refusal            failed prepare and observed reset/fault state
  phoenix-jet-expected-failure     checked runner rejected two engine errors
  phoenix-registry                 100 distinct synthetic scales; 200 entries

The jet report is deliberately a checked FAILURE (engine_error), although the
Godot process exited zero. It must not be counted as a clean pass. The other
six selected runs had no engine errors or warnings. Earlier invalid or failed
fixture attempts and unrelated repository source files are not included.

results/ includes the two original numeric JSON outputs and the exact-head CI
preflight and job-status evidence supplied by the audit lead. The CI failure is a recurrence
of a previously recorded missing-UID failure class, not a new mathematical
finding. The CI record is a historical remote observation, not a live query.

probes/ contains only audit-authored GDScript probes; fixtures/ contains their
small audit-authored project settings. manifests/fixtures.json specifies exact
SHA-256 identities for the source inputs and checked-runner files. The original
creator and blimp source manifests are preserved for provenance; generated UID
sidecars and import caches are recreated in the disposable fixtures. The
source checkout and Godot executable are not redistributed in this bundle.

The blimp session uses stubs/collision_world.gd in place of the repository's
collision-world script. It is an audit-authored fail-if-used stub. These
session probes supply an empty world and must never call its functions; they
therefore do not test scenery or collision behavior. The component probe uses
the real four source scripts and stock blimp data with no such stub. See the
probe files for all explicit input alterations and constructed conditions.

Reproduction
------------
On a Linux x86-64 host, with Python 3.9+, Git, the pinned checkout and the
exact pinned Godot executable:

  python3 reproduce.py --repo /absolute/path/to/OpenRCsimulator \
    --godot /absolute/path/to/Godot_v4.8-beta2_linux.x86_64 \
    --out /absolute/path/to/a/new/output-directory

The output directory must not already exist and must be outside the checkout;
omit --out to create a fresh temporary directory. The script checks the commit,
engine version and executable hash, verifies every copied source and the checked
runner's dependencies by SHA-256, builds four disposable projects, installs the
original probes and the explicitly disclosed stub, runs imports and checked
probes, and compares the numerical observations. It does not alter the source
checkout. Importing may create new UID files in the disposable projects.

The runner will print the jet's expected formatting errors and report a failed
checked invocation; the overall reproducer succeeds only when that specific
failure is present and all other required observations pass. If the defect has
been fixed, a different source or engine is supplied, or a probe diverges, the
reproducer refuses to present the old observations as reproduced. Reproduction
writes fresh logs and a machine-readable reproduction-summary.json in its
output directory; it does not change the original logs bundled here. On enrolled
or managed shared hosts, follow that host's test-pool admission and ownership
rules; the reproducer does not bypass them.

The retained registry payload byte count is a serialized-data observation, not
measured process RSS, a whole-app leak rate or an FPS estimate. The blimp
battery fixture modifies capacity, initial charge and cutoff; its result is not
a claim about stock-battery flight. No target-hardware benchmark is included.
