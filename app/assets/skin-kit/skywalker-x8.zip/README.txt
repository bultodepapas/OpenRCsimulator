OpenRC — guide.html

English — Create an aircraft skin with AI
guide.html — Create an aircraft skin with AI
In OpenRC: Aircraft → X8 Wing → Choose paint → Create a skin → Save Blender template…. Save skywalker-x8.zip and extract it into a new folder. Open skin guide opens this tutorial offline.

Alternative: edit one image, without Blender
This experimental route uses an image editor or image-generation assistant plus Python 3, without running Blender. In the extracted kit, X8-Paint.png is the exact original color atlas and X8-UV.png shows its UV boundaries. Give the assistant both images and ask it to edit the atlas using the prompt below. A photo of a shark or a rendered airplane is not a usable texture atlas.
Save the result as X8-Paint-edited.png, retaining the original 2048 × 2048 size and layout. Run the included pack_image.py using the command below, or ask an assistant with Python file execution to run it and return the resulting .orskin. Then load that .orskin through the same OpenRC skin menu. The packer creates the aircraft manifest; renaming a PNG does not.
Image generators can move details across UV boundaries or change the atlas layout. The packer checks the file, not the artistic fit. Inspect the paint on the actual X8 from above, below and both sides, including the elevons. If seams or markings do not align, revise the image or use Blender for 3D painting. Simple recoloring and large motifs are easier than exact text or seam-spanning artwork. Keep preview pictures separate from the color atlas.

Español — Crea una skin para tu avión con IA
guide.html — Crea una skin para tu avión con IA
En OpenRC: Aeronaves → Ala X8 → Elegir pintura → Crear una skin → Guardar plantilla de Blender…. Guarda skywalker-x8.zip y descomprímelo en una carpeta nueva. Abrir guía de skins abre este tutorial sin conexión.

Alternativa: edita una imagen sin Blender
Esta opción experimental usa un editor de imágenes o un asistente de generación de imágenes junto con Python 3, sin ejecutar Blender. En el kit descomprimido, X8-Paint.png es el atlas de color original exacto y X8-UV.png muestra sus límites UV. Entrega ambas imágenes al asistente y pídele que edite el atlas con el encargo de abajo. Una foto de un tiburón o un avión renderizado no es un atlas de textura utilizable.
Guarda el resultado como X8-Paint-edited.png, conservando el tamaño y la distribución originales de 2048 × 2048. Ejecuta el pack_image.py incluido con el comando de abajo, o pide a un asistente que pueda ejecutar Python y trabajar con archivos que lo ejecute y te entregue el .orskin resultante. Después carga ese .orskin desde el mismo menú de skins de OpenRC. El empaquetador crea el manifiesto del avión; cambiarle el nombre a un PNG no lo hace.
Los generadores de imágenes pueden mover detalles a través de los límites UV o cambiar la distribución del atlas. El empaquetador comprueba el archivo, no si el diseño encaja visualmente. Inspecciona la pintura en el X8 real desde arriba, abajo y ambos lados, incluidos los elevones. Si las uniones o las marcas no coinciden, corrige la imagen o usa Blender para pintar en 3D. Cambiar colores y usar motivos grandes es más fácil que conseguir texto exacto o arte que cruce uniones. Mantén las imágenes de vista previa separadas del atlas de color.

Deutsch — Eine Flugzeuglackierung mit KI erstellen
guide.html — Eine Flugzeuglackierung mit KI erstellen
In OpenRC: Flugzeug → X8 Wing → Lackierung wählen → Lackierung erstellen → Blender-Vorlage speichern…. Speichere skywalker-x8.zip und entpacke die Datei in einen neuen Ordner. Lackierungsanleitung öffnen öffnet diese Anleitung offline.

Alternative: Ein Bild ohne Blender bearbeiten
Dieser experimentelle Weg nutzt einen Bildeditor oder einen Assistenten zur Bilderzeugung sowie Python 3, ohne Blender auszuführen. Im entpackten Kit ist X8-Paint.png der exakte ursprüngliche Farbatlas; X8-UV.png zeigt dessen UV-Grenzen. Gib dem Assistenten beide Bilder und bitte ihn mit dem folgenden Prompt, den Atlas zu bearbeiten. Ein Foto eines Hais oder ein gerendertes Flugzeug ist kein verwendbarer Texturatlas.
Speichere das Ergebnis als X8-Paint-edited.png und behalte die ursprüngliche Größe von 2048 × 2048 und das Layout bei. Führe das mitgelieferte pack_image.py mit dem folgenden Befehl aus oder bitte einen Assistenten, der Python-Dateien ausführen kann, das Skript auszuführen und die erzeugte .orskin-Datei zurückzugeben. Lade diese .orskin-Datei anschließend über dasselbe OpenRC-Lackierungsmenü. Der Packer erstellt das Flugzeugmanifest; das Umbenennen eines PNGs tut dies nicht.
Bildgeneratoren können Details über UV-Grenzen hinweg verschieben oder das Atlaslayout verändern. Der Packer prüft die Datei, nicht die gestalterische Passung. Prüfe die Lackierung am tatsächlichen X8 von oben, unten und beiden Seiten, einschließlich der Elevons. Wenn Nähte oder Markierungen nicht zusammenpassen, überarbeite das Bild oder nutze Blender zum Malen in 3D. Einfaches Umfärben und große Motive sind leichter als präzise Schrift oder Motive über Nähte hinweg. Bewahre Vorschaubilder getrennt vom Farbatlas auf.

Français — Créez une livrée d'avion avec l'IA
guide.html — Créez une livrée d'avion avec l'IA
Dans OpenRC : Avion → X8 Wing → Choisir une peinture → Créer une livrée → Enregistrer le modèle Blender…. Enregistrez skywalker-x8.zip et extrayez-le dans un nouveau dossier. Ouvrir le guide des livrées ouvre ce tutoriel hors ligne.

Alternative : modifiez une image sans Blender
Cette méthode expérimentale utilise un éditeur d'images ou un assistant de génération d'images avec Python 3, sans exécuter Blender. Dans le kit extrait, X8-Paint.png est l'atlas de couleurs d'origine exact et X8-UV.png montre ses limites UV. Fournissez les deux images à l'assistant et demandez-lui de modifier l'atlas à l'aide du texte ci-dessous. Une photo de requin ou un avion rendu n'est pas un atlas de texture utilisable.
Enregistrez le résultat sous X8-Paint-edited.png, en conservant la taille et la disposition d'origine de 2048 × 2048. Exécutez le pack_image.py fourni avec la commande ci-dessous, ou demandez à un assistant capable d'exécuter Python et de manipuler des fichiers de l'exécuter et de vous fournir le .orskin obtenu. Chargez ensuite ce .orskin depuis le même menu de livrées d'OpenRC. Le script crée le manifeste de l'avion ; renommer un PNG ne le crée pas.
Les générateurs d'images peuvent déplacer des détails au-delà des limites UV ou modifier la disposition de l'atlas. Le script vérifie le fichier, pas l'adéquation visuelle du design. Inspectez la peinture sur le véritable X8 de dessus, de dessous et des deux côtés, élevons compris. Si les raccords ou les marquages ne s'alignent pas, corrigez l'image ou utilisez Blender pour peindre en 3D. Une recoloration et de grands motifs sont plus faciles à réaliser qu'un texte précis ou une illustration traversant des raccords. Conservez les images d'aperçu séparément de l'atlas de couleurs.

Italiano — Crea una livrea per l’aereo con l’IA
guide.html — Crea una livrea per l’aereo con l’IA
In OpenRC: Aerei → X8 Wing → Scegli livrea → Crea una livrea → Salva modello Blender…. Salva skywalker-x8.zip ed estrailo in una nuova cartella. Apri guida alle livree apre questa guida offline.

Alternativa: modifica un’immagine senza Blender
Questo metodo sperimentale usa un editor di immagini o un assistente per la generazione di immagini insieme a Python 3, senza eseguire Blender. Nel kit estratto, X8-Paint.png è l’atlante dei colori originale esatto e X8-UV.png mostra i suoi confini UV. Fornisci entrambe le immagini all’assistente e chiedigli di modificare l’atlante usando il prompt seguente. La foto di uno squalo o il rendering di un aereo non è un atlante di texture utilizzabile.
Salva il risultato come X8-Paint-edited.png, mantenendo le dimensioni originali di 2048 × 2048 e la disposizione. Esegui il pack_image.py incluso con il comando qui sotto, oppure chiedi a un assistente capace di eseguire file Python di eseguirlo e restituire la .orskin risultante. Poi carica la .orskin dallo stesso menu delle livree di OpenRC. Il programma crea il manifest dell’aereo; rinominare un PNG non lo fa.
I generatori di immagini possono spostare i dettagli oltre i confini UV o cambiare la disposizione dell’atlante. Il programma controlla il file, non l’adeguatezza artistica. Esamina la livrea sull’X8 effettivo dall’alto, dal basso e da entrambi i lati, compresi gli elevoni. Se giunture o decorazioni non combaciano, correggi l’immagine o usa Blender per dipingere in 3D. Una semplice ricolorazione e motivi grandi sono più facili di testo preciso o disegni che attraversano le giunture. Tieni le immagini di anteprima separate dall’atlante dei colori.

日本語 — AI で機体の塗装を作る
guide.html — AI で機体の塗装を作る
OpenRC で、機体 → X8 Wing → 塗装を選択 → 塗装を作成 → Blender テンプレートを保存… の順に進みます。skywalker-x8.zip を保存し、新しいフォルダーに展開してください。「塗装ガイドを開く」から、この説明をオフラインで開けます。

別の方法：Blender を使わずに画像を1枚編集
この実験的な方法では、Blender を起動せず、画像エディターまたは画像生成アシスタントと Python 3 を使います。展開したキット内の X8-Paint.png は元のカラーアトラスそのもので、X8-UV.png はその UV 境界を示します。両方の画像をアシスタントに渡し、下のプロンプトでアトラスの編集を依頼してください。サメの写真や飛行機のレンダリング画像は、使用できるテクスチャアトラスではありません。
元の 2048 × 2048 のサイズと配置を保ったまま、結果を X8-Paint-edited.png として保存します。下のコマンドで同梱の pack_image.py を実行するか、Python ファイルを実行できるアシスタントに実行を依頼し、生成された .orskin を受け取ってください。その後、同じ OpenRC の塗装メニューから .orskin を読み込みます。パッカーが機体のマニフェストを作成します。PNG の名前を変えるだけでは作成されません。
画像生成ツールは UV 境界を越えて細部を移動したり、アトラスの配置を変えたりすることがあります。パッカーが検査するのはファイルであり、絵柄が機体に合っているかどうかではありません。実際の X8 の上面、下面、両側面を、エレボンも含めて確認してください。継ぎ目や模様が合わない場合は画像を修正するか、Blender で 3D ペイントしてください。単純な色変更や大きな模様は、正確な文字や継ぎ目をまたぐ絵柄より作りやすくなります。プレビュー画像はカラーアトラスと分けて保存してください。

Português (Brasil) — Crie uma pintura para seu avião com IA
guide.html — Crie uma pintura para seu avião com IA
No OpenRC: Aeronave → X8 Wing → Escolher pintura → Criar uma pintura → Salvar modelo do Blender…. Salve skywalker-x8.zip e extraia-o em uma nova pasta. Abrir guia de pintura abre este tutorial sem conexão.

Alternativa: edite uma imagem sem o Blender
Esta opção experimental usa um editor de imagens ou um assistente de geração de imagens junto com Python 3, sem executar o Blender. No kit extraído, X8-Paint.png é o atlas de cor original exato e X8-UV.png mostra seus limites UV. Forneça as duas imagens ao assistente e peça que edite o atlas usando o pedido abaixo. Uma foto de tubarão ou uma aeronave renderizada não é um atlas de textura utilizável.
Salve o resultado como X8-Paint-edited.png, mantendo o tamanho e a disposição originais de 2048 × 2048. Execute o pack_image.py incluído usando o comando abaixo, ou peça a um assistente capaz de executar Python e trabalhar com arquivos que o execute e devolva o .orskin resultante. Depois carregue esse .orskin pelo mesmo menu de pinturas do OpenRC. O empacotador cria o manifesto da aeronave; renomear um PNG não o cria.
Geradores de imagens podem mover detalhes para além dos limites UV ou alterar a disposição do atlas. O empacotador verifica o arquivo, não se o design se encaixa visualmente. Inspecione a pintura no X8 real por cima, por baixo e pelos dois lados, incluindo os elevons. Se as emendas ou marcações não se alinharem, revise a imagem ou use o Blender para pintar em 3D. Recolorir e usar motivos grandes é mais fácil do que obter texto exato ou arte que atravesse emendas. Mantenha as imagens de prévia separadas do atlas de cor.

Русский — Создайте окраску самолёта с помощью ИИ
guide.html — Создайте окраску самолёта с помощью ИИ
В OpenRC: Самолёт → X8 Wing → Выбрать окраску → Создать окраску → Сохранить шаблон Blender…. Сохраните skywalker-x8.zip и распакуйте его в новую папку. Кнопка «Открыть руководство по окраске» открывает это руководство без подключения к сети.

Другой способ: изменить одно изображение без Blender
Этот экспериментальный способ использует редактор изображений или ассистента для генерации изображений и Python 3, без запуска Blender. В распакованном комплекте X8-Paint.png — точный исходный атлас цветов, а X8-UV.png показывает его UV-границы. Передайте ассистенту оба изображения и попросите изменить атлас с помощью промпта ниже. Фотография акулы или рендер самолёта не является пригодным атласом текстур.
Сохраните результат как X8-Paint-edited.png, сохранив исходный размер 2048 × 2048 и расположение элементов. Запустите входящий в комплект pack_image.py приведённой ниже командой или попросите ассистента, который может выполнять файлы Python, запустить его и вернуть полученный .orskin. Затем загрузите этот .orskin через то же меню окрасок OpenRC. Упаковщик создаёт манифест самолёта; переименование PNG этого не делает.
Генераторы изображений могут переносить детали через UV-границы или изменять расположение элементов атласа. Упаковщик проверяет файл, но не художественное соответствие. Осмотрите окраску на настоящем X8 сверху, снизу и с обеих сторон, включая элевоны. Если швы или рисунки не совпадают, исправьте изображение или используйте Blender для рисования в 3D. Простая перекраска и крупные мотивы проще точного текста или рисунков, проходящих через швы. Храните изображения предпросмотра отдельно от атласа цветов.

简体中文 — 使用 AI 创建飞机涂装
guide.html — 使用 AI 创建飞机涂装
在 OpenRC 中依次打开：飞机 → X8 Wing → 选择涂装 → 创建涂装 → 保存 Blender 模板…。保存 skywalker-x8.zip 并解压到一个新文件夹。选择“打开涂装指南”可离线打开本教程。

另一种方法：无需 Blender，只编辑一张图片
这条实验性流程使用图片编辑器或图片生成助手，并通过 Python 3 处理文件，无需运行 Blender。在解压后的套件中，X8-Paint.png 是完全对应原始模型的颜色图集，X8-UV.png 显示其 UV 边界。将两张图片都交给助手，并用下方提示词请它编辑图集。鲨鱼照片或飞机渲染图不能作为可用的纹理图集。
将结果保存为 X8-Paint-edited.png，保持原始的 2048 × 2048 尺寸和布局。使用下方命令运行套件中的 pack_image.py，或请能执行 Python 文件的助手运行它并返回生成的 .orskin 文件。然后通过同一个 OpenRC 涂装菜单加载该 .orskin。打包工具会创建飞机清单；仅将 PNG 重命名无法做到这一点。
图片生成工具可能把细节移过 UV 边界，或改变图集布局。打包工具只检查文件，不检查图案是否贴合模型。请在实际的 X8 模型上从上方、下方和两侧检查涂装，也要检查升降副翼。如果接缝或图案无法对齐，请修改图片，或使用 Blender 进行 3D 绘制。简单改色和大图案比精确文字或跨接缝图案更容易完成。请将预览图片与颜色图集分开保存。

Python 3:
python pack_image.py X8-Paint-edited.png --output my-design.orskin --label "My design"
