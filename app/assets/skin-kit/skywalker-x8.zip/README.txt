OpenRC Skywalker X8 skin starter

1. Extract this ZIP and open Skywalker-X8.blend in Blender 5.2.2.
2. Paint the existing x8_livery Base Color image in Texture Paint, or change
   a material's Principled Base Color. Keep the model, UVs and slots unchanged.
3. Save your .blend. Pack external images with File > External Data > Pack
   Resources to keep them with your project.
4. Switch to Scripting. In the Text Editor select Export OpenRC Skin.py and
   click Run Script. Choose a filename ending in .orskin and save it. The
   filename becomes the name shown in OpenRC.
5. In OpenRC, import the .orskin from the aircraft's skin controls.

Open guide.html for the complete offline tutorial and a reusable AI prompt.

Only Base Color and a directly connected sRGB Image Texture are exported.
Bake procedural or mixed Base Color nodes to a single image before export.
Other shader channels, geometry and transparency settings come from the
original aircraft. This package is not a 3D model or a flight-physics change.

For noninteractive Blender, run:
  blender --background Skywalker-X8.blend --python "Export OpenRC Skin.py" --
    --output my-design.orskin --label "My design"
(Use one command line; the line break above is for readability.)
