OpenRC — guide.html

English — Create an aircraft skin with AI
guide.html — Create an aircraft skin with AI
In OpenRC, select the aircraft, choose its paint, open Create a skin and save the kit ZIP. Extract it into a new folder and keep an untouched copy. Open skin guide opens this tutorial offline.

Edit the paint images without Blender
Use an image editor or image-editing assistant and Python 3. Give it kit.json if supported, the selected aircraft name, each supplied paint reference such as Paint-01.png you want to edit, its matching UV-01.png-style boundary reference and any design references. Numbered pairs belong to the same paint group; some aircraft have several. A subject photo or rendered aircraft is not an atlas. Extra 300S, P-51D Mustang and Turbo Lumber Evolution use a neutral six-view reference, not the stock paint. Packaging it unchanged will give the aircraft a neutral appearance. Some regions overlap, so inspect the painted model and adjust motifs as needed.
Save each edited PNG over the corresponding Paint-NN.png in the working copy, keeping unchanged groups in place. Run the command below in that folder, or ask an assistant with Python file access to run pack_image.py and provide the .orskin. Load that package in OpenRC. Keep the original canvas size when possible for detail; other supported sizes are not automatically rejected just for differing from the original.
Retain the original aspect ratio and layout even if the output size changes. Each side may be at most 4096 pixels; all packaged textures together may contain at most 16,777,216 pixels, each PNG at most 16 MiB, and the .orskin at most 32 MiB. The packer checks files, not artistic fit. Inspect the model above, below and from both sides, including moving surfaces or rotors. Repair seams, asymmetric bands or misplaced markings in the images, or use 3D painting for precise corrections.

Español — Crea una skin para tu aeronave con IA
guide.html — Crea una skin para tu aeronave con IA
En OpenRC, selecciona la aeronave, elige pintura, abre Crear una skin y guarda el ZIP del kit. Descomprímelo en una carpeta nueva y conserva una copia sin modificar. Abrir guía de skins abre este tutorial sin conexión.

Edita las imágenes de pintura sin Blender
Usa un editor o asistente de imágenes y Python 3. Proporciona kit.json si lo admite, el nombre de la aeronave seleccionada, cada referencia de pintura suministrada, como Paint-01.png, que quieras editar, su referencia de límites UV-01.png correspondiente y las referencias del diseño. Los pares numerados pertenecen al mismo grupo; algunas aeronaves tienen varios. Una foto del tema o una aeronave renderizada no es un atlas. Extra 300S, P-51D Mustang y Turbo Lumber Evolution usan una referencia neutra de seis vistas, no la pintura original. Si la empaquetas sin cambios, la aeronave tendrá un aspecto neutro. Algunas regiones se superponen: inspecciona el modelo pintado y ajusta los motivos si hace falta.
Guarda cada PNG editado sobre el Paint-NN.png correspondiente en la copia de trabajo y deja en su lugar los grupos sin cambios. Ejecuta el comando siguiente en esa carpeta o pide a un asistente con acceso a archivos y Python que ejecute pack_image.py y entregue el .orskin. Carga ese paquete en OpenRC. Conserva las dimensiones originales cuando puedas para mantener el detalle; otras dimensiones admitidas no se rechazan automáticamente por ser distintas.
Conserva la proporción y la distribución originales aunque cambie el tamaño. Cada lado admite hasta 4096 píxeles; todas las texturas empaquetadas suman como máximo 16,777,216 píxeles, cada PNG hasta 16 MiB y el .orskin hasta 32 MiB. El empaquetador comprueba archivos, no el ajuste visual. Inspecciona el modelo desde arriba, abajo y ambos lados, incluidas las superficies móviles o los rotores. Corrige uniones, bandas asimétricas o marcas mal ubicadas en las imágenes, o usa pintura 3D para ajustes precisos.

Deutsch — Eine Lackierung für ein Fluggerät mit KI erstellen
guide.html — Eine Lackierung für ein Fluggerät mit KI erstellen
Wähle in OpenRC das Fluggerät und seine Lackierung, öffne Lackierung erstellen und speichere das Kit als ZIP. Entpacke es in einen neuen Ordner und bewahre eine unveränderte Kopie auf. Lackierungsanleitung öffnen zeigt diese Anleitung offline.

Lackierungsbilder ohne Blender bearbeiten
Nutze einen Bildeditor oder Bildassistenten und Python 3. Gib ihm, sofern unterstützt, kit.json, den Namen des gewählten Fluggeräts, jede zu bearbeitende mitgelieferte Lackierungsreferenz wie Paint-01.png, die jeweils zugehörige UV-Grenzreferenz wie UV-01.png und deine Designreferenzen. Nummerierte Paare gehören zur selben Gruppe; manche Fluggeräte haben mehrere. Ein Motivfoto oder gerendertes Fluggerät ist kein Atlas. Extra 300S, P-51D Mustang und Turbo Lumber Evolution verwenden eine neutrale Referenz mit sechs Ansichten, nicht die Originallackierung. Unverändert verpackt erhält das Fluggerät ein neutrales Aussehen. Einige Bereiche überlappen sich; prüfe das lackierte Modell und passe Motive bei Bedarf an.
Speichere jedes bearbeitete PNG in der Arbeitskopie über dem zugehörigen Paint-NN.png und lasse unveränderte Gruppen stehen. Führe den folgenden Befehl in diesem Ordner aus oder bitte einen Assistenten mit Datei- und Python-Zugriff, pack_image.py auszuführen und die .orskin-Datei bereitzustellen. Lade das Paket in OpenRC. Behalte nach Möglichkeit die ursprünglichen Abmessungen für Details; andere unterstützte Größen werden nicht allein deshalb abgelehnt.
Behalte Seitenverhältnis und Layout bei, auch wenn sich die Größe ändert. Jede Seite darf höchstens 4096 Pixel haben; alle verpackten Texturen zusammen höchstens 16.777.216 Pixel, jedes PNG höchstens 16 MiB und die .orskin-Datei höchstens 32 MiB. Der Packer prüft Dateien, nicht die visuelle Passung. Prüfe das Modell von oben, unten und beiden Seiten samt beweglicher Flächen oder Rotoren. Korrigiere Nähte, asymmetrische Streifen und verschobene Markierungen in den Bildern oder nutze 3D-Malerei für genaue Korrekturen.

Français — Créez une livrée d'appareil avec l'IA
guide.html — Créez une livrée d'appareil avec l'IA
Dans OpenRC, choisissez l'appareil et sa peinture, ouvrez Créer une livrée et enregistrez le ZIP du kit. Extrayez-le dans un nouveau dossier et conservez une copie intacte. Ouvrir le guide affiche ce tutoriel hors ligne.

Modifiez les images de peinture sans Blender
Utilisez un éditeur ou assistant d'images et Python 3. Fournissez-lui kit.json si possible, le nom de l'appareil choisi, chaque référence de peinture fournie à modifier, comme Paint-01.png, sa référence de frontières UV correspondante comme UV-01.png et vos références de création. Chaque paire numérotée forme un groupe ; certains appareils en ont plusieurs. Une photo du sujet ou un rendu d'appareil n'est pas un atlas. Extra 300S, P-51D Mustang et Turbo Lumber Evolution utilisent une référence neutre à six vues, et non la peinture d'origine. L'empaqueter sans modification donnera à l'appareil une apparence neutre. Certaines régions se chevauchent ; inspectez le modèle peint et ajustez les motifs si nécessaire.
Enregistrez chaque PNG modifié sur le Paint-NN.png correspondant dans la copie de travail et laissez les groupes inchangés en place. Exécutez la commande ci-dessous dans ce dossier ou demandez à un assistant ayant accès aux fichiers et à Python d'exécuter pack_image.py et de fournir le .orskin. Chargez ce paquet dans OpenRC. Conservez les dimensions d'origine si possible pour les détails ; d'autres dimensions prises en charge ne sont pas automatiquement rejetées parce qu'elles diffèrent.
Conservez les proportions et la disposition d'origine même si la taille change. Chaque côté peut atteindre 4096 pixels ; toutes les textures empaquetées totalisent au maximum 16,777,216 pixels, chaque PNG 16 MiB et le .orskin 32 MiB. Le paquetage vérifie les fichiers, pas l'ajustement visuel. Examinez le modèle de dessus, dessous et des deux côtés, y compris les surfaces mobiles ou rotors. Corrigez les raccords, bandes asymétriques ou marques déplacées dans les images, ou utilisez la peinture 3D pour les corrections précises.

Italiano — Crea una livrea per il velivolo con l’IA
guide.html — Crea una livrea per il velivolo con l’IA
In OpenRC seleziona il velivolo e la sua livrea, apri Crea una livrea e salva lo ZIP del kit. Estrailo in una nuova cartella e conserva una copia intatta. Apri guida livree apre questo tutorial offline.

Modifica le immagini di pittura senza Blender
Usa un editor o assistente di immagini e Python 3. Fornisci, se supportato, kit.json, il nome del velivolo scelto, ogni riferimento di pittura fornito da modificare, come Paint-01.png, il riferimento ai confini UV corrispondente come UV-01.png e i riferimenti del progetto. Le coppie numerate formano gruppi; alcuni velivoli ne hanno più di uno. Una foto del soggetto o un velivolo renderizzato non è un atlante. Extra 300S, P-51D Mustang e Turbo Lumber Evolution usano un riferimento neutro a sei viste, non la livrea originale. Pacchettizzarlo senza modifiche darà al velivolo un aspetto neutro. Alcune aree si sovrappongono: controlla il modello dipinto e adatta i motivi se necessario.
Salva ogni PNG modificato sul corrispondente Paint-NN.png nella copia di lavoro e lascia al loro posto i gruppi invariati. Esegui il comando seguente in quella cartella oppure chiedi a un assistente con accesso ai file e a Python di eseguire pack_image.py e fornire il .orskin. Carica il pacchetto in OpenRC. Mantieni le dimensioni originali quando possibile per conservare i dettagli; altre dimensioni supportate non vengono rifiutate automaticamente solo perché diverse.
Mantieni proporzioni e disposizione originali anche se cambia la dimensione. Ogni lato può arrivare a 4096 pixel; tutte le texture incluse possono raggiungere in totale 16.777.216 pixel, ogni PNG 16 MiB e il .orskin 32 MiB. Il pacchettizzatore controlla i file, non l'adattamento visivo. Controlla il modello da sopra, sotto e da entrambi i lati, incluse superfici mobili o rotori. Correggi giunture, bande asimmetriche o segni fuori posto nelle immagini, oppure usa la pittura 3D per correzioni precise.

日本語 — AI で機体の塗装を作る
guide.html — AI で機体の塗装を作る
OpenRC で機体と塗装を選び、塗装の作成を開いてキットの ZIP を保存します。新しいフォルダーに展開し、未編集のコピーを保管してください。塗装ガイドはオフラインで開けます。

Blender を使わず塗装画像を編集する
画像エディターまたは画像編集アシスタントと Python 3 を使います。対応していれば kit.json、選択した機体名、編集する Paint-01.png などの付属塗装参考画像、対応する UV-01.png などの UV 境界参考画像、デザイン参考資料を渡してください。同じ番号が一組で、複数組ある機体もあります。題材の写真や機体のレンダリング画像はアトラスではありません。 Extra 300S、P-51D Mustang、Turbo Lumber Evolution には標準塗装ではなく中立的な六面図の参考画像が使われています。無編集のままパッケージ化すると、機体は中立的な外観になります。一部の領域は重なるため、塗装したモデルを確認し、必要に応じて模様を調整してください。
編集した PNG を作業用コピーの対応する Paint-NN.png に上書き保存し、変更しない組はそのまま残します。そのフォルダーで以下のコマンドを実行するか、ファイルと Python を扱えるアシスタントに pack_image.py の実行と .orskin の提供を依頼します。パッケージを OpenRC に読み込んでください。細部を保つため可能なら元の寸法を維持しますが、対応する別の寸法が元と違うだけで自動的に拒否されるわけではありません。
出力サイズが変わっても元の縦横比と配置を保ってください。各辺は最大 4096 ピクセル、パッケージ内の全テクスチャ合計は最大 16,777,216 ピクセル、各 PNG は最大 16 MiB、.orskin は最大 32 MiB です。パッカーはファイルを検査し、見た目の適合性は検査しません。上、下、左右からモデルを確認し、可動翼面やローターも見てください。継ぎ目、非対称な帯、ずれた模様を画像上で直すか、正確な修正には 3D ペイントを使います。

Português (Brasil) — Crie uma pintura para sua aeronave com IA
guide.html — Crie uma pintura para sua aeronave com IA
No OpenRC, selecione a aeronave, escolha a pintura, abra Criar uma pintura e salve o ZIP do kit. Extraia-o em uma nova pasta e guarde uma cópia sem alterações. Abrir guia de pintura abre este tutorial sem conexão.

Edite as imagens de pintura sem Blender
Use um editor ou assistente de imagens e Python 3. Forneça kit.json se houver suporte, o nome da aeronave selecionada, cada referência de pintura fornecida, como Paint-01.png, que deseja editar, sua referência de limites UV-01.png correspondente e as referências de design. Os pares numerados pertencem ao mesmo grupo; algumas aeronaves têm vários. Uma foto do tema ou aeronave renderizada não é um atlas. Extra 300S, P-51D Mustang e Turbo Lumber Evolution usam uma referência neutra de seis vistas, não a pintura original. Empacotá-la sem alterações dará à aeronave uma aparência neutra. Algumas regiões se sobrepõem; inspecione o modelo pintado e ajuste os motivos quando necessário.
Salve cada PNG editado sobre o Paint-NN.png correspondente na cópia de trabalho e mantenha os grupos inalterados no lugar. Execute o comando abaixo nessa pasta ou peça a um assistente com acesso a arquivos e Python para executar pack_image.py e fornecer o .orskin. Carregue esse pacote no OpenRC. Preserve as dimensões originais quando possível para manter detalhes; outras dimensões compatíveis não são automaticamente rejeitadas por serem diferentes.
Mantenha a proporção e a disposição originais mesmo se o tamanho mudar. Cada lado pode ter até 4096 pixels; todas as texturas empacotadas somam no máximo 16,777,216 pixels, cada PNG até 16 MiB e o .orskin até 32 MiB. O empacotador verifica arquivos, não o ajuste visual. Inspecione o modelo por cima, por baixo e dos dois lados, incluindo superfícies móveis ou rotores. Corrija emendas, faixas assimétricas ou marcas deslocadas nas imagens, ou use pintura 3D para ajustes precisos.

Русский — Создайте окраску летательного аппарата с помощью ИИ
guide.html — Создайте окраску летательного аппарата с помощью ИИ
В OpenRC выберите воздушное судно и окраску, откройте создание окраски и сохраните ZIP комплекта. Распакуйте его в новую папку и сохраните неизменённую копию. Кнопка открытия руководства показывает этот учебник без сети.

Измените изображения окраски без Blender
Используйте редактор или ассистента изображений и Python 3. Передайте ему, если поддерживается, kit.json, название выбранного воздушного судна, каждый предоставленный образец окраски вида Paint-01.png, который нужно изменить, соответствующий ориентир UV-границ вида UV-01.png и референсы дизайна. Пронумерованные пары образуют группы; у некоторых моделей их несколько. Фото объекта или рендер воздушного судна не является атласом. Extra 300S, P-51D Mustang и Turbo Lumber Evolution используют нейтральный образец с шестью видами, а не исходную окраску. Если упаковать его без изменений, модель приобретёт нейтральный вид. Некоторые области перекрываются: осмотрите окрашенную модель и при необходимости поправьте рисунки.
Сохраните каждый изменённый PNG поверх соответствующего Paint-NN.png в рабочей копии; неизменённые группы оставьте на месте. Выполните команду ниже в этой папке или попросите ассистента с доступом к файлам и Python запустить pack_image.py и предоставить .orskin. Загрузите пакет в OpenRC. По возможности сохраняйте исходные размеры ради деталей; другие поддерживаемые размеры не отклоняются автоматически только из-за отличия.
Сохраняйте исходные пропорции и расположение даже при изменении размера. Каждая сторона — не более 4096 пикселей; все упакованные текстуры вместе — не более 16 777 216 пикселей, каждый PNG — 16 MiB, .orskin — 32 MiB. Упаковщик проверяет файлы, а не визуальное соответствие. Осмотрите модель сверху, снизу и с обеих сторон, включая подвижные поверхности и роторы. Исправьте швы, асимметричные полосы или смещённые знаки в изображениях либо используйте 3D-рисование для точных правок.

简体中文 — 使用 AI 创建航空器涂装
guide.html — 使用 AI 创建航空器涂装
在 OpenRC 中选择航空器和涂装，打开“创建涂装”并保存套件 ZIP。解压到新文件夹，并保留一份未修改的副本。“打开涂装指南”可离线显示本教程。

无需 Blender，编辑涂装图片
使用图片编辑器或图片编辑助手以及 Python 3。若助手支持，请提供 kit.json、所选航空器名称、每张要编辑的 Paint-01.png 等随附涂装参考图、对应的 UV-01.png 类边界参考图以及设计参考图。相同编号是一组；有些航空器有多组。主题照片或航空器渲染图不是纹理图集。 Extra 300S、P-51D Mustang 和 Turbo Lumber Evolution 使用中性的六视图参考图，而非原厂涂装。不加修改地打包会让航空器呈现中性外观。部分区域会重叠，请检查涂装后的模型并按需调整图案。
在工作副本中将每张编辑后的 PNG 保存覆盖对应的 Paint-NN.png，未更改的组保留原位。在该文件夹中运行下方命令，或请能访问文件和运行 Python 的助手执行 pack_image.py 并提供 .orskin。将该包加载到 OpenRC。尽可能保持原始尺寸以保留细节；其他受支持的尺寸不会仅因不同于原尺寸而自动被拒绝。
即使输出尺寸改变，也要保持原始宽高比和布局。每边最多 4096 像素，包中所有纹理合计最多 16,777,216 像素，每张 PNG 最多 16 MiB，.orskin 最多 32 MiB。打包工具检查文件，不检查视觉贴合度。请从上、下和两侧检查模型，包括活动翼面或旋翼。在图片中修正接缝、不对称色带或错位标记；需要精确修正时可使用 3D 绘制。

Python 3:
python pack_image.py --output my-design.orskin --label "My design"
